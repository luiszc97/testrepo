let pIntFileSeqno = Ax.context.variable.FILE_SEQNO;

let mRsOutput = new Ax.rs.Reader().memory(options => {
	options.setColumnNames([
		'codobr',
		'codcap',
		'codsub1',
		'codsub2',
		'codsub3',
		'codsub4',
		'codsub5',
		'descri',
		'impniv',
		'impele',
		'difimp'
	]);
	options.setColumnTypes([
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.VARCHAR,
		Ax.sql.Types.DOUBLE, 
		Ax.sql.Types.DOUBLE,
		Ax.sql.Types.DOUBLE
	]);
});

let mArrCparParprelFast = Ax.db.executeQuery(`
	<select>
		<columns>
			codobr, codcap, codsub1, codsub2, codsub3, codsub4, codsub5,
			LPAD('',4*(nivel+(CASE WHEN codele IS NOT NULL THEN 1 ELSE 0 END)-1)) || descri descri,
			impniv
		</columns>
		<from table='cpar_parprel_fast' />
		<where>
			file_seqno = ? AND
			codcap != '0' AND
			codele IS NULL
		</where>
		<order>
			codobr, codcap, codsub1, codsub2, codsub3, codsub4, codsub5
		</order>
	</select>
`, pIntFileSeqno);

let mStrSqlCond;

for (let mRow of mArrCparParprelFast) {
	mStrSqlCond = '1=1';

	if (mRow.codsub1 != null) {
		mStrSqlCond = `codsub1 = '${mRow.codsub1}'`;
	}
	if (mRow.codsub2 != null) {
		mStrSqlCond = `codsub2 = '${mRow.codsub2}'`;
	}
	if (mRow.codsub3 != null) {
		mStrSqlCond = `codsub3 = '${mRow.codsub3}'`;
	}
    if (mRow.codsub4 != null) {
		mStrSqlCond = `codsub4 = '${mRow.codsub4}'`;
	}
    if (mRow.codsub5 != null) {
		mStrSqlCond = `codsub5 = '${mRow.codsub5}'`;
	}

    let mDecImpele = Ax.db.executeGet(`
        <select>
            <columns>
                <nvl>SUM(ROUND(rendi*precio,2)), 0</nvl> impele
            </columns>
            <from table='cpar_parprel_fast' />
            <where>
                file_seqno = ? AND
                codobr  = ? AND
                codcap  = ? AND
                ${mStrSqlCond}
            </where>
        </select>
    `, pIntFileSeqno, mRow.codobr, mRow.codcap);

    mRsOutput.rows().add([
        mRow.codobr, 
        mRow.codcap, 
        mRow.codsub1,
        mRow.codsub2, 
        mRow.codsub3,
        mRow.codsub4,
        mRow.codsub5,
        mRow.descri,
        mRow.impniv,
        mDecImpele,
        mRow.impniv - mDecImpele
    ]);
}

return mRsOutput

