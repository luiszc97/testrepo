
	let pIntCabid = Ax.context.variable.CABID;

	let mIntCabid = new Ax.lang.String(pIntCabid);
	let mStrCabchr = mIntCabid.lpad('0', 7);
	let mStrRootpt = '/mnt/factures/dirOut/';

    let mStr1 = mStrCabchr.toString().slice(0, 3);
    let mStr2 = mStrCabchr.toString().slice(3,5);

	let mStrHashpt = `${mStr1}/${mStr2}/`;

	let mIntDigcon;

	switch (pIntCabid) {
		case '299999': 
			mIntDigcon = 9;
		break;

		default:
			let mDouNun1 = 3 * Number(mStrCabchr.toString().slice(0, 1));
			let mDouNun2 = 1 * Number(mStrCabchr.toString().slice(1, 2));
			let mDouNun3 = 3 * Number(mStrCabchr.toString().slice(2, 3));
			let mDouNun4 = 1 * Number(mStrCabchr.toString().slice(3, 4));
			let mDouNun5 = 3 * Number(mStrCabchr.toString().slice(4, 5));
			let mDouNun6 = 1 * Number(mStrCabchr.toString().slice(5, 6));
			let mDouNun7 = 3 * Number(mStrCabchr.toString().slice(6, 7));

			let mDouSum = mDouNun1 + mDouNun2 + mDouNun3 + mDouNun4 +
							mDouNun5 + mDouNun6 + mDouNun7;
			
			mIntDigcon = Math.abs(100 - mDouSum)%10;
		break;
	}

	let mStrNamefl = `${mStrCabchr}${mIntDigcon}.pdf`;
	let mStrFilept = `${mStrRootpt}${mStrHashpt}${mStrNamefl}`;

	let mFolder = new Ax.io.File(mStrFilept);

	//throw new Ax.lang.Exception(mStrFilept);

	/// Creamos el fichero blob
	let ficheroBlob = new Ax.sql.Blob(mStrNamefl);
	ficheroBlob.setContentType("application/pdf");
	ficheroBlob.setContent(mFolder);

	return ficheroBlob;
