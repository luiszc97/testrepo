<script>
    // Variables
    let pIntPerini = Ax.context.variable.PERINI;
    let pIntPerfin = Ax.context.variable.PERFIN;
    let pIntEjerci = Ax.context.variable.EJERCI;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_1`);  

    Ax.db.execute(`
        <select intotemp='@tmp_1'>
            <columns>
                csaldos.placon, csaldos.cuenta, csaldos.dimcode1, csaldos.dimcode2,
                SUM(CASE WHEN csaldos.period = 0
                            THEN csaldos.debe - csaldos.haber
                            ELSE 0
                        END) salape,
                SUM(CASE WHEN csaldos.period BETWEEN 0 AND (CASE WHEN ? = 0
                                                                    THEN 0
                                                                    ELSE ? - 1
                                                                END)
                            THEN csaldos.debe - csaldos.haber
                            ELSE 0
                        END) salant,
                SUM(CASE WHEN csaldos.period BETWEEN ? AND ?
                            THEN csaldos.debe
                            ELSE 0
                        END) perdeb,
                SUM(CASE WHEN csaldos.period BETWEEN ? AND ?
                            THEN csaldos.haber
                            ELSE 0
                        END) perhab,
                SUM(csaldos.debe - csaldos.haber) saldo
            </columns>
            <from table='csaldos' />
            <where>
                csaldos.ejerci = ? AND
                csaldos.period BETWEEN 0 AND ? AND
                ${Ax.context.property.COND}
            </where>
            <group>1,2,3,4</group>
        </select>
    `, pIntPerini, pIntPerini, 
        pIntPerini, pIntPerfin, 
        pIntPerini, pIntPerfin,
        pIntEjerci, pIntPerfin);

    return Ax.db.executeQuery(`
        <select>
            <columns>
                @tmp_1.placon, @tmp_1.cuenta, ccuentas.nombre, @tmp_1.dimcode1, @tmp_1.dimcode2,
                SUM(salape) <alias name='salape' />, SUM(salant) <alias name='salant' />, 
                SUM(perdeb) <alias name='perdeb' />, SUM(perhab) <alias name='perhab' />,
                SUM(perdeb - perhab) <alias name='persal' />, SUM(saldo) <alias name='saldo' />
            </columns>
            <from table='@tmp_1'>
            <join type='left' table='ccuentas'>
                <on>@tmp_1.placon = ccuentas.placon</on>
                <on>@tmp_1.cuenta = ccuentas.codigo</on>
            </join>
            </from>
            <where>
                    (salape != 0 OR
                    salant != 0 OR
                    perdeb != 0 OR
                    perhab != 0)
            </where>
            <group>1,2,3,4,5</group>
        </select> 
    `);   

 </script>
