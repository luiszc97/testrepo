let pDatFecini = Ax.context.variable.FECINI;
let pDatFecfin = Ax.context.variable.FECFIN;
let pStrSqlcond = Ax.context.property.COND;

Ax.db.execute(`
    <table name='@tmp_circest' temp='yes'>
    <column name='usercode' type='char'    size='20' />
    <column name='username' type='varchar' size='60' />
    <column name='numact'   type='integer' />
    <column name='horavg'   type='decimal' size='6,1' />
    <column name='diaavg'   type='decimal' size='6,1' />
    </table>
`);