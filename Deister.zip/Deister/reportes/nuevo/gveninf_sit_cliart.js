<script>
    let pDateFecini = Ax.context.variable.FECINI;
    let pDateFecfin = Ax.context.variable.FECFIN;

    Ax.db.execute(`
        <union type='all' intotemp='@tmp_1'>
            <select>
                <columns>
                    gvenpedh.tercer, codfam, codart,
                    SUM(canped) canped,
                    SUM(icon_get_imploc(0, gdelegac.empcode, gvenpedh.divisa, gvenpedh.fecha, gvenpedh.cambio,
                                        gvenpedl.impnet * (1 + dtogen / 100))) impped,
                    0 canalb, 0 impalb,
                    0 canfac, 0 impfac
                </columns>
                <from table='gvenpedh'>
                    <join table='gvenpedl'>
                        <on>gvenpedh.cabid  = gvenpedl.cabid</on>
                    </join>
                    <join table='gdelegac'>
                        <on>gvenpedh.delega = gdelegac.codigo</on>
                    </join>
                    <join table='garticul'>
                        <on>gvenpedl.codart = garticul.codigo</on>
                    </join>
                </from>
                <where>
                    gvenpedh.empcode ${Ax.context.variable.EMPCODE} AND
                    gvenpedh.tercer ${Ax.context.variable.TERCER}   AND
                    gvenpedh.fecha  BETWEEN ? AND ? AND
                    ${Ax.context.property.COND}
                </where>
                <group>1,2,3</group>
                <having>SUM(canped) != 0</having>
            </select>

            <select>
                <columns>
                    gvenalbh.tercer, codfam, codart,
                    0, 0,
                    SUM(CASE WHEN gvenmovd.abono = 'S'
                            THEN -canmov
                            ELSE canmov
                        END),
                    SUM(icon_get_imploc(0, gdelegac.empcode, gvenalbh.divisa, gvenalbh.fecmov, gvenalbh.cambio,
                                        impnet * (1 + dtogen / 100))),
                    0, 0
                </columns>
                <from table='gvenalbh'>
                    <join table='gvenalbl'>
                        <on>gvenalbh.cabid  = gvenalbl.cabid</on>
                    </join>
                    <join table='gdelegac'>
                        <on>gvenalbh.delega = gdelegac.codigo</on>
                    </join>
                    <join table='garticul'>
                        <on>gvenalbl.codart = garticul.codigo</on>
                    </join>
                    <join table='gvenmovd'>
                        <on>gvenalbh.tipdoc = gvenmovd.codigo</on>
                        <on>gvenmovd.movalb = 'A'</on>
                    </join>
                </from>
                <where>
                    gvenalbh.empcode ${Ax.context.variable.EMPCODE} AND
                    gvenalbh.tercer ${Ax.context.variable.TERCER}   AND
                    gvenalbh.fecmov BETWEEN ? AND ? AND
                    ${Ax.context.property.COND}
                </where>
                <group>1,2,3</group>
            </select>

            <select>
                <columns>
                    gvenfach.tercer, codfam, codart,
                    0, 0,
                    0, 0,
                    SUM(CASE WHEN gvenfacd.abono = 'S'
                            THEN -canfac
                            ELSE canfac
                        END),
                    SUM(icon_get_imploc(0, gdelegac.empcode, gvenfach.divisa, gvenfach.fecha, gvenfach.cambio,
                                        impnet * (1 + dtogen / 100)))
                </columns>
                <from table='gvenfach'>
                    <join table='gvenfacl'>
                        <on>gvenfach.cabid  = gvenfacl.cabid</on>
                    </join>
                    <join table='gdelegac'>
                        <on>gvenfach.delega = gdelegac.codigo</on>
                    </join>
                    <join table='garticul'>
                        <on>gvenfacl.codart = garticul.codigo</on>
                    </join>
                    <join table='gvenfacd'>
                        <on>gvenfach.tipdoc = gvenfacd.codigo</on>
                    </join>
                </from>
                <where>
                    gvenfach.empcode ${Ax.context.variable.EMPCODE} AND
                    gvenfach.tercer ${Ax.context.variable.TERCER}   AND
                    gvenfach.fecha  BETWEEN ? AND ? AND
                    ${Ax.context.property.COND}
                </where>
                <group>1,2,3</group>
            </select>
        </union>
    `, pDateFecini, pDateFecfin, pDateFecini, pDateFecfin, pDateFecini, pDateFecfin);

    Ax.db.execute(`
        <index name='i_@tmp_1' table='@tmp_1' columns='tercer' oracle='no' />
    `);

    Ax.db.execute(`
        <select intotemp='@tmp_2'>
            <columns>
                tercer,
                SUM(CASE WHEN cefectos.clase = 'C'
                        THEN import ELSE -import
                    END) carpen
            </columns>
            <from table='cefectos' />
            <where>
                cefectos.empcode ${Ax.context.variable.EMPCODE} AND
                cefectos.tercer IN (SELECT tercer FROM @tmp_1) AND
                cefectos.caduca != 'S'             AND
                cefectos.fecven BETWEEN ? AND ?
            </where>
            <group>1</group>
        </select>
    `, pDateFecini, pDateFecfin);

    Ax.db.execute(`
        <select intotemp='@tmp_3'>
            <columns>
                DISTINCT tercer, 0 carpen
            </columns>
            <from table='@tmp_1' />
            <where>
                tercer NOT IN (SELECT tercer FROM @tmp_2)
            </where>
        </select>
    `);

    Ax.db.execute(`
        INSERT INTO @tmp_2
        SELECT * FROM @tmp_3
    `);

    Ax.db.execute(`
        <select intotemp='@tmp_4'>
            <columns>
                @tmp_1.tercer, nombre, carpen, @tmp_1.codfam, codart, nomart,
                SUM(canped) canped, SUM(impped) impped, 
                0 prmepe,
                SUM(canalb) canalb, SUM(impalb) impalb, 
                0 prmeal,
                SUM(canfac) canfac, SUM(impfac) impfac, 
                0 prmefa
            </columns>
            <from table='@tmp_1'>
                <join table='@tmp_2'>
                    <on>@tmp_1.tercer = @tmp_2.tercer</on>
                </join>
                <join type='left' table='ctercero'>
                    <on>@tmp_1.tercer = ctercero.codigo</on>
                </join>
                <join type='left' table='garticul'>
                    <on>@tmp_1.codart = garticul.codigo</on>
                </join>
            </from>
            <group>1,2,3,4,5,6</group>
        </select>
    `);

    Ax.db.execute(`
        UPDATE @tmp_4 SET prmepe = impped / canped WHERE canped != 0;
        UPDATE @tmp_4 SET prmeal = impalb / canalb WHERE canalb != 0;
        UPDATE @tmp_4 SET prmefa = impfac / canfac WHERE canfac != 0;
    `);

    return Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_4' />
            <order>1,2,3,4,5,6</order>
        </select>
    `)
</script>