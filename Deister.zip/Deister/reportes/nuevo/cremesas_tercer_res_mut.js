<script>
    let mStrCond = Ax.context.property.COND;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_1`);  

    Ax.db.execute(`  
        <select>
            <columns>
                cbancpro.nomcta || ' ' || cbancpro.iban nomcta,
                cremesas.numrem, cefectos.tercer, ctercero.nombre,
                cterbanc.iban,   cefectos.moneda, cremesas.fecrem,
                SUM(CASE WHEN cremesas.clase = 'C' THEN +impdiv ELSE -impdiv END) impdiv,
                SUM(CASE WHEN cremesas.clase = 'C' THEN +impppa ELSE -impppa END) impppa,
                SUM(CASE WHEN cremesas.clase = 'C' THEN +import ELSE -import END) import,
                SUM(CASE WHEN cremesas.clase = 'C' THEN +import ELSE -import END) importpos,
                cremesas.clase
            </columns>
            <from table='cremesas'>
                <join table='cefectos'>
                    <on>cremesas.numrem  = cefectos.remesa</on>
                    <join type='left' table='cterbanc'>
                        <on>cefectos.codper = cterbanc.codigo</on>
                        <on>cefectos.numban = cterbanc.numban</on>
                    </join>
                    <join type='left' table='cempresa'>
                        <on>cefectos.empcode = cempresa.empcode</on>
                    </join>
                    <join type='left' table='ctercero'>
                        <on>cefectos.tercer  = ctercero.codigo</on>
                    </join>
                </join>
                <join type='left' table='cbancpro'>
                    <on>cremesas.empcode = cbancpro.empcode</on>
                    <on>cremesas.ctafin  = cbancpro.ctafin</on>
                </join>
            </from>
            <where>
                cremesas.clase $CLASE AND
                ${mStrCond}
            </where>
            <group>1,2,3,4,5,6,7,cremesas.clase</group>
        </select>
    `);

    Ax.db.execute(`
        UPDATE @tmp_1
        SET importpos = 0
        WHERE (clase  = 'C' AND import <= 0)
        OR (clase != 'C' AND import >=0);
    `);

    return Ax.db.executeQuery(`
        <select>
            <columns>
                nomcta, numrem, tercer, nombre,
                icon_get_format_iban(iban) iban, moneda, fecrem,
                impdiv,
                impppa,
                import,
                importpos
            </columns>
            <from table='@tmp_1' />
            <order>1,2,4,3,5,6,7</order>
        </select>
    `);
</script>