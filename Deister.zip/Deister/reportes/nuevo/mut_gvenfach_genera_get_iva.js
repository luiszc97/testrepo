let pStrModfac  = Ax.context.variable.MODFAC;
let pDatFecfac  = Ax.context.variable.FECFAC;
let pDatFeclim  = Ax.context.variable.FECLIM;
let pStrSqlcond = Ax.context.property.COND;

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_selalb`);

Ax.db.execute(`
    <union intotemp='@tmp_selalb'>
        <select>
            <columns>
                gvenalbh.docser, gvenalbh.tipdoc,
                gvenalbh.tercer, gvenalbh.tipdir, gvenmovd.tipfac, gvenalbh.delega, gvenalbh.depart,
                gvenalbh.agente, gvenalbh.divisa, gvenalbh.cambio, gvenalbh.tipefe, gvenalbh.frmpag,
                gvenalbh.dtogen, gvenalbh.dtopp,  gvenalbh.direnv, gvenalbh.cabid,  gvenalbh.terfac,
                gvenalbh.dirfac, gvenalbh.climos, gvenalbh.nommos, gvenalbh.cif,    gvenalbh.direcc,
                gvenalbh.codnac, gvenalbh.nomnac, gvenalbh.codpos, gvenalbh.poblac, gvenalbh.codprv,
                gvenalbh.nomprv, gvenalbh.telef1, gvenalbh.telef2, gvenalbh.fax,    gvenalbh.email,
                gcliente.tercom, gvenalbh.portes, gcliente.agralb, gvenalbh.bancob, gvenalbh.valor,
                gvenalbh.terenv,

                --gvenalbh.valstk, 
                
                cterdire.zonimp <alias name='zimter' />,           gvenalbl.linid,
                gvenalbl.codart, gvenalbl.varstk, garticul.cimart,
                NULL::CHAR(6) opeiva, NULL::CHAR(6) tipiva
            </columns>
            <from table='gvenalbh'>
                <join table='gvenmovd'>
                    <on>gvenalbh.tipdoc = gvenmovd.codigo</on>
                    <on>(gvenmovd.tabori = 'TV' OR gvenmovd.tabori = 'gtpv_ticketh' OR gvenmovd.tabori IS NULL)</on>
                </join>
                <join table='gcliente'>
                    <on>gvenalbh.tercer = gcliente.codigo</on>
                    <on>gcliente.modfac = '${pStrModfac}'</on>
                </join>
                <join table='cterdire'>
                    <on>gvenalbh.terenv = cterdire.codigo</on>
                    <on>gvenalbh.direnv = cterdire.tipdir</on>
                </join>
                <join table='gvenalbl'>
                    <on>gvenalbh.cabid = gvenalbl.cabid</on>
                </join>
                <join table='garticul'>
                    <on>gvenalbl.codart = garticul.codigo</on>
                </join>
            </from>
            <where>
                gvenalbh.estcab = 'V' AND
                gvenalbh.fecmov &lt;= ${pDatFecfac} AND
                gvenmovd.tipfac IS NOT NULL AND
                ${pStrSqlcond}
            </where>
        </select>
        <select>
            <columns>
                gvenalbh.docser, gvenalbh.tipdoc,
                gvenalbh.tercer, gvenalbh.tipdir, gvenmovd.tipfac, gvenalbh.delega, gvenalbh.depart,
                gvenalbh.agente, gvenalbh.divisa, gvenalbh.cambio, gvenalbh.tipefe, gvenalbh.frmpag,
                gvenalbh.dtogen, gvenalbh.dtopp,  gvenalbh.direnv, gvenalbh.cabid,  gvenalbh.terfac,
                gvenalbh.dirfac, gvenalbh.climos, gvenalbh.nommos, gvenalbh.cif,    gvenalbh.direcc,
                gvenalbh.codnac, gvenalbh.nomnac, gvenalbh.codpos, gvenalbh.poblac, gvenalbh.codprv,
                gvenalbh.nomprv, gvenalbh.telef1, gvenalbh.telef2, gvenalbh.fax,    gvenalbh.email,
                gcliente.tercom, gvenalbh.portes, gcliente.agralb, gvenalbh.bancob, gvenalbh.valor,
                gvenalbh.terenv,

                --gvenalbh.valstk, 
                
                cterdire.zonimp <alias name='zimter' />,           gvenalbl.linid,
                gvenalbl.codart, gvenalbl.varstk, garticul.cimart,
                NULL::CHAR(6) opeiva, NULL::CHAR(6) tipiva
            </columns>
            <from table='gvenalbh'>
                <join table='gvenmovd'>
                    <on>gvenalbh.tipdoc = gvenmovd.codigo</on>
                    <on>gvenmovd.tabori IN ('gmovproh','EA','PV', 'TC')</on>
                </join>
                <join table='gcliente'>
                    <on>gvenalbh.tercer = gcliente.codigo</on>
                    <on>gcliente.modfac = '${pStrModfac}'</on>
                </join>
                <join table='cterdire'>
                    <on>gvenalbh.terenv = cterdire.codigo</on>
                    <on>gvenalbh.direnv = cterdire.tipdir</on>
                </join>
                <join table='gvenalbl'>
                    <on>gvenalbh.cabid = gvenalbl.cabid</on>
                    <join table='garticul'>
                        <on>gvenalbl.codart = garticul.codigo</on>
                    </join>
                </join>
            </from>
            <where>
                gvenalbh.estcab = 'V'              AND
                gvenalbh.fecmov &lt;= ${pDatFecfac} AND
                <nvl>gvenalbl.linori, 0</nvl> != 0 AND
                gvenmovd.tipfac IS NOT NULL        AND
                EXISTS (SELECT gvenpedh.cabid
                        FROM gvenpedh, gvenpedl, gvenalbl
                        WHERE gvenalbl.cabid  = gvenalbh.cabid
                        AND gvenalbl.linori = gvenpedl.linid
                        AND gvenpedl.cabid  = gvenpedh.cabid
                        AND gvenpedh.fecfin &lt;= ${pDatFeclim}) AND
                ${pStrSqlcond}
            </where>
        </select>
    </union>
`);

Ax.db.execute(`CREATE INDEX i_@tmp_selalb1 ON @tmp_selalb(cabid,linid)`);

Ax.db.execute(`CREATE INDEX i_@tmp_selalb2 ON @tmp_selalb(opeiva,tipiva)`);

let mArrTmpSelalb = Ax.db.executeQuery(`
    <select>
        <columns>*</columns>
        <from table='@tmp_selalb' />
    </select>
`);

let mObjResulProc1, mObjResulProc2;

for (let mRow of mArrTmpSelalb) {
    mObjResulProc1 = Ax.db.executeProcedure('garticul_get_ivatypes',
        columnIndex => {
            switch  (columnIndex) {
                case 1:  return 'o_opeiva';
                case 2:  return 'o_tipiva';
                default: return "undefined";
            }
        },
        'gvenalbh',
        mRow.cabid,
        mRow.linid,
        'C',
        mRow.tipdoc,
        mRow.delega,
        mRow.terenv,
        mRow.direnv,
        mRow.tercer,
        mRow.tipdir,
        mRow.zimter,
        mRow.codart,
        mRow.varstk,
        mRow.cimart,
        1
    ).toOne();

    mRow.opeiva = mObjResulProc1.o_opeiva;
    mRow.tipiva = mObjResulProc1.o_tipiva;
    
    mObjResulProc2 = Ax.db.executeProcedure('mut_garticul_get_ivatypes_cov',
        columnIndex => {
            switch  (columnIndex) {
                case 1:  return 'o_opeiva';
                case 2:  return 'o_tipiva';
            }
        },
        'gvenalbh',
        mRow.cabid,
        mRow.linid,
        mRow.opeiva,
        mRow.tipiva
    ).toOne();

    mRow.opeiva = mObjResulProc1.o_opeiva;
    mRow.tipiva = mObjResulProc1.o_tipiva;

    Ax.db.update('@tmp_selalb', 
        {
            'opeiva': mRow.opeiva,
            'tipiva': mRow.tipiva
        }, 
        {
            'cabid': mRow.cabid,
            'linid': mRow.linid
        }
    )
}

return Ax.db.executeQuery(`
    <select>
        <columns>
            DISTINCT tipfac, terfac, dirfac, delega, tipefe, frmpag, docser, opeiva, tipiva
        </columns>
        <from table='@tmp_selalb' />
        <order>1,2,3,4,5,6,7,8,9</order>
    </select>
`);