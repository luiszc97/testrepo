let pStrTipefe = Ax.context.variable.TIPEFE;
let pStrFrmpag = Ax.context.variable.FRMPAG;

