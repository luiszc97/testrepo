let pDatFecini = Ax.context.variable.FECINI;
let pDatFecfin = Ax.context.variable.FECFIN;
let pStrDelega = Ax.context.variable.DELEGA;

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_nifs`);

Ax.db.execute(`
    <select intotemp='@tmp_nifs'>
        <columns>DISTINCT cif</columns>
        <from table='ctercero' />
        <where>
            codigo <matches>'*-H'</matches> AND
            ${Ax.context.property.COND} AND
            ctercero.cif NOT IN ('B66012550')
        </where>
    </select>
`);

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_ctercero`);

Ax.db.execute(`
    <select intotemp='@tmp_ctercero'>
        <columns>
            codigo, cif, nombre
        </columns>
        <from table='ctercero' />
        <where>
            cif IN (SELECT @tmp_nifs.cif FROM @tmp_nifs) AND
            codigo <matches>'*-H'</matches>
        </where>
    </select>
`);

Ax.db.execute(`
    INSERT INTO @tmp_ctercero 
    SELECT codigo, cif, nombre
      FROM ctercero
     WHERE cif IN (SELECT @tmp_nifs.cif FROM @tmp_nifs) AND
           codigo  MATCHES '*-H'
`); 

Ax.db.execute(`CREATE INDEX i_@tmp_ctercero ON @tmp_ctercero(cif,codigo)`);

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_gcomfach`);

Ax.db.execute(`
    <select intotemp='@tmp_gcomfach'>
        <columns>
            ctercero.cif tercer, ctercero.nombre,
            <month>fecha</month> nummes,
            <nvl>gcomfacl_datc.centro, gcomfach.delega</nvl> centro,
            SUM(<nvl>gcomfacl_datc.import, gcomfacl.impnet</nvl>) impnet
        </columns>
        <from table='gcomfach'>
            <join table='@tmp_ctercero' alias='ctercero'>
                <on>gcomfach.tercer = ctercero.codigo</on>
            </join>
            <join table='gcomfacl'>
                <on>gcomfach.cabid = gcomfacl.cabid</on>
                <join type='left' table='gcomfacl_datc'>
                    <on>gcomfacl.linid = gcomfacl_datc.linid</on>
                </join>
            </join>
        </from>
        <where>
            gcomfach.fecha BETWEEN ${pDatFecini} AND ${pDatFecfin}
        </where>
        <group>1,2,3,4</group>
        <order>1,3,4</order>
    </select>
`);

Ax.db.execute(`
    DELETE FROM @tmp_gcomfach
     WHERE NOT (centro ${pStrDelega})
`);

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_output`);

Ax.db.execute(`
    <select intotemp='@tmp_output'>
        <columns>
            a.tercer, a.nombre,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 1) ene,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 2) feb,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 3) mar,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 4) abr,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 5) may,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 6) jun,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 7) jul,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 8) ago,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 9) sep,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 10) oct,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 11) nov,
            (SELECT SUM(b.impnet) FROM @tmp_gcomfach b WHERE a.tercer = b.tercer AND b.nummes = 12) dic,
            SUM(a.impnet) impnet
        </columns>
        <from table='@tmp_gcomfach' alias='a' />
        <group>1,2,3,4,5,6,7,8,9,10,11,12,13,14</group>
        <order>1</order>
    </select>
`);

return Ax.db.executeQuery(`
    <select>
        <columns>*</columns>
        <from table='@tmp_output' />
        <order>1</order>
    </select>
`)