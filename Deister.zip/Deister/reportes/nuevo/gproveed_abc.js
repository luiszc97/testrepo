<script>
    let mDateFecIni = Ax.context.variable.FECINI;
    let mDateFecFin = Ax.context.variable.FECFIN;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_1`);  

    //Calculo de entradas el total por Proveedor
    Ax.db.execute(`
        <union type='all' intotemp='@tmp_1'>
            <select oracle='ansi'>
                <columns>
                    gcommovh.empcode, gcommovh.almori codalm,
                    gcommovh.tercer, SUM(gcommovh.imptot) <alias name='imptot' />
                </columns>
                <from table='gcommovh'>
                    <join table='gcommovd'>
                        <on>gcommovh.tipdoc = gcommovd.codigo</on>
                    </join>
                    <join table='galmctas' alias='ori'>
                        <on>ori.codigo      = gcommovd.ctaori</on>
                    </join>
                    <join table='galmctas' alias='des'>
                        <on>des.codigo      = gcommovd.ctades</on>
                    </join>
                </from>
                <where>
                    gcommovh.fecmov BETWEEN ? AND ? AND
                    NOT EXISTS(SELECT *
                                FROM gdelegac
                                WHERE gdelegac.tercer = gcommovh.tercer
                                AND gdelegac.dirdlg = gcommovh.tipdir) AND
                    ori.indsal  = 'N' AND
                    des.indsal != 'N' AND
                    ${Ax.context.property.COND}
                </where>
                <group>1,2,3</group>
            </select>
            <select oracle='ansi'>
                <columns>
                    gvenmovh.empcode, gvenmovh.almori codalm,
                    gvenmovh.tercer, SUM(gvenmovh.imptot)  <alias name='imptot' />
                </columns>
                <from table='gvenmovh'>
                    <join table='gvenmovd'>
                        <on>gvenmovh.tipdoc = gvenmovd.codigo</on>
                    </join>
                    <join table='galmctas' alias='ori'>
                        <on>ori.codigo      = gvenmovd.ctaori</on>
                    </join>
                    <join table='galmctas' alias='des'>
                        <on>des.codigo      = gvenmovd.ctades</on>
                    </join>
                </from>
                <where>
                    gvenmovh.fecmov BETWEEN ? AND ? AND
                    NOT EXISTS(SELECT *
                                FROM gdelegac
                                WHERE gdelegac.tercer = gvenmovh.tercer
                                AND gdelegac.dirdlg = gvenmovh.tipdir) AND
                    ori.indsal  = 'N' AND
                    des.indsal != 'N' AND
                    ${Ax.context.property.COND}
                </where>
                <group>1,2,3</group>
            </select>
        </union>
    `, mDateFecIni, mDateFecFin, mDateFecIni, mDateFecFin);  

    //Calculo el total de final del listado
    Ax.db.execute(`
        <select intotemp='@tmp_2'>
            <columns>
                empcode, codalm, SUM(imptot) imptot
            </columns>
            <from table='@tmp_1' />
            <group>1,2</group>
        </select>
    `);

    //Calculo el porcentaje de cada proveedor
    return Ax.db.executeQuery(`
        <select>
            <columns>
                @tmp_1.empcode, cempresa.empname,
                @tmp_1.codalm,  galmacen.nomalm,
                @tmp_1.tercer,  ctercero.nombre,
                @tmp_1.imptot,
                ROUND(@tmp_1.imptot/ @tmp_2.imptot * 100, 4) porcen
            </columns>
            <from table='@tmp_1'>
                <join table='@tmp_2'>
                    <on>@tmp_2.empcode = @tmp_1.empcode</on>
                    <on>@tmp_2.codalm  = @tmp_1.codalm</on>
                </join>
                <join type='left' table='ctercero'>
                    <on>@tmp_1.tercer = ctercero.codigo</on>
                </join>
                <join table='cempresa'>
                    <on>@tmp_1.empcode = cempresa.empcode</on>
                </join>
                <join table='galmacen'>
                    <on>@tmp_1.codalm = galmacen.codigo</on>
                </join>
            </from>
        </select>
    `);
</script>