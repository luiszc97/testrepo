<script>
    let pIntNivel   = Ax.context.variable.NIVEL;
    let pStrEmpcode = Ax.context.variable.EMPCODE;
    let pIntEjerc   = Ax.context.variable.EJERCI;
    let pIntPeriod  = Ax.context.variable.PERIOD;

    //Informe de balance por operaciones con empresas del grupo. 
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_balsal`); 

    Ax.db.execute(`  
        CREATE TEMP TABLE @tmp_balsal (
            empcode  CHAR(4),
            cuenta   CHAR(14),
            dimcode1 CHAR(12),
            saldo    DECIMAL(14,2)
        )
        WITH NO LOG;
    `);

    Ax.db.execute(`  
        <index name='@i_tmp_balsal1' table='@tmp_balsal' columns='empcode, cuenta, dimcode1' />
    `);

    //////////////////////////////////////

    Ax.db.execute(`
        INSERT INTO @tmp_balsal 
        SELECT 
            empcode,  cuenta[1, ? ], dimcode1,
            SUM(debe-haber) AS saldo 
        FROM csaldos
        WHERE empcode   =  ?
        AND ejerci    =  ?
        AND period    <= ?
        AND dimcode1  != '0'
        AND ${Ax.context.property.COND}
        GROUP BY 1,2,3
        HAVING SUM(debe-haber) != 0.0
    `, pIntNivel, pStrEmpcode, pIntEjerc, pIntPeriod);

    return Ax.db.executeQuery(`
        <select>
            <columns>
                t.empcode, e.empname,
                t.cuenta,  icon_r_ccuenta(t.empcode, t.cuenta) AS nomcta
                ,SUM(CASE WHEN dimcode1 = '01' THEN saldo else 0 END) AS emp_01
                ,SUM(CASE WHEN dimcode1 = '02' THEN saldo else 0 END) AS emp_02
                ,SUM(CASE WHEN dimcode1 = '03' THEN saldo else 0 END) AS emp_03
                ,SUM(CASE WHEN dimcode1 = '04' THEN saldo else 0 END) AS emp_04
                ,SUM(CASE WHEN dimcode1 = '05' THEN saldo else 0 END) AS emp_05
                ,SUM(CASE WHEN dimcode1 = '06' THEN saldo else 0 END) AS emp_06
                ,SUM(CASE WHEN dimcode1 = '07' THEN saldo else 0 END) AS emp_07
                ,SUM(CASE WHEN dimcode1 = '08' THEN saldo else 0 END) AS emp_08
                ,SUM(CASE WHEN dimcode1 = '09' THEN saldo else 0 END) AS emp_09
                ,SUM(CASE WHEN dimcode1 = '10' THEN saldo else 0 END) AS emp_10

                ,SUM(CASE WHEN dimcode1 = '11' THEN saldo else 0 END) AS emp_11
                ,SUM(CASE WHEN dimcode1 = '12' THEN saldo else 0 END) AS emp_12
                ,SUM(CASE WHEN dimcode1 = '13' THEN saldo else 0 END) AS emp_13
                ,SUM(CASE WHEN dimcode1 = '14' THEN saldo else 0 END) AS emp_14
                ,SUM(CASE WHEN dimcode1 = '15' THEN saldo else 0 END) AS emp_15
                ,SUM(CASE WHEN dimcode1 = '16' THEN saldo else 0 END) AS emp_16
                ,SUM(CASE WHEN dimcode1 = '17' THEN saldo else 0 END) AS emp_17
                ,SUM(CASE WHEN dimcode1 = '18' THEN saldo else 0 END) AS emp_18
                ,SUM(CASE WHEN dimcode1 = '19' THEN saldo else 0 END) AS emp_19
                ,SUM(CASE WHEN dimcode1 = '20' THEN saldo else 0 END) AS emp_20

                ,SUM(CASE WHEN dimcode1 = '21' THEN saldo else 0 END) AS emp_21
                ,SUM(CASE WHEN dimcode1 = '22' THEN saldo else 0 END) AS emp_22
                ,SUM(CASE WHEN dimcode1 = '23' THEN saldo else 0 END) AS emp_23
                ,SUM(CASE WHEN dimcode1 = '24' THEN saldo else 0 END) AS emp_24
                ,SUM(CASE WHEN dimcode1 = '25' THEN saldo else 0 END) AS emp_25
                ,SUM(CASE WHEN dimcode1 = '26' THEN saldo else 0 END) AS emp_26
                ,SUM(CASE WHEN dimcode1 = '27' THEN saldo else 0 END) AS emp_27

                ,SUM(saldo) AS t_con_total
            </columns>
            <from table='@tmp_balsal' alias='t'>
                <join type='left' table='cempresa' alias='e'>
                    <on>t.empcode = e.empcode</on>
                </join>
            </from>
            <group>1,2,3,4</group>
        </select>
    `);
</script>