let pIntCabid = Ax.context.variable.CABID;

let mObjMutFilelnk = Ax.db.executeQuery(`
	<select>
		<columns>pathname</columns>
		<from table='mut_filelnk' />
		<where>
			tabname = 'gcomfach' AND
			cabid = ?
		</where>
	</select>
`, pIntCabid).toOne().setRequired('Link no trobat. Contactar amb Aplicacions Corporatives.');

let mStrPahtname = mObjMutFilelnk.pathname.toString()

let mStrSub = mStrPahtname.slice(0, 28);
let mStrFilename = mStrPahtname.replace(mStrSub, "");

let mFolder = new Ax.io.File(mStrPahtname);

if (!(mFolder.isFile())) {	
	throw new Ax.lang.Exception(`Fitxer [${mStrFilename}] no trobat. Contactar amb Aplicacions Corporatives.`)
}

/// Creamos el fichero blob
let ficheroBlob = new Ax.sql.Blob(mStrFilename);
ficheroBlob.setContentType("application/pdf");
ficheroBlob.setContent(mFolder);

return ficheroBlob;