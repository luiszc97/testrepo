/**
 * mt_balcon_cta
 * Informe de balance por operaciones con empresas del grupo.
 */ 
var pIntNivel   = Ax.context.variable.NIVEL;
var pStrEmpcode = Ax.context.variable.EMPCODE;
var pIntEjerc   = Ax.context.variable.EJERCI;
var pIntPeriod  = Ax.context.variable.PERIOD;

var mTmpBalsal = Ax.db.getTempTableName('@tmp_balsal');

Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpBalsal}`);

Ax.db.execute(`
	CREATE TEMP TABLE ${mTmpBalsal} (
		empcode  char (4),
		cuenta   char (14),
		dimcode2 char (12) ,
		saldo    decimal (14,2),
		saldo1   decimal (14,2),
		saldo2   decimal (14,2),
		saldo3   decimal (14,2)
	) WITH NO LOG;
`);

// Crear indice
Ax.db.execute(`CREATE UNIQUE INDEX i_${mTmpBalsal} ON ${mTmpBalsal}(empcode,cuenta,dimcode2)`);

//
Ax.db.execute(`
	INSERT INTO ${mTmpBalsal} 
	SELECT casientos.empcode,  cuenta[1, ${pIntNivel}], dimcode2,
		   SUM(capuntes.debe - capuntes.haber) AS saldo,
		   SUM(CASE WHEN origen = 'CO'             THEN (capuntes.debe-capuntes.haber) ELSE 0.00 END) AS saldo1, 
		   SUM(CASE WHEN origen = 'RS'             THEN (capuntes.debe-capuntes.haber) ELSE 0.00 END) AS saldo2, 
		   SUM(CASE WHEN origen NOT IN ('CO','RS') THEN (capuntes.debe-capuntes.haber) ELSE 0.00 END) AS saldo3  	
	  FROM casientos, capuntes
	 WHERE casientos.id_asiento = capuntes.id_asiento
		   AND casientos.empcode   = ?
		   AND casientos.fecha BETWEEN MDY(1, 1, ${pIntEjerc}) AND sdm_mdy(${pIntPeriod}, 31, ${pIntEjerc})
		   AND casientos.empcode   IN (SELECT s.empcon FROM cempresa_con s)
		   AND ${Ax.context.property.COND}
	GROUP BY 1, 2, 3
`, pStrEmpcode);

return Ax.db.executeQuery(`
	<select>
		<columns>
			t.empcode, e.empname,
			t.cuenta,  icon_r_ccuenta(t.empcode, t.cuenta) AS nomcta
			,SUM(CASE WHEN dimcode2 = '01' THEN saldo1 ELSE 0 END) AS emp_01
			,SUM(CASE WHEN dimcode2 = '02' THEN saldo1 ELSE 0 END) AS emp_02
			,SUM(CASE WHEN dimcode2 = '03' THEN saldo1 ELSE 0 END) AS emp_03
			,SUM(CASE WHEN dimcode2 = '04' THEN saldo1 ELSE 0 END) AS emp_04
			,SUM(CASE WHEN dimcode2 = '05' THEN saldo1 ELSE 0 END) AS emp_05
			,SUM(CASE WHEN dimcode2 = '06' THEN saldo1 ELSE 0 END) AS emp_06
			,SUM(CASE WHEN dimcode2 = '07' THEN saldo1 ELSE 0 END) AS emp_07
			,SUM(CASE WHEN dimcode2 = '08' THEN saldo1 ELSE 0 END) AS emp_08
			,SUM(CASE WHEN dimcode2 = '09' THEN saldo1 ELSE 0 END) AS emp_09
			,SUM(CASE WHEN dimcode2 = '10' THEN saldo1 ELSE 0 END) AS emp_10
			,SUM(CASE WHEN dimcode2 = '11' THEN saldo1 ELSE 0 END) AS emp_11
			,SUM(CASE WHEN dimcode2 = '12' THEN saldo1 ELSE 0 END) AS emp_12
			,SUM(CASE WHEN dimcode2 = '13' THEN saldo1 ELSE 0 END) AS emp_13
			,SUM(CASE WHEN dimcode2 = '14' THEN saldo1 ELSE 0 END) AS emp_14
			,SUM(CASE WHEN dimcode2 = '15' THEN saldo1 ELSE 0 END) AS emp_15
			,SUM(CASE WHEN dimcode2 = '16' THEN saldo1 ELSE 0 END) AS emp_16
			,SUM(CASE WHEN dimcode2 = '17' THEN saldo1 ELSE 0 END) AS emp_17
			,SUM(CASE WHEN dimcode2 = '18' THEN saldo1 ELSE 0 END) AS emp_18
			,SUM(CASE WHEN dimcode2 = '19' THEN saldo1 ELSE 0 END) AS emp_19
			,SUM(CASE WHEN dimcode2 = '20' THEN saldo1 ELSE 0 END) AS emp_20
			,SUM(CASE WHEN dimcode2 = '21' THEN saldo1 ELSE 0 END) AS emp_21
			,SUM(CASE WHEN dimcode2 = '22' THEN saldo1 ELSE 0 END) AS emp_22
			,SUM(CASE WHEN dimcode2 = '23' THEN saldo1 ELSE 0 END) AS emp_23
			,SUM(CASE WHEN dimcode2 = '24' THEN saldo1 ELSE 0 END) AS emp_24
			,SUM(CASE WHEN dimcode2 = '24' THEN saldo1 ELSE 0 END) AS emp_24
			,SUM(CASE WHEN dimcode2 = '25' THEN saldo1 ELSE 0 END) AS emp_25
			,SUM(saldo2) AS t_con_recla_homog
			,SUM(saldo3) AS t_con_ajustaments
			,SUM(saldo)  AS t_con_total
		</columns>
		<from table='${mTmpBalsal}' alias='t'>
			<join type='left' table='cempresa' alias='e'>
				<on>t.empcode = e.empcode</on>
			</join>
		</from>
		<group>1,2,3,4</group>
	</select>
`)