let pStrAssignUser = Ax.context.variable.ASSIGN_USER;

let mRsOutput = new Ax.rs.Reader().memory(options => {
    options.setColumnNames(['assign_user','docser','ini_number','synant','synpro']);
    options.setColumnTypes([Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR,Ax.sql.Types.INTEGER, Ax.sql.Types.TIMESTAMP, 
    Ax.sql.Types.TIMESTAMP]);
});

let mArrAppsSfaTaskAssign = Ax.db.executeQuery(`
    <select>
        <columns>
            mut_nfc_ordetrah.assign_user, mut_nfc_ordetrah.ini_number,
            mut_nfc_ordetrah.docser, mut_nfc_ordetrah.ini_datsyn,
            apps_sfa_task_assign.date_of_sync
        </columns>
        <from table='apps_sfa_task_assign'>
            <join table='mut_nfc_ordetrah'>
                <on>apps_sfa_task_assign.assign_user = mut_nfc_ordetrah.assign_user</on>
                <on>apps_sfa_task_assign.assign_number = mut_nfc_ordetrah.ini_number</on>
            </join>
        </from>
        <where>
            apps_sfa_task_assign.assign_user = ? AND
            apps_sfa_task_assign.task_code = 'COI' AND
            apps_sfa_task_assign.assign_state = 1
        </where>
    </select>
`, pStrAssignUser)

for (let mRow of mArrAppsSfaTaskAssign) {
    Ax.db.update('apps_sfa_task_assign', 
        {
            'assign_hide': 0,
            'date_to_sync': new Ax.sql.Date(),
            'date_of_sync': null
        }, 
        {
            'assign_user': pStrAssignUser,
            'assign_type': 1,
            'assign_number': mRow.ini_number
        }
    )

    mRsOutput.rows().add([pStrAssignUser, mRow.docser, 
        mRow.ini_number, mRow.date_of_sync, new Ax.sql.Date()]);

}

return mRsOutput;