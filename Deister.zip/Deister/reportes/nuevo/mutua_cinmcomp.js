let pStrSistem  = Ax.context.variable.SISTEM;
let pStrCtaexp  = Ax.context.variable.CTAEXP;
let pStrCcoste  = Ax.context.variable.CCOSTE;
let pDatFecini  = Ax.context.variable.FECINI;
let pDatFecfin  = Ax.context.variable.FECFIN;
let pStrSeccio  = Ax.context.variable.SECCIO;
let pStrNulos   = Ax.context.variable.NULOS;
let pStrSqlcond = Ax.context.property.COND;

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_cimpcomp`);

Ax.db.execute(`
    <select intotemp='@tmp_cimpcomp'>
        <columns>
            cinmelem.empcode,
            cinmelem.ctaexp, cinmelem.seccio, cinmelem.centro[1,3] seccio1,
            cinmelem.centro, cinmcomp.codinm, cinmcomp.codele,
            cinmcomp.codcom, cinmcomp.nomcom, cinmcomp.numhis,
            cinmelem.codcta,
            cinmcomp.fecha,  cinmcomp.fecini, cinmcval.estado,
            cinmcval.porcen, cinmcval.inicom valhoy,
            cinmcval.invcom  valinv, cinmcval.rescom valres,
            cinmcval.acucom  valacu, cinmcval.netcom valnet,
            ROUND(0,3) acuprv, ROUND(0,3) netprv,
            cinmcomp.tercer, cinmcomp.notas,
            ROUND(0,3) dotamoc, ROUND(0,3) dotamon
        </columns>
        <from table='cinmcomp'>
            <join table='cinmcval'>
                <on>cinmcomp.empcode = cinmcval.empcode</on>
                <on>cinmcomp.codinm  = cinmcval.codinm</on>
                <on>cinmcomp.codele  = cinmcval.codele</on>
                <on>cinmcomp.codcom  = cinmcval.codcom</on>
                <on>cinmcomp.numhis  = cinmcval.numhis</on>
            </join>
            <join table='cinmelem'>
                <on>cinmcomp.empcode = cinmelem.empcode</on>
                <on>cinmcomp.codinm  = cinmelem.codinm</on>
                <on>cinmcomp.codele  = cinmelem.codele</on>
            </join>
        </from>
        <where>
        (cinmelem.ctaexp <matches>${pStrCtaexp}</matches> OR ('${pStrNulos}' = 'S' AND cinmelem.ctaexp      IS NULL)) AND
        (cinmelem.centro <matches>${pStrCcoste}</matches> OR ('${pStrNulos}' = 'S' AND cinmelem.centro      IS NULL)) AND
        (cinmelem.seccio          ${pStrSeccio}           OR ('${pStrNulos}' = 'S' AND cinmelem.seccio      IS NULL)) AND
        (cinmelem.centro[1,3]     ${pStrSeccio}           OR ('${pStrNulos}' = 'S' AND cinmelem.centro[1,3] IS NULL)) AND
            cinmcval.sistem = '${pStrSistem}' AND
            ${pStrSqlcond}
        </where>
        <order>1,2,3,4,5,6,7,8</order>
    </select>
`);

let mArrTmpCimpconp = Ax.db.executeQuery(`
    <select>
        <columns>empcode, codinm, codele, codcom, numhis</columns>
        <from table='@tmp_cimpcomp' />
    </select>
`);

for (let mRow of mArrTmpCimpconp) {
    mRow.dotamoc = 0.00;
    mRow.dotamon = 0.00;

    // =========================================
    // [X][     ][ ] 
    // =========================================
    let mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>estado, fecini, fecfin, import</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ?  AND
                codele  = ?  AND
                codcom  = ?  AND
                numhis  = ?  AND
                (${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
            NOT(${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                sistem  = '${pStrSistem}'
            </where>
            <order>1</order>
        </select>
    `, mRow.empcode, mRow.codinm, mRow.codele, 
        mRow.codcom, mRow.numhis);

    for (let mItem of mArrCinmamor) {
        if (mItem.fecini != null) {
            let mDatFecfin = new Ax.sql.Date(mItem.fecfin);
            let mDatFecini = new Ax.sql.Date(mItem.fecini);

            let mDateFechaIni = new Ax.sql.Date(pDatFecini);

            mRow.diesam = (mDatFecini.days(mDatFecfin)) + 1;
            mRow.diespr = (mDateFechaIni.days(mDatFecfin)) + 1;

            let mDecResult = Math.floor(((mItem.import * mRow.diespr)/mRow.diesam), 2);

            if (mItem.estado == 'C') {
                mRow.dotamoc = mRow.dotamoc + mDecResult;
            } else {                
                mRow.dotamon = mRow.dotamon + mDecResult;
            }
        }
    }

    // =========================================
    // [ ][XXXXX][ ]
    // =========================================
    mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>estado, MIN(fecini) fecini, MAX(fecfin) fecfin, SUM(import) import</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
            NOT(${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
            NOT(${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                cinmamor.fecini &gt;= ${pDatFecini} AND
                cinmamor.fecfin &lt;= ${pDatFecfin} AND
                sistem  = '${pStrSistem}'
            </where>
            <group>1</group>
            <order>1</order>
        </select>
    `, mRow.empcode, mRow.codinm, mRow.codele, 
        mRow.codcom, mRow.numhis);

    for (let mItem of mArrCinmamor) {
        if (mItem.fecini != null){
            let mDatFecfin1 = new Ax.sql.Date(mItem.fecfin);
            let mDatFecini1 = new Ax.sql.Date(mItem.fecini);
            
            mRow.diesam = (mDatFecini1.days(mDatFecfin1)) + 1;
            mRow.diespr = mRow.diesam;

            mDecResult = Math.floor(((mItem.import * mRow.diespr)/mRow.diesam), 2);

            if (mItem.estado == 'C') {
                mRow.dotamoc = mRow.dotamoc + mDecResult;
            } else {                
                mRow.dotamon = mRow.dotamon + mDecResult;
            }
        }
    }

    // =========================================
    // [ ][     ][X]
    // =========================================
    mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>
                estado, fecini, fecfin, import
            </columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
                NOT(${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                (${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                sistem  = '${pStrSistem}'
            </where>
            <order>1</order>
        </select>
    `, mRow.empcode, mRow.codinm, mRow.codele, 
        mRow.codcom, mRow.numhis);

    for (let mItem of mArrCinmamor) {
        if (mItem.fecini != null) {
            let mDatFecfin1 = new Ax.sql.Date(mItem.fecfin);
            let mDatFecini1 = new Ax.sql.Date(mItem.fecini);
            
            mRow.diesam = (mDatFecini1.days(mDatFecfin1)) + 1;
            mRow.diespr = mDatFecini1.days(new Ax.sql.Date(pDatFecfin)) + 1;

            mDecResult = Math.floor(((mItem.import * mRow.diespr)/mRow.diesam), 2);

            if (mItem.estado == 'C') {
                mRow.dotamoc = mRow.dotamoc + mDecResult;
            } else {
                mRow.dotamon = mRow.dotamon + mDecResult;
            }
        }
    }

    // =========================================
    // [XXXXXXXXXXX] 
    // =========================================
    mArrCinmamor = Ax.db.executeQuery(`
        <select prefix='cinmamor_'>
            <columns>estado, MIN(fecini) fecini, MAX(fecfin) fecfin, SUM(import) import</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
            (${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
            (${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                sistem  = '${pStrSistem}'
            </where>
            <group>1</group>
            <order>1</order>
        </select>
    `, mRow.empcode, mRow.codinm, mRow.codele, 
    mRow.codcom, mRow.numhis);

    for (let mItem of mArrCinmamor) {
        if (mItem.fecini != null) {
            let mDatFecfin1 = new Ax.sql.Date(mItem.fecfin);
            let mDatFecini1 = new Ax.sql.Date(mItem.fecini);
            
            mRow.diesam = (mDatFecini1.days(mDatFecfin1)) + 1;

            let mDatFecini2 = new Ax.sql.Date(pDatFecini); 
            mRow.diespr = mDatFecini2.days(new Ax.sql.Date(pDatFecfin)) + 1;

            mDecResult = Math.floor(((mItem.import * mRow.diespr)/mRow.diesam), 2);

            if (mItem.estado == 'C') {
                mRow.dotamoc = mRow.dotamoc + mDecResult;
            } else {
                mRow.dotamon = mRow.dotamon + mDecResult;
            }
        }
    }

    Ax.db.update(`
        UPDATE @tmp_cimpcomp
           SET acuprv  = valacu + ${Math.floor(mRow.dotamon, 3)},
               netprv  = valnet - ${Math.floor(mRow.dotamon, 3)},
               dotamoc = ${Math.floor(mRow.dotamoc, 3)},
               dotamon = ${Math.floor(mRow.dotamon, 3)}
         WHERE empcode = ? AND
               codinm  = ? AND
               codele  = ? AND
               codcom  = ? AND
               numhis  = ?
    `, mRow.empcode, mRow.codinm, mRow.codele, 
    mRow.codcom, mRow.numhis);
}

return Ax.db.executeQuery(`
    <select>
        <columns>*</columns>
        <from table='@tmp_cimpcomp'/>
    </select>
`);

