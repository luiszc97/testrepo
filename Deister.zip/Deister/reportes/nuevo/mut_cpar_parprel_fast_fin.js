let pStrSqlCond = Ax.context.property.COND;
let pDatFecdoc  = Ax.context.variable.FECDOC;
let pIntAlbara  = Ax.context.variable.CERALB;

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_outfin`);

Ax.db.execute(`
    <select intotemp='@tmp_outfin'>
        <columns>
            cpar_parprel_fast.empcode, cpar_parprel_fast.codpre, cpar_parpreh.nompre,
            cpar_parprel_fast.codart,  garticul.nomart, gconcuen.ctacon,
            <cast type='decimal' size='10,2'>0</cast> imppr1,
            <nvl>SUM(ROUND(cpar_parprel_fast.rendi*cpar_parprel_fast.precio,2)), 0</nvl> imppr2,
            <cast type='decimal' size='10,2'>0</cast> impadj,
            <cast type='decimal' size='10,2'>0</cast> imprea,
            <cast type='decimal' size='10,2'>0</cast> impest
        </columns>
        <from table='cpar_parprel_fast'>
            <join table='cpar_parpreh'>
                <on>cpar_parprel_fast.empcode = cpar_parpreh.empcode</on>
                <on>cpar_parprel_fast.codpre  = cpar_parpreh.codpre</on>
            </join>
            <join type='left' table='garticul'>
                <on>cpar_parprel_fast.codart = garticul.codigo</on>
                <join table='cempresa'>
                    <on>cpar_parprel_fast.empcode = cempresa.empcode</on>
                    <join table='gconcuen'>
                        <on>garticul.tipcon = gconcuen.codigo</on>
                        <on>gconcuen.tipast = 'NOBR'</on>
                        <on>gconcuen.relaci = 'OBR'</on>
                        <on>gconcuen.placon = cempresa.placon</on>
                    </join>
                </join>
            </join>
        </from>
        <where>
            cpar_parprel_fast.tippre = '1' AND
            cpar_parprel_fast.codexp = '2' AND
            cpar_parprel_fast.codele IS NOT NULL AND
            ${pStrSqlCond}
        </where>
        <group>1,2,3,4,5,6,7,9,10,11</group>
    </select>
`);

let mArrTmpOutfin = Ax.db.executeQuery(`
    <select>
        <columns>empcode, codpre, codart</columns>
        <from table='@tmp_outfin' />
    </select>
`);

for (let mItem of mArrTmpOutfin) {
    let mDecImppr1 = Ax.db.executeGet(`
        <select>
            <columns>
                <nvl>SUM(ROUND(rendi*precio,2)), 0</nvl> imppr1
            </columns>
            <from table='cpar_parprel_fast' />
            <where>
                empcode = ? AND
                codpre  = ? AND
                tippre  = 1   AND
                codexp  = '1' AND
                codele IS NOT NULL AND
                codart  = ?
            </where>
        </select>
    `, mItem.empcode, mItem.codpre, mItem.codart);

    let mObjParpelFast = Ax.db.executeQuery(`
        <select>
            <columns>
                <nvl>SUM(ROUND(rendi*precio,2)), 0</nvl> impadj,
                <nvl>SUM(ROUND(impest,2)), 0</nvl> impest
            </columns>
            <from table='cpar_parprel_fast' />
            <where>
                empcode = ? AND
                codpre  = ? AND
                tippre  = 3   AND
                codele IS NOT NULL AND
                codart  = ?
            </where>
        </select>
    `, mItem.empcode, mItem.codpre, mItem.codart).toOne();

    let mDecImprea = Ax.db.executeGet(`
        <select>
            <columns>
                <nvl>SUM(ROUND(rendi*precio,2)), 0</nvl> imprea
            </columns>
            <from table='cpar_parprel_fast' />
            <where>
                empcode = ? AND
                codpre  = ? AND
                tippre  = 4   AND
                codele IS NOT NULL AND
                codart  = ? AND
                fecdoc &lt;= ${pDatFecdoc} AND
                (${pIntAlbara} = 0 OR (${pIntAlbara} = 1 AND docdes IS NOT NULL))
            </where>
        </select>
    `, mItem.empcode, mItem.codpre, mItem.codart);

    Ax.db.update('@tmp_outfin', 
        {
            'imppr1': mDecImppr1,
            'impadj': mObjParpelFast.impadj,
            'imprea': mDecImprea,
            'impest': mObjParpelFast.impest
        }, 
        {
            'empcode': mItem.empcode,
            'codpre' : mItem.codpre,
            'codart' : mItem.codart
        }
    )
}

return Ax.db.executeQuery(`
    <select>
        <columns>*</columns>
        <from table='@tmp_outfin' />
    </select>
`);
