<script>
    let pIntValxml = Ax.context.variable.VALXML;
    let pStrTypeInvoice = Ax.context.variable.TYPE_INVOICE;

    let cargoRs = new Ax.rs.Reader().memory(options => {
        options.setColumnNames(['file_seqno','file_name','file_memo','file_size','file_md5','file_status','error_message']);
        options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.VARCHAR,Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.INTEGER, Ax.sql.Types.VARCHAR]);
    });

    let mBoolValxml;

    if (pIntValxml == 1) {
        mBoolValxml = true;
    } else {
        mBoolValxml = false;
    }

    let mArrGvenfach = Ax.db.executeQuery(`
    <select>
        <columns>cabid</columns>
        <from table='gvenfach' />
        <where>
            ${Ax.context.property.COND}
        </where>
    </select>
    `).toJSONArray();

    for (let mRow of mArrGvenfach) {
        try {
            Ax.db.beginWork();

            let mIntFileSeqno = Ax.db.call('gvenfach_efactura_abast_agr', pStrTypeInvoice, `gvenfach.cabid = ${mRow.cabid}`, mBoolValxml, 'GEN', '','');

            let mObjCsopmagn = Ax.db.executeQuery(`
                <select>
                    <columns>
                        csopmagn.file_seqno, csopmagn.file_name, csopmagn.file_memo,
                        csopmagn.file_size, csopmagn.file_md5, 0 file_status,
                        '' error_message
                    </columns>
                    <from table='csopmagn' />
                    <where>
                        file_seqno = ?
                    </where>
                </select>   
            `, mIntFileSeqno).toOne();    
            
            cargoRs.rows().add([mObjCsopmagn.file_seqno, mObjCsopmagn.file_name, mObjCsopmagn.file_memo, mObjCsopmagn.file_size, mObjCsopmagn.file_md5, mObjCsopmagn.file_status, null]);

            Ax.db.update('mut_gvenfach_efactura', 
                {
                    'estado': 3,
                    'file_seqno': mIntFileSeqno,
                    'errmsg': null,
                    'user_sync': Ax.db.getUser(),
                    'date_sync': new Ax.sql.Date()
                }, 
                {
                    'cabid': mRow.cabid
                }
            )

            Ax.db.commitWork();
        
        } catch (error) {
            Ax.db.rollbackWork();

            cargoRs.rows().add([mRow.cabid, null, null, null, null, 1, Ax.util.Error.getMessage(error)]);

            Ax.db.update('mut_gvenfach_efactura', 
                {
                    'estado': -1,
                    'file_seqno': null,
                    'errmsg': Ax.util.Error.getMessage(error),
                    'user_sync': Ax.db.getUser(),
                    'date_sync': new Ax.sql.Date()
                }, 
                {
                    'cabid': mRow.cabid
                }
            )

        }

    }

    cargoRs.rows().sort(["file_status DESC"]);

    return cargoRs;
</script>