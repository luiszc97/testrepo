<script>
    let mIntNumany = Ax.context.variable.NUMANY;
    let mIntMesIni = Ax.context.variable.MESINI;
    let mIntMesfin = Ax.context.variable.MESFIN;
    let mStrTercer = Ax.context.variable.TERCER;
    let mStrTipcli = Ax.context.variable.TIPCLI;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_output`);  

    Ax.db.execute(`  
        <select intotemp='@tmp_output'>
            <columns>
                gvenmovh.cabid,  gvenmovl.linid,
                gvenmovh.tipdoc,
                CASE WHEN cempresa.empcode IS NOT NULL AND cempresa.empcode != '14' THEN 'G'
                    ELSE 'E'
                END tipcli,
                gvenmovh.delega,
                gvenmovh.terenv, gvenmovh.direnv,
                gvenmovh.tercer, ctercero.nombre, gvenmovh.tipdir,
                gvenmovl.codart, garticul.nomart, gvenmovl.varstk,
                glog_articulo.ubipic,
                gvenmovh.fecmov, gvenmovh.docser,
                NULL::CHAR(4) opeiva, NULL::CHAR(4) tipiva,
                CASE WHEN gvenmovl.impnet >= 0
                    THEN geanmovl.impcos
                    ELSE -geanmovl.impcos
                END precst,
                gvenmovl.precio preven,
                CASE WHEN gvenmovl.impnet >= 0
                    THEN  ROUND(geanmovl.canmov*geanmovl.impcos, 2)
                    ELSE -ROUND(geanmovl.canmov*geanmovl.impcos, 2)
                END impcst,
                gvenmovl.impnet impven,
                CASE WHEN gvenmovl.impnet >= 0
                    THEN gvenmovl.impnet - ROUND(geanmovl.canmov*geanmovl.impcos, 2)
                    ELSE gvenmovl.impnet + ROUND(geanmovl.canmov*geanmovl.impcos, 2)
                END difere
            </columns>
            <from table='gvenmovh'>
                <join table='gvenmovl'>
                    <on>gvenmovh.cabid = gvenmovl.cabid</on>
                    <join table='garticul'>
                        <on>gvenmovl.codart = garticul.codigo</on>
                        <join type='left' table='glog_articulo'>
                            <on>gvenmovh.almori = glog_articulo.codalm</on>
                            <on>gvenmovl.codart = glog_articulo.codart</on>
                            <on>gvenmovl.varstk = glog_articulo.varlog</on>
                        </join>
                    </join>
                    <join table='geanmovl'>
                        <on>gvenmovl.linid = geanmovl.lindes</on>
                    </join>
                </join>
                <join table='ctercero'>
                    <on>gvenmovh.tercer = ctercero.codigo</on>
                    <join type='left' table='cempresa'>
                        <on>ctercero.terhol = cempresa.tercer</on>
                    </join>
                </join>
            </from>
            <where>
                gvenmovh.empcode = '07' AND
                gvenmovh.tipdoc IN ('NEED','NEID','NVED','NVET','NVID','REID','RVID') AND
                gvenmovh.tercer ${mStrTercer} AND
                YEAR(gvenmovh.fecmov)  = ? AND
                MONTH(gvenmovh.fecmov) BETWEEN ? AND ?
            </where>
            <order>1</order>
        </select>
    `, mIntNumany, mIntMesIni, mIntMesfin);

    Ax.db.execute(`
        <index name='i_@tmp_output1' table='@tmp_output' columns='cabid,linid' />
        <index name='i_@tmp_output2' table='@tmp_output' columns='tercer,nombre,opeiva,tipiva' />
    `)

    let mArrTmpOutput = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_output' />
            <order>1,4,7,8</order>
        </select>
    `).toJSONArray();

    for (let mRow of mArrTmpOutput) {
        let mGarticulTypes = Ax.db.call('garticul_get_ivatypes', 
            'gvenmovh', 
            mRow.cabid, 
            mRow.linid, 
            null, 
            mRow.tipdoc,
            mRow.delega,
            mRow.terenv,
            mRow.direnv,
            mRow.tercer,
            mRow.tipdir,
            null,
            mRow.codart,
            mRow.varstk,
            null,
            0
        );

        mRow.opeiva  = mGarticulTypes.opeiva; 
        mRow.tipiva  = mGarticulTypes.tipiva; 
        mRow.porapl2 = mGarticulTypes.porapl2; 
        mRow.tipiva2 = mGarticulTypes.tipiva2; 
        mRow.operet  = mGarticulTypes.operet; 
        mRow.tipret  = mGarticulTypes.tipret;

        Ax.db.update('@tmp_output', 
            {
                'opeiva': mRow.opeiva,
                'tipiva': mRow.tipiva
            }, 
            {
                'cabid': mRow.cabid,
                'linid': mRow.linid
            }
        )

    }

    return Ax.db.executeQuery(`
        <select>
            <columns>
                tercer, nombre, opeiva, tipiva,
                SUM(impcst) impcst, SUM(impven) impven, SUM(difere) difere
            </columns>
            <from table='@tmp_output' />
            <where>
                (? = 'T' OR tipcli = ?)
            </where>
            <group>1,2,3,4</group>
            <order>1,2,3,4</order>
        </select>
    `, mStrTipcli, mStrTipcli);

</script>