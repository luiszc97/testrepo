let pIntNumany = Ax.context.variable.NUMANY;
let pIntNummes = Ax.context.variable.NUMMES;

//Controls.
if (pIntNumany < 2018 || pIntNumany >= 2100) {
    throw new Ax.lang.Exception(`Any [${pIntNumany}] no permés.`)
}

//Esborrem fitxers previament generats.
Ax.db.beginWork();

let mIntSeqno = Ax.db.executeGet(`
    <select>
        <columns>seqno</columns>
        <from table='mut_far_dimscab' />
        <where>
            numany = ? AND
            nummes = ?
        </where>
    </select>
`, pIntNumany, pIntNummes);

if (mIntSeqno) {
    Ax.db.delete('mut_far_dimsdet', 
        {
            'seqno': mIntSeqno
        }
    );

    Ax.db.delete('mut_far_dimscab', 
        {
            'seqno': mIntSeqno
        }
    );
}

// Escriptura de les capçaleres del fitxer.
let mIntNumser = 0;

if (pIntNumany != 2018) {
    mIntNumser = (pIntNumany * 100) + pIntNummes;
}

let mStrFilename = `DCIMS${mIntNumser}.csv`;

let mFile = new Ax.io.File(mStrFilename);
mFile.write('codi;descripcio;delegacio;quantitat;preu\n');

//Guardarem el detall en una taula temporal.
Ax.db.execute(`DROP TABLE IF EXISTS @tmp_dcmidet`);
Ax.db.execute(`
    <select intotemp='@tmp_dcmidet'>
        <columns>*</columns>
        <from table='mut_far_dimsdet' />
        <where>1=0</where>
    </select>
`);

//Recorrem els consums i els escrivim en el fitxer i la taula de detall temporal.
let mIntNumlin = 0;
Ax.db.execute(`DROP TABLE IF EXISTS @tmp_artdata`);

Ax.db.execute(`
    <select intotemp='@tmp_artdata'>
        <columns>
            <nvl><trim>gartvarl.reffab</trim>, '-'</nvl> camp01,
            garticul.nomart camp02,
            gdelegac.nomdlg camp03,
            SUM(ROUND(canmov)) camp04,
            <trim>garticul.codigo</trim> codart,
            gartvarl.varlog
        </columns>
        <from table='geanmovh'>
            <join table='geanmovl'>
                <on>geanmovh.cabid = geanmovl.cabid</on>
                <join table='garticul'>
                    <on>geanmovl.codart = garticul.codigo</on>
                </join>
                <join type='left' table='gartprov'>
                    <on>geanmovl.codart = gartprov.codart</on>
                    <join table='gartvarl'>
                        <on>gartprov.codart = gartvarl.codart</on>
                        <on>gartprov.varlog = gartvarl.varlog</on>
                    </join>
                </join>
            </join>
            <join type='left' table='gdelegac'>
                <on>geanmovh.delega = gdelegac.codigo</on>
            </join>
        </from>
        <where>
            YEAR(geanmovh.fecmov)  = ${pIntNumany} AND
        (MONTH(geanmovh.fecmov) = ${pIntNummes} OR ${pIntNummes} = 0) AND
            garticul.codtip = 'FAR' AND garticul.codigo!='400535007' AND
            garticul.auxnum2 = 0 AND
            gartprov.priori = 99 AND
        (garticul.codigo NOT MATCHES 'F*' OR
            garticul.codigo MATCHES 'FDP*' OR
            garticul.codigo MATCHES 'FME*')
        </where>
        <group>1,2,3,5,6</group>
        <order>1,3</order>
    </select>
`);

Ax.db.execute(`<index name='i_@tmp_artdata' table='@tmp_artdata' columns='camp01,camp03' />`);

let mArrTmpArtdata = Ax.db.executeQuery(`
    <select>
        <columns>
            DISTINCT camp01, camp03
        </columns>
        <from table='@tmp_artdata' />
        <order>1,2</order>
    </select>
`);

for (let mRow of mArrTmpArtdata) {
    let mObjTmpArtData = Ax.db.executeQuery(`
        <select first='1' >
            <columns>camp02, camp04, codart, varlog</columns>
            <from table='@tmp_artdata' />
            <where>
                camp01 = ? AND
                camp03 = ?
            </where>
        </select>
    `, mRow.camp01, mRow.camp03).toOne();

    mRow.camp02 = mObjTmpArtData.camp02;
    mRow.camp04 = mObjTmpArtData.camp04;
    mRow.codart = mObjTmpArtData.codart;
    mRow.varlog = mObjTmpArtData.varlog;

    mIntNumlin++;

    mRow.ubipic = Ax.db.executeGet(`
        <select>
            <columns>ubipic</columns>
            <from table='glog_articulo' />
            <where>
                codalm = '14FAR' AND
                codart = ? AND
                varlog = '0'
            </where>
        </select>
    `, mRow.codart);

    mRow.camp05 = 0;

    if (mRow.ubipic != null) {
        mRow.ultval = Ax.db.executeGet(`
            <select>
                <columns>max(fecval) ultval</columns>
                <from table='galmvalo' />
                <where>
                    codalm = '14FAR' AND
                    cuenta = 'DISP'  AND
                    codart = ? AND
                    codubi = ? AND
                    varlog = '0' AND
                    numlot = '0' AND
                    YEAR(fecval) &gt;= 2018 AND
                    YEAR(fecval) &lt;= ${pIntNumany} AND
                    (${pIntNummes} = 0 OR MONTH(fecval) &lt;= ${pIntNummes})
                </where>
            </select>
        `, mRow.codart, mRow.ubipic);

        if (mRow.ultval != null) {
            mRow.camp05 = Ax.db.executeGet(`
                <select>
                    <columns>
                        <nvl>ROUND(coste, 3), 0</nvl> camp05
                    </columns>
                    <from table='galmvalo' />
                    <where>
                        codalm = '14FAR' AND
                        cuenta = 'DISP'  AND
                        codart = ? AND
                        codubi = ? AND
                        varlog = '0' AND
                        numlot = '0' AND
                        fecval = ?
                    </where>
                </select>
            `, mRow.codart, mRow.ubipic, mRow.ultval);
        }
    }

    Ax.db.insert('@tmp_dcmidet', 
        {
            'seqno' : 0,
            'numlin': mIntNumlin,
            'camp01': mRow.camp01,
            'camp02': mRow.camp02,
            'camp03': mRow.camp03,
            'camp04': mRow.camp04,
            'camp05': mRow.camp05,
            'codart': mRow.codart,
            'varlog': mRow.varlog,
        }
    )

    let mStrResult = mRow.camp05.toString().replace(".", ",");

    mFile.write(`${mRow.camp01};${mRow.camp02};${mRow.camp03};${mRow.camp04};${mStrResult};\n`);

    //Tanquem fitxer i l'enregistrem a la capçalera de missatge DCMIH.
    mIntSeqno = Ax.db.insert('mut_far_dimscab', 
        {
            'seqno' : 0,
            'numany': pIntNumany,
            'nummes': pIntNummes,
            'file_name': mStrFilename,
            'file_type': 'text/csv',
            'file_size': mFile.length(),
            'file_data': mFile,
            'user_created': Ax.db.getUser(),
            'date_created': new Ax.sql.Date()
        }
    ).getSerial();

    //Volquem la taula temporal de detall a la taula final i retornem el
    //llistat resultant del procés. 
    Ax.db.execute(`
        INSERT INTO mut_far_dcmidet 
        SELECT  ${mIntSeqno},
            numlin, camp01, camp02, camp03,
            camp04, NVL(camp05, 0) camp05, codart, varlog
        FROM @tmp_dcmidet
        ORDER BY numlin
    `);

    Ax.db.commitWork();

    return Ax.db.executeQuery(`
        <select>
            <columns>
                mut_far_dimscab.file_name, mut_far_dimsdet.numlin,
                mut_far_dimsdet.camp01, mut_far_dimsdet.camp02, mut_far_dimsdet.camp03,
                mut_far_dimsdet.camp04, mut_far_dimsdet.camp05
            </columns>
            <from table='mut_far_dimscab'>
                <join table='mut_far_dimsdet'>
                    <on>mut_far_dimscab.seqno = mut_far_dimsdet.seqno</on>
                </join>
            </from>
            <where>
                mut_far_dimscab.seqno = ?
            </where>
            <order>1,2</order>
        </select>
    `, mIntSeqno);

}