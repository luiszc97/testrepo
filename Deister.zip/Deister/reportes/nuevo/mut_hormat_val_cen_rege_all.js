let pStrCodigo = Ax.context.variable.CODIGO;

Ax.db.execute(`DROP TABLE IF EXISTS @tmp_autoriz`);

Ax.db.execute(`
    <select intotemp='@tmp_autoriz'>
        <columns>gcommovl.cabid, gcommovl.linid</columns>
        <from table='gman_parteser'>
            <join table='gman_parteids'>
                <on>gman_parteser.cabid = gman_parteids.linid</on>
                <join table='gcommovh'>
                    <on>gman_parteids.cabdes = gcommovh.cabid</on>
                </join>
                <join table='gcommovl'>
                    <on>gman_parteids.cabdes = gcommovl.cabid</on>
                    <on>gman_parteids.lindes = gcommovl.linid</on>
                </join>
            </join>
            <join table='gman_ordetrah'>
                <on>gman_parteser.docord = gman_ordetrah.docser</on>
                <join type='left' table='gdelgrph'>
                    <on>gdelgrph.codigo ${pStrCodigo}</on>
                    <join table='gdelgrpl'>
                        <on>gdelgrpl.grpdel = gdelgrph.codigo</on>
                        <on>gdelgrpl.delgrp = gman_ordetrah.delega</on>
                    </join>
                </join>
            </join>
        </from>
        <where>
            gman_parteids.tabid = 'gman_parteser' AND
            gcommovh.estcab = 'E' AND
            ${Ax.context.property.COND}
        </where>
    </select>
`);

let mIntNumreg = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*) numreg</columns>
        <from table='@tmp_autoriz' />
    </select>
`);

Ax.db.call('gdocumen_autoriz', 'gcommovh', 'gcommovl', '@tmp_autoriz');

return Ax.db.executeQuery(`
    <select>
        <columns>${mIntNumreg} ||' registres autoritzats.' strmsg</columns>
        <from table='systables' />
        <where>
            tabname = 'systables'
        </where>
    </select>
`)