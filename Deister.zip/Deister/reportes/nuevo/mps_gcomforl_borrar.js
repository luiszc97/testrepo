<script>
    let mainRs = new Ax.rs.Reader().memory(options => {
        options.setColumnNames(['val_rowid']);
        options.setColumnTypes([Ax.sql.Types.INTEGER]);
    });

    let mArrGcomforl = Ax.db.executeQuery(`
        <select>
            <columns>gcomforh.rowid</columns>
            <from table='gcomforl'>
                <join table='gcomforh'>
                    <on>gcomforh.cabid = gcomforl.cabid</on>
                </join>
            </from>
            <where>
                ${Ax.context.property.COND}
            </where>
        </select>
    `).toJSONArray();

    for (let mRow of mArrGcomforl) {
        mainRs.rows().add([mRow.rowid]);
    }

    Ax.db.execute(`
        DELETE FROM gcomforl
        WHERE ${Ax.context.property.COND}
    `);

    for (let mRow of mainRs) {
        Ax.db.call('gcomforh', 'V', mRow.val_rowid);
    };

    return Ax.db.executeQuery(`
        <select>
            <columns>'Registres Borrats'</columns>
            <from table='cdataemp' />    
        </select>
    `);
</script>