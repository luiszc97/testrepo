let mStrNomart   = Ax.context.variable.NOMART;
let mStrNomvar   = Ax.context.variable.NOMVAR;
let mStrCodtip   = Ax.context.variable.CODTIP;
let mStrEstadoAr = Ax.context.variable.ESTADO_AR;
let mStrEstadoVl = Ax.context.variable.ESTADO_VL;
let mStrEstadoPr = Ax.context.variable.ESTADO_PR;
let mIntStkbas   = Ax.context.variable.STKBAS;
let mStrUbipic   = Ax.context.variable.UBIPIC;
let mStrCartype  = Ax.context.variable.CARTYPE;
let mStrCarcode1 = Ax.context.variable.CARCODE1;
let mStrCarname1 = Ax.context.variable.CARNAME1;
let mStrCardata1 = Ax.context.variable.CARDATA1;
let mStrCartext1 = Ax.context.variable.CARTEXT1;
let mStrIo1      = Ax.context.variable.IO1;
let mStrCarcode2 = Ax.context.variable.CARCODE2;
let mStrCarname2 = Ax.context.variable.CARNAME2;
let mStrCardata2 = Ax.context.variable.CARDATA2;
let mStrCartext2 = Ax.context.variable.CARTEXT2;
let mStrIo2      = Ax.context.variable.IO2;
let mStrCarcode3 = Ax.context.variable.CARCODE3;
let mStrCarname3 = Ax.context.variable.CARNAME3;
let mStrCardata3 = Ax.context.variable.CARDATA3;
let mStrCartext3 = Ax.context.variable.CARTEXT3;
let mStrIo3      = Ax.context.variable.IO3;
let mStrCarcode4 = Ax.context.variable.CARCODE4;
let mStrCarname4 = Ax.context.variable.CARNAME4;
let mStrCardata4 = Ax.context.variable.CARDATA4;
let mStrCartext4 = Ax.context.variable.CARTEXT4;
let mStrIo4      = Ax.context.variable.IO4;
let mStrCarcode5 = Ax.context.variable.CARCODE5;
let mStrCarname5 = Ax.context.variable.CARNAME5;
let mStrCardata5 = Ax.context.variable.CARDATA5;
let mStrCartext5 = Ax.context.variable.CARTEXT5;


Ax.db.execute(`DROP TABLE IF EXISTS @tmp_log_farsoli`);

Ax.db.execute(`
    <select intotemp="@mut_sel_garticul_sit">
        <columns>
            garticul.codtip,
            garticul.codfam,
            garticul.codigo,
            garticul.nomart,
            gartprov.despro,
            gartvarl.nomvar,
            gartprov.refpro,
            gartvarl.udmpre,
            NVL(galmstkg.stkbas,0) - NVL(galmstkg.stksal,0) stkbas,
            garticul.udmbas,
            gartprov.priori,
            gartprov.codpro,
            gartprov.varlog,
            garticul.estado,
            gartprov.estado estadop,
            gartvarl.estado estadoa,
            1 comptador,

            garticul_cart.carcode,
            ccaractt.carname,
            garticul_cart.carseqn,
            garticul_cart.cardata,
            garticul_cart.cartext,

            glog_articulo.ubipic,
            glog_articulo.codalm,

            garticul.auxchr2,
            garticul.artid
        </columns>
        <from table='garticul'>
            <join table='gartvarl'>
                <on>gartvarl.codart = garticul.codigo</on>
                <join table='gartprov'>
                    <on>gartprov.codart = gartvarl.codart</on>
                    <on>gartprov.varlog = gartvarl.varlog</on>
                </join>
                <join type='left' table='galmstkg'>
                    <on>galmstkg.codart = garticul.codigo</on>
                    <on>galmstkg.varlog = '0'</on>
                </join>
            </join>
            <join type='left' table='garticul_cart'>
                <on>garticul_cart.cabid = garticul.artid</on>
                <join type='left' table='ccaractt'>
                    <on>ccaractt.carcode = garticul_cart.carcode</on>
                </join>
            </join>
            <join type='left' table='glog_articulo'>
                <on>glog_articulo.codart = garticul.codigo</on>
                <on>glog_articulo.varlog  = '0'</on>
            </join>
        </from>
        <where>
            NVL(garticul.nomart,'') ${mStrNomart}
            AND NVL(gartvarl.nomvar,'') ${mStrNomvar}
            AND garticul.codtip ${mStrCodtip}
            AND garticul.estado ${mStrEstadoAr}
            AND gartvarl.estado ${mStrEstadoVl}
            AND gartprov.estado ${mStrEstadoPr}
            AND ${Ax.context.property.COND}
        </where>
    </select>
`);

Ax.db.execute(`CREATE INDEX i_@mut_sel_garticul_sit_1 ON @mut_sel_garticul_sit(codigo,carcode,carname,cardata)`);
Ax.db.execute(`CREATE INDEX i_@mut_sel_garticul_sit_2 ON @mut_sel_garticul_sit(ubipic)`);
Ax.db.execute(`CREATE INDEX i_@mut_sel_garticul_sit_3 ON @mut_sel_garticul_sit(stkbas)`);

return Ax.db.executeQuery(`
    <select>
        <columns>
            UNIQUE
            t.codtip,
            t.codfam,
            gartfami.nomfam,
            t.codigo,
            t.nomart,

            REPLACE(
                    REPLACE(
                            ( '({**' ||
                            TRIM(
                                    (CASE WHEN FFGUIAPE.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFGUIAPE.carcode,3,LENGTH(FFGUIAPE.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFSTOCK.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFSTOCK.carcode,3,LENGTH(FFSTOCK.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFESTUPE.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFESTUPE.carcode,3,LENGTH(FFESTUPE.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFALTRES.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFALTRES.carcode,3,LENGTH(FFALTRES.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFDIETA.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFDIETA.carcode,3,LENGTH(FFDIETA.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFDUP.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFDUP.carcode,3,LENGTH(FFDUP.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFFM.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFFM.carcode,3,LENGTH(FFFM.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFFMC.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFFMC.carcode,3,LENGTH(FFFMC.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFMATERIAL.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFMATERIAL.carcode,3,LENGTH(FFMATERIAL.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFME.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFME.carcode,3,LENGTH(FFME.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFMPI.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFMPI.carcode,3,LENGTH(FFMPI.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFNEVERA.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFNEVERA.carcode,3,LENGTH(FFNEVERA.carcode))) ELSE "" END) ||
                                    (CASE WHEN FFQR.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FFQR.carcode,3,LENGTH(FFQR.carcode))) ELSE "" END)
                                )
                            || '**})')
                            ,'({****})'
                            ,''
                        )
                    ,' '
                    ,','
                ) car_far,

            REPLACE(
                    REPLACE(
                            ( '({**' ||
                            TRIM(
                                    (CASE WHEN FCNOTA_ARTICLE.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FCNOTA_ARTICLE.carcode,3,LENGTH(FCNOTA_ARTICLE.carcode))) ELSE "" END) ||
                                    (CASE WHEN FCESTRANGER.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FCESTRANGER.carcode,3,LENGTH(FCESTRANGER.carcode))) ELSE "" END) ||
                                    (CASE WHEN FCESTUPEFAENT.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FCESTUPEFAENT.carcode,3,LENGTH(FCESTUPEFAENT.carcode))) ELSE "" END) ||
                                    (CASE WHEN FCDOMICILIARIA.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FCDOMICILIARIA.carcode,3,LENGTH(FCDOMICILIARIA.carcode))) ELSE "" END) ||
                                    (CASE WHEN FCFM.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FCFM.carcode,3,LENGTH(FCFM.carcode))) ELSE "" END) ||
                                    (CASE WHEN FCMP.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FCMP.carcode,3,LENGTH(FCMP.carcode))) ELSE "" END) ||
                                    (CASE WHEN FCPO.carcode IS NOT NULL THEN ' ' || TRIM(SUBSTR(FCPO.carcode,3,LENGTH(FCPO.carcode))) ELSE "" END)
                                )
                            || '**})')
                            ,'({****})'
                            ,''
                        )
                    ,' '
                    ,','
                ) car_com,

            FFCODATC.cardata car_atc,
            t.stkbas,
            t.auxchr2,
            galmubic.zonlog,
            galmzonl.nomzon,
            t.ubipic,
            galmubic.nomubi,
            t.despro,
            t.nomvar,
            t.refpro,
            t.udmpre,
            t.udmbas,
            t.priori,
            t.codpro,
            ctercero.nombre,
            t.varlog,
            t.estado,
            t.estadop,
            t.estadoa,
            t.comptador
        </columns>
        <from table='@mut_sel_garticul_sit' alias='t'>
            <join type='left' table='gartfami'>
                <on>gartfami.codigo = t.codfam</on>
            </join>
            <join type='left' table='galmubic'>
                <on>galmubic.codalm = t.codalm</on>
                <on>galmubic.codigo = t.ubipic</on>
                <join type='left' table = 'galmzonl'>
                    <on>galmzonl.recint = galmubic.recint</on>
                    <on>galmzonl.codigo = galmubic.zonlog</on>
                </join>
            </join>
            <join type='left' table='ctercero'>
                <on>ctercero.codigo = t.codpro</on>
            </join>
            <join type='left' table='garticul_cart' alias='FCNOTA_ARTICLE'>
                <on>FCNOTA_ARTICLE.cabid   = t.artid</on>
                <on>FCNOTA_ARTICLE.carcode IN ("FCNOTA_ARTICLE","CCNOTA_ARTICLE")</on>
                <on>FCNOTA_ARTICLE.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FCESTRANGER'>
                <on>FCESTRANGER.cabid   = t.artid</on>
                <on>FCESTRANGER.carcode IN ("FCESTRANGER")</on>
                <on>FCESTRANGER.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FCESTUPEFAENT'>
                <on>FCESTUPEFAENT.cabid   = t.artid</on>
                <on>FCESTUPEFAENT.carcode IN ("FCESTUPEFAENT")</on>
                <on>FCESTUPEFAENT.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FCDOMICILIARIA'>
                <on>FCDOMICILIARIA.cabid   = t.artid</on>
                <on>FCDOMICILIARIA.carcode IN ("FCDOMICILIARIA")</on>
                <on>FCDOMICILIARIA.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FCFM'>
                <on>FCFM.cabid   = t.artid</on>
                <on>FCFM.carcode IN ("FCFM")</on>
                <on>FCFM.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FCMP'>
                <on>FCMP.cabid   = t.artid</on>
                <on>FCMP.carcode IN ("FCMP")</on>
                <on>FCMP.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FCPO'>
                <on>FCPO.cabid   = t.artid</on>
                <on>FCPO.carcode IN ("FCPO")</on>
                <on>FCPO.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFGUIAPE'>
                <on>FFGUIAPE.cabid   = t.artid</on>
                <on>FFGUIAPE.carcode IN ("FFGUIAPE")</on>
                <on>FFGUIAPE.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFSTOCK'>
                <on>FFSTOCK.cabid   = t.artid</on>
                <on>FFSTOCK.carcode IN ("FFSTOCK")</on>
                <on>FFSTOCK.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFESTUPE'>
                <on>FFESTUPE.cabid   = t.artid</on>
                <on>FFESTUPE.carcode IN ("FFESTUPE")</on>
                <on>FFESTUPE.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFALTRES'>
                <on>FFALTRES.cabid   = t.artid</on>
                <on>FFALTRES.carcode IN ("FFALTRES")</on>
                <on>FFALTRES.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFDIETA'>
                <on>FFDIETA.cabid   = t.artid</on>
                <on>FFDIETA.carcode IN ("FFDIETA")</on>
                <on>FFDIETA.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFDUP'>
                <on>FFDUP.cabid   = t.artid</on>
                <on>FFDUP.carcode IN ("FFDUP")</on>
                <on>FFDUP.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFFM'>
                <on>FFFM.cabid   = t.artid</on>
                <on>FFFM.carcode IN ("FFFM")</on>
                <on>FFFM.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFFMC'>
                <on>FFFMC.cabid   = t.artid</on>
                <on>FFFMC.carcode IN ("FFFMC")</on>
                <on>FFFMC.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFMATERIAL'>
                <on>FFMATERIAL.cabid   = t.artid</on>
                <on>FFMATERIAL.carcode IN ("FFMATERIAL")</on>
                <on>FFMATERIAL.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFME'>
                <on>FFME.cabid   = t.artid</on>
                <on>FFME.carcode IN ("FFME")</on>
                <on>FFME.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFMPI'>
                <on>FFMPI.cabid   = t.artid</on>
                <on>FFMPI.carcode IN ("FFMPI")</on>
                <on>FFMPI.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFNEVERA'>
                <on>FFNEVERA.cabid   = t.artid</on>
                <on>FFNEVERA.carcode IN ("FFNEVERA")</on>
                <on>FFNEVERA.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFQR'>
                <on>FFQR.cabid   = t.artid</on>
                <on>FFQR.carcode IN ("FFQR")</on>
                <on>FFQR.cardata = "S"</on>
            </join>
            <join type='left' table='garticul_cart' alias='FFCODATC'>
                <on>FFCODATC.cabid   = t.artid</on>
                <on>FFCODATC.carcode IN ("FFCODATC")</on>
            </join>

        </from>
    <where>
    (
        (
            (
                (
                    (
                        EXISTS (SELECT *
                                FROM @mut_sel_garticul_sit tt
                                WHERE
                                    NVL(tt.carcode,"_") ${mStrCarcode1} AND
                                    NVL(tt.carname,"_") ${mStrCarname1} AND
                                    NVL(tt.cardata,"_") ${mStrCardata1} AND
                                    NVL(tt.cartext,"_") ${mStrCartext1} AND
                                    tt.codigo = t.codigo
                                )
                        )
                ${mStrIo1}
                    (
                        EXISTS (SELECT *
                                FROM @mut_sel_garticul_sit tt
                                WHERE
                                    NVL(tt.carcode,"_") ${mStrCarcode2} AND
                                    NVL(tt.carname,"_") ${mStrCarname2} AND
                                    NVL(tt.cardata,"_") ${mStrCardata2} AND
                                    NVL(tt.cartext,"_") ${mStrCartext2} AND
                                    tt.codigo = t.codigo
                                )
                        )
                    )
                ${mStrIo2}
                    (
                        EXISTS (SELECT *
                                FROM @mut_sel_garticul_sit tt
                                WHERE
                                    NVL(tt.carcode,"_") ${mStrCarcode3} AND
                                    NVL(tt.carname,"_") ${mStrCarname3} AND
                                    NVL(tt.cardata,"_") ${mStrCardata3} AND
                                    NVL(tt.cartext,"_") ${mStrCartext3} AND
                                    tt.codigo = t.codigo
                        )
                    )
                )
                ${mStrIo3}
                (
                    EXISTS (SELECT *
                            FROM @mut_sel_garticul_sit tt
                            WHERE
                                NVL(tt.carcode,"_") ${mStrCarcode4} AND
                                NVL(tt.carname,"_") ${mStrCarname4} AND
                                NVL(tt.cardata,"_") ${mStrCardata4} AND
                                NVL(tt.cartext,"_") ${mStrCartext4} AND
                                tt.codigo = t.codigo
                            )
                    )
                )
                ${mStrIo4}
                (
                    EXISTS (SELECT *
                                FROM @mut_sel_garticul_sit tt
                                WHERE
                                    NVL(tt.carcode,"_") ${mStrCarcode5} AND
                                    NVL(tt.carname,"_") ${mStrCarname5} AND
                                    NVL(tt.cardata,"_") ${mStrCardata5} AND
                                    NVL(tt.cartext,"_") ${mStrCartext5} AND
                                    tt.codigo = t.codigo
                            )
                    )
                )
            AND NVL(t.ubipic,"_") ${mStrUbipic}
            AND NVL(t.stkbas,0)   ${mIntStkbas}
        </where>
    </select>
`);