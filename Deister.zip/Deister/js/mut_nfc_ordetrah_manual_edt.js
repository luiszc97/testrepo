function mut_nfc_ordetrah_manual_edt(pIntcabid, pDatefecfin, pStrHorfin, pIntEstado){
    let mRegexp = `\d{2}:\d{2}`;
    if (!mRegexp.test(pStrHorfin)){
        throw new Ax.ext.Exception(`Format d'hora d'inici incorrecte [${pStrHorfin}].`);
    }

    let mIntFinhor = parseInt(pStrHorfin.slice(0, 2));
    let mIntFinmin = parseInt(pStrHorfin.slice(3, 5));

    if (mIntFinhor > 23 || mIntFinmin > 59) {
        throw new Ax.ext.Exception(`Format d'hora de finalització incorrecte [${pStrHorfin}].`)
    }

    let mArrOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                seqno, DATE(ini_datcon) fecini, ini_datcon
            </columns>
            <from table='mut_nfc_ordetrah' />
            <where>
                cabid  = ? AND
                estado = -3
            </where>
            <order>1 DESC</order>
        </select>
    `, pIntcabid);

    for (let mRow of mArrOrdetrah) {
        Ax.db.beginWork();
        let mTime = mRow.ini_datcon;
        let mStrHorIni = `${mTime.getHours()}:${mTime.getMinutes()}`;

        if (mRow.fecini == pDatefecfin && mStrHorIni == pStrHorfin) {
            throw new Ax.ext.Exception(`Hora d'inici igual o posterior a hora de finalització.`)
        }

        Ax.db.delete('mut_nfc_ordetrah',{'seqori': mRow.seqno});
        Ax.db.delete('mut_nfc_ordetrah',{'seqno': mRow.seqno});

        Ax.db.call('mut_nfc_ordetrah_manual_reg', pIntcabid, mRow.seqno, mRow.fecini, mStrHorIni, pDatefecfin, pStrHorfin,pIntEstado);

        Ax.db.commitWork();

        break;
    }


}