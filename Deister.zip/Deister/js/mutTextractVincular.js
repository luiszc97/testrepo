function mutTextractVincular(pIntOrigen, pData) {
    //El array se obtiene mediante el 'request.getParameterValues'.
    ///http.request.getParameterValues

    //Obtenir selecció de l'usuari.
     let mArrData = [];

     // pData viene de los datos seleccionados
     if (Array.isArray(pData)) {
         // Para varias filas seleccionadas
         pData.forEach(row => {
             mArrData.push({ orden : row.orden });
 
             //Obtener los diferentes albaranes seleccionados y borrarlos.
             Ax.db.call('textract_vincular', row.orden, pIntOrigen);
         });
     } else {
         // Para una sola fila seleccionada
         mArrData.push({ orden : pData.orden });
 
         //Obtener los diferentes albaranes seleccionados y borrarlos.
         Ax.db.call('textract_vincular', pData.orden, pIntOrigen);
     }
}