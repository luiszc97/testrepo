function mutCircvaleSendmail() {
    let mStrHtmlog = `
        <html>
            <head>
                <style>
                table,th,td {font-family:sans-serif; font-size:8pt; border:1px solid black; border-collapse:collapse; padding-right:20px}
                th {color:white; background-color:black; text-align:left;}
                </style>
            </head>

            <body>
                <table>
                    <tr alignment='left'>
                        <th>Codi</th>
                        <th>Nom</th>
                        <th>Mail</th>
                        <th>Factures</th>
                        <th>Estat</th>
                    </tr>    
    `;

    let mArrCircvalu = Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT mut_circvalu.codigo codusr,
                cuserids.username, mut_circvalu.mail
            </columns>
            <from table='mut_circvalu'>
                <join table='cuserids'>
                    <on>mut_circvalu.codigo = cuserids.usercode</on>
                </join>
            </from>
        </select>
    `);

    for (let mRow of mArrCircvalu) {
        let mIntNumfac = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*) numfac</columns>
                <from table='mut_circvale'>
                    <join table='mut_circvall'>
                        <on>mut_circvale.circui = mut_circvall.circui</on>
                        <on>mut_circvale.orden  = mut_circvall.orden</on>
                    </join>
                </from>
                <where>
                    mut_circvale.tabname = 'gcomfach'   AND
                    mut_circvall.codusr  = ? AND
                    NOT EXISTS (SELECT mut_circvala.rowid
                                FROM mut_circvala
                                WHERE mut_circvale.tabname = mut_circvala.tabname
                                AND mut_circvale.cabid   = mut_circvala.cabid
                                AND mut_circvale.orden   = mut_circvala.orden
                                AND mut_circvala.accion IN ('A','R')
                                AND mut_circvala.vigent  = 1)
                </where>
            </select>
        `, mRow.codusr);

        let mStrMessage1 = `Sr/a ${mRow.username}, l'informem que té `;
        let mStrMessage2;

        switch (mIntNumfac) {
            case value:'0'
                continue;
            break;

            case value:'1'
                mStrMessage2 = '1 factura pendent de validar ';
            break;   

            default:
                mStrMessage2 = `${mIntNumfac} factures pendents de validar `;
            break;
        }

        let mDateFecven = Ax.db.executeGet(`
            <select>
                <columns>MIN(fecven) fecven</columns>
                <from table='mut_circvale'>
                    <join table='gcomface'>
                        <on>mut_circvale.cabid = gcomface.cabid</on>
                    </join>
                    <join table='mut_circvall'>
                        <on>mut_circvale.circui = mut_circvall.circui</on>
                        <on>mut_circvale.orden  = mut_circvall.orden</on>
                    </join>
                </from>
                <where>
                    mut_circvale.tabname = 'gcomfach'   AND
                    mut_circvall.codusr  = ?            AND
                    NOT EXISTS (SELECT mut_circvala.rowid
                                  FROM mut_circvala
                                 WHERE mut_circvale.tabname = mut_circvala.tabname
                                   AND mut_circvale.cabid   = mut_circvala.cabid
                                   AND mut_circvale.orden   = mut_circvala.orden
                                   AND mut_circvala.accion IN ('A','R')
                                   AND mut_circvala.vigent  = 1)
                </where>
            </select>
        `, mRow.codusr);

        let mStrMessage3 = `(primer venciment ${mDateFecven}).`;
        let mStrMessage4 = 'No respongui aquest correu. Aquesta és una adreça no monitoritzada i les respostes a aquest correu no seran llegides.';

        let mStrContent  = `
            <html>
                <body>
                    <p>${mStrMessage1}${mStrMessage2} ${mStrMessage3}</p>
                    <p><font size='1' color='blue'>${mStrMessage4}</font></p>
                </body>
            </html>
        `;

        let mStrStatus;

        try {
            let mMail = new Ax.mail.MailerMessage();
            mMail.from('noreply@mutuaterrassa.cat');
            mMail.to(mRow.mail);
            mMail.subject('Té factures per validar');
            mMail.setHtml(mStrContent);

            //Se hace el envío del email
            let mMailer = new Ax.mail.Mailer();
            mMailer.setSMTPServer("localhost", 25);
            mMailer.send(mMail);
            
            mStrStatus = 'OK';
        } catch (error) {
            mStrStatus = Ax.util.Error.getMessage(error);
        }

        mStrHtmlog = mHtmlContent + `
            <tr>
                <td>${mRow.codusr}</td>
                <td>${mRow.username}</td>
                <td>${mRow.mail}</td>
                <td>${mIntNumfac}</td>
                <td>${mStrStatus}</td>
            </tr>
        `;

    }

    mStrHtmlog = mHtmlContent + `
            </table>
        </body>
    </html>
    `;

    mStrContent = `
        <html>
            <body>
                <p>${mStrMessage1}${mStrMessage2} ${mStrMessage3}</p>
                <p><font size='1' color='blue'>${mStrMessage4}</font></p>
            </body>
        </html>
    `;

    let mObjMail = Ax.db.call('mutSysMailSelect', 'mutCircvaleSendmail', 'general');

    let mMail = new Ax.mail.MailerMessage();
    mMail.from(mObjMail.mail_from);
    mMail.to(mObjMail.mail_to);
    mMail.cc(mObjMail.mail_cc);
    mMail.bcc(mObjMail.mail_bcc);
    mMail.subject('Log Mailing Validació de Factures');
    mMail.setHtml(mStrHtmlog);

    //Se hace el envío del email
    let mMailer = new Ax.mail.Mailer();
    mMailer.setSMTPServer("localhost", 25);
    mMailer.send(mMail);     

}