function mutCatlabFileImport(pIntSeqno) {
    try {
        Ax.db.beginWork();

        let mObjCatlabFile = Ax.db.executeQuery(`
            <select>
                <columns>file_data, file_name</columns>
                <from table='mut_catlab_file' />
                <where>
                    seqno = ?
                </where>
            </select>
        `, pIntSeqno).toOne();

        Ax.db.update('mut_catlab_file', 
            {
                'estat': 1
            }, 
            {
                'seqno': pIntSeqno
            }
        );

        let mStrFile = `/erpsync/catlab/${mObjCatlabFile.file_name}`;

        let mF = new Ax.io.File(mStrFile);
        mF.write(mObjCatlabFile.file_data);

        Ax.db.call('mut_catlab_import');

        Ax.db.update('mut_catlab_file', 
            {
                'estat': 2
            }, 
            {
                'seqno': pIntSeqno,
                'estat': 1
            }
        );

        Ax.db.commitWork();

    } catch (error) {
        Ax.db.rollbackWork();

        Ax.db.beginWork();
        mF.delete();

        let mError = Ax.util.Error.getMessage(error);

        Ax.db.update('mut_catlab_file', 
            {
                'estat': 5,
                'errmsg': mError
            }, 
            {
                'seqno': pIntSeqno
            }
        );

        Ax.db.commitWork();

        throw new Ax.lang.Exception(`No se ha procesado debido a [${mError}].`);
    }
}