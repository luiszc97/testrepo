function cpar_parprel_fast_ArtImport(pIntLinid) {
    let mObjCparParprelFast = Ax.db.executeQuery(`
        <select>
            <columns>
                cpar_parprel_fast.linid,
                cpar_bc3file.empcode, cpar_bc3file.codpre,
                cpar_bc3file.tippre,  cpar_bc3file.codexp,
                cpar_parprel_fast.codobr, cpar_parprel_fast.codcap,
                cpar_parprel_fast.codsub1,cpar_parprel_fast.codsub2,
                cpar_parprel_fast.codsub3,cpar_parprel_fast.codsub4,
                cpar_parprel_fast.codsub5,cpar_parprel_fast.codele,
                cpar_parprel_fast.codart
            </columns>
            <from table='cpar_parprel_fast'>
                <join table='cpar_bc3file'>
                    <on>cpar_parprel_fast.file_seqno = cpar_bc3file.file_seqno</on>
                </join>
            </from>
            <where>
                cpar_parprel_fast.linid = ? AND
                NOT (cpar_parprel_fast.tippre = '1' AND cpar_parprel_fast.codexp = '2') AND
                cpar_parprel_fast.codele IS NOT NULL AND
                cpar_parprel_fast.docdes IS NULL
            </where>
        </select>
    `, pIntLinid).toOne();

    if (mObjCparParprelFast.linid == null) {
        return;
    }

    let mArrCparBc3file = Ax.db.executeQuery(`
        <select>
            <columns>
                cpar_parprel_fast.codart
            </columns>
            <from table='cpar_bc3file'>
                <join table='cpar_parprel_fast'>
                    <on>cpar_bc3file.file_seqno = cpar_parprel_fast.file_seqno</on>
                </join>
            </from>
            <where>
                cpar_bc3file.empcode = ? AND
                cpar_bc3file.codpre  = ? AND
                cpar_parprel_fast.tippre = '1'       AND
                cpar_parprel_fast.codexp = '2'       AND
                <nvl>cpar_parprel_fast.codobr , '-'</nvl> = <nvl>? , '-'</nvl> AND
                <nvl>cpar_parprel_fast.codcap , '-'</nvl> = <nvl>? , '-'</nvl> AND
                <nvl>cpar_parprel_fast.codsub1, '-'</nvl> = <nvl>? , '-'</nvl> AND
                <nvl>cpar_parprel_fast.codsub2, '-'</nvl> = <nvl>? , '-'</nvl> AND
                <nvl>cpar_parprel_fast.codsub3, '-'</nvl> = <nvl>? , '-'</nvl> AND
                <nvl>cpar_parprel_fast.codsub4, '-'</nvl> = <nvl>? , '-'</nvl> AND
                <nvl>cpar_parprel_fast.codsub5, '-'</nvl> = <nvl>? , '-'</nvl> AND
                cpar_parprel_fast.codele  = ?
            </where>
        </select>
    `, mObjCparParprelFast.empcode, mObjCparParprelFast.codpre,
        mObjCparParprelFast.codobr, mObjCparParprelFast.codcap,
        mObjCparParprelFast.codsub1, mObjCparParprelFast.codsub2,
        mObjCparParprelFast.codsub3, mObjCparParprelFast.codsub4,
        mObjCparParprelFast.codsub5, mObjCparParprelFast.codele
    );

    for (let mRow of mArrCparBc3file) {
        Ax.db.update('cpar_parprel_fast', 
            {
                'codart': mRow.codart
            }, 
            {
                'linid': pIntLinid
            }
        )
    }

}