function mut_load_farma_v3(pStrUrlPro, pStrFiltroPro, pStrDbsnamePro, 
                           pStrLoadColPro, pStrFinFicPro, pStrForFecPro, 
                           pIntMilSegPro, pStrTmaxPro, pStrAnulErrPro) {
    if (pStrAnulErrPro == null || pStrAnulErrPro == '') {
        pStrAnulErrPro = `= "NINGUNO"`;
    }
    
    if (pStrTmaxPro == '*') {
        pStrTmaxPro = '0:10';
    }

    if (pStrDbsnamePro == '*') {
        pStrDbsnamePro = 'aegerus';
    }

    let mStrPathRec;
    if (pStrUrlPro == '*') {
        mStrPathRec = `/ulisestest/aegerus/rec`;

    } else {
        mStrPathRec = pStrUrlPro;
    }

    let mStrPathBac = `${mStrPathRec}/bac`;    

    if (pStrLoadColPro == '*') {
        pStrLoadColPro = 'tipdoc,delega,depart,docser,codart,cansol,user_created,idtran';     
    }    

    if (pStrForFecPro == '*') {
        pStrForFecPro ='dd-MM-yyyy'
    }

    Ax.db.beginWork();

    //Generar un identificador de proceso       
    //para poder borrar al final todos los      
    //registros utilizados en mut_load_farma_pre
    //en el proceso actual                      
    //Para cargar los ficheros, se utiliza una  
    //tabla temporal @mut_load_farma_pre antes  
    //de pasar los datos a la tabla             
    //mut_load_farma_pre     
    let mStrIdePro = Ax.db.executeGet(`
        <select>
            <columns>
                ${pStrDbsnamePro} || '_' || user || '_' || DBINFO('sessionid') || '_' || DBINFO('utc_current') idepro
            </columns>
            <from table='cdataemp' />
        </select>
    `);
    /*
    let mainRs = new Ax.rs.Reader().memory(options => {
        options.setColumnNames(['tipdoc','empcode','delega','depart','fecsol',
        'docser','estadh','clasif','codfor','fecini','fecfin','codalm','codart',
        'varlog', 'desvar','cansol', 'desamp','dbsname','estadl','user_created',
        'date_created','user_updated','date_updated','errno','isamno','errmsg',
        'idtran','cabdes','lindes','idfich','idepro']);
        options.setColumnTypes([Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, Ax.sql.Types.DATE,
            Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, Ax.sql.Types.DATE, Ax.sql.Types.DATE, Ax.sql.Types.CHAR, Ax.sql. Types.CHAR, 
            Ax.sql.Types.CHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.DECIMAL, Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, Ax.sql.Types.CHAR, 
            Ax.sql.Types.DATE, Ax.sql.Types.CHAR, Ax.sql.Types.DATE, Ax.sql.Types.INTEGER, Ax.sql.Types.INTEGER, Ax.sql.Types.LVARCHAR, 
            Ax.sql.Types.VARCHAR, Ax.sql.Types.INTEGER, Ax.sql.Types.INTEGER, Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR
        ])
    });
    */

    Ax.db.execute(`DROP TABLE IF EXISTS @mut_load_farma_pre`);  

    Ax.db.execute(`  
        CREATE TEMP TABLE @mut_load_farma_pre (
            tipdoc CHAR(4) NOT NULL,
            empcode CHAR(4) DEFAULT '14' NOT NULL,
            delega CHAR(6) NOT NULL,
            depart CHAR(6) DEFAULT '0' NOT NULL,
            fecsol DATE DEFAULT CURRENT_DATE NOT NULL,
            docser CHAR(20) NOT NULL,
            estadh CHAR(1) DEFAULT 'N' NOT NULL,
            clasif CHAR(12),
            codfor CHAR(16),
            fecini DATE,
            fecfin DATE,
            codalm CHAR(12) DEFAULT '14FAR' NOT NULL,
            codart CHAR(16) NOT NULL,
            varlog CHAR(6) DEFAULT '0' NOT NULL,
            desvar VARCHAR(255),
            cansol DECIMAL(12,3) NOT NULL,
            desamp INTEGER,
            dbsname CHAR(20),
            estadl CHAR(1) DEFAULT 'N' NOT NULL,
            user_created CHAR(20) NOT NULL,
            date_created DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
            user_updated CHAR(20),
            date_updated DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
            errno INTEGER,
            isamno INTEGER,
            errmsg LVARCHAR(2000),
            idtran VARCHAR(128) NOT NULL,
            cabdes INTEGER,
            lindes INTEGER,
            idfich VARCHAR(128),
            idepro VARCHAR(128)
        )
        WITH NO LOG;
    `);

    let mStrLkCancelar = 'S';

    //Leer en mut_load_farma_estpro el registro   
    //<p_dbsname_pro /> , en caso de existir      
    //                                            
    //Si el campo fecini esta informado y el      
    //campo fecfin esta informado, procederemos   
    //a continuar con el proceso, iniciando los   
    //datos de control codpro , fecini i nulando  
    //fecfin                                      
    //                                            
    //Si el campo fecini esta informado y el      
    //campo fecfin no esta informado, verificamos 
    //el tiempo transcurrido desde el inicio del  
    //proceso, si supera el tiempo indicado en    
    //p_tmax_pro, procederemos a continuar con el 
    //proceso, iniciando los datos de control     
    //codpro , fecini i nulando fecfin            
    //                                            
    //Si el campo fecini esta informado y el      
    //campo fecfin no esta informado, verificamos 
    //el tiempo transcurrido desde el inicio del  
    //proceso, si no supera el tiempo indicado en 
    //p_tmax_pro, emitiremos un excepcion,        
    //indicando que existe otro proceso en        
    //ejecucion, mostrando los datos de dicho     
    //proceso, cancelando nuestro proceso         

    let mObjMutLoadFarmaEstpro = Ax.db.executeQuery(`
        <select>
            <columns>
                *,
                replace(extend(current, year to day) - extend(fecini, year to day),' ','') ndias,
                replace(extend(current, hour to minute) - extend(fecini, hour to minute),' ','') nhoras
            </columns>
            <from table='mut_load_farma_estpro' />
            <where>
                dbsname = ?
            </where>
        </select>
    `, pStrDbsnamePro).toOne();

    if (mObjMutLoadFarmaEstpro.dbsname == null || (mObjMutLoadFarmaEstpro.fecini != null && mObjMutLoadFarmaEstpro.fecfin != null)) {
        mStrLkCancelar = 'N';
    } else {
        if (mObjMutLoadFarmaEstpro.fecini != null 
            && mObjMutLoadFarmaEstpro.fecfin == null 
            && (mObjMutLoadFarmaEstpro.ndias > 0 
            || (mObjMutLoadFarmaEstpro.ndias == 0 && mObjMutLoadFarmaEstpro.nhoras > pStrTmaxPro))) {
            
            mStrLkCancelar = 'N';
        }
    }

    if (mStrLkCancelar == 'S') {
        throw new Ax.lang.Exception(`Unaltre proces [${mObjMutLoadFarmaEstpro.idepro}] de tipus [<lk_dbsname/>] se esta executant [${mObjMutLoadFarmaEstpro.fecini}]`);
    }

    Ax.db.delete('mut_load_farma_estpro',
        {
            'dbsname': pStrDbsnamePro
        }
    );

    Ax.db.insert('mut_load_farma_estpro', 
        {
            'dbsname': pStrDbsnamePro,
            'idepro' : mStrIdePro,
            'fecini' : new Ax.util.Date()
        }
    )

    // PROCESOS INICIO
    // Borrar los registros de la tabla pre
    Ax.db.delete('mut_load_farma_pre',
        {
            'dbsname': pStrDbsnamePro
        }
    );

    Ax.db.commitWork();    

    let mFilesl = new Ax.io.File(mStrPathRec);

    for (let mRow of mFilesl) {
        if (pStrFiltroPro == '*'){
            // Se verifica que el archivo sea un aeg
            if (!mRow.isFile() || mRow.getName().match(/.*\.aeg$/gi) == null) {
                continue;
            } 

        } else {
            let regex = new RegExp(".*\\." + pStrFiltroPro + "$", "gi");

            if (!mRow.isFile() || mRow.getName().match(regex) == null) {
                continue;
            }
        }

        let mStrFicheroNam0 = mRow.getName();
        let mStrFicheroRec  = `${mStrPathRec}/${mStrFicheroNam0}`;

        //Para darle tiempo a que cierre el fichero que procesaremos por si no lo esta pausamos 10seg
        Ax.lang.System.sleep(pIntMilSegPro);

        // ==========================================
        // INICIO TRANSFORMACION A TEMPORAL          
        // ==========================================

        //Cargar todos los ficheros en la tabla pre
        /*mainRs.rows().add([
            'tipdoc',
            null,
            'delega',
            'depart',
            null,
            'docser',
            null,
            null,
            null,
            null,
            null,
            null,
            'codart',
            null, 
            null,
            'cansol', 
            null,
            null,
            null,
            'user_created',
            null,
            null,
            null,
            null,
            null,
            null,
            'idtran',
            null,
            null,
            null,
            null
        ]);*/

        Ax.db.update('@mut_load_farma_pre',
            {
                'idfich' : mStrFicheroNam0
            },
            {
                'idfich': null
            }
        );  
        Ax.db.update('@mut_load_farma_pre',
            {
                'clasif' : pStrDbsnamePro
            },
            {
                'clasif': null
            }
        ); 
        Ax.db.update('@mut_load_farma_pre',
            {
                'dbsname' : pStrDbsnamePro
            },
            {
                'dbsname': null
            }
        );  
        Ax.db.update('@mut_load_farma_pre',
            {
                'idepro' : mStrIdePro
            },
            {
                'idepro': null
            }
        ); 

        //Si la variable fin fichero no es * y el fichero que procesamos no tiene
        //un registro con el tipdoc igual a la variable fin fichero, borraremos
        //los registros de mut_load_farma_pre, correspondiente a la dbsname y
        //al fichero que estamos procesando
        //Se procesara en otro proceso, siempre que cumpla las condiciones 
        let mIntCant = Ax.db.executeGet(`
            <select>
                <columns>count(*)</columns>
                <from table='@mut_load_farma_pre' />
                <where>
                    idfich  = ? AND
                    tipdoc  = ? AND
                    dbsname = ?
                </where>
            </select>
        `, mStrFicheroNam0, pStrFinFicPro, pStrDbsnamePro);

        if (!mIntCant && pStrFinFicPro != '*') {
            Ax.db.delete('@mut_load_farma_pre', 
               {
                   'idfich':  mStrFicheroNam0,
                   'dbsname': pStrDbsnamePro
               }
            )
        }

        //En todos los casos borramos el registro de final de fichero si existe
        Ax.db.delete('@mut_load_farma_pre', 
           {
               'idfich':  mStrFicheroNam0,
               'tipdoc':  pStrFinFicPro,
               'dbsname': pStrDbsnamePro
           }
        )

        //FINAL TRANSFORMACION A TEMPORAL
        Ax.db.execute(`
            INSERT INTO mut_load_farma_pre 
            (tipdoc,empcode,delega,depart,fecsol,docser,estadh,clasif,codfor,
            fecini,fecfin,codalm,codart,varlog,desvar,cansol,desamp,dbsname,
            estadl,user_created,date_created,user_updated,date_updated,errno,
            isamno,errmsg,idtran,cabdes,lindes,idfich,idepro)

            SELECT 
                UPPER(tipdoc),empcode,UPPER(TRIM(delega)),TRIM(depart),
                fecsol,docser,estadh,clasif,codfor,fecini,fecfin,codalm,
                codart,varlog,desvar,cansol,desamp,dbsname,estadl,
                user_created,date_created,user_updated,date_updated,errno,
                isamno,errmsg,idtran,cabdes,lindes,idfich,idepro
            FROM @mut_load_farma_pre
        `);

        //Inicializar registros de la tabla temporal
        //Para cargar el siguiente fichero          
        Ax.db.execute(`
                DELETE FROM @mut_load_farma_pr
                WHERE 1=1
        `);
       
    }

    //Updatamos estas tablas, pues parece que tiene problemas
    //con las estadisticas normales diarias                  
    Ax.db.execute(`
        update statistics for table mut_load_farma_pre;
        update statistics for table mut_load_farma_h;
        update statistics for table mut_load_farma_l;
    `);

    // Cargar en el fichero temporal los documentos que contienen registros       
    // erroneos (E) o no finalizados aun (N) para intentar volver a procesarlos,  
    // solo pasar documentos 
    // erroneos (E) o no finalizados aun (N) que no intenten pasar de origen,     
    // en estos casos tomaremos
    // los datos de origen, por si los errores estan arreglados en origen
    Ax.db.execute(`
        INSERT INTO mut_load_farma_pre 
        (tipdoc,empcode,delega,depart,fecsol,docser,estadh,clasif,codfor,
            fecini,fecfin,codalm,codart,varlog,desvar,cansol,desamp,dbsname,
            estadl,user_created,date_created,user_updated,date_updated,
            idtran,idfich,idepro)

        SELECT 
            UPPER(REPLACE(h.tipdoc,'*','')) tipdoc,
            REPLACE(h.empcode,'*','') empcode,
            UPPER(REPLACE(h.delega,'*','')) delega,
            REPLACE(h.depart,'*','') depart,
            h.fecsol,
            CASE WHEN SUBSTR(h.docser,1,1) = '*' THEN substr(h.docser,19,3) else substr(h.docser,18,3) end docser,
            'N' estadh,
            REPLACE(h.clasif,'*','') clasif,
            REPLACE(h.codfor,'*','') codfor,
            h.fecini,
            h.fecfin,
            REPLACE(h.codalm,'*','') codalm,
            
            REPLACE(l.codart,'*','') codart,
            REPLACE(l.varlog,'*','') varlog,
            l.desvar,
            l.cansol,
            l.desamp,
            h.dbsname,
            'N' estadl,
            h.user_created,
            h.date_created,
            h.user_updated,
            h.date_updated,
            h.idtran,
            h.idfich,
            ${mStrIdePro} idepro
        FROM mut_load_farma_h h, mut_load_farma_l l
        WHERE 
            l.docser  = h.docser AND
            l.dbsname = h.dbsname AND
            h.estadh NOT IN ('T','A') AND
            l.estadl NOT IN ('T','A') AND
            NOT EXISTS (SELECT *
                        FROM mut_load_farma_pre p
                        WHERE p.dbsname = h.dbsname
                        AND p.docser  = replace(h.docser,'*','')
                        AND NVL((SELECT UNIQUE p1.codart
                                    FROM gartprov p1
                                    WHERE p1.refpro = p.codart
                                    AND p1.estado = 'A'),
                            NVL((SELECT UNIQUE a1.codigo
                                    FROM garticul a1
                                    WHERE a1.codigo = p.codart
                                    AND a1.estado = 'A'), p.codart)) = REPLACE(l.codart,'*','')
                        AND p.varlog  = replace(l.varlog,'*','')) AND
            h.dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname
                            FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            h.dbsname = ?        
    `, pStrDbsnamePro, pStrDbsnamePro);

    // Esborrem línies anul·lades amb quantitat 0.
    Ax.db.delete('mut_load_farma_pre', 
        {
            'cansol': 0
        }
    )

    //Borrar los registros erroneos (E) o no traspasados, para intentar
    //traspasarlos
    //Lineas
    Ax.db.execute(`
        EXISTS (SELECT mut_load_farma_h.docser
                FROM mut_load_farma_h
            WHERE mut_load_farma_h.estadh NOT IN ('T','A')
                AND mut_load_farma_h.dbsname = mut_load_farma_l.dbsname
                AND mut_load_farma_h.docser  = mut_load_farma_l.docser) AND
        dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                UNION SELECT UNIQUE ? FROM cdataemp) AND
        dbsname = ? AND
        estadl NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);

    //Cabecera
    Ax.db.execute(`
        estadh NOT IN ('T','A') AND
        dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                    UNION SELECT UNIQUE ? FROM cdataemp) AND
        dbsname = ?
    `, pStrDbsnamePro, pStrDbsnamePro);


    // Insertar en mut_load_farma_h tanto las nuevas cabeceras 
    // como las cabeceras no procesadas aun o erroneas         
    // para intentar procesarlas                                   
    let mArrMutLoadFarmaPre = Ax.db.executeQuery(`
        <select>
            <columns>
                tipdoc,
                empcode,
                delega,
                depart,
                fecsol,
                docser,
                estadh,
                clasif,
                codfor,
                fecini,
                fecfin,
                codalm,
                dbsname,
                MIN(user_created) user_created,
                MIN(date_created) date_created,
                MIN(user_updated) user_updated,
                MIN(date_updated) date_updated,
                errno,
                isamno,
                errmsg,
                idtran,
                cabdes,
                idfich,
                idepro
            </columns>
            <from table='mut_load_farma_pre' />
            <group>1,2,3,4,5,6,7,8,9,10,11,12,13,18,19,20,21,22,23,24</group>
        </select>
    `).toJSONArray(); 
    
    for (let mRow of mArrMutLoadFarmaPre) {
        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_load_farma_h' />
                <where>
                    docser  = ? AND
                    estadh  = ? AND
                    dbsname = ?
                </where>
            </select>        
        `, mRow.docser, mRow.estadh, mRow.dbsname);

        if (mIntCount) {
            throw new Ax.lang.Exception(`Clau duplicada per docser: ${mRow.docser} estadh: ${mRow.estadh} dbsname: ${mRow.dbsname} fixter: ${mRow.idfich}`)
        }

        Ax.db.insert('mut_load_farma_h', mRow);

        Ax.db.insert('mut_load_farma_h_estpro_his', 
            {
                'dbsname': mRow.dbsname,
                'idepro' : mRow.idepro,
                'docser' : mRow.docser,
                'estadh' : mRow.estadh
            }
        )
    }
    // Insertar en mul_load_farma_l tanto las nuevas lineas 
    // como las lineas no procesadas aun o erroneas         
    // para intentar procesarlas    
    Ax.db.execute(`
        INSERT INTO mut_load_farma_l 
        SELECT  docser, codart, varlog, desvar,
                SUM(cansol) cansol,
                desamp, dbsname, estadl,
                MIN(user_created) user_created, MIN(date_created),
                MIN(user_updated) user_updated, MIN(date_updated),
                errno, isamno, errmsg, idtran, lindes,
                idepro
        FROM mut_load_farma_pre
        GROUP BY 1,2,3,4,6,7,8,13,14,15,16,17,18
    `); 
    
    //Diferencies idtran i docser (Numero d'ordre)
    let mStrErrMsg = `TRIM(NVL(errmsg,'') || " Numero d'ordre ID Transaccio [" || substr(idtran,5,3) || "] diferent que numero d'ordre de Document [" || substr(docser,length(docser)-2,3) || "]; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET errno = -746, 
            isamno = 0,
            errmsg = '${mStrErrMsg}',
            estadh = 'E',
            user_updated = ${Ax.db.getUser()},
            date_updated = ${new Ax.util.Date()}
        WHERE
            substr(idtran,5,3) != substr(docser,length(docser)-2,3) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //Diferencies idtran i docser (Tipus document)
    let mStrErrMsg2 = `TRIM(NVL(errmsg,'') || " Tipus document ID Transaccio [" || substr(idtran,1,4) || "] diferent que tipus document de Document [" || substr(docser,1,4) || "]; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET errno = -746, 
            isamno = 0,
            errmsg = '${mStrErrMsg2}',
            estadh = 'E',
            user_updated = ${Ax.db.getUser()},
            date_updated = ${new Ax.util.Date()}
        WHERE
            substr(idtran,1,4) != substr(docser,1,4) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //Diferencies idtran i idfich (Fitxer de transaccio o Fitxer desti no son el mateixos)
    let mStrErrMsg3 = `TRIM(NVL(errmsg,'') || " Fitxer ID Transaccio [" || idtran || "] diferent que Fitxer [" || idfich || "]; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET errno = -746, 
            isamno = 0,
            errmsg = '${mStrErrMsg3}',
            estadh = 'E',
            user_updated = ${Ax.db.getUser()},
            date_updated = ${new Ax.util.Date()}
        WHERE
            idfich not matches '*' || idtran || '*' AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //Aquesta delegació no pot demanar a Farmàcia
    let Strdelega = `"*" || REPLACE(NVL(delega,'______'),"*","")`;
    let mStrErrMsg4 = `TRIM(NVL(errmsg,'') || " Aquesta delegació no pot demanar a Farmàcia; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            delega = ${Strdelega},
            errno = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg4},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            codalm MATCHES "??FAR" AND
            NOT EXISTS (SELECT *
                        FROM gdelgrpl
                        WHERE (gdelgrpl.grpdel MATCHES "F[A-R,T-Z,0-9]*" OR gdelgrpl.grpdel IN ('14SS08','14SM05','14SM06'))
                        AND gdelgrpl.delgrp = UPPER(REPLACE(mut_load_farma_h.delega,'*',''))
                        AND gdelgrpl.estado = "A") AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //Tipus de document inexistent 
    let mStrTipDoc = `"*" || tipdoc`;
    let mStrErrMsg5 = `TRIM(NVL(errmsg,'') || " No existeix el tipus de document; ")`;
    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            tipdoc = ${mStrTipDoc},
            errno = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg5},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            tipdoc NOT IN (SELECT codigo FROM gcomsold WHERE estado = 'A') AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //No existeix l'empresa
    let mStrEmpcode = `"*" || empcode`;
    let mStrErrMsg6 = `TRIM(NVL(errmsg,'') || " No existeix l'empresa; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            empcode = ${mStrEmpcode},
            errno = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg6},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            empcode NOT IN (SELECT empcode FROM cempresa WHERE estado = 'A') AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //No existeix la delegació 
    let mStrDelega = `"*" || REPLACE(NVL(delega,'______'),"*","")`;
    let mStrErrMsg7 = `TRIM(NVL(errmsg,'') || " No existeix la delegació; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            delega = ${mStrDelega},
            errno = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg7},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            delega NOT IN (SELECT codigo FROM gdelegac) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //La delegacio no pertany a aquesta empresa
    let mStrErrMsg8 = `TRIM(NVL(errmsg,'') || " La delegació [" || TRIM(REPLACE(NVL(mut_load_farma_h.delega,''),'*','')) || "] no pertany a l'empresa [" || trim(mut_load_farma_h.empcode) || "]; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            errno = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg8},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            NOT EXISTS (SELECT *
                        FROM gdelegac
                    WHERE gdelegac.codigo  = UPPER(REPLACE(mut_load_farma_h.delega,'*',''))
                        AND gdelegac.empcode = mut_load_farma_h.empcode) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                    UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 

    //No existeix el departament
    let mStrDepart  = `"*" || depart`;
    let mStrErrMsg9 = `TRIM(NVL(errmsg,'') || " No existeix el departament; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            depart = ${mStrDepart},
            errno = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg9},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            NOT EXISTS (SELECT *
                        FROM gdeparta
                    WHERE gdeparta.delega = UPPER(REPLACE(mut_load_farma_h.delega,'*',''))
                        AND gdeparta.depart = REPLACE(mut_load_farma_h.depart,'*','')
                        ) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                    UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);   
    
    //El document esta duplicat
    let mStrDocser = `"*" || docser`;
    let mStrErrMsg10 = `TRIM(NVL(errmsg,'') || " Sol·licitud ja traspassada; ")`;            

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            docser = ${mStrDocser},
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg10},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            EXISTS (SELECT *
                        FROM gcomsolh
                    WHERE gcomsolh.docser = mut_load_farma_h.docser) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);   

    //No existeix la clasificació
    let mStrClasif = `"*" || clasif`;
    let mStrErrMsg11 = `TRIM(NVL(errmsg,'') || " No existeix la clasificació; ")`; 

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            clasif = ${mStrClasif},
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg11},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            NOT EXISTS (SELECT *
                        FROM gclasdoc
                    WHERE gclasdoc.tabid = "gcomsolh"
                        AND NVL(gclasdoc.tipdoc,mut_load_farma_h.tipdoc) = mut_load_farma_h.tipdoc
                        AND gclasdoc.codigo = mut_load_farma_h.clasif
                        AND mut_load_farma_h.fecsol BETWEEN gclasdoc.fecini AND gclasdoc.fecfin) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                    UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro); 
    
    //No existeix el formulari
    let mStrCodfor = `"*" || codfor`;
    let mStrErrMsg12 = `TRIM(NVL(errmsg,'') || " No existeix el formulari; ")`;       
    
    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            codfor = ${mStrCodfor},
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg12},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            codfor IS NOT NULL AND
            NOT EXISTS (SELECT gcomforh.docser
                        FROM gcomforh
                        WHERE gcomforh.delega = UPPER(REPLACE(mut_load_farma_h.delega,'*',''))
                        AND gcomforh.depart = REPLACE(mut_load_farma_h.depart,'*','')
                        AND gcomforh.docser = mut_load_farma_h.codfor
                        AND mut_load_farma_h.fecsol BETWEEN fecini AND fecfin) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);     

    //El magatzem no pertany a l'empresa
    let mStrErrMsg13 = `TRIM(NVL(errmsg,'') || " El magatzem [" || trim(codalm) || "] no pertany a l'empresa [" || trim(empcode) || "]; ")`; 
    
    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg13},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            NOT EXISTS (SELECT *
                        FROM galmacen
                    WHERE galmacen.codigo  = mut_load_farma_h.codalm
                        AND galmacen.empcode = mut_load_farma_h.empcode) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                    UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);    
    
    //No existeix el magatzem
    let mStrCodalm = `"*" || codalm`;
    let mStrErrMsg14 = `TRIM(NVL(errmsg,'') || " No existeix el magatzem; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            codalm = ${mStrCodalm},
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg14},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            codalm NOT IN (SELECT codigo FROM galmacen WHERE estado = 'A' AND NVL(fecbaj, mut_load_farma_h.fecsol) >= mut_load_farma_h.fecsol) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);  
    
    //Línies de diferents usuaris
    let mStrErrMsg15 = `TRIM(NVL(errmsg,'') || " Línies de diferents usuaris; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg15},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            EXISTS (SELECT l.docser
                        FROM mut_load_farma_l l
                    WHERE mut_load_farma_h.docser  = l.docser
                        AND mut_load_farma_h.dbsname = l.dbsname
                        AND mut_load_farma_h.user_created != l.user_created) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);   
    
    //No existeix l'article
    let mStrCodart = `"*" || codart`;
    let mStrErrMsg16 = `TRIM(NVL(errmsg,'') || " No existeix l'article; ")`; 

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            codart = ${mStrCodart},
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg16},
            estadl = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            codart NOT IN (SELECT codigo FROM garticul WHERE estado = 'A') AND
            EXISTS (SELECT mut_load_farma_h.docser
                    FROM mut_load_farma_h
                    WHERE mut_load_farma_h.estadh NOT IN ('T','A')
                    AND mut_load_farma_h.dbsname = mut_load_farma_l.dbsname
                    AND mut_load_farma_h.docser  = mut_load_farma_l.docser) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadl NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);  

    //No existeix la variable logística
    let mStrVarlog = `"*" || varlog`;
    let mStrErrMsg17 = `TRIM(NVL(errmsg,'') || " No existeix la variable logística; ")`;
    let mStrEstadl = `DECODE(cansol,0,'A','E')`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            varlog = ${mStrVarlog},
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg17},
            estadl = ${mStrEstadl},
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            NOT EXISTS (SELECT *
                        FROM gartvarl
                    WHERE gartvarl.codart = mut_load_farma_l.codart
                        AND gartvarl.varlog = mut_load_farma_l.varlog
                        AND gartvarl.estado = 'A') AND
            EXISTS (SELECT mut_load_farma_h.docser
                    FROM mut_load_farma_h
                WHERE mut_load_farma_h.estadh NOT IN ('T','A')
                    AND mut_load_farma_h.dbsname = mut_load_farma_l.dbsname
                    AND mut_load_farma_h.docser  = mut_load_farma_l.docser) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                    UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadl NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);  

    //Se produit errors a les lineas, modifica les capçaleres per indicar error a les lineas
    let mStrErrMsg18 = `TRIM(NVL(errmsg,'') || " S'han produït errors a les línies; ")`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            errno  = -746, 
            isamno = 0,
            errmsg = ${mStrErrMsg18},
            estadh = 'E',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            EXISTS (SELECT *
                        FROM mut_load_farma_l
                    WHERE mut_load_farma_l.docser = mut_load_farma_h.docser
                        AND mut_load_farma_l.estadl = 'E'
                        AND mut_load_farma_l.dbsname = mut_load_farma_h.dbsname
                        AND mut_load_farma_l.docser  = mut_load_farma_h.docser) AND
            dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                        UNION SELECT UNIQUE ? FROM cdataemp) AND
            dbsname = ? AND
            estadh NOT IN ('T','A')
    `, pStrDbsnamePro, pStrDbsnamePro);  

    //Pasa los ficheros procesados a bac , verifica los que coloco en pre
    //y solo pasa a bac los que tengan registro en mut_load_farma_h del
    //fichero a pasar a bac
    //
    //Es posa aqui perque la ruta i el fitxer de backup quedir al camp
    //coment de la sol.licitud
    let count = 0;
    for (let mRow of mFilesl) {
        count++;
        if (pStrFiltroPro == '*'){
            // Se verifica que el archivo sea un aeg
            if (!mRow.isFile() || mRow.getName().match(/.*\.aeg$/gi) == null) {
                continue;
            } 

        } else {
            let regex = new RegExp(".*\\." + pStrFiltroPro + "$", "gi");

            if (!mRow.isFile() || mRow.getName().match(regex) == null) {
                continue;
            }
        }

        let mStrFicheroRec  = `${mStrPathRec}/${mRow.getName()}`;
        let mStrFicheroNom = mRow.getName();

        let date = new Ax.sql.Date()
        let mDateCurrent = date.format('ddMMyyyyhhmmss')

        mDateCurrent = `${mDateCurrent}`

        let mStrFicheroBac = `${mStrPathBac}/${mRow.getName()}_${mDateCurrent}`;

        //Si el fitxer s'ha creat correctament a mut_load_farma_h
        //es a dir el fitxer existeix a idfich, es pasa el fitxer
        //al directori bac  
        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>count(*)</columns>
                <from table='mut_load_farma_h' />
                <where>
                    idfich = ?
                </where>
            </select>        
        `, mStrFicheroNom);    

        if (mIntCount) {
            //mStrFicheroRec
            let mFichero = Ax.io.File(mStrFicheroRec);
            mFichero.renameTo(mStrFicheroBac + mRow.getName());
        }

        Ax.db.update('mut_load_farma_h', 
            {
                'idfich': mStrFicheroBac
            }, 
            {
                'idfich': mStrFicheroNom
            }
        );

    }

    // Procesa nomes els registres de la BDs amb estat 'N',
    // els altres han estat procesats amb anterioritat o
    // son erronis, no cal fer la carrega de moment 
    // 
    // and mut_load_farma_h.dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre 
    //union    
    //select unique pStrDbsnamePro from cdataemp)
    // and mut_load_farma_h.dbsname = pStrDbsnamePro
    // and mut_load_farma_h.estadh = 'N'  
    //                                                                 
    // select * from mut_load_farma_h;   
    // select * from mut_load_farma_l;    

    Ax.db.beginWork();

    Ax.db.execute(`
        INSERT INTO gcomsolh 
        (cabid,tipdoc,empcode,delega,depart,fecsol,docser,divisa,cambio,impres,clasif,estcab,errcab,imptot,codfor,fecini,fecfin,docori,dtogen,dtopp,movest,movhis,codalm,indmod,user_created,date_created,user_updated,date_updated,coment)

        SELECT 
            0 cabid,
            tipdoc,
            empcode,
            delega,
            depart,
            fecsol,
            docser,
            'EUR' divisa,
            1 cambio,
            'N' impres,
            clasif,
            'V' estcab,
            0 errcab,
            0 imptot,
            codfor,
            fecini,
            fecfin,
            idtran docori,
            0 dtogen,
            0 dtopp,
            0 movest,
            0 movhis,
            codalm,
            'S' indmod,
            user_created,
            date_created,
            user_updated,
            date_updated,
            idfich
        FROM mut_load_farma_h
        WHERE mut_load_farma_h.dbsname IN (SELECT UNIQUE 
              mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                          UNION SELECT UNIQUE ? FROM cdataemp)
              and mut_load_farma_h.dbsname = ?
              and mut_load_farma_h.estadh = 'N'
    `, pStrDbsnamePro, pStrDbsnamePro);

    Ax.db.execute(`
        INSERT INTO gcomsoll 
        (linid,cabid,orden,codart,varlog,desvar,cansol,udmsol,canpre,udmpre,precio,dtolin,canped,canser,canadj,canext,impnet,estlin,errlin,desamp,indmod)

        SELECT 
            0 linid,
            gcomsolh.cabid cabid,
            0 orden,
            mut_load_farma_l.codart,
            mut_load_farma_l.varlog,
            mut_load_farma_l.desvar,
            mut_load_farma_l.cansol,
            gartvarl.udmcom udmsol,
            mut_load_farma_l.cansol canpre,
            gartvarl.udmpre udmpre,
            0 precio,
            0 dtolin,
            0 canped,
            0 canser,
            0 canadj,
            0 canext,
            0 impnet,
            'V' estlin,
            0 errlin,
            mut_load_farma_l.desamp,
            'S' indmod
        FROM mut_load_farma_l, mut_load_farma_h, gcomsolh, gartvarl
        WHERE 
                mut_load_farma_h.dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                    UNION SELECT UNIQUE ? FROM cdataemp)
            and mut_load_farma_h.dbsname = ?
            and mut_load_farma_h.estadh = 'N'
            and mut_load_farma_l.estadl = 'N'
            and mut_load_farma_l.docser = mut_load_farma_h.docser
            and gcomsolh.docser = mut_load_farma_h.docser
            and gartvarl.codart = mut_load_farma_l.codart
            and gartvarl.varlog = mut_load_farma_l.varlog
    `, pStrDbsnamePro, pStrDbsnamePro);

    let mArrMutLoadFarmaH = Ax.db.executeQuery(`
        <select>
            <columns>
            gcomsolh.rowid
            </columns>
            <from table='mut_load_farma_h'>
                <join table='gcomsolh'>
                    <on>gcomsolh.docser = mut_load_farma_h.docser</on>
                </join>
            </from>
            <where>
                mut_load_farma_h.estadh = 'N'
                and mut_load_farma_h.dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                                                UNION SELECT UNIQUE <p_dbsname_pro /> FROM cdataemp)
                and mut_load_farma_h.dbsname = <p_dbsname_pro />
            </where>
        </select>
    `);

    for (let mRow of mArrMutLoadFarmaH) {
        Ax.db.call('gcomsolh', 'V', mRow.rowid);
    }

    // Actualitza els camps de les taules                 
    // mut_load_farma_h i mut_load_farma_l                
    // mut_load_farma_h.estadh       = 'T'                
    // mut_load_farma_h.cabddes      = gcomsolh.cabid     
    // mut_load_farma_h.user_updated = user               
    // mut_load_farma_h.date_updated = current            
    //                                                    
    // mut_load_farma_l.estadl       = 'T'                
    // mut_load_farma_l.lindes       = gcomsoll.linid     
    // mut_load_farma_l.user_updated = user               
    // mut_load_farma_l.date_updated = current  

    let mStrLindes = `(select gcomsoll.linid
        from gcomsoll,gcomsolh
       where gcomsolh.cabid  = gcomsoll.cabid
         and gcomsolh.docser = mut_load_farma_l.docser
         and gcomsoll.codart = mut_load_farma_l.codart
         and gcomsoll.varlog = mut_load_farma_l.varlog)`;
    
    Ax.db.execute(`
        UPDATE mut_load_farma_l
        SET 
            estadl = 'T',
            lindes  = ${mStrLindes}, 
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            estadl = 'N'
            and exists (select *
                        from gcomsoll,gcomsolh
                        where gcomsolh.cabid  = gcomsoll.cabid
                        and gcomsolh.docser = mut_load_farma_l.docser
                        and gcomsoll.codart = mut_load_farma_l.codart
                        and gcomsoll.varlog = mut_load_farma_l.varlog)
            and exists (select *
                        from mut_load_farma_h
                        where mut_load_farma_h.docser = mut_load_farma_l.docser
                        and mut_load_farma_h.estadh = 'N')
    `);  

    let mStrCabdes = `(select gcomsolh.cabid
        from gcomsolh
       where gcomsolh.docser = mut_load_farma_h.docser)`;

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            estadh = 'T',
            cabdes  = ${mStrCabdes}, 
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            estadh = 'N'
            and exists (select *
                        from gcomsolh
                        where gcomsolh.docser = mut_load_farma_h.docser)
    `);  

    // Actualitza els camps de les taules                 
    // mut_load_farma_h i mut_load_farma_l                
    // mut_load_farma_h.estadh       = 'A'                
    // mut_load_farma_h.user_updated = user               
    // mut_load_farma_h.date_updated = current            
    //                                                    
    // Si se producen errores en las lineas del tipo      
    // pStrAnulErrPro , los marcaremos como anulados     
    // automaticamente y si todas las lineas del documento
    // estan anulados, anulamos la cabecera    
    
    Ax.db.execute(`
        UPDATE mut_load_farma_l
        SET 
            estadl = 'A',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            mut_load_farma_l.estadl = "E"
            and mut_load_farma_l.errmsg ${pStrAnulErrPro}
            and exists (select *
                        from mut_load_farma_h
                        where mut_load_farma_h.docser = mut_load_farma_l.docser
                        and mut_load_farma_h.estadh = 'E'
                        and mut_load_farma_h.dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                                                            UNION SELECT UNIQUE ? FROM cdataemp)
                        and mut_load_farma_h.dbsname = ?
                        )
    `, pStrDbsnamePro, pStrDbsnamePro);  

    Ax.db.execute(`
        UPDATE mut_load_farma_h
        SET 
            estadh = 'A',
            user_updated = '${Ax.db.getUser()}',
            date_updated = ${new Ax.util.Date()}
        WHERE
            mut_load_farma_h.estadh = "E"
            and  mut_load_farma_h.dbsname IN (SELECT UNIQUE mut_load_farma_pre.dbsname FROM mut_load_farma_pre
                                            UNION SELECT UNIQUE ? FROM cdataemp)
            and mut_load_farma_h.dbsname = ?
            and not exists (select *
                            from mut_load_farma_l
                            where mut_load_farma_l.docser = mut_load_farma_h.docser
                            and mut_load_farma_l.estadl != 'A')
    `, pStrDbsnamePro, pStrDbsnamePro);  

    Ax.db.commitWork();

    //PROCESOS FINAL

    //Justifica el ultimo proceso realizado
    Ax.db.update('mut_load_farma_estpro', 
        {
            'fecfin': new Ax.sql.Date()
        },
        {
            'dbsname': pStrDbsnamePro
        }
    );

    Ax.db.execute(`
        INSERT INTO mut_load_farma_estpro_his 

        SELECT 
            *,
            ${count} +1 nficfi,
            (select count(*)
            from mut_load_farma_h h
            where h.idepro  = mut_load_farma_estpro.idepro
                and h.dbsname = mut_load_farma_estpro.dbsname) nreghe,
            (select count(*)
            from mut_load_farma_h h,mut_load_farma_l l
            where l.docser  = h.docser
                and l.dbsname = h.dbsname
                and h.idepro  = mut_load_farma_estpro.idepro
                and h.dbsname = mut_load_farma_estpro.dbsname) nregli
        FROM mut_load_farma_estpro
        WHERE dbsname = ?
    `, pStrDbsnamePro);


}