function mutPorprvExportTercers() {
    let mStrPathbase = '/erpsync/ppv/';
    
    //==========================================================
    // IDIOMES
    //==========================================================
    ///table.unload
    let mStrPathname = `${mStrPathbase}erp_porprv_ctipoidi.dat`;

    let mRsCtipoidi = Ax.db.executeQuery(`
        <select>
            <columns>codigo, nomidi</columns>
            <from table='ctipoidi'/>
            <order>codigo<order>
        </select>
    `);

    let mStrContent = '';
    let mArrColumnsNames = mRsCtipoidi.getColumnsNames();

    for ( let mRow of mRsCtipoidi ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    let mBlob = new Ax.sql.Blob(`${mStrPathname}`);
    mBlob.setContent(mStrContent);
 
    // Guardamos el fichero en el directorio
    let mFile = new Ax.io.File(`${mStrPathname}`);
    mFile.write(mBlob);

    //==========================================================
    // PAÏSOS
    //==========================================================
    mStrPathname = `${mStrPathbase}erp_porprv_ctiponac.dat`;
    
    let mRsCtiponac = Ax.db.executeQuery(`
        <select>
            <columns>codigo, nomnac</columns>
            <from table='ctiponac'/>
            <order>codigo<order>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsCtiponac.getColumnsNames();

    for ( let mRow of mRsCtiponac ) {
        for ( let mStrColumnName of mArrColumnsNames ) {
            mStrContent += `${mRow[mStrColumnName]}|`;
        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrPathname}`);
    mBlob.setContent(mStrContent);
 
    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrPathname}`);
    mFile.write(mBlob);

    //==========================================================
    // PROVÍNCIES
    //==========================================================
    mStrPathname = `${mStrPathbase}erp_porprv_cprovinc.dat`;

    let mRsCprovinc = Ax.db.executeQuery(`
        <select>
            <columns>codnac,codigo,nomprv</columns>
            <from table='cprovinc'/>
            <order>codnac,codigo<order>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsCprovinc.getColumnsNames();

    for ( let mRow of mRsCprovinc ) {
        for ( let mStrColumnName of mArrColumnsNames ) {
            mStrContent += `${mRow[mStrColumnName]}|`;
        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrPathname}`);
    mBlob.setContent(mStrContent);
 
    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrPathname}`);
    mFile.write(mBlob);

    //==========================================================
    // TERCERS
    //==========================================================
    mStrPathname = `${mStrPathbase}erp_porprv_ctercero.dat`;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_ctercero`);  

    Ax.db.execute(`  
        <select intotemp='@tmp_ctercero'>
            <columns>
                codigo, cif, nombre,
                CASE WHEN idioma IN ('ca','es') THEN idioma
                     ELSE 'en'
                 END idioma, refter
            </columns>
            <from table='ctercero' />
            <where>
                refter IS NOT NULL
            </where>
            <order>codigo</order>
        </select>
    `);

    let mRsTmpCtercer = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_ctercero'/>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsTmpCtercer.getColumnsNames();

    for ( let mRow of mRsTmpCtercer ) {
        for ( let mStrColumnName of mArrColumnsNames ) {
            mStrContent += `${mRow[mStrColumnName]}|`;
        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrPathname}`);
    mBlob.setContent(mStrContent);
 
    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrPathname}`);
    mFile.write(mBlob);

    //==========================================================
    // ADRECES
    //==========================================================
    mStrPathname = `${mStrPathbase}erp_porprv_cterdire.dat`;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_cterdire`);  

    Ax.db.execute(`  
        <select intotemp='@tmp_cterdire'>
            <columns>
                cterdire.codigo, cterdire.tipdir, cterdire.direcc,
                cterdire.poblac, cterdire.codnac, cterdire.codprv,
                cterdire.codpos, cterdire.telef1, cterdire.telef2,
                REPLACE(cterdire.email,'|',',') email
            </columns>
            <from table='ctercero'>
                <join table='cterdire'>
                    <on>ctercero.codigo = cterdire.codigo</on>
                </join>
            </from>
            <where>
                ctercero.refter IS NOT NULL AND
                cterdire.tipdir IN ('0','P','S0','OBR')
            </where>
            <order>codigo,tipdir</order>
        </select>
    `);

    let mRsTmpCterdire = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_cterdire'/>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsTmpCterdire.getColumnsNames();

    for ( let mRow of mRsTmpCterdire ) {
        for ( let mStrColumnName of mArrColumnsNames ) {
            mStrContent += `${mRow[mStrColumnName]}|`;
        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrPathname}`);
    mBlob.setContent(mStrContent);
 
    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrPathname}`);
    mFile.write(mBlob);

}