function mutPlanconlCogeGenera(pIntCabid, pIntDelete) {
    if (pIntDelete) {
        Ax.db.delete('mut_planconl_coge',
            {
                'cabid': pIntCabid
            }
        )
    }

    let mObjMutPlanconh = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='mut_planconh' />
            <where>
                cabid = ?
            </where>
        </select>    
    `, pIntCabid).toOne();

    let mObjMutPlanconjCoge = Ax.db.executeGet(`
        <select>
            <columns>patsel</columns>
            <from table='mut_planconj_coge' />
            <where>
                empcode = ?
            </where>
        </select>    
    `, mObjMutPlanconh.empcode).toOne()
        .setRequired(`Patró de selecció de jerarquíes de CC no informat per l'empresa [${mObjMutPlanconh.empcode}].`);

    let mArrCcosdgrp = Ax.db.executeQuery(`
        <select>
            <columns>codigo</columns>
            <from table='ccosdgrp' />
            <where>
                codigo MATCHES ${mObjMutPlanconjCoge.patsel} || '*'
            </where>
        </select>    
    `);

    for (let mRow of mArrCcosdgrp) {
        let mDecSaldo = Ax.db.executeGet(`
            <select>
                <columns>
                    CASE WHEN NOT('${mObjMutPlanconh.ctadeb}' MATCHES '7*' OR '${mObjMutPlanconh.ctahab}' MATCHES '7*')
                        THEN <nvl>SUM(ccossalc.debe)  - SUM(ccossalc.haber), 0</nvl>
                        ELSE <nvl>SUM(ccossalc.haber) - SUM(ccossalc.debe),  0</nvl>
                    END saldo
                </columns>
                <from table='ccossalc'>
                    <join table='ccosdlin'>
                        <on>ccossalc.centro = ccosdlin.centro</on>
                        <join table='ccosdgrp'>
                            <on>ccosdlin.codgrp = ccosdgrp.codigo</on>
                        </join>
                    </join>
                </from>
                <where>
                    ccossalc.ejerci  = ${mObjMutPlanconh.numany}  AND
                (${mObjMutPlanconh.period} = 0 OR ccossalc.period &lt;= ${mObjMutPlanconh.period}) AND
                    ccossalc.empcode = '${mObjMutPlanconh.empcode}' AND
                    ccossalc.sistem  = 'A' AND
                    ccossalc.placon  = 'ES' AND
                    (#mut_planconh_ctaori) AND
                    ccosdgrp.codigo  = ?
                </where>
            </select>   
        `, mRow.codigo);

        Ax.db.insert('mut_planconl_coge', 
            {
                'linid': 0,
                'cabid': mObjMutPlanconh.cabid,
                'grpcen': mRow.codigo,
                'impact': mDecSaldo,
                'imprea': 0,
                'impdif': mDecSaldo*-1,
                'user_created': Ax.db.getUser(),
                'date_created': new Ax.sql.Date(),
                'user_updated': Ax.db.getUser(),
                'date_updated': new Ax.sql.Date()
            }
        )
    }

}