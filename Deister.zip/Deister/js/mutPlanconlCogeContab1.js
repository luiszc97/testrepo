function mutPlanconlCogeContab1(pIntCabid) {
    let mObjPlanconh = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='mut_planconh' />
            <where>
                cabid = ?
            </where>
        </select>    
    `, pIntCabid).toOne();

    //Comprovacions prèvies.
    if (mObjPlanconh.estado == 'A' || mObjPlanconh.estado == 'B') {
        throw new Ax.lang.Exception('La plantilla no està tancada.');
    }

    if (mObjPlanconh.tippla != 'COGE') {
        throw new Ax.lang.Exception(`No es poden comptabilitzar tipus de plantilles del tipus [${mObjPlanconh.tippla}.]`);
    }

    let mStrPlacon;

    //Configuració dels apunts a generar. 
    switch (mObjPlanconh.empcode) {
        case '13':
            mStrPlacon = mObjPlanconh.empcode
        break;
    
        default:
            mStrPlacon = 'ES'
        break;
    }

    let mDecImptot = Ax.db.executeGet(`
        <select>
            <columns>SUM(impdif) imptot</columns>
            <from table='mut_planconl_coge' />
            <where>
                cabid = ?
            </where>
        </select>
    `, pIntCabid);

    let mStrOperac = null;

    if (mObjPlanconh.ctadeb.charAt(0) == '6') {
        mStrOperac = 'debe-haber';
    }

    if (mObjPlanconh.ctadeb.charAt(0) == '7') {
        mStrOperac = 'debe-debe';
    }

    if (mStrOperac == null) {
        throw new Ax.lang.Exception('Operació no contemplada.')
    }

    let mStrCuenta = mObjPlanconh.ctadeb;
    let mStrContra = mObjPlanconh.ctahab;
    let mDecDebe;
    let mDecHaber;

    if (mStrOperac == 'debe-haber') {
        if (mDecImptot >= 0) {
            mDecDebe  = Math.abs(mDecImptot);
            mDecHaber = 0;

        } else {
            mDecDebe  = 0;
            mDecHaber = Math.abs(mDecImptot);
        }

    } else {
        if (mDecImptot >= 0) {
            mDecDebe  = 0;
            mDecHaber = Math.abs(mDecImptot);

        } else {
            mDecDebe  = Math.abs(mDecImptot);
            mDecHaber = 0;
        }
    }

    if (mObjPlanconh.period == 0) {
        mObjPlanconh.period = 12;
    }
    let mStrResult = mObjPlanconh.numany.slice(2, 4);
    let mStrSerjus = `${mObjPlanconh.empcode}PREV${mStrResult}-`;

    let mDateFecha;
    let mDatefeccon;
    let mStrSercon;

    switch (mObjPlanconh.period) {
        case 12:
            mDateFecha = new Ax.sql.Date(mObjPlanconh.numany,12,31);    
            mDatefeccon = mDateFecha;
            mStrSercon = mStrSerjus;
        break;
    
        default:
            mDateFecha = Ax.db.executeGet(`
                <select>
                    <columns>
                        MDY(${mObjPlanconh.period} + 1,1,${mObjPlanconh.numany}) - 1 units day
                    </columns>
                    <from table='wic_dual'/>
                </select>
            `);
            mDateFecha = new Ax.sql.Date(mDateFecha);

            mDatefeccon = Ax.db.executeGet(`
                <select>
                    <columns>
                        MDY(${mObjPlanconh.period} + 1,1,${mObjPlanconh.numany})
                    </columns>
                    <from table='wic_dual'/>
                </select>
            `);
            mDatefeccon = new Ax.sql.Date(mDatefeccon);

            mStrSercon = mStrSerjus;

        break;
    }

    //Creació de l'apunt de previsions. 
    mObjPlanconh.jusser = Ax.db.executeFunction('icon_nxt_jusemp','EF', mObjPlanconh.empcode, mStrSerjus, mDateFecha, 'S').toValue();

    let mIntSerial = Ax.db.insert('capuntes', 
        {
            'apteid': 0,
            'diario': 'PR',
            'moneda': 'EUR',
            'empcode': mObjPlanconh.empcode,
            'proyec': `${mObjPlanconh.empcode}0000`,
            'seccio': `${mObjPlanconh.empcode}0000`,
            'jusser': mObjPlanconh.jusser,
            'docser': mObjPlanconh.jusser,
            'fecha': mDateFecha,
            'placon': mStrPlacon,
            'cuenta': mStrCuenta,
            'dimcode1': 0,
            'dimcode2': 0,
            'concep': `Previsions ${mObjPlanconh.concep}`,
            'debe': mDecDebe,
            'haber': mDecHaber,
            'divdeb': mDecDebe,
            'divhab': mDecHaber,
            'sistem': 'A',
            'origen': 'P',
            'user_created': Ax.db.getUser(),
            'date_created': new Ax.sql.Date(),
            'user_updated': Ax.db.getUser(),
            'date_updated': new Ax.sql.Date()
        }
    ).getSerial();

    let mIntApteid1 = mIntSerial;

    let mIntAsient = executeGet(`
        <select>
            <columns>asient</columns>
            <from table='capuntes' />
            <where>
                apteid = ?
            </where>
        </select>  
    `, mIntApteid1);

    let mIntSerial2 = Ax.db.insert('capuntes', 
        {
            'apteid': 0,
            'diario': 'PR',
            'moneda': 'EUR',
            'empcode': mObjPlanconh.empcode,
            'proyec': `${mObjPlanconh.empcode}0000`,
            'seccio': `${mObjPlanconh.empcode}0000`,
            'jusser': mObjPlanconh.jusser,
            'docser': mObjPlanconh.jusser,
            'fecha': mDateFecha,
            'asient': mIntAsient,
            'placon': mStrPlacon,
            'cuenta': mStrContra,
            'dimcode1': 0,
            'dimcode2': 0,
            'concep': `Previsions ${mObjPlanconh.concep}`,
            'debe': mDecHaber,
            'haber': mDecDebe,
            'divdeb': mDecHaber,
            'divhab': mDecDebe,
            'sistem': 'A',
            'origen': 'P',
            'user_created': Ax.db.getUser(),
            'date_created': new Ax.sql.Date(),
            'user_updated': Ax.db.getUser(),
            'date_updated': new Ax.sql.Date()
        }
    ).getSerial();

    let mIntApteid2 = mIntSerial2;

    mIntAsient = executeGet(`
        <select>
            <columns>asient</columns>
            <from table='capuntes' />
            <where>
                apteid = ?
            </where>
        </select>  
    `, mIntApteid2);

    //Creació dels moviments de costos de previsions.
    let mObjMutPlanconjCoge = Ax.db.executeQuery(`
        <select>
            <columns>patdif</columns>
            <from table='mut_planconj_coge' />
            <where>
                empcode = ?
            </where>
        </select>      
    `, mObjPlanconh.empcode).toOne()
        .setRequired(`Patró de selecció de jerarquíes de CC no informat per l'empresa [${mObjPlanconh.empcode}].`);

    let mArrPlanconlCoge = Ax.db.executeQuery(`
        <select>
            <columns>
                REPLACE(grpcen, ${mObjMutPlanconjCoge.patdif}, '') centro, impdif
            </columns>
            <from table='mut_planconl_coge' />
            <where>
                cabid = ?
            </where>
        </select>
    `, pIntCabid).toJSONArray();

    for (let mRow of mArrPlanconlCoge) {
        if (mStrOperac == 'debe-haber') {
            if (mRow.impdif >= 0) {
                mDecDebe = Math.abs(mRow.impdif);
                mDecHaber = 0;
            } else {
                mDecDebe = 0;
                mDecHaber = Math.abs(mRow.impdif);
            }

        } else {
            if (mRow.impdif >= 0) {
                mDecDebe = 0;
                mDecHaber = Math.abs(mRow.impdif);
            } else {
                mDecDebe = Math.abs(mRow.impdif);
                mDecHaber = 0;
            }
        }

        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='ccuentas' />
                <where>
                    placon = ? AND
                    codigo = ? AND
                    tipcta = 'C'
                </where>
            </select>
        `, mStrPlacon, mStrCuenta);

        if (mIntCount) {
            Ax.db.insert('ccoscont', 
                {
                    'orden'  : 0,
                    'apteid' : mIntApteid1,
                    'fecha'  : mDateFecha,
                    'diario' : 'PR',
                    'empcode': mObjPlanconh.empcode,
                    'proyec' : `${mObjPlanconh.empcode}0000`,
                    'seccio' : `${mObjPlanconh.empcode}0000`,
                    'jusser' : mObjPlanconh.jusser,
                    'docser' : mObjPlanconh.jusser,
                    'placon' : mStrPlacon,
                    'cuenta' : mStrCuenta,
                    'ctaexp' : 'GE',
                    'centro' : mRow.centro,
                    'sistem' : 'A',
                    'concep' : `Previsions ${mObjPlanconh.concep}`,
                    'porcen' : 100,
                    'debe'   : mDecDebe,
                    'haber'  : mDecHaber,
                    'cantid1': 0,
                    'cantid2': 0,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date(),
                    'user_updated': Ax.db.getUser(),
                    'date_updated': new Ax.sql.Date()
                }
            )
        }
        
        mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='ccuentas' />
                <where>
                    placon = ? AND
                    codigo = ? AND
                    tipcta = 'C'
                </where>
            </select>
        `, mStrPlacon, mStrCuenta);

        if (mIntCount) {
            Ax.db.insert('ccoscont', 
                {
                    'orden'  : 0,
                    'apteid' : mIntApteid2,
                    'fecha'  : mDateFecha,
                    'diario' : 'PR',
                    'empcode': mObjPlanconh.empcode,
                    'proyec' : `${mObjPlanconh.empcode}0000`,
                    'seccio' : `${mObjPlanconh.empcode}0000`,
                    'jusser' : mObjPlanconh.jusser,
                    'docser' : mObjPlanconh.jusser,
                    'placon' : mStrPlacon,
                    'cuenta' : mStrCuenta,
                    'ctaexp' : 'GE',
                    'centro' : mRow.centro,
                    'sistem' : 'A',
                    'concep' : `Previsions ${mObjPlanconh.concep}`,
                    'porcen' : 100,
                    'debe'   : mDecDebe,
                    'haber'  : mDecHaber,
                    'cantid1': 0,
                    'cantid2': 0,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date(),
                    'user_updated': Ax.db.getUser(),
                    'date_updated': new Ax.sql.Date()
                }
            )
        }
    }

    //Generació de l'apunt de reversió.
    let mRsCapuntes = Ax.db.call('capuntes_duplasto', 
        'R', mObjPlanconh.empcode, mDateFecha, mIntAsient, 
        mObjPlanconh.empcode, mDatefeccon, null, null, null,
        null, mStrSercon, null, 'M', 1, `Reversió Previsions ${mObjPlanconh.concep}`
    );

    if (mRsCapuntes.getRowCount() != 1) {
        throw new Ax.lang.Exception(`No s'ha pogut generar apunt de contrapartida.`)
    }

    
    let mIntIdx = 0;

    for (let mRow of mRsCapuntes) {
        mIntIdx++;
        if (mIntIdx == 1) {
            mObjPlanconh.juscon = mRow.jusser;
        }
    }

    Ax.db.update('capuntes', 
        {
            'origen': 'P'
        }, 
        {
            'jusser': mObjPlanconh.juscon
        }
    )

    //Actualització de l'estat de la plantilla.
    Ax.db.update('mut_planconh', 
        {
            'jusser': mObjPlanconh.jusser,
            'juscon': mObjPlanconh.juscon,
            'estado': 'X'
        }, 
        {
            'cabid': pIntCabid
        }
    )

    let mObj = {'jusser': mObjPlanconh.jusser, 'juscon':mObjPlanconh.juscon};

    return mObj

}