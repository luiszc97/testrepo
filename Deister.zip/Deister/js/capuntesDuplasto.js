/* 
// capuntes_duplasto(p_area, p_empcode, p_fecha, p_asient, .. )        
//                                                                     
// Proceso de duplicacion del asiento contable indicado en p_fecha,    
// p_asient. El nuevo asiento se copiara en diferido o real segun la   
// procedencia del original.                                           
//                                                                     
// p_area                                                              
// ======                                                              
// D   Contabilidad en diferido.                                       
// R   Contabilidad real.                                              
//                                                                     
// p_fecha y p_asient                                                  
// ==================                                                  
// Identificadores asiento a duplicar.                                 
//                                                                     
// p_empcodenew, p_fecnew, p_dianew, etc..                             
// =======================================                             
// Estos parametros sustituiran valores en el nuevo asiento si vienen  
// informados.                                                         
//                                                                     
// Devuelve fecha y numero del nuevo asiento.
*/     
function capuntesDuplasto(
    pStrArea,
    pStrEmpcode,   
    pDateFecha,     
    pIntAsient,    
    pStrEmpcodenew,
    pDateFecnew,    
    pStrDianew,    
    pStrPronew,    
    pStrSecnew,    
    pStrSisnew,    
    pStrJusnew,    
    pStrDocnew,    
    pStrOrinew,    
    pIntInvasi,    
    pStrConcep    
) {
    //UPPER de las variables.
    pStrEmpcodenew = pStrEmpcodenew.toUpperCase();
    pStrDianew = pStrDianew.toUpperCase();
    pStrPronew = pStrPronew.toUpperCase();
    pStrSecnew = pStrSecnew.toUpperCase();
    pStrSisnew = pStrSisnew.toUpperCase();
    pStrJusnew = pStrJusnew.toUpperCase();
    pStrDocnew = pStrDocnew.toUpperCase();
    pStrOrinew = pStrOrinew.toUpperCase();

    //Tablas virtuales para actualizar cimpcont.genera al final del proceso.
    let mRsCapuntesGen = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['apteid_new','apteid_old']);
		options.setColumnTypes([Ax.sql.Types.INTEGER,Ax.sql.Types.INTEGER]);
	});

    let mRsCimpcontGen = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['orden_new','genera_old']);
		options.setColumnTypes([Ax.sql.Types.INTEGER,Ax.sql.Types.INTEGER]);
	});

    //Obtiene el nuevo codigo de empresa, aunque, normalmente sera el mismo.
    if (pStrEmpcodenew == null) {
        pStrEmpcodenew = pStrEmpcode;
    }

    //Obtiene el nuevo numero de asiento.
    if (pDateFecnew == null) {
        pDateFecnew = pDateFecha;
    }

    let mIntAstnew = Ax.db.executeFunction('icon_nxt_asient', pStrEmpcodenew, pDateFecnew, 1).toValue();

    //Obtiene el nuevo numero de justificante contable.
    if (pStrJusnew != null) {
        pStrJusnew = Ax.db.executeFunction('icon_nxt_jusemp', 'EF', pStrEmpcodenew, pStrJusnew, pDateFecnew, 'N').toValue();
    }

    //Obtiene el nuevo numero de documento contable.
    if (pStrDocnew != null) {
        pStrDocnew = Ax.db.executeFunction('icon_nxt_docemp', pStrEmpcodenew, pStrDocnew, pDateFecnew, 'N').toValue();
    }

    // =================
    // p_area:          
    // =======          
    //    R = Real      
    //    D = Diferido  
    // =================
    let tabCapuntes;
    let tabCimpcont;
    let tabCcoscont;

    if (pStrArea == 'R') {
        tabCapuntes = 'capuntes';
        tabCimpcont = 'cimpcont';
        tabCcoscont = 'ccoscont';

    } else {
        tabCapuntes = 'captpool';
        tabCimpcont = 'cimppool';
        tabCcoscont = 'ccospool';
    }

    //Obtener mObjCempresa 
    let mObjCempresa = Ax.db.executeQuery(`
        <select>
            <columns>descon</columns>
            <from table='cempresa' />
            <where>
                empcode = ?
            </where>
        </select>
    `, pStrEmpcode).toOne()
        .setRequired(`Empresa [${pStrEmpcode}] no encontrada.`);

    //Verifica la existencia del asiento a duplicar. 
    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*) count</columns>
            <from table='${tabCapuntes}' />
            <where>
                empcode = ? AND
                fecha   = ? AND
                asient  = ?
            </where>
        </select>
    `, pStrEmpcode, pDateFecha, pIntAsient)

    if (mIntCount == 0) {
        throw new Ax.lang.Exception(`Area-Empresa-Fecha-Asiento:[${pStrArea} / ${pStrEmpcode} / ${pDateFecha} / ${pIntAsient}] Inexistente.`)
    }

    //Usuario y fecha-hora creación.
    let mStrUserCreated = Ax.db.getUser();
    let mDateCreated    = new Ax.sql.Date();

    //ASIENTO A DUPLICAR.
    let mArrTabCapuntes = Ax.db.executeQuery(`
        <select>
            <columns>
                ${tabCapuntes}.apteid,
                <nvl>'${pStrDianew}', ${tabCapuntes}.diario</nvl> diario,
                ${tabCapuntes}.moneda, ${tabCapuntes}.cambio,
                '${pStrEmpcodenew}' empcode,
                <nvl>'${pStrPronew}', ${tabCapuntes}.proyec</nvl> proyec,
                <nvl>'${pStrSecnew}', ${tabCapuntes}.seccio</nvl> seccio,
                <nvl>'${pStrJusnew}', ${tabCapuntes}.jusser</nvl> jusser,
                <nvl>'${pStrDocnew}', ${tabCapuntes}.docser</nvl> docser,
                ${pDateFecnew} fecha, ${mIntAstnew} asient, ${tabCapuntes}.orden,
                ${tabCapuntes}.cuenta,  ${tabCapuntes}.dimcode1, ${tabCapuntes}.dimcode2,
                ${tabCapuntes}.codcon,  ${tabCapuntes}.concep,   ${tabCapuntes}.debe,
                ${tabCapuntes}.haber ,  ${tabCapuntes}.divdeb,   ${tabCapuntes}.divhab,
                ${tabCapuntes}.cantid1, ${tabCapuntes}.cantid2,
                <nvl>'${pStrSisnew}', ${tabCapuntes}.sistem</nvl> sistem,
                ${tabCapuntes}.fecval, ${tabCapuntes}.contra, ${tabCapuntes}.codaux,
                ${tabCapuntes}.ctaaux, ${tabCapuntes}.origen, ${tabCapuntes}.loteid,
                ${tabCapuntes}.punteo, ${tabCapuntes}.cosaut
            </columns>
            <from table='${tabCapuntes}' />
            <where>
                empcode = ? AND
                fecha   = ? AND
                asient  = ?
            </where>
        </select>  
    `, pStrEmpcode, pDateFecha, pIntAsient).toJSONArray();

    for (let mRow of mArrTabCapuntes) {
        if (mRow.origen != 'I') {
            //IMPUESTOS
            if (pStrOrinew == null) {
                mRow.origen = mRow.origen;
            } else {
                mRow.origen = pStrOrinew;
            }

            if (mRow.fecval != null) {
                mRow.fecval = mRow.fecval + (pDateFecnew - pDateFecha);
            }

            //Invertir asiento contable
            if (pIntInvasi == 1) {
                //Invertir posición contable o cambiar signo
                if (mObjCempresa.descon == 1) {
                    let mIntBakDebe  = mRow.debe;
                    let mIntBakHaber = mRow.haber;
                    mRow.debe = mIntBakHaber;
                    mRow.haber = mIntBakDebe;
                    mIntBakDebe  = mRow.divdeb;
                    mIntBakHaber = mRow.divhab;
                    mRow.debe = mIntBakHaber;
                    mRow.haber = mIntBakDebe;

                } else {
                    mRow.debe   = mRow.debe * -1;  
                    mRow.haber  = mRow.haber * -1;
                    mRow.divdeb = mRow.divdeb * -1;
                    mRow.divhab = mRow.divhab * -1;
                }

            }

            // La insercion a capuntes/captpool se realiza con la columna cosaut
            // igual a cero para evitar que los programas de costes activen su
            // generación, no obstante , después del insert dejaremos el valor
            // cosaut tal y como estaba planificado en el apunte contable origen.
            let mIntCosautBackup = mRow.cosaut;
            mRow.cosaut = 0;
            let mIntApteid = mRow.apteid;
            mRow.user_created = mStrUserCreated;
            mRow.date_created = mDateCreated;
            mRow.user_updated = mStrUserCreated;
            mRow.date_updated = mDateCreated;

            // Modifica el concepto del apunte, en los casos que la variable p_concep
            //contenga datos, si p_concep contiene '*' no se modifica el contenido del concepto
            if (pStrConcep != '*') {
                mRow.concep = pStrConcep;
            }

            // Insercion de apuntes  
            mRow.apteid = Ax.db.insert(`${tabCapuntes}`, mRow).getSerial();
            
            if (mIntCosautBackup == 1) {
                //El trigger de update no invocará el proceso ccosprog_genera porque solo
                //alteramos el contenido de la columna cosaut.
                Ax.db.execute(`
                    UPDATE ${tabCapuntes}
                       SET cosaut = ${mIntCosautBackup}
                     WHERE apteid = ${mRow.apteid} 
                `)

            }

            //Actualiza v_capuntes_gen. Al final de este traspaso permitira
            //actualizar cimpcont.genera.
            if (mRow.origen == 'I') {
                mRsCapuntesGen.rows().add([ mRow.apteid, mIntApteid]);
            }

            //Traspasa los registros de impuestos (IVA, IRPF, .)
            let mArrCimpcont = Ax.db.executeQuery(`
                <select>
                    <columns>
                        ${tabCimpcont}.orden,  ${tabCimpcont}.apteid, ${tabCimpcont}.genera,
                        ${tabCimpcont}.natfac,
                        ${pDateFecnew} fecha,
                        <eval-date><val unit='d'><days><datefrom>${pDateFecnew}</datefrom><dateto>${pDateFecha}</dateto></days></val><val unit='date'>${tabCimpcont}.fecdoc</val></eval-date> fecdoc,
                        ${tabCimpcont}.fecope, ${tabCimpcont}.fecrec,  ${tabCimpcont}.moneda,
                        ${tabCimpcont}.cambio,
                        '${pStrEmpcodenew}' empcode,
                        <nvl>'${pStrPronew}', ${tabCimpcont}.proyec</nvl> proyec,
                        <nvl>'${pStrSecnew}', ${tabCimpcont}.seccio</nvl> seccio,
                        <nvl>'${pStrJusnew}', ${tabCimpcont}.jusser</nvl> jusser,
                        <nvl>'${pStrDocnew}', ${tabCimpcont}.docser</nvl> docser,
                        ${tabCimpcont}.refter,  ${tabCimpcont}.docrec,  ${tabCimpcont}.tercer,
                        ${tabCimpcont}.tipdir,  ${tabCimpcont}.nombre,  ${tabCimpcont}.cif,
                        ${tabCimpcont}.codnac,  ${tabCimpcont}.codpos,  ${tabCimpcont}.import,
                        ${tabCimpcont}.zimfis,  ${tabCimpcont}.zimter,  ${tabCimpcont}.opeimp,
                        ${tabCimpcont}.codimp,  ${tabCimpcont}.codtra,  ${tabCimpcont}.tipimp,
                        ${tabCimpcont}.basimp,  ${tabCimpcont}.totimp,  ${tabCimpcont}.basdiv,
                        ${tabCimpcont}.totdiv,  ${tabCimpcont}.valida,  ${tabCimpcont}.docgen,
                        ${tabCimpcont}.tipret,  ${tabCimpcont}.imppor,  ${tabCimpcont}.porpro,
                        ${tabCimpcont}.auxchr1, ${tabCimpcont}.auxchr2, ${tabCimpcont}.auxchr3,
                        ${tabCimpcont}.auxchr4, ${tabCimpcont}.auxfec1, ${tabCimpcont}.auxfec2,
                        ${tabCimpcont}.auxnum1, ${tabCimpcont}.auxnum2
                    </columns>
                    <from table='${tabCimpcont}' />
                    <where>
                        apteid = ?
                    </where>
                    <order>
                        orden
                    </order>
                </select>
            `, mIntApteid).toJSONArray();

            for (let mItem of mArrCimpcont) {
                let mIntGenera = mItem.genera;
                mItem.orden = 0;
                mItem.genera = 0;
                mItem.apteid = mRow.apteid;
                mItem.user_created = mStrUserCreated;
                mItem.date_created = mDateCreated;
                mItem.user_updated = mStrUserCreated;
                mItem.date_updated = mDateCreated;

                //Invertir asiento contable
                if (pIntInvasi == 1) {
                    mItem.import = mItem.import * -1; 
                    mItem.basimp = mItem.basimp * -1;
                    mItem.totimp = mItem.totimp * -1;
                    mItem.basdiv = mItem.basdiv * -1;
                    mItem.totdiv = mItem.totdiv * -1;
                }

                //Insercion del registro de impuestos
                let mIntOrden = Ax.db.insert(`${tabCimpcont}`, mItem).getSerial();

                //Actualiza v_cimpcont_gen. Al final de este traspaso permitira
                //actualizar cimpcont.genera.
                if (mIntGenera != 0) {
                    mRsCimpcontGen.rows().add([ mIntOrden, mIntGenera ]);
                }

            }

            //Traspasa los costes 
            let mArrCcoscont = Ax.db.executeQuery(`
                <select>
                    <columns>
                        ${mRow.apteid} apteid, ${pDateFecnew} fecha,
                        <nvl>'${pStrDianew}', ${tabCcoscont}.diario</nvl> diario,
                        '${pStrEmpcodenew}' empcode,
                        <nvl>'${pStrPronew}', ${tabCcoscont}.proyec</nvl> proyec,
                        <nvl>'${pStrSecnew}', ${tabCcoscont}.seccio</nvl> seccio,
                        <nvl>'${pStrJusnew}', ${tabCcoscont}.jusser</nvl> jusser,
                        <nvl>'${pStrDocnew}', ${tabCcoscont}.docser</nvl> docser,
                        <nvl>'${pStrSisnew}', ${tabCcoscont}.sistem</nvl> sistem,
                        ${tabCcoscont}.cuenta, ${tabCcoscont}.dimcode1, ${tabCcoscont}.dimcode2,
                        ${tabCcoscont}.ctaexp, ${tabCcoscont}.centro,   ${tabCcoscont}.codcon,
                        ${tabCcoscont}.concep, ${tabCcoscont}.porcen,   ${tabCcoscont}.debe,
                        ${tabCcoscont}.haber,  ${tabCcoscont}.cantid1,  ${tabCcoscont}.cantid2
                    </columns>
                    <from table='${tabCcoscont}' />
                    <where>
                        apteid = ? AND
                        orden  &gt; 0
                    </where>
                </select>
            `, mIntApteid).toJSONArray();

            for (const mItem of mArrCcoscont) {
                mItem.orden = 0;
                mItem.user_created = mStrUserCreated;
                mItem.date_created = mDateCreated;
                mItem.user_updated = mStrUserCreated;
                mItem.date_updated = mDateCreated;

                //Modifica el concepto del apunte, en los casos que la variable p_concep
                //contenga datos, si p_concep contiene '*' no se modifica el contenido del concepto
                if (pStrConcep != '*') {
                    mItem.concep = pStrConcep;             
                }

                //Invertir asiento contable
                if (pIntInvasi == 1) {
                    //Invertir posición contable o cambiar signo
                    if (mObjCempresa.descon == 1) {
                        let mIntBakDebe = mItem.debe;
                        let mIntBackHaber = mItem.haber;
                        mItem.debe = mIntBackHaber;
                        mItem.haber = mIntBakDebe;
                    } else {
                        mItem.debe = mItem.debe * -1;
                        mItem.haber = mItem.haber * -1;
                    }

                }

                //Acceso a un script customizable con reglas personalizadas
                Ax.db.insert(`${tabCcoscont}`, mItem);

            }

            /*
            //  Traspasa los efectos                                               
            //                                                       
            //  Antes de nada montamos el where, ya que en función de dónde obtenga
            //  los datos, las condiciones son unas u otras                        
            */
           let mStrWhereCefectos;
           let mStrTabCefectos;
           let mStrTabCefectosIns;
           if (pStrArea == 'R') {
                mStrWhereCefectos = `numero IN (SELECT numero FROM cefectos WHERE apteid = ${mIntApteid}) AND
                                     numord = (SELECT MIN(s.numord) FROM cefechis s
                                             WHERE s.numero = cefechis.numero)`;
                
                mStrTabCefectos = 'cefechis';
                mStrTabCefectosIns = 'cefectos';

           } else {
                mStrWhereCefectos = `apteid = ${mIntApteid}`;
                mStrTabCefectos = 'cefepool';
                mStrTabCefectosIns = 'cefepool';
           }
           
           let mArrTabCefectos = Ax.db.executeQuery(`
                <select prefix='cefectos_'>
                    <columns>
                        ${mRow.apteid} apteid,
                        ${mStrTabCefectos}.tercer, ${mStrTabCefectos}.cuenta, ${mStrTabCefectos}.clase,
                        <eval-date><val unit='d'><days><datefrom>${pDateFecnew}</datefrom><dateto>${pDateFecha}</dateto></days></val><val unit='date'>${mStrTabCefectos}.fecha</val></eval-date> fecha,
                        <eval-date><val unit='d'><days><datefrom>${pDateFecnew}</datefrom><dateto>${pDateFecha}</dateto></days></val><val unit='date'>${mStrTabCefectos}.fecven</val></eval-date> fecven,
                        <nvl>'${pStrJusnew}', ${mStrTabCefectos}.jusser</nvl> jusser,

                        <nvl>'${pStrDocnew}', ${mStrTabCefectos}.docser</nvl> docser,
                        ${mStrTabCefectos}.numefe, ${mStrTabCefectos}.import,
                        '${pStrEmpcodenew}' empcode,
                        <nvl>'${pStrPronew}', ${mStrTabCefectos}.proyec</nvl> proyec,
                        <nvl>'${pStrSecnew}', ${mStrTabCefectos}.seccio</nvl> seccio,
                        ${mStrTabCefectos}.tipefe, ${mStrTabCefectos}.estado, ${mStrTabCefectos}.caduca,
                        <nvl>'${pStrSisnew}', ${mStrTabCefectos}.sistem</nvl> sistem,
                        ${mStrTabCefectos}.codper, ${mStrTabCefectos}.numban,
                        (CASE WHEN '${pStrEmpcode}' = '${pStrEmpcodenew}'
                                THEN ${mStrTabCefectos}.ctafin
                                ELSE NULL
                            END) ctafin,
                        ${mStrTabCefectos}.impiva, ${mStrTabCefectos}.impret,
                        ${mStrTabCefectos}.tipdoc, ${mStrTabCefectos}.moneda,
                        ${mStrTabCefectos}.cambio, ${mStrTabCefectos}.impdiv,
                        ${mStrTabCefectos}.codppa, <today/> feccam, ${pDateFecnew} feccon,
                        <eval-date><val unit='d'><days><datefrom>${pDateFecnew}</datefrom><dateto>${pDateFecha}</dateto></days></val><val unit='date'>${mStrTabCefectos}.fecaux</val></eval-date> fecaux,
                        ${mStrTabCefectos}.agente, ${mStrTabCefectos}.parest
                    </columns>
                    <from table='${mStrTabCefectos}' />
                    <where>
                        ${mStrWhereCefectos}
                    </where>
                </select>
           `);

            for (let mItem of mArrTabCefectos) {
                mItem.numero = 0;
                mItem.gastos = 0;
                mItem.difcam = 0;
                mItem.impppa = 0;
                mItem.numori = 0;
                mItem.numdes = 0;
                mItem.opeant = 0;
                mItem.openum = 1;
                mItem.user_created = mStrUserCreated;
                mItem.date_created = mDateCreated;
                mItem.user_updated = mStrUserCreated;
                mItem.date_updated = mDateCreated;

                //Invertir asiento contable
                if (pIntInvasi == 1) {
                    mItem.import = mItem.import * -1;
                    mItem.impdiv = mItem.impdiv * -1;
                    mItem.impiva = mItem.impiva * -1;
                    mItem.impret = mItem.impret * -1;
                }   
                
                //Insercion del registro de efectos
                Ax.db.insert(`${mStrTabCefectosIns}`, mItem);

            }
            
        }
    }

    //Ponemos el genera de los impuestos como corresponde.
    for (let mRow of mRsCimpcontGen) {
        for (let mItem of mRsCapuntesGen) {
            if (mRow.genera_old == mItem.apteid_old) {
                Ax.db.update(`${tabCimpcont}`, 
                    {
                        'genera': mItem.apteid_new
                    }, 
                    {
                        'orden': mRow.orden_new
                    }
                )
            }
        }
    }

    //Borrado de las tablas virtuales para el enlace de cimpcont.genera 
    mRsCapuntesGen.clear();
    mRsCimpcontGen.clear();
    
    //Obtiene el justificante y el documento del nuevo asiento.
    let mIntOApteid = Ax.db.executeGet(`
        <select>
            <columns>MIN(apteid) apteid</columns>
            <from table='#tab_capuntes' />
            <where>
                empcode = ? AND
                fecha   = ? AND
                asient  = ?
            </where>
        </select>   
    `, pStrEmpcodenew, pDateFecnew, mIntAstnew);

    let mObjO = Ax.db.executeQuery(`
        <select>
            <columns>
                jusser, docser
            </columns>
            <from table='#tab_capuntes' />
            <where>
                apteid = ?
            </where>
        </select>
    `, mIntOApteid).toOne();

    //Resultados en tabla virtual mRsOutputDuplasto  
    let mRsOutputDuplasto = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['area','empcode','fecha','asient','jusser','docser']);
		options.setColumnTypes([Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.DATE, Ax.sql.Types.INTEGER, Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR]);
	});

    mRsOutputDuplasto.rows().add([ pStrArea, pStrEmpcodenew, pDateFecnew, mIntAstnew, mObjO.juseer, mObjO.docser]);

    //Retorna el RS. 
    return mRsOutputDuplasto;

}