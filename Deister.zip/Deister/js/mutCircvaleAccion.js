function mutCircvaleAccion(
    pStrTabname,
    pIntCabid,
    pStrAccion,
    pStrCircui,
    pIntOrden,
    pIntIncide,
    pStrComent) {

   //I Iniciar  
   //E Etiquetar
   //V Vincular PDF
   //A Acceptar
   //R Rebutjar
   //D Reestablir
   //F Finalitzar
   //C Comentari
   
    let mIntNumhis = Ax.db.executeGet(`
        <select>
            <columns><nvl>MAX(numhis),0</nvl> + 1 numhis</columns>
            <from table='mut_circvala' />
            <where>
                tabname = ? AND
                cabid   = ?
            </where>
        </select>   
     `, pStrTabname, pIntCabid);

    let mObjCircvale;

    switch (pStrAccion) {
        //Iniciar
        case 'I':
            Ax.db.insert('mut_circvale',
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid,
                    'estado': 'I',
                    'circui': pStrCircui,
                    'orden': null,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date(),
                    'user_updated': Ax.db.getUser(),
                    'date_updated': new Ax.sql.Date()
                }
            );

            Ax.db.insert('mut_circvala',
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid,
                    'numhis': mIntNumhis,
                    'accion': pStrCircui,
                    'circui': 'I',
                    'orden': null,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date(),
                }
            );

        break;

        //ETIQUETAR
        case 'E':
            mObjCircvale = Ax.db.executeQuery(`
                <select>
                    <columns>circui, orden</columns>
                    <from table='mut_circvale' />
                    <where>
                        tabname = ? AND
                        cabid   = ?
                    </where>
                </select>      
            `, pStrTabname, pIntCabid).toOne(); 

            Ax.db.insert('mut_circvala',
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid,
                    'numhis': mIntNumhis,
                    'accion': 'E',
                    'circui': mObjCircvale.circui,
                    'orden': mObjCircvale.orden,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date(),
                }
            );

        break;
        
        // VINCULAR PDF.  
        case 'V':
            mObjCircvale = Ax.db.executeQuery(`
                <select>
                    <columns>circui, orden, estado</columns>
                    <from table='mut_circvale' />
                    <where>
                        tabname = ? AND
                        cabid   = ?
                    </where>
                </select>
            `, pStrTabname, pIntCabid).toOne();

            let mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_circvall' />
                    <where>
                        circui = ?
                    </where>
                </select>          
            `, mObjCircvale.circui);

            if (mObjCircvale.estado != 'V') {
                if (mIntCount) {
                    if (mObjCircvale.orden == null) {
                        mObjCircvale.orden = Ax.db.executeGet(`
                            <select>
                                <columns>MIN(orden) orden</columns>
                                <from table='mut_circvall' />
                                <where>
                                    circui = ?
                                </where>
                            </select>    
                        `, mObjCircvale.circui);
                    }

                    Ax.db.update('mut_circvale', 
                        {
                            'estado': 'P',
                            'orden': mObjCircvale.orden
                        }, 
                        {
                            'tabname': pStrTabname,
                            'cabid': pIntCabid
                        }
                    )

                } else {
                    Ax.db.update('mut_circvale', 
                        {
                            'estado': 'V',
                            'orden': null
                        }, 
                        {
                            'tabname': pStrTabname,
                            'cabid': pIntCabid
                        }
                    )
                }
            }

            Ax.db.insert('mut_circvala', 
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid,
                    'numhis': mIntNumhis,
                    'accion': 'V',
                    'circui': mObjCircvale.circui,
                    'orden': null,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date()
                }
            )

        break;

        //ACCEPTAR.
        case 'A':
            mObjCircvale = Ax.db.executeQuery(`
                <select>
                    <columns>
                        mut_circvale.circui, mut_circvale.orden,
                        mut_circvall.codusr, mut_circvall.usralt,
                        mut_circvale.indcom
                    </columns>
                    <from table='mut_circvale'>
                        <join table='mut_circvall'>
                            <on>mut_circvale.circui = mut_circvall.circui</on>
                            <on>mut_circvale.orden  = mut_circvall.orden</on>
                        </join>
                    </from>
                    <where>
                        mut_circvale.tabname = ? AND
                        mut_circvale.cabid   = ?
                    </where>
                </select>            
            `, pStrTabname, pIntCabid).toOne();

            if (
                !(
                    (Ax.db.getUser() == mObjCircvale.usralt) ||
                    (Ax.db.getUser() == mObjCircvale.codusr) ||
                    (Ax.db.getUser() == 'srf') ||
                    (Ax.db.getUser() == '43449838D')
                )
            ){
                throw new Ax.lang.Exception(`Usuari [${Ax.db.getUser()}] no autoritzat.`)
            }

            let mIntNxtord = null;

            mIntNxtord = Ax.db.executeGet(`
                <select>
                    <columns>
                        first 1 orden nxtord
                    </columns>
                    <from table='mut_circvall' />
                    <where>
                        circui =   ? AND
                        orden &gt; ?
                    </where>
                    <order>orden ASC</order>
                </select>
            `, mObjCircvale.circui , mObjCircvale.orden);

            if (pStrComent != null) {
                Ax.db.update('mut_circvale', 
                    {
                        'indcom': 1
                    }, 
                    {
                        'tabname': pStrTabname,
                        'cabid': pIntCabid,
                        'indcom': 0
                    }
                )
            }

            if (mIntNxtord != null) {
                Ax.db.update('mut_circvale', 
                    {
                        'estado': 'P',
                        'orden':  mIntNxtord
                    }, 
                    {
                        'tabname': pStrTabname,
                        'cabid': pIntCabid
                    }
                )

            } else {
                Ax.db.update('mut_circvale', 
                    {
                        'estado': 'V',
                        'orden':  null
                    }, 
                    {
                        'tabname': pStrTabname,
                        'cabid': pIntCabid
                    }
                )
            }

            Ax.db.insert('mut_circvala',
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid,
                    'numhis': mIntNumhis,
                    'accion': 'A',
                    'circui': mObjCircvale.circui,
                    'orden': mObjCircvale.orden,
                    'coment': pStrComent,
                    'vigent': 1,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date(),
                }
            );

        break;
        
        //REBUTJAR.
        case 'R':
            mObjCircvale = Ax.db.executeQuery(`
                <select>
                    <columns>
                        mut_circvale.circui, mut_circvale.orden,
                        mut_circvall.codusr, mut_circvall.usralt
                    </columns>
                    <from table='mut_circvale'>
                        <join table='mut_circvall'>
                            <on>mut_circvale.circui = mut_circvall.circui</on>
                            <on>mut_circvale.orden  = mut_circvall.orden</on>
                        </join>
                    </from>
                    <where>
                        mut_circvale.tabname = ? AND
                        mut_circvale.cabid   = ?
                    </where>
                </select>            
            `, pStrTabname, pIntCabid).toOne();

            if (
                !(
                    (Ax.db.getUser() == mObjCircvale.usralt) ||
                    (Ax.db.getUser() == mObjCircvale.codusr) ||
                    (Ax.db.getUser() == 'srf') ||
                    (Ax.db.getUser() == '43449838D')
                )
            ){
                throw new Ax.lang.Exception(`Usuari [${Ax.db.getUser()}] no autoritzat.`)
            }

            if (pStrComent != null) {
                Ax.db.update('mut_circvale', 
                    {
                        'indcom': 1
                    }, 
                    {
                        'tabname': pStrTabname,
                        'cabid':   pIntCabid,
                        'indcom':  0
                    }
                )
            }

            switch (pIntIncide) {
                case 2:
                    let mIntPrvord = Ax.db.executeGet(`
                        <select>
                            <columns>
                                first 1 orden prvord
                            </columns>
                            <from table='mut_circvall' />
                            <where>
                                circui =   ? AND
                                orden &lt; ?
                            </where>
                            <order>orden DESC</order>
                        </select>        
                    `, mObjCircvale.circui, mObjCircvale.orden);

                    if (mIntPrvord == null) {
                        throw new Ax.lang.Exception(`Validador en primera posició del circuit. No es pot retrocedir.`);
                    }

                    Ax.db.update('mut_circvale', 
                        {
                            'estado': 'P',
                            'orden': mIntPrvord
                        }, 
                        {
                            'tabname': pStrTabname,
                            'cabid':   pIntCabid
                        }
                    )

                    Ax.db.execute(`
                        UPDATE mut_circvala
                            SET vigent = 0
                        WHERE 
                            tabname = '${pStrTabname}' 
                            AND cabid = ${pIntCabid}
                            AND numhis <= ${mIntNumhis} 
                            AND accion  IN ('A','R')
                            AND orden = ${mIntPrvord}
                            AND vigent  = 1
                    `);

                    break;
            
                default:
                    Ax.db.update('mut_circvale', 
                        {
                            'estado': 'R',
                            'orden' : null
                        }, 
                        {
                            'tabname': pStrTabname,
                            'cabid'  : pIntCabid
                        }
                    )

                    break;
            }

            Ax.db.insert('', 
                {
                    'tabname': pStrTabname,
                    'cabid'  : pIntCabid,
                    'numhis' : mIntNumhis,
                    'accion' : 'R',
                    'circui' : mObjCircvale.circui,
                    'orden'  : mObjCircvale.orden,
                    'incide' : pIntIncide,
                    'coment' : pStrComent,
                    'vigent' : 1,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date()
                }
            )

        break;

        //REESTABLIR.
        case 'D':
            let mStrEstado = Ax.db.executeGet(`
                <select>
                    <columns>estado</columns>
                    <from table='mut_circvale' />
                    <where>
                        tabname = ? AND
                        cabid   = ?
                    </where>
                </select>            
            `, pStrTabname, pIntCabid);

            switch (mStrEstado) {
                case 'I':
                    Ax.db.insert('mut_circvala', 
                        {
                            'cabid' : pIntCabid,
                            'numhis': mIntNumhis,
                            'accion': 'D',
                            'circui': pStrCircui,
                            'orden': pIntOrden,
                            'user_created': Ax.db.getUser(),
                            'date_created': new Ax.sql.Date()
                        }
                    )

                    Ax.db.update('mut_circvale', 
                        {
                            'circui': pStrCircui,
                            'orden': null
                        }, 
                        {
                            'tabname': pStrTabname,
                            'cabid': pIntCabid
                        }
                    )
                    
                break;
            
                default:
                    Ax.db.execute(`
                        UPDATE mut_circvala
                           SET vigent = 0
                         WHERE tabname = '${pStrTabname}' 
                           AND cabid   = ${pIntCabid}
                           AND numhis  < ${mIntNumhis} 
                           AND accion  IN ('A','R')
                           AND orden   >= ${pIntOrden}
                           AND vigent  = 1
                    `);

                    Ax.db.insert('mut_circvala',
                        {
                            'tabname': pStrTabname,
                            'cabid'  : pIntCabid,
                            'numhis' : mIntNumhis,
                            'accion' : 'D',
                            'circui' : pStrCircui,
                            'orden'  : pIntOrden,
                            'user_created': Ax.db.getUser(),
                            'date_created': new Ax.sql.Date()
                        }
                    );

                    let mIntCount = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='mut_circvall' />
                            <where>
                                circui = ?
                            </where>
                        </select>                    
                    `, pStrCircui);

                    if (mIntCount) {
                        Ax.db.update('', 
                            {
                                'estado': 'P',
                                'circui': pStrCircui,
                                'orden':  pIntOrden,
                                'indcom': 0
                            }, 
                            {
                                'tabname': pStrTabname,
                                'cabid': pIntCabid
                            }
                        )

                    } else {
                        Ax.db.update('mut_circvale',
                            {
                                'estado': 'V',
                                'circui': pStrCircui,
                                'orden': null,
                                'indcom': 0
                            },
                            {
                                'tabname': pStrTabname,
                                'cabid': pIntCabid
                            }
                        )

                    }                    

                break;
            }

        break;

        //FINALITZAR
        case 'F':
            let mStrCircui = Ax.db.executeGet(`
                <select>
                    <columns>circui</columns>
                    <from table='mut_circvale' />
                    <where>
                        tabname = ? AND
                        cabid   = ?
                    </where>
                </select>            
            `, pStrTabname, pIntCabid);

            Ax.db.update('mut_circvale', 
                {
                    'estado': 'V',
                    'circui': mStrCircui,
                    'orden':  null,
                    'indcom': 1 
                }, 
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid
                }
            )

            Ax.db.insert('mut_circvala', 
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid,
                    'numhis': mIntNumhis,
                    'accion': 'F',
                    'circui': mStrCircui,
                    'orden': null,
                    'coment': pStrComent,
                    'vigent': 1,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date()
                }
            )

        break;

        //COMENTARI
        case 'C':
            let mStrCircui2 = Ax.db.executeGet(`
                <select>
                    <columns>circui</columns>
                    <from table='mut_circvale' />
                    <where>
                        tabname = ? AND
                        cabid   = ?
                    </where>
                </select>            
            `, pStrTabname, pIntCabid);

            Ax.db.insert('mut_circvala', 
                {
                    'tabname': pStrTabname,
                    'cabid': pIntCabid,
                    'numhis': mIntNumhis,
                    'accion': 'C',
                    'circui': mStrCircui2,
                    'orden': null,
                    'coment': pStrComent,
                    'vigent': 1,
                    'user_created': Ax.db.getUser(),
                    'date_created': new Ax.sql.Date()
                }
            )

        break;

        default:
            throw new Ax.lang.Exception(`Acción [${pStrAccion}] no contemplada.`)
        break;
    }
   
}