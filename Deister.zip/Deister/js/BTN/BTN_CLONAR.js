pIntFileSeqno = data.file_seqno;
pStrTippre    = field.tippre;
pStrCodexp    = field.codexp;
pDatFecdoc    = field.fecdoc;
pStrRefter    = field.docdes;

let mObjCparBc3file = Ax.db.executeQuery(`
    <select>
        <columns>*</columns>
        <from table='cpar_bc3file' />
        <where>
            file_seqno = ?
        </where>
    </select>
`, pIntFileSeqno);

if (pStrTippre == 1) {
    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='cpar_bc3file' />
            <where>
                empcode = ? AND
                codpre  = ? AND
                tippre  = ? AND
                codexp  = ?
            </where>
        </select>
    `, mObjCparBc3file.empcode, mObjCparBc3file.codpre, 
    pStrTippre, pStrCodexp);

    if (mIntCount) {
        throw new Ax.lang.Exception(`Ja existeix el Pressupost ${pStrCodexp} de [${mObjCparBc3file.codpre}].`);
    }

}

mObjCparBc3file.seqno = 0;
mObjCparBc3file.tippre = pStrTippre;
mObjCparBc3file.codexp = pStrCodexp;
mObjCparBc3file.file_name = '-'
mObjCparBc3file.file_memo = '-'
mObjCparBc3file.fecdoc = pDatFecdoc;
mObjCparBc3file.refter = pStrRefter;

mObjCparBc3file.user_created = Ax.db.getUser();
mObjCparBc3file.date_created = new Ax.sql.Date();

let mIntSerial = Ax.db.insert('cpar_bc3file', mObjCparBc3file).getSerial();

let mIntFileSeqno = mIntSerial;

let mIntRowId = Ax.db.executeGet(`
    <select>
        <columns>rowid</columns>
        <from table='cpar_bc3file' />
        <where>
            file_seqno = ?
        </where>
    </select>
`, mIntFileSeqno);

let mArrCparParprelFast = Ax.db.executeQuery(`
    <select>
        <columns>*</columns>
        <from table='cpar_parprel_fast' />
        <where>
            file_seqno = ?
        </where>
        <order>linid</order>
    </select>
`, pIntFileSeqno);

for (let mRow of mArrCparParprelFast) {
    mRow.linid  = 0
    mRow.tippre = pStrTippre;
    mRow.codexp = pStrCodexp;
    mRow.file_seqno = mIntFileSeqno;
    mRow.fecdoc = pDatFecdoc;
    mRow.refter = pStrRefter;
    mRow.docdes = null;

    Ax.db.insert('cpar_parprel_fast', mRow)
}

Ax.db.call('cparBc3file', 'V', mIntRowId);


