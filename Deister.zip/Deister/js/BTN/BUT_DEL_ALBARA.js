let pIntFileSeqno = data.file_seqno;

Ax.db.beginWork();

let mObjCparParprelFast = {};
mObjCparParprelFast.cabid = null;

mObjCparParprelFast = Ax.db.executeQuery(`
    <select>
        <columns>
            DISTINCT gcommovh.cabid, gcommovh.estcab, gcommovh.fconta
        </columns>
        <from table='cpar_parprel_fast'>
            <join table='gcommovh'>
                <on>cpar_parprel_fast.docdes = gcommovh.docser</on>
            </join>
        </from>
        <where>
            cpar_parprel_fast.file_seqno = ?
        </where>
    </select>
`, pIntFileSeqno).toOne();

if (mObjCparParprelFast.cabid == null) {
    return;
}

if (mObjCparParprelFast.estcab == 'F') {
    throw new Ax.lang.Exception(`Albarà facturat. No es pot eliminar.`)
}

if (mObjCparParprelFast.estcab == 'H') {
    throw new Ax.lang.Exception(`Albarà històric. No es pot eliminar.`)
}

if (mObjCparParprelFast.fconta != null) {
    throw new Ax.lang.Exception(`Albarà comptabilitzat. No es pot eliminar.`)
}

Ax.db.delete('gcommovl', 
    {
        'cabid': mObjCparParprelFast.cabid
    }
)

Ax.db.delete('gcommovh', 
    {
        'cabid': mObjCparParprelFast.cabid
    }
)

Ax.db.update('cpar_parprel_fast', 
    {
        'docdes': null
    }, 
    {
        'file_seqno': pIntFileSeqno
    }
)

Ax.db.update('cpar_bc3file', 
    {
        'estado': 'G'
    }, 
    {
        'file_seqno': pIntFileSeqno
    }
)

Ax.db.commitWork();