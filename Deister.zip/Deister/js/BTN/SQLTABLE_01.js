let pStrEmpcode = Ax.context.variable.EMPCODE;
let pStrCodpre  = Ax.context.variable.CODPRE;
let pStrCodexp  = Ax.context.variable.CODEXP;
let pStrCodcap  = Ax.context.variable.CODCAP;
let pIntMosele  = Ax.context.variable.MOSELE;

let mRsOutput = new Ax.rs.Reader().memory(options => {
	options.setColumnNames([
        'empcode', 'codpre', 'nivel', 
        'descri',  'codele', 'rendi', 
        'unidad',  'prepre', 'imppre', 
        'nomter',  'renaco', 'preaco', 
        'impaco',  'impest', 'rencto', 
        'impcto',  'porcen' 
	]);
	options.setColumnTypes([
		Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.INTEGER,
		Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.DOUBLE,
		Ax.sql.Types.VARCHAR, Ax.sql.Types.DOUBLE,  Ax.sql.Types.DOUBLE, 
		Ax.sql.Types.VARCHAR, Ax.sql.Types.DOUBLE,  Ax.sql.Types.DOUBLE,
        Ax.sql.Types.DOUBLE,  Ax.sql.Types.DOUBLE,  Ax.sql.Types.DOUBLE,
        Ax.sql.Types.DOUBLE,  Ax.sql.Types.DOUBLE
	]);

});

let mObjCpar = Ax.db.executeQuery(`
    <select>
        <columns>MIN(fecdoc) fecini, MAX(fecdoc) fecfin</columns>
        <from table='cpar_parprel_fast' />
        <where>
            empcode ${pStrEmpcode} AND
            codpre  ${pStrCodpre}  AND
            tippre  = '4'
        </where>
    </select>
`).toOne();

mObjCpar.anyini = null;
mObjCpar.mesini = null;
mObjCpar.anyfin = null;
mObjCpar.mesfin = null;

if (mObjCpar.fecini != null) {

    let mDatFecIni = new Ax.sql.Date(mObjCpar.fecini)
    let mIntAnyIni = mDatFecIni.getFullYear();
    let mIntMesIni = mDatFecIni.getMonth();

    let mDatFecFin = new Ax.sql.Date(mObjCpar.fecfin)
    let mIntAnyFin = mDatFecFin.getFullYear();
    let mIntMesFin = mDatFecFin.getMonth() ;

    mObjCpar.anyini = mIntAnyIni;
    mObjCpar.mesini = mIntMesIni + 1;
    mObjCpar.anyfin = mIntAnyFin;
    mObjCpar.mesfin = mIntMesFin + 1;

    let mIntIdx = -1;

    for (let mAnyIdx = mObjCpar.anyini; mAnyIdx <= mObjCpar.anyfin; mAnyIdx++) {
        if (mAnyIdx == mObjCpar.anyini) {
            mObjCpar.mesmin = mObjCpar.mesini;
        } else {
            mObjCpar.mesmin = 1
        }

        if (mAnyIdx == mObjCpar.anyfin) {
            mObjCpar.mesmax = mObjCpar.mesfin;
        } else {
            mObjCpar.mesmax = 12
        }

        for (let mMesIdx = mObjCpar.mesmin; mMesIdx <= mObjCpar.mesmax; mMesIdx++) {
            mIntIdx = mIntIdx + 1;

            let mStrIdx = mIntIdx.toString().lpad('0', 2);

            mRsOutput.cols().add(`renc${mStrIdx}`, Ax.sql.Types.DOUBLE);
            mRsOutput.cols().add(`impc${mStrIdx}`, Ax.sql.Types.DOUBLE);
        }
    }
}

let mArrCparParprelFast = Ax.db.executeQuery(`
    SELECT 
        p.empcode,
        p.codpre,
        p.nivel,
        p.codobr,
        p.codcap,
        p.codsub1,
        p.codsub2,
        p.codsub3,
        p.codsub4,
        p.codsub5,
        p.numele,
        p.codele,
        LPAD('',4*(p.nivel+(CASE WHEN p.codele IS NOT NULL THEN 1 ELSE 0 END)-1)) ||
        CASE WHEN p.codele IS NULL
            THEN CASE WHEN p.codele IS NULL AND p.nivel IN (1,2) THEN TRIM(p.codcap)
                    WHEN p.codele IS NULL AND p.nivel = 3 THEN TRIM(p.codsub1)
                    WHEN p.codele IS NULL AND p.nivel = 4 THEN TRIM(p.codsub2)
                    WHEN p.codele IS NULL AND p.nivel = 5 THEN TRIM(p.codsub3)
                    WHEN p.codele IS NULL AND p.nivel = 6 THEN TRIM(p.codsub4)
                    WHEN p.codele IS NULL AND p.nivel = 7 THEN TRIM(p.codsub5)
                    ELSE ''
                END || ' - '
            ELSE ''
        END || TRIM(SUBSTR(p.descri,1,80)) descri,
        CASE WHEN p.codele IS NOT NULL THEN p.rendi ELSE NULL::DECIMAL END rendi,
        p.unidad,
        CASE WHEN p.codele IS NOT NULL THEN p.precio ELSE CAST(NULL AS decimal (10,2) ) END prepre,
        CASE WHEN p.codele IS NOT NULL THEN ROUND(p.rendi*p.precio,2) ELSE ROUND(p.impniv,2) END imppre,
        SUM(CASE WHEN a.codele IS NOT NULL THEN a.rendi ELSE NULL::DECIMAL END) renaco,
        SUM(CASE WHEN a.codele IS NOT NULL THEN a.precio ELSE CAST(NULL AS decimal (10,2) ) END) preaco,
        SUM(CASE WHEN a.codele IS NOT NULL THEN ROUND(a.rendi*a.precio,2) ELSE ROUND(a.impniv,2) END) impaco,
        SUM(a.impest) impest
            
    FROM cpar_parprel_fast p
        ,OUTER cpar_parprel_fast a
    WHERE 
        p.empcode = a.empcode AND 
        p.codpre  = a.codpre AND 
        NVL(p.codcap, '-')  = NVL(a.codcap, '-') AND 
        NVL(p.codsub1, '-') = NVL(a.codsub1, '-') AND 
        NVL(p.codsub2, '-') = NVL(a.codsub2, '-') AND 
        NVL(p.codsub3, '-') = NVL(a.codsub3, '-') AND 
        NVL(p.codsub4, '-') = NVL(a.codsub4, '-') AND 
        NVL(p.codsub5, '-') = NVL(a.codsub5, '-') AND 
        NVL(p.codele,  '-') = NVL(a.codele, '-')
    AND 
                p.tippre  = '1' AND
                p.empcode ${pStrEmpcode} AND
                p.codpre  ${pStrCodpre}  AND
                p.codexp  = '${pStrCodexp}' AND
                p.codcap  ${pStrCodcap}   AND
                a.tippre  = '3' AND
            (${pIntMosele} = 1 OR (${pIntMosele} = 0 AND p.codele IS NULL))
            
    GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17
    ORDER BY p.empcode,p.codpre,p.codobr,p.codcap,p.codsub1,p.codsub2,p.codsub3,p.codsub4,p.codsub5,p.numele
`);

for (let mRow of mArrCparParprelFast) {
    let mObjFast = {};
    mObjFast.nomter = null;

    mObjFast = Ax.db.executeQuery(`
        SELECT 
            SUM(CASE WHEN codele IS NOT NULL THEN rendi ELSE NULL::DECIMAL END) rencto,
            SUM(CASE WHEN codele IS NOT NULL THEN ROUND(rendi*precio,2) ELSE ROUND(impniv,2) END) impcto
        FROM cpar_parprel_fast
        WHERE tippre  = '4' AND
            empcode = '${mRow.empcode}' AND
            codpre  = '${mRow.codpre}'  AND
            NVL(codcap , '-') = NVL('${mRow.codcap}' , '-') AND
            NVL(codsub1, '-') = NVL('${mRow.codsub1}', '-') AND
            NVL(codsub2, '-') = NVL('${mRow.codsub2}', '-') AND
            NVL(codsub3, '-') = NVL('${mRow.codsub3}', '-') AND
            NVL(codsub4, '-') = NVL('${mRow.codsub4}', '-') AND
            NVL(codsub5, '-') = NVL('${mRow.codsub5}', '-') AND
            NVL(codele , '-') = NVL('${mRow.codele}' , '-')
    `).toOne();

    if (mRow.codele != null) {
        mRow.numreg = Ax.db.executeGet(`
        SELECT COUNT(*) numreg
          FROM cpar_parprel_fast a
                ,OUTER (cpar_bc3file b, OUTER ctercero t)
         WHERE a.file_seqno = b.file_seqno AND 
               b.tercer = t.codigo
           AND 
                a.tippre  = '3' AND
                a.empcode = '${mRow.empcode}' AND
                a.codpre  = '${mRow.codpre}'  AND
                a.codexp  = '${pStrCodexp}'  AND
                NVL(a.codcap , '-') = NVL('${mRow.codcap}' , '-') AND
                NVL(a.codsub1, '-') = NVL('${mRow.codsub1}', '-') AND
                NVL(a.codsub2, '-') = NVL('${mRow.codsub2}', '-') AND
                NVL(a.codsub3, '-') = NVL('${mRow.codsub3}', '-') AND
                NVL(a.codsub4, '-') = NVL('${mRow.codsub4}', '-') AND
                NVL(a.codsub5, '-') = NVL('${mRow.codsub5}', '-') AND
                a.codele = '${mRow.codele}'
        `);

        if (mRow.numreg > 1) {
            throw new Ax.lang.Exception(`${mRow.numreg} industrials en acords per la partida [${mRow.codcap}-${mRow.codsub1 || ''}-${mRow.codsub2 || ''}-${mRow.codsub3 || ''}-${mRow.codsub4 || ''}-${mRow.codsub5 || ''}:${mRow.codele}].`);
        }

        mObjFast.nomter = Ax.db.executeGet(`
            SELECT NVL(t.nomaux, t.nombre) nomter
              FROM cpar_parprel_fast a
                    ,OUTER (cpar_bc3file b, OUTER ctercero t)
            WHERE a.file_seqno = b.file_seqno AND 
                  b.tercer = t.codigo
            AND 
                a.tippre  = '3' AND
                a.empcode = '${mRow.empcode}' AND
                a.codpre  = '${mRow.codpre}'  AND
                a.codexp  = '${pStrCodexp}'   AND
                NVL(a.codcap , '-') = NVL('${mRow.codcap}', '-') AND
                NVL(a.codsub1, '-') = NVL('${mRow.codsub1}' '-') AND
                NVL(a.codsub2, '-') = NVL('${mRow.codsub2}' '-') AND
                NVL(a.codsub3, '-') = NVL('${mRow.codsub3}' '-') AND
                NVL(a.codsub4, '-') = NVL('${mRow.codsub4}' '-') AND
                NVL(a.codsub5, '-') = NVL('${mRow.codsub5}' '-') AND
                a.codele = '${mRow.codele}'
        `);
    
    }

    mObjFast.empcode = mRow.empcode;
    mObjFast.codpre  = mRow.codpre;
    mObjFast.nivel   = mRow.nivel;
    mObjFast.descri  = mRow.descri;
    mObjFast.codele  = mRow.codele;
    mObjFast.rendi   = mRow.rendi;
    mObjFast.unidad  = mRow.unidad;
    mObjFast.prepre  = mRow.prepre;
    mObjFast.imppre  = mRow.imppre;     
    
    if (mObjFast.codele != null) {
        mObjFast.nomter = null;
    }

    mObjFast.renaco = mRow.renaco;
    mObjFast.preaco = mRow.preaco;
    mObjFast.impaco = mRow.impaco;
    mObjFast.impest = mRow.impest;

    if (mObjFast.impaco != 0) {
        mObjFast.porcen = (mObjFast.impcto/mObjFast.impaco) * 100;
    } else {
        mObjFast.porcen = 0;
    }

    if (mObjCpar.fecini != null) {
        let mIntIdx = -1;

        for (let mAnyIdx = mObjCpar.anyini; mAnyIdx <= mObjCpar.anyfin; mAnyIdx++) {
            if (mAnyIdx == mObjCpar.anyini) {
                mObjCpar.mesmin = mObjCpar.mesini;
            } else {
                mObjCpar.mesmin = 1
            }
    
            if (mAnyIdx == mObjCpar.anyfin) {
                mObjCpar.mesmax = mObjCpar.mesfin;
            } else {
                mObjCpar.mesmax = 12
            }

            for (let mMesIdx = mObjCpar.mesmin; mMesIdx <= mObjCpar.mesmax; mMesIdx++) {
                mIntIdx = mIntIdx + 1;
    
                let mStrIdx = mIntIdx.toString().lpad('0', 2);

                let mStrRenc = `renc${mStrIdx}`;
                let mStrimpc = `impc${mStrIdx}`;

                let mObjO = Ax.db.executeQuery(`
                    SELECT 
                        SUM(c.rendi) ${mStrRenc},
                        SUM(CASE WHEN c.codele IS NOT NULL
                                THEN c.rendi*c.precio
                                ELSE impniv
                            END) ${mStrimpc}
                        
                    FROM cpar_parprel_fast c
                        ,cpar_bc3file b
                    WHERE 
                        c.file_seqno = b.file_seqno
                    AND 
                        c.empcode = '${mRow.empcode}' AND
                        c.codpre  = '${mRow.codpre}'  AND
                        c.tippre  = '4'           AND
                        NVL(c.codcap , '-') = NVL('${mRow.codcap}' , '-') AND
                        NVL(c.codsub1, '-') = NVL('${mRow.codsub1}', '-') AND
                        NVL(c.codsub2, '-') = NVL('${mRow.codsub2}', '-') AND
                        NVL(c.codsub3, '-') = NVL('${mRow.codsub3}', '-') AND
                        NVL(c.codsub4, '-') = NVL('${mRow.codsub4}', '-') AND
                        NVL(c.codsub5, '-') = NVL('${mRow.codsub5}', '-') AND
                        NVL(c.codele , '-') = NVL('${mRow.codele}' , '-') AND
                        YEAR(c.fecdoc)   = ${mAnyIdx} AND
                        MONTH(c.fecdoc) = ${mMesIdx}              
                `).toOne();

                mObjFast[`${mStrRenc}`] = mObjO[`${mStrRenc}`];
                mObjFast[`${mStrRenc}`] = mObjO[`${mStrRenc}`];

                if (mObjFast[`mStrRenc`] == 0) {
                    mObjFast[`mStrRenc`] = null;

                }
                
            }

        }

    }

    let mArrColumsn = [];

    mArrColumsn.push(mObjFast.empcode);
    mArrColumsn.push(mObjFast.codpre);
    mArrColumsn.push(mObjFast.nivel);
    mArrColumsn.push(mObjFast.descri);
    mArrColumsn.push(mObjFast.codele);
    mArrColumsn.push(mObjFast.rendi);
    mArrColumsn.push(mObjFast.unidad);
    mArrColumsn.push(mObjFast.prepre);
    mArrColumsn.push(mObjFast.imppre);
    mArrColumsn.push(mObjFast.nomter);
    mArrColumsn.push(mObjFast.renaco);
    mArrColumsn.push(mObjFast.preaco);
    mArrColumsn.push(mObjFast.impaco);
    mArrColumsn.push(mObjFast.impest);
    mArrColumsn.push(mObjFast.rencto);
    mArrColumsn.push(mObjFast.impcto);
    mArrColumsn.push(mObjFast.porcen);

    for (const key in mObjFast) {
        if (mObjFast[key].starsWith('renc') || mObjFast[key].starsWith('impc')) {
            mArrColumsn.push(mObjFast[key])            
        }
    }
    mRsOutput.rows().add([mArrColumsn]);

}

Ax.db.execute(`DROP TABLE IF EXISTS tmp_meslbl`);  

Ax.db.execute(`
    <select intotemp='tmp_meslbl'>
        <columns>
            DISTINCT empcode, codpre
        </columns>
        <from table='cpar_parprel_fast' />
        <where>
            empcode ${pStrEmpcode} AND
            codpre  ${pStrCodpre}  AND
            tippre  = '1' 	  AND
            codexp  = '${pStrCodexp}'
        </where>
    </select>
`)

return mRsOutput;
