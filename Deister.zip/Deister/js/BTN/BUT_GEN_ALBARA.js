let pIntFileSeqno = data.file_seqno;
/*
 * =========================================================
 * Selecció de les dades bàsiques de la certificació.
 * =========================================================
 */
let mObjCparBc3file = Ax.db.executeQuery(`
    <select>
        <columns>
            empcode, codpre, codexp, 
            file_memo, tippre, tercer, 
            fecdoc, refter
        </columns>
        <from table='cpar_bc3file' />
        <where>
            file_seqno = ?
        </where>
    </select>
`, pIntFileSeqno).toOne();

let gcommovh = {};
gcommovh.empcode = mObjCparBc3file.empcode;
gcommovh.codpre  = mObjCparBc3file.codpre;
gcommovh.codpar  = '0';
gcommovh.tercer  = mObjCparBc3file.tercer;
gcommovh.fecmov  = mObjCparBc3file.fecdoc;
gcommovh.refter  = mObjCparBc3file.refter;
gcommovh.coment  = mObjCparBc3file.file_memo;

/*
 * =========================================================
 * Comprobacions prèvies. 
 * =========================================================
 */
if (mObjCparBc3file.tippre != '4') {
    throw new Ax.lang.Exception(`No es pot generar Albarà d'un document que no sigui del tipus Certificació.`);
}

if (!mObjCparBc3file.refter.length) {
    throw new Ax.lang.Exception('Referència de proveïdor no informada.');
}

let mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='cpar_parprel_fast' />
        <where>
            file_seqno = ? AND
            codele IS NOT NULL AND
            codart IS NULL
        </where>
    </select>
`, pIntFileSeqno);

if (mIntCount) {
    throw new Ax.lang.Exception('Hi ha partides sense article assignat.');
}

mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='cpar_parprel_fast' />
        <where>
            file_seqno = ? AND
            codele IS NOT NULL AND
            codart IS NOT NULL AND
            NOT EXISTS (SELECT garticul.codigo
                        FROM garticul
                        WHERE cpar_parprel_fast.codart = garticul.codigo)
        </where>
    </select>
`, pIntFileSeqno);

if (mIntCount) {
    throw new Ax.lang.Exception(`Hi ha partides amb un article no definit al mestre d'articles.`);
}

mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='cpar_parprel_fast' />
        <where>
            file_seqno = ? AND
            codele IS NOT NULL AND
            rendi = 0
        </where>
    </select>
`, pIntFileSeqno);

if (mIntCount) {
    throw new Ax.lang.Exception('Hi ha partides amb amidament 0.');
}

/*
 * =========================================================
 * Eliminar, si es dona el cas, l'albarà generat previament. 
 * =========================================================
 */
let mObjCparParprelFast = {};
mObjCparParprelFast.cabid = null;

mObjCparParprelFast = Ax.db.executeQuery(`
    <select>
        <columns>
            DISTINCT gcommovh.cabid, cpar_parprel_fast.docdes
        </columns>
        <from table='cpar_parprel_fast'>
            <join table='gcommovh'>
                <on>cpar_parprel_fast.docdes = gcommovh.docser</on>
            </join>
        </from>
        <where>
            cpar_parprel_fast.file_seqno = ?
        </where>
    </select>
`, pIntFileSeqno).toOne();

if (mObjCparParprelFast.cabid != null) {
    mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='gcommovh' />
            <where>
                docser = ? AND
                estcab IN ('F','H')
            </where>
        </select>
    `, mObjCparParprelFast.docdes);

    if (mIntCount) {
        throw new Ax.lang.Exception(`Albarà en estat Facturat, no es pot regenerar.`);
    }

    Ax.db.delete('gcommovl', 
        {
            'cabid': mObjCparParprelFast.cabid
        }
    )

    Ax.db.delete('gcommovh', 
        {
            'cabid': mObjCparParprelFast.cabid
        }
    )
}

/*
 * =========================================================
 * Determinar tipus d'albarà a generar. 
 * =========================================================
 */
gcommovh.tipdoc = 'NOBR';

mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='cpar_parprel_fast' alias='c1' />
        <where>
            c1.file_seqno = ? AND
            c1.codele IS NOT NULL AND
            c1.codart IN ('TAXES', 'LLICE') AND
            NOT EXISTS (SELECT c2.rowid
                          FROM cpar_parprel_fast c2
                         WHERE c1.file_seqno = c2.file_seqno
                           AND c2.codele IS NOT NULL
                           AND c1.codart NOT IN ('TAXES', 'LLICE'))
        </where>
    </select>
`, pIntFileSeqno);

if (mIntCount) {
    gcommovh.tipdoc = 'NOBT';

} else {
    mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='cempresa' />
            <where>
                tercer = ? AND
                grpent IS NOT NULL
            </where>
        </select>
    `, gcommovh.tercer);

    if (mIntCount) {
        gcommovh.tipdoc = 'ROBR';
    }

}

let mObjCparParpreh = Ax.db.executeQuery(`
    <select>
        <columns>proyec, seccio</columns>
        <from table='cpar_parpreh' />
        <where>
            empcode = ? AND
            codpre  = ?
        </where>
    </select>
`, gcommovh.empcode, gcommovh.codpre).toOne();

gcommovh.delega = null;

let mObjGdeparta = Ax.db.executeQuery(`
    <select first='1'>
        <columns>delega, depart</columns>
        <from table='gdeparta' />
        <where>
            proyec = ? AND
            seccio = ? AND
            estado = 'A'
        </where>
    </select>
`, mObjCparParpreh.proyec, mObjCparParpreh.seccio).toOne()
.setRequired(`Projecte-secció [${mObjCparParpreh.proyec}-${mObjCparParpreh.seccio}] sense departament associat.`);

gcommovh.delega = mObjGdeparta.delega;
gcommovh.depart = mObjGdeparta.depart;

let mStrCond = `${mObjGdeparta.empcode}OBR`

let mObjGalmacen = Ax.db.executeQuery(`
    <select>
        <columns>codigo almori</columns>
        <from table='galmacen' />
        <where>
            codigo = '${mStrCond}'
        </where>
    </select>
`, mObjGdeparta.empcode).toOne()
.setRequired(`Empresa [${mObjGdeparta.empcode}] sense magatzem d'obres.`);

gcommovh.almori = mObjGalmacen.almori;

let gcommovl = {}
gcommovl.cabid =  Ax.db.call('gcommovh_Insert', null, gcommovh);

let mObjGcommovh = Ax.db.executeQuery(`
    <select>
        <columns>rowid, docser</columns>
        <from table='gcommovh' />
        <where>
            cabid = ?
        </where>
    </select>
`, gcommovl.cabid).toOne();

gcommovh.rowid  = mObjGcommovh.rowid;
gcommovh.docser = mObjGcommovh.docser;

Ax.db.update('cpar_parprel_fast', 
    {
        'docdes': gcommovh.docser
    }, 
    {
        'file_seqno': pIntFileSeqno
    }
);

Ax.db.update('cpar_bc3file', 
    {

        'estado': 'T'
    }, 
    {
        'file_seqno': pIntFileSeqno
    }
);

gcommovl.linid = 0;
gcommovl.orden = 0;
gcommovl.varlog = '0';
gcommovl.numlot = '0';
gcommovl.estlin = 'E';
gcommovl.errlin = 0;
gcommovl.ubiori = '0';
gcommovl.ubides = '0';
gcommovl.dtolin = 0;
gcommovl.impnet = 0;

let mArrCparParprelFast = Ax.db.executeQuery(`
    <select>
        <columns>
            cpar_parprel_fast.codart,
            garticul.udmbas udmcom,
            SUM(cpar_parprel_fast.rendi) canmov,
            SUM(ROUND(cpar_parprel_fast.rendi*cpar_parprel_fast.precio,2)) import
        </columns>
        <from table='cpar_parprel_fast'>
            <join table='garticul'>
                <on>cpar_parprel_fast.codart = garticul.codigo</on>
            </join>
        </from>
        <where>
            cpar_parprel_fast.file_seqno = ? AND
            cpar_parprel_fast.codele IS NOT NULL AND
            cpar_parprel_fast.rendi  != 0 AND
            cpar_parprel_fast.precio != 0
        </where>
        <group>1,2</group>
    </select>
`, pIntFileSeqno);

for (let mRow of mArrCparParprelFast) {
    gcommovl.codart = mRow.codart;
    gcommovl.udmcom = mRow.udmcom;
    gcommovl.canmov = mRow.canmov;
    gcommovl.import = mRow.import;

    gcommovl.orden  = gcommovl.orden + 2;
    gcommovl.canpre = 1;
    gcommovl.udmpre = gcommovl.udmcom;
    gcommovl.canmov = 1;
    gcommovl.precio = gcommovl.import;

    delete gcommovl.import;

    Ax.db.insert('gcommovl', gcommovl)

}

Ax.db.call('gcommovh', 'I', gcommovh.rowid)

