let mStrDocdes = null;

mStrDocdes = Ax.db.executeGet(`
    <select>
        <columns>DISTINCT docdes</columns>
        <from table='cpar_parprel_fast' />
        <where>
            file_seqno = ?
        </where>
    </select>
`, data.file_seqno);

if (mStrDocdes != null) {
    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='gcomalbh' />
            <where>
                docser = ? AND
                estcab IN ('E','V')
            </where>
        </select>
    `, mStrDocdes);

    if (mIntCount) {
        let mIntCount2 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gcomalbh' />
                <where>
                    docser = ? AND
                    fconta IS NOT NULL
                </where>
            </select>
        `, mStrDocdes);

        if (mIntCount2) {
            throw new Ax.lang.Exception(`El pressupost té un albarà comptabilitzat.`);
        }

        Ax.db.delete('gcomalbl',
            `
                cabid IN (SELECT gcomalbh.cabid
                            FROM gcomalbh
                           WHERE docser = ?
            `
        , mStrDocdes);

        Ax.db.delete('gcomalbh', 
            {
                'docser': mStrDocdes
            }
        );
    } else {
        throw new Ax.lang.Exception(`El pressupost ja té un albarà associat.`);
    }
}

Ax.db.delete('gcomalbl', 
    {
        'file_seqno': data.file_seqno
    }
);

let mIntRowId = Ax.db.executeGet(`
    <select>
        <columns>rowid</columns>
        <from table='cpar_bc3file' />
        <where>
            file_seqno = ?
        </where>
    </select>
`, data.file_seqno)

Ax.db.call('cparBc3file', 'V', mIntRowId)