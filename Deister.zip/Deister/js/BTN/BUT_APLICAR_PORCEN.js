let pIntFileSeqno = data.file_seqno;
let pDecPorcen    = field.porcen;

let mObjCparBc3file = Ax.db.executeQuery(`
    <select>
        <columns>tippre, estado</columns>
        <from table='cpar_bc3file' />
        <where>
            file_seqno = ?
        </where>
    </select>
`, pIntFileSeqno).toOne();
 
if (mObjCparBc3file.tippre != '4') {
    throw new Ax.lang.Exception(`No es pot aplicar percentatge a amidaments d'un document que no sigui Certificació.`);
}

if (mObjCparBc3file.estado != 'T') {
    throw new Ax.lang.Exception(`No es pot aplicar percentatge a amidaments d'una certificació tancada.`);
}

Ax.db.beginWork();

let mArrCparParprelFast = Ax.db.executeQuery(`
    <select>
        <columns>linid, rendi</columns>
        <from table='cpar_parprel_fast' />
        <where>
            file_seqno = ? AND
            codele IS NOT NULL AND
            rendi != 0
        </where>
    </select>
`, pIntFileSeqno)

for (let mRow of mArrCparParprelFast) {
    Ax.db.update('cpar_parprel_fast', 
        {
            'rendi': mRow.rendi * (pDecPorcen/100)
        }, 
        {
            'linid': mRow.linid
        }
    )
}

Ax.db.commitWork();