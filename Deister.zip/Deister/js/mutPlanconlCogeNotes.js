function mutPlanconlCogeNotes(pIntCabid, pIntNummes, pStrGrpcen) {
    let mObjPlanconh = Ax.db.executeQuery(`
        <select>
            <columns>empcode, numany, ctaori</columns>
            <from table='mut_planconh' />
            <where>
                cabid = ?
            </where>
        </select>
    `, pIntCabid).toOne();

    mObjPlanconh.ctaori = mObjPlanconh.ctaori.replace('ccossalc','ccoscont');

    let mStrCade = `${mObjPlanconh.empcode}SCS3`

    return Ax.db.executeQuery(`
        <select>
            <columns>
                ccoscont.fecha, capuntes.concep,
                ccoscont.debe,  ccoscont.haber,
                ccoscont.debe-ccoscont.haber saldo
            </columns>
            <from table='ccoscont'>
                <join table='capuntes'>
                    <on>ccoscont.apteid = capuntes.apteid</on>
                    <join type='left' table='cenllote'>
                        <on>capuntes.loteid = cenllote.loteid</on>
                        <join table='cenlsubs'>
                            <on>cenllote.loteid = cenlsubs.loteid</on>
                        </join>
                    </join>
                </join>
                <join table='ccosdlin'>
                    <on>ccoscont.centro = ccosdlin.centro</on>
                    <join table='ccosdgrp'>
                        <on>ccosdlin.codgrp = ccosdgrp.codigo</on>
                    </join>
                </join>
            </from>
            <where>
                NOT EXISTS (SELECT capuntes.loteid = cenllote.loteid
                            FROM cenllote, cenlsubs
                            WHERE capuntes.loteid = cenllote.loteid
                            AND cenllote.loteid = cenlsubs.loteid
                            AND cenllote.tabname IN ('gcomfach','gvenfach')) AND
                ccoscont.empcode = '${mObjPlanconh.empcode}' AND
                YEAR(ccoscont.fecha)  = ${mObjPlanconh.numany} AND
                (${pIntNummes} = 0 OR MONTH(ccoscont.fecha) = ${pIntNummes}) AND
                ccoscont.placon  = 'ES' AND
                (${ mObjPlanconh.ctaori}) AND
                ccosdgrp.codigo MATCHES '${mStrCade}' || '*' AND
                ('${pStrGrpcen}' = '-' OR ccosdgrp.codigo = '${pStrGrpcen}')
            </where>
            <order>1</order>
        </select>    
    `);

}