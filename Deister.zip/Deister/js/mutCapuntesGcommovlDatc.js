function mutCapuntesGcommovlDatc(
    pDateFecini,  
    pDateFecfin,  
    pStrEmpcode, 
    pStrProyec,  
    pStrSeccio,  
    pStrSistem,  
    pStrDimcode1,
    pStrDimcode2,
    pStrCuenta,  
    pStrCodaux,  
    pStrCtaaux        
) {
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_capuntes`);  

    Ax.db.execute(`  
        <select intotemp='@tmp_capuntes'>
            <columns>DISTINCT placon, cuenta, jusser</columns>
            <from table='capuntes' />
            <where>
                empcode  ${pStrEmpcode}   AND
                proyec   ${pStrProyec}    AND
                seccio   ${pStrSeccio}    AND
                sistem   ${pStrSistem}    AND
                dimcode1 ${pStrDimcode1}  AND
                dimcode2 ${pStrDimcode2}  AND
                cuenta   ${pStrCuenta}    AND
                codaux   ${pStrCodaux}    AND
                ctaaux   ${pStrCtaaux}    AND
                fecha BETWEEN ${pDateFecini} AND ${pDateFecfin} AND
                asient &gt; 0 AND
                docser NOT <matches>'OBER*'</matches> AND
                docser NOT <matches>'TANC*'</matches> AND
                docser NOT <matches>'AP*'</matches>   AND
                NOT (capuntes.asient = 0 AND
                    capuntes.fecha = (SELECT s.fecini
                                        FROM cperiodo s
                                        WHERE s.empcode = capuntes.empcode
                                        AND ${pDateFecini} BETWEEN s.fecini AND s.fecfin))
            </where>
        </select>
    `, mIntNumany, mIntMesIni, mIntMesfin);

    return Ax.db.executeQuery(`
        <select>
            <columns>
                @tmp_capuntes.cuenta, ccuentas.nombre,
                gcommovd.nomdoc,
                gcommovh.fecmov, gcommovh.docser,
                ROUND(gcommovh.imptot*(100+garticul_tipiva_get_imppor
                    ('gcomalbh',      gcommovh.cabid,  gcommovl.linid,
                    gcommovh.fecmov, gcommovh.tercer, ctercero.requiv,
                    CASE WHEN garticul.cimart = 'BOR' THEN 'NOR'
                        WHEN garticul.cimart = 'BRE' THEN 'NRE'
                        WHEN garticul.cimart = 'BSR' THEN 'NSR'
                        WHEN garticul.cimart = 'BEX' THEN 'NEX'
                        ELSE 'NEX'
                    END))/100, 2) imptot,
                gcommovl.codart, garticul.nomart,
                gcommovl_datc.codpre, gcommovl_datc.codpar,
                ROUND(gcommovl_datc.import*(100+garticul_tipiva_get_imppor
                    ('gcomalbh',      gcommovh.cabid,  gcommovl.linid,
                    gcommovh.fecmov, gcommovh.tercer, ctercero.requiv,
                    CASE WHEN garticul.cimart = 'BOR' THEN 'NOR'
                        WHEN garticul.cimart = 'BRE' THEN 'NRE'
                        WHEN garticul.cimart = 'BSR' THEN 'NSR'
                        WHEN garticul.cimart = 'BEX' THEN 'NEX'
                        ELSE 'NEX'
                    END))/100, 2) import
            </columns>
            <from table='@tmp_capuntes'>
                <join type='left' table='ccuentas'>
                    <on>@tmp_capuntes.placon = ccuentas.placon</on>
                    <on>@tmp_capuntes.cuenta = ccuentas.codigo</on>
                </join>
                <join table='gcommovh'>
                    <on>@tmp_capuntes.jusser = gcommovh.docser</on>
                    <join table='gcommovd'>
                        <on>gcommovh.tipdoc = gcommovd.codigo</on>
                    </join>
                    <join table='ctercero'>
                        <on>gcommovh.tercer = ctercero.codigo</on>
                    </join>
                    <join table='gcommovl'>
                        <on>gcommovh.cabid = gcommovl.cabid</on>
                        <join type='left' table='gcommovl_datc'>
                            <on>gcommovl.linid = gcommovl_datc.linid</on>
                        </join>
                        <join table='garticul'>
                            <on>gcommovl.codart = garticul.codigo</on>
                        </join>
                    </join>
                </join>
            </from>
            <order>1,3,4,6</order>
        </select>    
    `);
}