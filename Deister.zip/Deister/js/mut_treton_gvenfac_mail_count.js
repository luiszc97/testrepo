//Comptador d'incidències per decidir si s'envia email o no. 
function mut_treton_gvenfac_mail_count(){

    let mIntCount = 0;

    let mArrLista = Ax.db.executeQuery(`
        <union>
            <select>
                <columns>
                    DISTINCT DATE(t.fecfac) AS DATA, t.docser AS DOCSER, t.errno AS COMPTADOR, t.errmsg AS MISSATGE
                </columns>
                <from table='mut_treton_gvenfac' alias='t'>
                </from>
                <where>t.errno NOT IN (200,0)
                AND DATE(CURRENT) = DATE(t.date_created)
                </where>
            </select>

            <select>
                <columns>
                    DISTINCT DATE(t.fecfac), t.docser, 1, 'NO COMPTABILITZADA'
                </columns>
                <from table='mut_treton_gvenfac' alias='t'>
                    <join table='gvenfach' alias='f'>
                        <on>f.docser = t.docser </on>
                    </join>
                </from>
                <where>t.errno IN (0)
                AND DATE(CURRENT) = DATE(t.date_created)
                AND f.estcab!='C'
                </where>
            </select>
        </union>    
    `).toJSONArray();

    mArrLista.forEach(e => {
        mIntCount =  mIntCount + 1;

    });

    return mIntCount;

}