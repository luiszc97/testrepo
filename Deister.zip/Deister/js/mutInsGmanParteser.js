function mutInsGmanParteser(
    pDatFecini,
    pStrDocord,
    pStrCodope,
    pStrTiphor,
    pStrHorini,
    pStrHorfin,
    pStrHortot,
    pDecPrecio,
    pStrComent
) {
    if (pStrHorini == null) {
        throw new Ax.lang.Exception(`Hora d'inici no informada.`)
    }

    if (pStrHorfin == null) {
        throw new Ax.lang.Exception('Hora de finalització no informada.')
    }

    let mTimHorini = null;

    let mHour, mMinute;

    if (pStrHorini != '') {
        mHour   = pStrHorini.slice(0, 2);
        mMinute = pStrHorini.slice(3, 5);
        
        mTimHorini = new Ax.sql.Time(mHour,mMinute,0);
    }

    let mTimHorfin = null;

    if (pStrHorfin != '') {
        mHour   = pStrHorfin.slice(0, 2);
        mMinute = pStrHorfin.slice(3, 5);

        mTimHorfin = new Ax.sql.Time(mHour,mMinute,0);
    }

    if (pStrHortot.length == 6) {
        mHour   = pStrHortot.slice(0, 1);
        mMinute = pStrHortot.slice(2, 3);

    } else {
        mHour   = pStrHortot.slice(0, 2);
        mMinute = pStrHortot.slice(3, 5);
    }

    let mHortot = new Ax.sql.Time(mHour,mMinute,0);

    let mObjOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                empcode, tercer, tipdir, codmaq, codser codgrp
            </columns>
            <from table='gman_ordetrah' />
            <where>
                docser = ?
            </where>
        </select>
    `, pStrDocord).toOne();

    let mStrTipdoc;
    let mIntCount;

    switch (mObjOrdetrah.tercer) {
        case 'A58477712': 
            pDatFecini = new Ax.sql.Date(pDatFecini);
            let mIntAny = pDatFecini.getFullYear();

            if (mIntAny >= 2021) {
                mStrTipdoc = 'EXI';
            } else {
                mStrTipdoc = 'EXT';
            }
        break;

        case 'A28061737': 
            mStrTipdoc = 'EXE';
        break;

        case 'V65928277': 
            mStrTipdoc = 'MODE';
        break;

        case 'PLS': 
            mStrTipdoc = 'MODB';

            mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='gman_ordetrah' />
                    <where>
                        docser = ? AND
                        empcode = '07' AND
                        tercer IN ('A08642142', 'PLS')
                    </where>
                </select>
            `, pStrDocord);

            if (mIntCount) {
                mStrTipdoc = 'MOBP';
            }

        break;

        case 'A08642142': 
        case 'G59747535': 
            mStrTipdoc = 'MODI';

            mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='gman_ordetrah' />
                    <where>
                        docser = ? AND
                        empcode = '07' AND
                        tercer IN ('A08642142', 'PLS')
                    </where>
                </select>
            `, pStrDocord);

            if (mIntCount) {
                mStrTipdoc = 'MODP';
            }

            mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='gman_ordetrah' />
                    <where>
                        docser  = ? AND
                        empcode = '10' AND
                        tercer  ='G59747535'
                    </where>
                </select>        
            `, pStrDocord);

            if (mIntCount) {
                mStrTipdoc = 'MODP';
            }

        break;
    
        default:
            mStrTipdoc = 'MODI';
        break;
    }

    let mStrCodser = Ax.db.executeGet(`
        <select>
            <columns>codser</columns>
            <from table='gman_partesd' />
            <where>
                codigo = ?
            </where>
        </select>
    `, mStrTipdoc);

    let mStrServic = Ax.db.executeGet(`
        <select>
            <columns>
                gman_servoper.codser servic
            </columns>
            <from table='gman_servoper'>
                <join table='gman_tiposerv'>
                    <on>gman_servoper.codser = gman_tiposerv.codigo</on>
                </join>
                <join table='mut_servgroup'>
                    <on>mut_servgroup.codser = gman_servoper.codser</on>
                </join>
            </from>
            <where>
                gman_servoper.codope = ? AND
                gman_tiposerv.codart IS NOT NULL AND
                mut_servgroup.codgrp = ? AND 
                ? BETWEEN gman_servoper.fecini AND gman_servoper.fecfin
            </where>
        </select>
    `, pStrCodope, mObjOrdetrah.codgrp, pDatFecini);

    if (mStrServic == null) {
        throw new Ax.lang.Exception(`Servei no definit per l´operari: [${pStrCodope}] i el grup de serveis: [${mObjOrdetrah.codgrp}]`)
    }

    //Generar el comunicat.

    let mIntSer = Ax.db.insert('gman_parteser', 
        {
            cabid  : 0,
            tipdoc : mStrTipdoc,
            empcode: mObjOrdetrah.empcode,
            docser : mStrCodser,
            docord : pStrDocord,
            tercer : mObjOrdetrah.tercer,
            tipdir : mObjOrdetrah.tipdir,
            codmaq : mObjOrdetrah.codmaq,
            codope : pStrCodope,
            codser : mStrServic,
            fecini : pDatFecini,
            horini : mTimHorini,
            horfin : mTimHorfin,
            tiphor : pStrTiphor,
            hortot : mHortot,
            precio : pDecPrecio,
            estcab : 'E',
            errcab : 0,
            coment : pStrComent,
            user_created: Ax.db.getUser()
        }
    ).getSerial();

    let mIntRowId = Ax.db.executeGet(`
        <select>
            <columns>
                <rowid table='gman_parteser' />
            </columns>
            <from table='gman_parteser' />
            <where>
                cabid = ?
            </where>
        </select>
    `, mIntSer);

    //Validar el comunicat generat perquè es generi l'albarà destí. 
    Ax.db.call('gman_parteser', 'I', mIntRowId)

}