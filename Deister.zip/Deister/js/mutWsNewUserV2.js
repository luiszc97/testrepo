function mutWsNewUserV2(
    pStrUserOri,
    pStrUserNew,
    pStrUserName,
    pStrLockInfo,
    pStrDbmsPass  
) {
    try {
        Ax.db.beginWork();
        let mStrUserOri = pStrUserOri.toUpperCase();
        let mStrUserNew = pStrUserNew.toUpperCase();

        let dbName = Ax.db.of('wic_conf');
        let mStrUserGroup = dbName.executeGet(`
            <select>
                <columns>user_group</columns>
                <from table='wic_user' />
                <where>
                    UPPER(user_code) = UPPER(?)
                </where>
            </select>
        `, mStrUserOri);

        let mStrXmlCode = `
        <call name = "wic_user_copy"><args><arg>${mStrUserOri}</arg><arg>${mStrUserNew}</arg><arg>${pStrUserName}</arg><arg><null /></arg><arg><null /></arg><arg>${mStrUserGroup}</arg><arg><true /></arg><arg><true /></arg></args></call>
        `;

        let soap = new Ax.net.SOAPClient("http://10.200.0.161/soap/servlet/rpcrouter", options => {
            options.setUser("manager");
            options.setPassword("manager123");
        });

        let mArrayParam = ["wic_conf", mStrXmlCode];

        let mResponse = soap.call("urn:SOAPXMLServer", "executeXML", "wic_conf", "cerrauth_autoriza", mArrayParam);

        dbName.update('wic_user',
            {
                'user_notes': mStrUserNew,
                'user_lockinfo': pStrLockInfo
            },
            {
                'user_code': mStrUserNew
            }
        )

        // Actualizar el DB user
        dbName.execute(`
            UPDATE wic_dbms_usersdb
            SET dbms_user = ?
            WHERE usr_code = ?
              AND dbms_code IN (SELECT obj_code 
                                  FROM wic_dbms_objects 
                                 WHERE obj_server = 'erpmutuapro'
        `, mStrUserNew, mStrUserNew);

        // Actualitzar contrasenya de la wic_dbms_passwords 
        dbName.update('wic_dbms_passwords', 
            {
                'password': Ax.ext.crypt.encrypt(pStrDbmsPass),
                'passinfo': null
            }, 
            {
                'usr_code': mStrUserNew,
                'srv_code': 'erpmutuapro'
            }
        )

        Ax.db.commitWork();

        return 'OK';

    } catch (error) {
        Ax.db.rollbackWork();

        let mStrErrmsg = Ax.util.Error.getMessage(error);
        return `No s'ha pogut copiar el usuari degut a [${mStrErrmsg}]`
    }
}