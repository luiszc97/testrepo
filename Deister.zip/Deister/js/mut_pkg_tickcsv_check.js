function mut_pkg_tickcsv_check(pStrNomfit, pStrStatus, pIntCorrel) {
    Ax.db.beginWork();

    Ax.db.update('mut_pkg_tickcsv', 
        {
            'status': 'P',
            'errmsg': null,
            'user_error': null,
            'date_error': null
        }, 
        {
            'nomfit': pStrNomfit
        }
    );

    Ax.db.commitWork();

    //Recorrem tot els registres del fitxer. 
    let mArrPkgTickcsv = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='mut_pkg_tickcsv' />
            <where>
                nomfit = ?
            </where>
            <order>numlin DESC</order>
        </select>
    `, pStrNomfit).toJSONArray();

    for (let mRow of mArrPkgTickcsv) {
        try {
            //Controls de repetició del fitxer. 
            let mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_pkg_tickets' />
                    <where>
                        nomfit  = ?
                    </where>
                </select>
            `, mRow.nomfit);

            if (mIntCount) {
                throw new Ax.lang.Exception(`Fitxer [${mRow.nomfit}] ja processat.`);
            }

            let mIntCount1 = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_pkg_tickcsv' />
                    <where>
                        nomfit  = ? AND
                        numlin  = ? AND
                        numseq != ?
                    </where>
                </select>
            `, mRow.nomfit, mRow.numlin, mRow.numseq);

            if (mIntCount1) {
                throw new Ax.lang.Exception(`Fitxer i línia [${mRow.nomfit}, ${mRow.numlin}] repetits.`);
            }

            //Controls de contingut del camp TPV.
            if (mRow.codtpv == null) {
                throw new Ax.lang.Exception('Camp [TPV] no informat.');
            }

            //Controls de contingut del camp Mode de Pagament.
            if (mRow.modpag == null) {
                throw new Ax.lang.Exception('Camp [Mode de Pagament] no informat.');
            }
            
            switch (mRow.modpag) {
                case 'CO':
                case 'SF':
                case 'NF':
                    break;
            
                default:
                    throw new Ax.lang.Exception(`Mode de Pagament [${mRow.modpag}] no contemplat.`);
                    break;
            }

            //Controls de contingut del camp Número de Tiquet.
            if (mRow.numtiq == null) {
                throw new Ax.lang.Exception('Camp [Número de Tiquet] no informat.');
            }

            let mRegexp = `/\d{4}[/]\d{8}/`;
            
            if (!mRow.numtiq.match(mRegexp)){
                throw new Ax.lang.Exception(`Format del número de tiquet incorrecte. Ha de ser 4 dígits + "/" + 8 dígits.`);
            }

            //Controls de repetició del Número de Tiquet.
            let mIntCount2 = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_pkg_tickcsv' />
                    <where>
                        codtpv  = ? AND
                        modpag  = ? AND
                        numtiq  = ? AND
                        numseq != ?
                    </where>
                </select>           
            `,mRow.codtpv, mRow.modpag, mRow.numtiq, mRow.numseq);

            if (mIntCount2) {
                throw new Ax.lang.Exception('Ticket repetit.');
            }

            let mIntCount3 = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_pkg_tickets' />
                    <where>
                        codtpv = ? AND
                        modpag = ? AND
                        numtiq = ?
                    </where>
                </select>
            `,mRow.codtpv, mRow.modpag, mRow.numtiq);

            if (mIntCount3) {
                throw new Ax.lang.Exception('Ticket processat.');
            }

            //Calculem el que seria el nº de tiquet anterior a l'actual.
            if (pIntCorrel) {
                let mLsttiq = `${mRow.numtiq.slice(0, 5)}    ${(mRow.numtiq.slice(5, 13)-1).padStart(8, 0)}`;

                let mIntCount4 = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='mut_pkg_tickcsv' />
                        <where>
                            codtpv = ? AND
                            modpag = ? AND
                            numtiq &lt; ? AND
                            numseq != ?
                        </where>
                    </select>                
                `,mRow.codtpv, mRow.modpag, mRow.numtiq, mRow.numseq);

                if (mIntCount4) {
                    let mIntCount5 = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='mut_pkg_tickcsv' />
                            <where>
                                codtpv = ? AND
                                modpag = ? AND
                                numtiq = ?
                            </where>
                        </select>                    
                    `,mRow.codtpv, mRow.modpag, mLsttiq);

                    if (!mIntCount5) {
                        throw new Ax.lang.Exception(`Número de ticket anterior no localitzat per [${mRow.codtpv}${mRow.modpag}-${mRow.numtiq}] a mut_pkg_tickcsv.`)
                    }
                    
                } else {
                    let mIntCount6 = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='mut_pkg_tickets' />
                            <where>
                                codtpv = ? AND
                                modpag = ?
                            </where>
                        </select>    
                    `,mRow.codtpv, mRow.modpag);

                    if (mIntCount6) {
                        let mIntCount7 = Ax.db.executeGet(`
                            <select>
                                <columns>COUNT(*)</columns>
                                <from table='mut_pkg_tickets' />
                                <where>
                                    codtpv = ? AND
                                    modpag = ? AND
                                    numtiq = ?
                                </where>
                            </select>    
                        `,mRow.codtpv, mRow.modpag, mLsttiq);

                        if (!mIntCount7) {
                            throw new Ax.lang.Exception(`Número de ticket anterior no localitzat per [${mRow.codtpv}${mRow.modpag}-${mRow.numtiq}] a mut_pkg_tickets.`);

                        }
                    }
                }
            }

            //Controls de contingut del camps de dates.
            if (mRow.datexp == null) {
                throw new Ax.lang.Exception(`Camp [Data d'Expedició] no informat.`);
            }

            let mRegexp2 = `/20\d{2}[0-1]\d{1}[0-3]\d{1}/`;
            
            if (!mRow.datexp.match(mRegexp2)){
                throw new Ax.lang.Exception(`Format de la Data d'Expedició incorrecte.`);
            }

            let mDateXp = new Ax.sql.Date(mRow.datexp/1000,(mRow.datexp/100)%100,mRow.datexp/100);

            if (mDateXp > new Ax.sql.Date()) {
                throw new Ax.lang.Exception(`Data d'Expedició no pot ser posterior al dia d'avui.`); 
            }

            let mDateMesAnte = Ax.db.executeGet(`
                <select>
                    <columns>
                        TODAY - 30 UNITS DAY 
                    </columns>
                    <from table='wic_dual' />
                </select>  
            `)

            if (mDateXp < mDateMesAnte) {
                throw new Ax.lang.Exception(`Data d'Expedició no pot ser anterior a 30 dies.`);
            }

            if (mRow.horexp == null) {
                throw new Ax.lang.Exception(`Camp [Hora d'Expedició] no informat.`);
            }

            if (mRow.datent == null) {
                throw new Ax.lang.Exception(`Camp [Data d'Entrada] no informat.`);
            }

            if (mRow.horent == null) {
                throw new Ax.lang.Exception(`Camp [Hora d'Entrada] no informat.`);
            }

            //Si no ve informada ni la Data ni la Hora de Sortida,   
            //les setejem com la Data i Hora d'Expedició + 2 minuts i
            //marquem el registre com a "modificat".       
            if (mRow.datsor == null && mRow.horsor == null) {
                mRow.datsor = mRow.datexp;
                let mStrHorsorH = mRow.horexp.slice(0, 2);
                let mStrHorsorM = mRow.horexp.slice(3, 5);
                let mStrHorsorS = mRow.horexp.slice(6, 8);

                if (mStrHorsorM >= 60) {
                    mStrHorsorM = mStrHorsorM % 60;
                    mStrHorsorH = mStrHorsorH + 1;
                }

                if (mStrHorsorH >= 24) {
                    mStrHorsorH = 23;
                    mStrHorsorM = 59;
                    mStrHorsorS = 59;
                }

                mStrHorsorH = mStrHorsorH.padStart(2, '0');
                mStrHorsorM = mStrHorsorM.padStart(2, '0');
                mStrHorsorS = mStrHorsorS.padStart(2, '0');

                mRow.horsor = `${mStrHorsorH}:${mStrHorsorM}:${mStrHorsorS}`;

                Ax.db.update('mut_pkg_tickcsv', 
                    {
                        'datsor': mRow.datsor,
                        'horsor': mRow.horsor,
                        'indmod': 1
                    }, 
                    {
                        'nomfit': mRow.nomfit,
                        'numlin': mRow.numlin
                    }
                )

            }

            if (mRow.datsor == null) {
                throw new Ax.lang.Exception(`Camp [Data de Sortida] no informat.`); 
            }

            if (mRow.horsor == null) {
                throw new Ax.lang.Exception(`Camp [Hora de Sortida] no informat.`); 
            }

            //Controls de contingut del camp NIF de l'expedidor.
            if (mRow.nifexp == null) {
                throw new Ax.lang.Exception(`Camp [NIF de l'Expedidor] no informat.`); 
            }

            //Controls de contingut del camp Tipus de Gestió.
            if (mRow.tipges == null) {
                throw new Ax.lang.Exception(`Camp [Tipus de Gestió] no informat.`); 
            }

            switch (mRow.tipges) {
                case 'Ticket':
                case 'Varios':   
                case 'Excesos': 
                    break;
            
                default:
                    throw new Ax.lang.Exception(`Tipus de Gestió [${mRow.tipges}] no contemplada.`); 
                    break;
            }

            //Controls de contingut del camp Tipus Impositiu.
            if (mRow.tipimp == null) {
                throw new Ax.lang.Exception(`Camp [Tipus Impositiu] no informat.`);
            }

            if (mRow.tipimp != 21) {
                throw new Ax.lang.Exception(`Tipus impositiu [${mRow.tipimp}] no contemplat.`);
            }

            //Controls de contingut sobre els camps d'imports.
            if (mRow.imptot == null) {
                throw new Ax.lang.Exception(`Camp [Import] no informat.`);
            }

            if (mRow.quoimp == null) {
                throw new Ax.lang.Exception(`Camp [Quota tributaria] no informat.`);
            }

            if (mRow.impefe == null) {
                throw new Ax.lang.Exception(`Camp [Import Efectiu] no informat.`);
            }

            if (mRow.imptar == null) {
                throw new Ax.lang.Exception(`Camp [Import Tarja] no informat.`);
            }

            if (mRow.impvia == null) {
                throw new Ax.lang.Exception(`Camp [Import VIA-T] no informat.`);
            }

            if (mRow.modpag == 'CO' && mRow.impvia != 0) {
                throw new Ax.lang.Exception(`Import VIA-T informat en mode de pagament Comptat.`);
            }

            if ((mRow.modpag == 'SF' || mRow.modpag == 'NF') && mRow.impefe != 0) {
                throw new Ax.lang.Exception(`Import Efectiu informat en mode de pagament VIA-T.`);
            }

            if ((mRow.modpag == 'SF' || mRow.modpag == 'NF') && mRow.imptar != 0) {
                throw new Ax.lang.Exception(`Import Tarja informat en mode de pagament VIA-T.`);
            }

            if ((mRow.basimp + mRow.quoimp) != mRow.imptot) {
                throw new Ax.lang.Exception(`Base impositiva i quota ha de ser igual a l'import total.`);
            }

            if ((mRow.impefe + mRow.imptar + mRow.impvia) != mRow.imptot) {
                throw new Ax.lang.Exception(`La suma dels diferents imports de pagament ha de ser igual a l'import total.`);
            }

            let mIntAbs = Math.abs(Math.round(((mRow.basimp * mRow.tipimp)/100).toFixed(2)) - mRow.quoimp);
            if (mIntAbs > 0.01) {
                throw new Ax.lang.Exception(`Desquadre en la quota impositiva [${mIntAbs} vs ${mRow.quoimp}].`);
            }

            //Controls de contingut sobre el camp Divisa.
            if (mRow.divisa != 'EUR') {
                throw new Ax.lang.Exception('Camp [Divisa] no és Euro.');
            }

            //Controls de contingut sobre el camp Comercialitzadora.
            //let mRegexp3 = `/\d{4}[/]\d{8}/`;
            
            if ((mRow.modpag == 'SF' || mRow.modpag == 'NF') && mRow.comerc == null){
                throw new Ax.lang.Exception('Camp [Comercialitzadora] no informat.');
            }

            let mIntCount8 = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_pkg_comerci' />
                    <where>
                        codigo = ?
                    </where>
                </select>
            `, mRow.comerc);

            if ((mRow.modpag == 'SF' || mRow.modpag == 'NF') && !mIntCount8) {
                throw new Ax.lang.Exception('Comercialitzadora no existeix.');
            }

            //Ha d'existir la parametrització que ens indiqui com
            //crear la factura. 
            let mIntCount9 = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_pkg_confdoc' />
                    <where>
                        nifexp = ? AND
                        codtpv = ? AND
                        modpag = ?
                    </where>
                </select>
            `, mRow.nifexp, mRow.codtpv, mRow.modpag);   
            
            if (!mIntCount9) {
                throw new Ax.lang.Exception(`Parametrització de factura inexistent per [${mRow.nifexp}/${mRow.codtpv}/${mRow.modpag}].`);
            }

        } catch (error) {
            Ax.db.beginWork();

            Ax.db.update('mut_pkg_tickcsv', 
                {
                    'status': 'E',
                    'errmsg': Ax.util.Error.getMessage(error),
                    'user_error': Ax.db.getUser(),
                    'date_error': new Ax.sql.Date()
                }, 
                {
                    'nomfit': mRow.nomfit,
                    'numlin': mRow.numlin
                }
            )

            Ax.db.commitWork();
        }
    }

    Ax.db.beginWork();

    let mIntCant = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='mut_pkg_tickcsv' />
            <where>
                nomfit = ? AND
                status = 'E'
            </where>
        </select>
    `, pStrNomfit);

    let mStrStatus;
    if (mIntCant) {
        Ax.db.execute(`
            UPDATE mut_pkg_tickcsv
            SET status = 'E', 
                errmsg = 'Error en altres línies del fitxer.',
                user_error = '${Ax.db.getUser()}',
                date_error = ${new Ax.util.Date()}
            WHERE
                nomfit  = ? AND
                status != 'E'
        `, pStrNomfit); 

        mStrStatus = 'B';
    } else {
        mStrStatus = pStrStatus;

        Ax.db.update('mut_pkg_tickcsv', 
            {
                'status': mStrStatus
            },
            {
                'nomfit': pStrNomfit
            }
        )
    }

    Ax.db.commitWork();

    return mStrStatus;
    
}