function mutAegerusProces() {
    function __local_send_errmail(pStrMessage) {
        let mObjMail = Ax.dd.call('mut_sys_mail_select', 'mut_aegerus_load','general');

        let mMail = new Ax.mail.MailerMessage();
        mMail.from(mObjMail.mail_from);
        mMail.to(mObjMail.mail_to);
        mMail.cc(mObjMail.mail_cc);
        mMail.bcc(mObjMail.mail_bcc);
        mMail.subject('ERP @mut_aegerus_proces Error');
        mMail.setText(pStrMessage);

        //Se hace el envío del email
        let mMailer = new Ax.mail.Mailer();
        mMailer.setSMTPServer("localhost", 25);
        mMailer.send(mMail);  
    }

    try {
        Ax.db.beginWork();
        //Controls previs.

        Ax.db.execute(`
            UPDATE mut_aegerus_tercers
            SET errno = -10,
                errmsg = 'NUMDOC INVÀLID'
            WHERE 
                errno = 0 AND 
                NVL(numdoc,'-') IN ('-','NULL')
        `);

        Ax.db.execute(`
            UPDATE mut_aegerus_tercers
            SET errno = -20,
                errmsg = 'CENTRE SENSE EQUIVALÈNCIA'
            WHERE 
                errno = 0 AND NOT EXISTS (SELECT * 
                FROM mut_aegerus_erp e 
                WHERE mut_aegerus_tercers.codcen=e.codcen 
                AND mut_aegerus_tercers.tipcont=e.tipcont) 
                AND NOT EXISTS (SELECT * 
                FROM ctercero 
                WHERE codigo = mut_aegerus_tercers.numdoc)
        `);

        Ax.db.execute(`
            UPDATE mut_aegerus_tercers
            SET errno = -30,
                errmsg = 'CODI POSTAL INEXISTENT'
            WHERE 
                errno = 0 AND NOT EXISTS 
                (SELECT * FROM cmunicip 
                WHERE cmunicip.codpos = mut_aegerus_tercers.codpos) 
                AND NOT EXISTS 
                (SELECT * FROM ctercero WHERE codigo = mut_aegerus_tercers.numdoc)
        `);

        Ax.db.execute(`
            UPDATE mut_aegerus_tercers
            SET errno = -40,
                errmsg = 'CODI IBAN INEXISTENT'
            WHERE 
                errno = 0 AND
                NVL(codiban,'(null)') IN ('(null)','NULL','001','002') AND 
                NOT EXISTS (SELECT * FROM ctercero WHERE codigo = mut_aegerus_tercers.numdoc)
        `);

        Ax.db.execute(`
            UPDATE mut_aegerus_tercers
            SET numdoc = TRIM(numdoc)
            WHERE 
                errno = 0 
        `);

        // Creació de tercers.
        // Creació Tercers
        Ax.db.execute(`
            INSERT INTO ctercero 
                (seqno,codigo,nombre,cif,codare,codcla,terres)
            SELECT 
                0,
                TRIM(t.numdoc),
                TRIM(UPPER(t.cognoms)) || ' ' || UPPER(t.nom),
                t.numdoc,e.codare, e.codcla, e.terres
            FROM mut_aegerus_tercers t
                    ,mut_aegerus_erp e
            WHERE 
                    e.codcen = t.codcen AND e.tipcont = t.tipcont
                AND t.errno NOT IN (-10, -20, 100)
                AND DATE(t.dataini) = (SELECT MAX(DATE(t2.dataini)) 
                                        FROM mut_aegerus_tercers t2 
                                        WHERE t.numdoc=t2.numdoc)
                AND NOT EXISTS (SELECT * 
                                FROM ctercero 
                                WHERE codigo = TRIM(t.numdoc))
                                    
            GROUP BY 1,2,3,4,5,6,7
        `);

        //Creació cterdire 
        Ax.db.execute(`
            INSERT INTO cterdire 
                (codigo, tipdir, direcc, poblac, codpos, codnac, zonimp)
            SELECT TRIM(numdoc), 
                   '0', direcc, poblac, t.codpos, 
                    NVL(cmunicip.codnac,'ESP'), 'ESCO'
              FROM mut_aegerus_tercers t
                    ,OUTER cmunicip
             WHERE t.codpos=cmunicip.codpos
               AND t.errno NOT IN (-10, -20, 100)
               AND DATE(t.dataini) = (SELECT MAX(DATE(t2.dataini)) 
                                        FROM mut_aegerus_tercers t2 
                                       WHERE t.numdoc=t2.numdoc)
               AND NOT EXISTS (SELECT * 
                                 FROM cterdire 
                                 WHERE codigo = TRIM(numdoc) AND tipdir = '0')
                                  
            GROUP BY 1,2,3,4,5,6,7
        `);

        //Creació gcliente 
        Ax.db.execute(`
            INSERT INTO gcliente 
                (cliid, codigo, terfac, tercom, tipcli, dtocom, dtopp, minped, codpri, divisa, portes, modfac, infage, estado, agralb, fecalt)
            SELECT '0', TRIM(numdoc), TRIM(numdoc), TRIM(numdoc), '0',
                    0, 0, 0, 0, 'EUR', 'P', 'D','N' ,'A' ,'S', TODAY
            FROM mut_aegerus_tercers 
            WHERE errno NOT IN (-10, -20, 100)
                AND EXISTS (SELECT * 
                              FROM ctercero 
                             WHERE codigo=TRIM(numdoc))
                AND NOT EXISTS (SELECT * 
                                  FROM gcliente
                                 WHERE codigo = TRIM(numdoc))
            GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
        `);

        //Creació cterbanc
        Ax.db.execute(`
            INSERT INTO cterbanc 
                (codigo, numban, priori, grpemp, iban, codban)
            SELECT 
                TRIM(numdoc), 0, 99, 'ALL', codiban, 
                LEFT(codiban,2) || SUBSTR(codiban, 5, 4)
            FROM mut_aegerus_tercers 
            WHERE errno IN (0)
                AND NVL(codiban,'(null)') NOT IN ('(null)','NULL','001','002')
                AND DATE(dataini) = (SELECT MAX(DATE(t2.dataini)) FROM mut_aegerus_tercers t2 WHERE mut_aegerus_tercers.numdoc=t2.numdoc)
                AND NOT EXISTS (SELECT * FROM cterbanc WHERE codigo=TRIM(numdoc) AND iban=codiban)
                AND NOT EXISTS (SELECT * FROM cterbanc WHERE codigo=TRIM(numdoc) AND grpemp='ALL' AND priori=99)
                AND NOT EXISTS (SELECT * FROM cterbanc WHERE codigo=TRIM(numdoc) AND numban=0)
            GROUP BY 1,2,3,4,5,6
        `);

        //Creació cterpago v. 1
        Ax.db.execute(`
            INSERT INTO cterpago 
                (codigo, tipefe, tippag, numban, codtip, priori, grpemp)
            SELECT 
                TRIM(numdoc), 'RE', '0', 0, 'C', 0, 'ALL'
            FROM mut_aegerus_tercers 
            WHERE errno IN (0)
                AND NOT EXISTS (SELECT * FROM cterpago WHERE codigo=TRIM(numdoc) AND codtip='C' AND grpemp='ALL' AND priori=0)
                AND NOT EXISTS (SELECT * FROM cterpago WHERE codigo=TRIM(numdoc) AND codtip='C' AND grpemp='ALL' AND tipefe='RE' AND tippag='0')
                AND EXISTS (SELECT * FROM cterbanc WHERE codigo=TRIM(numdoc) AND numban=0)
            GROUP BY 1,2,3,4,5,6,7
        `);
        
        //Creació cterpago v. 2
        Ax.db.execute(`
            INSERT INTO cterpago 
                (codigo, tipefe, tippag, codtip, priori, grpemp)
            SELECT 
                TRIM(numdoc), 'EF', '0', 'C', 0, 'ALL'
            FROM mut_aegerus_tercers 
            WHERE errno IN (-40)
                AND EXISTS (SELECT * FROM ctercero WHERE codigo=TRIM(numdoc))
                AND NOT EXISTS (SELECT * FROM cterpago WHERE codigo=TRIM(numdoc))
            GROUP BY 1,2,3,4,5,6
        `);

        //Actualització i Creació ccuentas
        Ax.db.execute(`
            UPDATE mut_aegerus_tercers
            SET 
                cuedef = (SELECT REPLACE(TRIM(e.cuenta) || (100000000 + seqno),'0.1','0.') 
                FROM ctercero, mut_aegerus_erp e 
                WHERE codigo = TRIM(mut_aegerus_tercers.numdoc) AND e.codcen = mut_aegerus_tercers.codcen AND e.tipcont = mut_aegerus_tercers.tipcont)
            WHERE
                mut_aegerus_tercers.errno NOT IN (-10, -20, 100)
                AND EXISTS (SELECT * FROM mut_aegerus_erp e WHERE e.tipcta=1 AND e.codcen = mut_aegerus_tercers.codcen AND e.tipcont = mut_aegerus_tercers.tipcont)
        `);

        Ax.db.execute(`
            INSERT INTO ccuentas 
                (placon, codigo, nombre, tipcta, activa, tipact)
            SELECT 'ES' placon, t.cuedef, nombre, 'T', 'IEV', 'A'
              FROM ctercero ,mut_aegerus_tercers t ,mut_aegerus_erp e
             WHERE codigo = TRIM(t.numdoc) 
               AND e.codcen = t.codcen AND e.tipcont = t.tipcont
               AND t.errno NOT IN (-10, -20, 100)
               AND e.tipcta=1
               AND t.cuedef IS NOT NULL
               AND NOT EXISTS (SELECT * FROM ccuentas WHERE codigo = t.cuedef)						
              GROUP BY 1,2,3,4,5,6
        `);

        //Creació ctertipo  
        Ax.db.execute(`
            INSERT INTO ctertipo 
                (codigo, codtip, placon, cuenta, tiprel, aplret)
            SELECT 
                codigo, 'C', 'ES' placon, CASE WHEN e.tipcta=1 THEN t.cuedef ELSE TRIM(e.cuenta) END cuedef, 'CL', 'N'
            FROM ctercero ,mut_aegerus_tercers t mut_aegerus_erp e
            WHERE  codigo = TRIM(t.numdoc) 
              AND e.codcen = t.codcen AND e.tipcont = t.tipcont
              AND t.errno NOT IN (-10, -20, 100)
              AND DATE(t.dataini) = (SELECT MAX(DATE(t2.dataini)) FROM  mut_aegerus_tercers t2 WHERE t.numdoc=t2.numdoc)
              AND NOT EXISTS (SELECT * FROM ctertipo x WHERE x  codigo=ctercero.codigo AND x.codtip='C' AND x.placon='ES'  AND tiprel = 'CL')
                                      
              GROUP BY 1,2,3,4,5,6
        `);

        //Creació csepadom 
        Ax.db.execute(`
            INSERT INTO csepadom 
                (empcode, claman, creide, tercer, tipdir, codper, numban, tipdom, tipope, refdom, fecfir, estado)
            SELECT 
                '10', 'C', 'ES91000G59747535', TRIM(numdoc), '0', TRIM(numdoc), 0, 1 AS tipdom, 2 AS tipope, '10/' || TRIM(numdoc) || '-0001' AS refdom, MAX(DATE(dataini)) AS fecfir, 2 AS estat
            FROM mut_aegerus_tercers
            WHERE 
                errno NOT IN (-10, -20, -30, -40, 100) AND NOT EXISTS (SELECT * FROM csepadom WHERE empcode='10' AND claman='C' AND refdom='10/' || TRIM(numdoc) || '-0001')
                    AND EXISTS (SELECT * FROM cterbanc WHERE codigo=TRIM(numdoc) AND numban=0)
                    AND EXISTS (SELECT * FROM cterdire WHERE codigo=TRIM(numdoc) AND tipdir='0')
            GROUP BY numdoc
        `);

        Ax.db.execute(`
            UPDATE mut_aegerus_tercers
            SET 
                errno = 100,
                errmsg = 'PROCESSAT'
            FROM mut_aegerus_tercers
            WHERE
                errno NOT IN (-10, -20, -30)
        `);

        Ax.db.commitWork();

    } catch (error) {
        Ax.db.rollbackWork();

        let mError = Ax.util.Error.getMessage(error);
        __local_send_errmail(`Error actualitzant tercers: [${mError}].`);
    }

}