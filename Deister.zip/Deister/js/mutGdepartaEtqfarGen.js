function mutGdepartaEtqfarGen(pStrDelega, pStrDepart, pStrUserDept, pStrUserCode) {
    //Selecció de dades 
    let mObjGdelegac = Ax.db.executeQuery(`
        <select>
            <columns>
                gdelegac.codigo,gdelegac.nomdlg,
                gdeparta.depart,gdeparta.nomdep 
            </columns>
            <from table='gdelegac'>
                <join table='gdeparta'>
                    <on>gdeparta.delega = gdelegac.codigo</on>
                </join>
            </from>
            <where>
                gdelegac.codigo = ?
                AND gdeparta.depart = ?
            </where>
        </select>
    `, pStrDelega, pStrDepart).toOne();

    let mObjUserEtiqFar = {};
    mObjUserEtiqFar.user_pimp = null;
    mObjUserEtiqFar.user_ppor = null;
    mObjUserEtiqFar.user_pout = null;

    mObjUserEtiqFar = executeQuery(`
        <select>
            <columns>
                mut_user_etiq_far.user_pimp,
                mut_user_etiq_far.user_ppor,
                mut_user_etiq_far.user_pout
            </columns>
            <from table='mut_user_etiq_far' />
            <where>
                    mut_user_etiq_far.user_dept = ?
                AND mut_user_etiq_far.user_code = ?
            </where>
        </select>
    `, pStrUserDept, pStrUserCode).toOne();

    if (mObjUserEtiqFar.user_pimp == null) {
        mObjUserEtiqFar.user_pimp = '172.17.10.214';
    }

    if (mObjUserEtiqFar.user_pout == null) {
        mObjUserEtiqFar.user_pout = 5000;
    }

    if (mObjUserEtiqFar.user_ppor == null) {
        mObjUserEtiqFar.user_ppor = 9100;
    }

    let mStrZplchr = `^XA~TA000~JSN^LT0^MNW^PON^PMN^LH0,0^JMA^PR4,4~SD15^JUS^LRN^CI0^XZ
    ^XA
    ^MMT
    ^PW480
    ^LL0280
    ^LS0
    ^FT363,284^BQN,2,5
    ^FDLA,${mObjGdelegac.depart}^FS
    ^FT28,132^BQN,2,5
    ^FDLA,${mObjGdelegac.codigo}^FS
    ^FT290,57^A0N,28,28^FH\^FD${mObjGdelegac.codigo}^FS
    ^FT28,249^A0N,28,16^FH\^FD${mObjGdelegac.nomdep}^FS
    ^FT147,100^A0N,28,16^FH\^FD${mObjGdelegac.nomdlg}^FS
    ^FT208,205^A0N,28,28^FH\^FD${mObjGdelegac.depart}^FS
    ^FO19,136^GB465,0,8^FS
    ^FT147,57^A0N,28,28^FH\^FDDelegaci\A2 :^FS
    ^FT28,206^A0N,28,28^FH\^FDDepartament :^FS
    ^PQ1,0,1,Y^XZ`;
 
    let mSocket = new Ax.net.SocketClient(mObjUserEtiqFar.user_pimp, mObjUserEtiqFar.user_ppor);

    /* Creamos el fichero blob */
    let ficheroBlob = new Ax.sql.Blob("FileName.txt");
    ficheroBlob.setContentType("text/plain");
    ficheroBlob.setContent(mStrZplchr);

    let mBytes = ficheroBlob.getBytes();

    //get queue state
    mSocket.connect();
    mSocket.write(`${mSocket}${mBytes}`);
    mSocket.await();
    mSocket.setTimeout(mObjUserEtiqFar.user_pout);

}