function ws_gman_parteser_get_photo(pIntCabid, pStrAssignUser, pIntAssignType, pIntAssignNumber) {
     
    let mStrXmlCode = `${Ax.db.call('gman_parteser_get_photo', pIntCabid, pStrAssignUser, pIntAssignType, pIntAssignNumber)}`;

    let soap = new Ax.net.SOAPClient("http://10.106.0.15/soap/servlet/rpcrouter", options => {
        options.setUser("jas");
        options.setPassword("123mona123");
     });
    
     let mArrayParam = ["mutua_mobile", mStrXmlCode];
     
    //soap.call("mutua_mobile", mStrXmlCode);
    soap.call("urn:SOAPXMLServer", "executeXML", "mutua_mobile", "cerrauth_autoriza", mArrayParam);
    
}