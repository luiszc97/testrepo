/* 
// =========================================================================
// PRJ #63781 Actualització del nom d'usuari tal com està a BDP_PROFESSIONAL
// Actualitza el nom a mutua.cuserids i a confdb.wic_user
// =========================================================================
*/
function mutUsernameUpd() {
    let mArrBdpProfessional = Ax.db.executeQuery(`
        <select>
            <columns>
                prs_usr,
                (prs_cognoms || ', ' || prs_nom) username
            </columns>
            <from table='bdp_professional' /> 
        </select>
    `);

    for (let mRow of mArrBdpProfessional) {
        // Actualitzar la taula cuserids
        Ax.db.execute(`
            UPDATE cuserids
               SET username = '${mRow.username}'
             WHERE usercode = '${mRow.prs_usr}'
               AND username != '${mRow.username}'    
        `)

        //Actualitzar la taula wic_user de la BBDD confdb 
        let dbName = Ax.db.of('confdb');
        //Actualitzar els registres del mateix usercode pero amb
        // username diferent
        dbName.execute(`
            UPDATE wic_user
               SET user_name = '${mRow.username}'
             WHERE user_code = '${mRow.prs_usr}'
               AND user_name != '${mRow.username}'    
        `);
    }
}