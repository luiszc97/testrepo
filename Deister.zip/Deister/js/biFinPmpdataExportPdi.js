function biFinPmpdataExportPdi(pStrEmpcode) {
    let mStrPathname = '/mnt/deister_dwh/fin/';
    let mDatToday = new Ax.sql.Date();
    let mDatTimestamp = mDatToday.format('ddMMyy_HHmmss');
    let mStrFiletemp = `${mStrPathname}bi_fin_pmpdata_${pStrEmpcode}_${mDatTimestamp}.work`;
    let mStrFilename = `${mStrPathname}bi_fin_pmpdata_${pStrEmpcode}_${mDatTimestamp}.pdi`;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_output`);  
    
    let mDatFeSub = Ax.db.executeGet(`
        select today - 365 units day from wic_dual
    `);

    Ax.db.call('mut_pmp_pro_dwh', 
        new Ax.sql.Date(mDatFeSub),
        new Ax.sql.Date(),
        `MATCHES '*'`,
        `MATCHES '*'`,
        'S',
        'S',
        'S',
        'S',
        'S',
        'BETWEEN -99999999999999 AND 9999999999999999',
        `MATCHES '${pStrEmpcode}'`,
        `MATCHES '*'`,
        `MATCHES '*'`,
        `MATCHES '*'`,
        '&gt; 0',
        '1=1'
    );

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_bi_fin_pmpdata`);  
    Ax.db.execute(`
        <select intotemp='@tmp_bi_fin_pmpdata'>
            <columns>
                empcode, codcla,  tippro, terhol, cif,
                tercer,  placon,  cuenta, nombre, numfac,
                basimp,  nombre1, saldo,  per_mig_cob,
                tippag,  cter,    fecpos, fec_ini_fac,
                fec_fin
            </columns>
            <from table='@tmp_output' />
            <order>1,2,3,5,12,6,7</order>
        </select>
    `);

    let mFiletemp = new Ax.io.File(mStrFiletemp);

    ///<table.unload>
    let mRsTmpBiFinPmpdata = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_bi_fin_pmpdata'/>
        </select>
    `);

    let mStrContent = '';
    let mArrColumnsNames = mRsTmpBiFinPmpdata.getColumnsNames();

    for ( let mRow of mRsTmpBiFinPmpdata ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    let mBlob = new Ax.sql.Blob(`${mFiletemp}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    let mFile = new Ax.io.File(`${mFiletemp}`);
    mFile.write(mBlob);

    ///file.copy & file.delete => file.renameTo
    mFiletemp.renameTo(mStrFilename)

}