function mutGvenmovhCopanu(pStrDocser, pStrTypdia) {

    //Estructura de sortida.  
    let mRsOutputDuplasto = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['empcode','delega','depart','fecmov','docser','oriaux','tercer','imptot']);
		options.setColumnTypes([Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.DATE, 
            Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.DOUBLE]);
	});

    //Obtenir dades de l'albarà base.
    let mObjGvenmovh = Ax.db.executeQuery(`
        <select>
            <columns>
                cabid,  tipdoc, empcode, almori, almdes, delega, depart,
                fecmov, docser, tercer,  tipdir, docori, refter, oriaux
            </columns>
            <from table='gvenmovh' />
            <where>
                docser = ?
            </where>
        </select>    
    `, pStrDocser).toOne()
        .setRequired(`Albarà de vendes [${pStrDocser}] inexistent.`);

    let mStrCodser = Ax.db.executeGet(`
        <select>
            <columns>codser</columns>
            <from table='gvenmovd' />
            <where>
                codigo = ?
            </where>
        </select>
    `, mObjGvenmovh.tipdoc);

    if (mObjGvenmovh.oriaux != null) {
        throw new Ax.lang.Exception(`Albarà de vendes [${pStrDocser}] amb origen auxiliar. No es pot copiar.`);
    }

    //Comprovacions inicials.
    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='gvenmovh' />
            <where>
                tipdoc  = ? AND
                empcode = ? AND
                delega  = ? AND
                depart  = ? AND
                <year>fecmov</year> = <date.year>?</date.year> AND
                tercer  = ?  AND
                oriaux  = ?
            </where>
        </select>
    `, mObjGvenmovh.tipdoc, mObjGvenmovh.empcode, mObjGvenmovh.delega, mObjGvenmovh.depart, 
        mObjGvenmovh.fecmov, mObjGvenmovh.tercer, mObjGvenmovh.docser);
    
    if (mIntCount) {
        throw new Ax.lang.Exception('Ja existeixen albarans generats per aquest període.');
    }

    //Preparació de les dates.   
    let mDateFecmov= new Ax.sql.Date(mObjGvenmovh.fecmov);
    let mIntNumdia = mDateFecmov.getDate();
    let mIntMesini = mDateFecmov.getMonth()+1;

    if (mIntMesini == 12) {
        throw new Ax.lang.Exception(`Últim mes de l'any. No es genera cap albarà.`);
    }

    let mIntMesfin = 12;
    let mIntPeriod = 1;
    let mIntNumany = mObjGvenmovh.getFullYear();

    //Cursor de copies. 
    Ax.db.beginWork();

    for (let mIdx = mIntMesini; mIdx <= m_mesfin; mIdx + mIntPeriod) {
        let mBoolErrdat = false;
        let mDateFecmov;

        switch (pStrTypdia) {
            case 'P':
                mDateFecmov = new Ax.sql.Date(mIntNumany,mIdx,1);
            break;

            case 'U':
                if (mIdx != 12) {
                    let mDate = Ax.db.executeGet(`
                        <select>
                            <columns>
                                MDY(${mIdx}+1,1,${mIntNumany}) - 1 units day
                            </columns>
                            <from table='wic_dual'/>
                        </select>
                    `);

                    mDateFecmov = new Ax.sql.Date(mDate);

                } else {
                    mDateFecmov = new Ax.sql.Date(mIntNumany, 12, 31);
                }

            break;
        
            default:
                let mDate = Ax.db.executeGet(`
                    <select>
                        <columns>
                            MDY(${mIdx}+1,1,${mIntNumany}) - 1 units day
                        </columns>
                        <from table='wic_dual'/>
                    </select>
                `);

                let mIntLstdia = mDate.getDate();

                if (mIntNumdia <= mIntLstdia) {
                    mDateFecmov = new Ax.sql.Date(mIntNumany, mIdx, mIntNumdia);

                } else {
                    mDateFecmov = new Ax.sql.Date(mIntNumany, mIdx, mIntLstdia);
                }

            break;
        }

        let mIntCabgen = Ax.db.call('gvenmovh_copia',
            0, 
            mObjGvenmovh.cabid, 
            mObjGvenmovh.tipdoc,
            mObjGvenmovh.empcode,
            mObjGvenmovh.almori,
            mObjGvenmovh.almdes, 
            mObjGvenmovh.delega,
            mObjGvenmovh.depart,
            mDateFecmov,
            mStrCodser,
            mObjGvenmovh.tercer, 
            mObjGvenmovh.tipdir,
            mObjGvenmovh.docori,
            'N'
        );

        Ax.db.update('gvenmovh', 
            {
                'oriaux': mObjGvenmovh.docser
            }, 
            {
                'cabid': mIntCabgen
            }
        )

        //Afegir dades de l'albarà creat a l'estructura de sortida. 
        mObjGvenmovh = Ax.db.executeQuery(`
            <select>
                <columns>
                    empcode, delega, depart, fecmov,
                    docser,  oriaux, tercer, imptot
                </columns>
                <from table='gvenmovh' />
                <where>
                    cabid = ?
                </where>
            </select>
        `, mIntCabgen).toOne()

        mRsOutputDuplasto.rows().add([ mObjGvenmovh.empcode, mObjGvenmovh.delega, mObjGvenmovh.depart, mObjGvenmovh.fecmov, 
            mObjGvenmovh.docser, mObjGvenmovh.oriaux, mObjGvenmovh.tercer, mObjGvenmovh.imptot]);
        
    }

    Ax.db.commitWork();

    return mRsOutputDuplasto;

}