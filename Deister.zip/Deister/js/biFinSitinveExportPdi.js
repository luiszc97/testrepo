function biFinSitinveExportPdi() {
    let mIntOAnyini = 2017;
    let mDatToday = new Ax.sql.Date();
    let mIntOAnyfin = mDatToday.getFullYear();
    let mStrOPathname = `/mnt/deister_dwh/fin/`;
    let mDatOTimestamp = mDatToday.format('ddMMyy_HHmmss');
    let mStrOFiletemp = `${mStrOPathname}bi_fin_sitinve_${mDatOTimestamp}.work`;
    let mStrOFilename = `${mStrOPathname}bi_fin_sitinve_${mDatOTimestamp}.pdi`;

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_unload`);  
    
    Ax.db.execute(`
        CREATE TEMP TABLE @tmp_unload (
            numany  smallint ,
            empcode  char (4) ,
            codpre  char (10) ,
            nompre  varchar (60) ,
            codpar  char (20) ,
            nompar  varchar (80) ,
            tippar  char (1) ,
            impprp  decimal (16,2) ,
            imppe1  decimal (16,2) ,
            impnoc  decimal (16,2) ,
            imppe2  decimal (16,2) ,
            impal1  decimal (16,2) ,
            impnos  decimal (16,2) ,
            impal2  decimal (16,2) ,
            impfa1  decimal (16,2) ,
            impnof  decimal (16,2) ,
            impfa2  decimal (16,2) ,
            imppag  decimal (16,2) ,
            impfan  decimal (16,2) 
        ) WITH NO LOG;
    `);

    for (let mIdx = mIntOAnyini; mIdx <= mIntOAnyfin; mIdx++) {
        let mIntRemainder = mIdx % 2000;
        let mStrOPrefix = `${mIntRemainder}`;

        let mArrCparParpreh = Ax.db.executeQuery(`
            <select>
                <columns>DISTINCT empcode</columns>
                <from table='cpar_parpreh' />
                <order>1</order>
            </select>
        `);

        for (let mRow of mArrCparParpreh) {
            Ax.db.execute(`DROP TABLE IF EXISTS @tmp_partid`); 
            Ax.db.execute(`
                <select intotemp='@tmp_partid'>
                    <columns>
                        cpar_parpreh.empcode, cpar_parpreh.codpre, cpar_parpreh.nompre,
                        cpar_parprel.codpar,  cpar_parprel.nompar
                    </columns>
                    <from table='cpar_parpreh'>
                        <join table='cpar_parprel'>
                            <on>cpar_parpreh.empcode = cpar_parprel.empcode</on>
                            <on>cpar_parpreh.codpre  = cpar_parprel.codpre</on>
                        </join>
                    </from>
                    <where>
                        cpar_parpreh.empcode = ? AND
                        cpar_parpreh.codpre <matches>'${mStrOPrefix}*'</matches> AND
                        cpar_parpreh.estado != 'E'
                    </where>
                    <order>1,2,4</order>
                </select>
            `, mRow.empcode);

            Ax.db.execute(`<index name='i_@tmp_partid1' table='@tmp_partid' columns='empcode,codpre,codpar' />`);

            Ax.db.execute(`
                INSERT INTO @tmp_unload 
                (numany, empcode, codpre, codpar, tippar, impprp, imppe1, impnoc, imppe2, impal1, impnos, impal2, 
                impfa1, impnof, impfa2, imppag, impfan)
                VALUES (${mIdx}, ?, '-', '-', 'T',
                0.00, 0.00, 0.00, 0.00, 0.00, 0.00,
                0.00, 0.00, 0.00, 0.00, 0.00, 0.00)
            `, mRow.empcode);

            let mDecOTotprp = 0.00;
            let mDecOTotpe1 = 0.00;
            let mDecOTotnoc = 0.00;
            let mDecOTotpe2 = 0.00;
            let mDecOTotal1 = 0.00;
            let mDecOTotnos = 0.00;
            let mDecOTotal2 = 0.00;
            let mDecOTotfa1 = 0.00;
            let mDecOTotnof = 0.00;
            let mDecOTotfa2 = 0.00;
            let mDecOTotpag = 0.00;
            let mDecOTotfan = 0.00;    

            let mArrTmpPartid = Ax.db.executeQuery(`
                <select>
                    <columns>*</columns>
                    <from table='@tmp_partid' />
                    <order>1,2,4</order>
                </select>
            `);
            
            for (let mItem of mArrTmpPartid) {

                mItem.impprp = null;
                mItem.imppe1 = null;
                mItem.impnoc = null;
                mItem.imppe2 = null;
                mItem.impal1 = null;
                mItem.impnos = null;
                mItem.impal2 = null;
                mItem.impfa1 = null;
                mItem.impnof = null;
                mItem.impfa2 = null;
                mItem.imppag = null;
                mItem.impfan = null;

                let mIntCount = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='@tmp_partid' />
                        <where>
                            empcode = ? AND
                            codpre  = ? AND
                            codpar <matches>'#m_codpar*'</matches>
                        </where>
                    </select>    
                `, mItem.empcode, mItem.codpre);

                if (mIntCount > 1) {
                    mItem.tippar = 'D';
                    Ax.db.insert('@tmp_unload', mItem)
                    continue;
                }

                mIntCount = Ax.db.executeGet(`
                    <select prepare='false'>
                        <columns>COUNT(*)</columns>
                        <from table='@tmp_partid' />
                        <where>
                            empcode = ? AND
                            codpre  = ? AND
                            codpar != ? AND
                            ? MATCHES TRIM(codpar) || '*'
                        </where>
                    </select>    
                `, mItem.empcode, mItem.codpre, mItem.codpar, mItem.codpar);

                if (condition) {
                    mItem.tippar = 'I';
                } else {
                    mItem.tippar = 'U';
                }

                mItem.impprp = Ax.db.executeGet(`
                    <select>
                        <columns><nvl>SUM(gasprei), 0</nvl> impprp</columns>
                        <from table='cpar_prehist' />
                        <where>
                            empcode = ? AND
                            codpre  = ? AND
                            codpar  = ?
                        </where>
                    </select>
                `, mItem.empcode, mItem.codpre, mItem.codpar);

                mItem.imppe1 = Ax.db.executeGet(`
                    <select>
                        <columns>
                            ROUND(SUM(garticul_get_basesimp_mps('gcompedh','C',
                                        gcompedh.divisa, gcompedh.delega, gcompedh.tercer,
                                        gcompedh.tipdir, gcompedl.codart, gcompedl.varlog,
                                        gcompedl_datc.import, gcompedh.fecha, 'TTT',
                                        gcompedh.cabid, gcompedl.linid)),2) imppe1
                        </columns>
                        <from table='gcompedh'>
                            <join table='gcompedl'>
                                <on>gcompedh.cabid = gcompedl.cabid</on>
                                <join table='gcompedl_datc'>
                                    <on>gcompedl.linid = gcompedl_datc.linid</on>
                                </join>
                            </join>
                        </from>
                        <where>
                            gcompedh.empcode     = ? AND
                            gcompedl_datc.codpre = ? AND
                            gcompedl_datc.codpar = ?
                        </where>
                    </select>    
                `, mItem.empcode, mItem.codpre, mItem.codpar);

                mItem.imppe2 = mItem.imppe1;

                mItem.impal1 = Ax.db.executeGet(`
                    <select>
                        <columns>
                            ROUND(SUM(garticul_get_basesimp_mps('gcomalbh','C',
                                        gcommovh.divisa, gcommovh.delega, gcommovh.tercer,
                                        gcommovh.tipdir, gcommovl.codart, gcommovl.varlog,
                                        gcommovl_datc.import, gcommovh.fecmov, 'TTT',
                                        gcommovh.cabid, gcommovl.linid)),2) impal1
                        </columns>
                        <from table='gcommovl_datc'>
                            <join table='gcommovl'>
                                <on>gcommovl_datc.linid = gcommovl.linid</on>
                                <join table='gcommovh'>
                                    <on>gcommovl.cabid = gcommovh.cabid</on>
                                </join>
                            </join>
                        </from>
                        <where>
                            gcommovl_datc.codpre = ? AND
                            gcommovl_datc.codpar = ? AND
                            gcommovh.empcode     = ? 
                        </where>
                    </select>
                `, mItem.codpre, mItem.codpar, mItem.empcode);

                mItem.impal2 = mItem.impal1;

                mItem.impfa1 = Ax.db.executeGet(`
                    <select>
                        <columns>ROUND(SUM(garticul_get_basesimp_mps('gcomfach','C',
                                                gcomfach.divisa, gcomfach.delega, gcomfach.terfac,
                                                gcomfach.dirfac, gcomfacl.codart, gcomfacl.varlog,
                                                gcomfacl_datc.import, gcomfach.fecha, 'TTT',
                                                gcomfach.cabid, gcomfacl.linid)),2) impfa1
                        </columns>
                        <from table='gcomfacl_datc'>
                            <join table='gcomfacl'>
                                <on>gcomfacl_datc.linid = gcomfacl.linid</on>
                                <join table='gcomfach'>
                                    <on>gcomfacl.cabid = gcomfach.cabid</on>
                                </join>
                            </join>
                        </from>
                        <where>
                            gcomfacl_datc.codpre = ? AND
                            gcomfacl_datc.codpar = ? AND
                            gcomfach.empcode     = ?
                        </where>
                    </select>    
                `, mItem.codpre, mItem.codpar, mItem.empcode);

                mItem.impfa2 = mItem.impfa1;
                mItem.imppag = 0;

                let mArrGcomfach = Ax.db.executeQuery(`
                    <select>
                        <columns>DISTINCT cefectos.numero</columns>
                        <from table='gcomfach'>
                            <join table='gcomfacl'>
                                <on>gcomfach.cabid = gcomfacl.cabid</on>
                                <join table='gcomfacl_datc'>
                                    <on>gcomfacl.linid = gcomfacl_datc.linid</on>
                                </join>
                            </join>
                            <join table='capuntes'>
                                <on>capuntes.loteid IN (SELECT cenllote.loteid FROM cenllote, cenlsubs WHERE cenllote.loteid = cenlsubs.loteid AND cenllote.tabname = 'gcomfach' AND cenllote.modcon = 1 AND cenlsubs.procid = gcomfach.cabid)</on>
                                <join table='cefectos'>
                                    <on>capuntes.apteid = cefectos.apteid</on>
                                </join>
                            </join>
                        </from>
                        <where>
                            gcomfach.empcode     = ? AND
                            gcomfacl_datc.codpre = ? AND
                            gcomfacl_datc.codpar = ? AND
                            cefectos.estado      IN ('PA','CO')
                        </where>
                    </select>
                `, mItem.empcode, mItem.codpre, mItem.codpar);

                for (let mNum of mArrGcomfach) {
                    mDecImport = Ax.db.executeGet(`
                        <select>
                            <columns>
                                FIRST 1 
                                <nvl>import,0</nvl> import
                            </columns>
                            <from table='cefectos' />
                            <where>
                                numero = ?
                            </where>
                        </select>
                    `, mNum.numero);

                    mItem.imppag = mItem.imppag + mDecImport; 
                }

                if (mItem.imppag == 0) {
                    mItem.imppag = null;
                }

                mItem.impnoc = (mItem.impprp || 0) - (mItem.imppe1 || 0);
                mItem.impnos = (mItem.imppe2 || 0) - (mItem.impal1 || 0);
                mItem.impnof = (mItem.impal2 || 0) - (mItem.impfa1 || 0);
                mItem.impfan = (mItem.impfa2 || 0) - (mItem.imppag || 0);

                if (mItem.impprp == 0) mItem.impprp = null;
                if (mItem.imppe1 == 0) mItem.imppe1 = null;
                if (mItem.impnoc == 0) mItem.impnoc = null;
                if (mItem.imppe2 == 0) mItem.imppe2 = null;
                if (mItem.impal1 == 0) mItem.impal1 = null;
                if (mItem.impnos == 0) mItem.impnos = null;
                if (mItem.impal2 == 0) mItem.impal2 = null;
                if (mItem.impfa1 == 0) mItem.impfa1 = null;
                if (mItem.impnof == 0) mItem.impnof = null;
                if (mItem.impfa2 == 0) mItem.impfa2 = null;
                if (mItem.imppag == 0) mItem.imppag = null;
                if (mItem.impfan == 0) mItem.impfan = null;

                Ax.db.insert('@tmp_unload', mItem);
            }

            let mArrTmpUnload = Ax.db.executeQuery(`
                <select>
                    <columns>
                        empcode, codpre, codpar
                    </columns>
                    <from table='@tmp_unload' />
                    <where>
                        numany  = ${mIdx}  AND
                        empcode = ? AND
                        tippar  = 'D'
                    </where>
                </select>
            `, mRow.empcode);

            for (let mItem of mArrTmpUnload) {

                let mObjTmpUnload = Ax.db.executeQuery(`
                    <select>
                        <columns>
                            SUM(<nvl>impprp,0</nvl>) impprp, SUM(<nvl>imppe1,0</nvl>) imppe1, SUM(<nvl>impnoc,0</nvl>) impnoc,
                            SUM(<nvl>imppe2,0</nvl>) imppe2, SUM(<nvl>impal1,0</nvl>) impal1, SUM(<nvl>impnos,0</nvl>) impnos,
                            SUM(<nvl>impal2,0</nvl>) impal2, SUM(<nvl>impfa1,0</nvl>) impfa1, SUM(<nvl>impnof,0</nvl>) impnof,
                            SUM(<nvl>impfa2,0</nvl>) impfa2, SUM(<nvl>imppag,0</nvl>) imppag, SUM(<nvl>impfan,0</nvl>) impfan
                        </columns>
                        <from table='@tmp_unload' />
                        <where>
                            numany  = ${mIdx}  AND
                            empcode = ? AND
                            codpre  = ?  AND
                            codpar  <matches>'${mItem.codpar}*'</matches> AND
                            tippar  = 'I'
                        </where>
                    </select>
                `, mItem.empcode, mItem.codpre).toOne();

                mDecOTotprp = mDecOTotprp + (mObjTmpUnload.impprp || 0);
                mDecOTotpe1 = mDecOTotpe1 + (mObjTmpUnload.imppe1 || 0);
                mDecOTotnoc = mDecOTotnoc + (mObjTmpUnload.impnoc || 0);
                mDecOTotpe2 = mDecOTotpe2 + (mObjTmpUnload.imppe2 || 0);
                mDecOTotal1 = mDecOTotal1 + (mObjTmpUnload.impal1 || 0);
                mDecOTotnos = mDecOTotnos + (mObjTmpUnload.impnos || 0);
                mDecOTotal2 = mDecOTotal2 + (mObjTmpUnload.impal2 || 0);
                mDecOTotfa1 = mDecOTotfa1 + (mObjTmpUnload.impfa1 || 0);
                mDecOTotnof = mDecOTotnof + (mObjTmpUnload.impnof || 0);
                mDecOTotfa2 = mDecOTotfa2 + (mObjTmpUnload.impfa2 || 0);
                mDecOTotpag = mDecOTotpag + (mObjTmpUnload.imppag || 0);
                mDecOTotfan = mDecOTotfan + (mObjTmpUnload.impfan || 0);

                if (mObjTmpUnload.impprp == 0) 
                    mObjTmpUnload.impprp = null;
                if (mObjTmpUnload.imppe1 == 0) 
                    mObjTmpUnload.imppe1 = null;
                if (mObjTmpUnload.impnoc == 0) 
                    mObjTmpUnload.impnoc = null;
                if (mObjTmpUnload.imppe2 == 0) 
                    mObjTmpUnload.imppe2 = null;
                if (mObjTmpUnload.impal1 == 0) 
                    mObjTmpUnload.impal1 = null;
                if (mObjTmpUnload.impnos == 0) 
                    mObjTmpUnload.impnos = null;
                if (mObjTmpUnload.impal2 == 0) 
                    mObjTmpUnload.impal2 = null;
                if (mObjTmpUnload.impfa1 == 0) 
                    mObjTmpUnload.impfa1 = null;
                if (mObjTmpUnload.impnof == 0) 
                    mObjTmpUnload.impnof = null;
                if (mObjTmpUnload.impfa2 == 0) 
                    mObjTmpUnload.impfa2 = null;
                if (mObjTmpUnload.imppag == 0) 
                    mObjTmpUnload.imppag = null;
                if (mObjTmpUnload.impfan == 0) 
                    mObjTmpUnload.impfan = null;

                Ax.db.update('@tmp_unload', 
                    {
                        'impprp': mObjTmpUnload.impprp,
                        'imppe1': mObjTmpUnload.imppe1,
                        'impnoc': mObjTmpUnload.impnoc,
                        'imppe2': mObjTmpUnload.imppe2,
                        'impal1': mObjTmpUnload.impal1,
                        'impnos': mObjTmpUnload.impnos,
                        'impal2': mObjTmpUnload.impal2,
                        'impfa1': mObjTmpUnload.impfa1,
                        'impnof': mObjTmpUnload.impnof,
                        'impfa2': mObjTmpUnload.impfa2,
                        'imppag': mObjTmpUnload.imppag,
                        'impfan': mObjTmpUnload.impfan
                    }, 
                    {
                        'numany' : mIdx,
                        'empcode': mRow.empcode,
                        'codpre' : mItem.codpre,
                        'codpar' : mItem.codpar,
                        'tippar' : 'D'
                    }
                )

            }

            Ax.db.update('', 
                {
                    'impprp':mDecOTotprp, 
                    'imppe1':mDecOTotpe1, 
                    'impnoc':mDecOTotnoc, 
                    'imppe2':mDecOTotpe2, 
                    'impal1':mDecOTotal1, 
                    'impnos':mDecOTotnos, 
                    'impal2':mDecOTotal2, 
                    'impfa1':mDecOTotfa1, 
                    'impnof':mDecOTotnof, 
                    'impfa2':mDecOTotfa2, 
                    'imppag':mDecOTotpag, 
                    'impfan':mDecOTotfan 

                }, 
                {
                    'numany' : mIdx,
                    'empcode': mItem.empcode,
                    'tippar' : 'T'
                }
            )

        }
        
    }

    let mFileTemp = new Ax.io.File(mStrOFiletemp);

    ///table.unload
    let mRsTmpUnload = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_unload'/>
        </select>
    `);

    let mStrContent = '';
    let mArrColumnsNames = mRsTmpUnload.getColumnsNames();

    for ( let mRow of mRsTmpUnload ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    let mBlob = new Ax.sql.Blob(`${mStrOFiletemp}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    let mFile = new Ax.io.File(`${mStrOFiletemp}`);
    mFile.write(mBlob);

    ///file.copy & file.delete => file.renameTo
    mFileTemp.renameTo(mStrOFilename)

}