function mut_nfc_ordetrah_timeout() {
    //Iteració sobre les tasques en estat 'En procés'.
    let mArrOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                seqno, cabid, docser, assign_user, assign_type,
                fin_number, ini_datcon
            </columns>
            <from table='mut_nfc_ordetrah' />
            <where>
                estado IN (2,12) AND
                ini_datcon IS NOT NULL
            </where>
        </select>
    `).toJSONArray();

    for (let mRow of mArrOrdetrah) {
        //Si no han transcorregut 13h, saltar.
        let mDobTimDif = (new Ax.util.Date() - new Ax.util.Date(mRow.ini_datcon))/3600;

        if (mDobTimDif < 13 || mDobTimDif == null) {
            continue;
        }

        //Cancel·lar tasca (si tasca de finalització no està Ended).
        let mObjAssign = Ax.db.executeQuery(`
            <select>
                <columns>
                    task_code, assign_state
                </columns>
                <from table='apps_sfa_task_assign' />
                <where>
                    assign_user   = ? AND
                    assign_type   = ? AND
                    assign_number = ?
                </where>
            </select>
        `, mRow.assign_user, mRow.assign_type, mRow.fin_number).toOne();

        if (mObjAssign.assign_state == 2) {
            continue;
        }

        Ax.db.update('apps_sfa_task_assign', 
            {
                'assign_state': 3
            }, 
            {
                'assign_user'  : mRow.assign_user,
                'assign_type'  : mRow.assign_type,
                'assign_number': mRow.fin_number
            }
        )

        //Passar acció NFC a estat Expirat.
        Ax.db.update('mut_nfc_ordetrah', 
            {
                'estado': -3,
                'cancel_user': Ax.db.getUser(),
                'cancel_date': new Ax.sql.Date()
            }, 
            {
                'seqno'  : mRow.seqno
            }
        )

        //Si es tracta d'una OT agrupada, expirar les subtasques.
        if (mObjAssign.task_code == 'PAI') {
            let mArrNfcOrdetrah = Ax.db.executeQuery(`
                <select>
                    <columns>
                        seqno seqsub, fin_number sub_number
                    </columns>
                    <from table='mut_nfc_ordetrah' />
                    <where>
                        seqdes = ? AND
                        estado IN (2,12)
                    </where>
                </select>
            `, mRow.seqno).toJSONArray();

            for (let item of mArrNfcOrdetrah) {
                Ax.db.update('apps_sfa_task_assign', 
                    {
                        'assign_state': 3
                    }, 
                    {
                        'assign_user'  : mRow.assign_user,
                        'assign_type'  : mRow.assign_type,
                        'assign_number': item.sub_number
                    }
                )

                Ax.db.update('mut_nfc_ordetrah', 
                    {
                        'estado'     : -13,
                        'cancel_user': Ax.db.getUser(),
                        'cancel_date': new Ax.sql.Date()
                    }, 
                    {
                        'seqno': item.seqsub
                    }
                )
            }
        }

        let mStrLinkot = `<![CDATA[http://erpmutua2012/coreapps/wic_mutua/formauto_s.jsp?code=gman_ordetrah&dbms=]]>${Ax.db.getCode()}<![CDATA[&cond=gman_ordetrah.docser+%3D+%27]]>${mRow.docser}<![CDATA[%27]]>`;

        let mStrNomali = null;
        let mStrOperac = null;

        let mObjGmanOrdetrah = Ax.db.executeQuery(`
            <select>
                <columns>
                    FIRST 1 gdepgrph.nomgrp locali, gman_ordetrah.operac
                </columns>
                <from table='gman_ordetrah'>
                    <join table='gdepgrpl'>
                        <on>gman_ordetrah.delega = gdepgrpl.delega</on>
                        <on>gman_ordetrah.depart = gdepgrpl.depart</on>
                        <join table='gdepgrph'>
                            <on>gdepgrpl.codgru = gdepgrph.codigo</on>
                        </join>
                    </join>
                </from>
                <where>
                    gman_ordetrah.docser = ?
                </where>
                <order>gdepgrph.codigo</order>
            </select>
        `, mRow.docser).toOne();

        let mObjCperEmpleado = Ax.db.executeQuery(`
            <select>
                <columns>nomemp, tercer</columns>
                <from table='cper_empleado' />
                <where>
                    codigo = ?
                </where>
            </select>
        `, mRow.assign_user).toOne();

        let mObjMailConf  = Ax.db.call('mut_sys_mail_select','mut_nfc_ordetrah_timeout','general');

        let mStrMailfrom = mObjMailConf.mail_from;
        let mStrMailto   = mObjMailConf.mail_to;
        let mStrMailcc   = mObjMailConf.mail_cc;
        let mStrMailbcc   = mObjMailConf.mail_bcc;

        mStrMailto = Ax.db.call('mut_nfc_get_mailconf', mObjCperEmpleado.tercer, 0);

        if (mStrMailto.length != 0) {
            let mMail = new Ax.mail.MailerMessage();
            mMail.from(mStrMailfrom);
            mMail.to(mStrMailto);
            mMail.cc(mStrMailcc);
            mMail.bcc(mStrMailbcc);
            mMail.subject(`NFC Mobile - ${mRow.docser} expirada`);
            mMail.setHtml(`
                <html>
                    <body>
                        <p>La següent ordre de treball ha superat el temps màxim (13h) per a la seva conclusió.</p>
                        <p />
                        <p>Localització: ${mObjGmanOrdetrah.locali || ''}</p>
                        <p>Ordre de treball: <a href='${mStrLinkot}'>${mRow.docser}</a></p>
                        <p>Operació: ${mObjGmanOrdetrah.operac || ''}</p>
                        <p>Operari: ${mRow.assign_user} ${mObjCperEmpleado.nomemp || ''}</p>
                    </body>
                </html>
            `);

            //Se hace el envío del email
            let mMailer = new Ax.mail.Mailer();
            mMailer.setSMTPServer("localhost", 25);
            mMailer.send(mMail);            
        }

        Ax.db.call('mut_nfc_ordetrah_unlock', mRow.seqno)

    }
}