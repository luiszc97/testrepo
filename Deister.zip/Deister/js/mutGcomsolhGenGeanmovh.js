function mutGcomsolhGenGeanmovh(pIntCabid, pStrTipsol, pStrTipean) {
    //Insert de geanmovh. 
    let mObjGcomsolh = Ax.db.executeQuery(`
        <select>
            <columns>
            *
            </columns>
            <from table='gcomsolh' />
            <where>
                gcomsolh.cabid = ?
            </where>  
        </select>
    `, pIntCabid).toOne();

    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>
                count(*)
            </columns>
            <from table='geanmovh' />
            <where>
                    geanmovh.docori = ?
                AND geanmovh.tipdoc = ?
            </where>
        </select> 
    `, mObjGcomsolh.docser, pStrTipean);

    if (mObjGcomsolh.tipdoc == pStrTipsol && mObjGcomsolh.estcab == 'V' && !mIntCount) {
        let mIntCabean = Ax.db.executeFunction('geanmovh_inserta',
            mObjGcomsolh.delega,    // delega              
            mObjGcomsolh.depart,    // depart              
            mObjGcomsolh.codalm,    // almori              
            null,                   // almdes              
            pStrTipean,             // tipdoc              
            new Ax.sql.Date(),      // fecmov              
            null,                   // docser              
            null,                   // refter              
            mObjGcomsolh.docser,    // docori              
            null,                   // oriaux              
            null,                   // terexp              
            null,                   // direxp              
            null,                   // coment              
            0,                      // genrf               
            'N'                     // indmod 
        ).toValue();

        let mIntRowean = Ax.db.executeGet(`
            <select>
                <columns>
                    <rowid table='geanmovh' /> rowean
                </columns>
                <from table='geanmovh' />
                <where>
                    cabid = ?
                </where>
            </select>
        `, mIntCabean);

        if (mIntRowean != null) {
            Ax.db.call('geanmovh', 'I', mIntRowean)
        }

    }

}