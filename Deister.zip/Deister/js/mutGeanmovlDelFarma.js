function mutGeanmovlDelFarma(pIntCabid, pIntLinid) {
    if (Ax.db.getCode() != 'mutua') {
        return;
    }

    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='geanmovh' />
            <where>
                geanmovh.cabid = ?       AND
                geanmovh.tipdoc IN ('COCF','DEVA') AND
                geanmovh.almori MATCHES '??FAR'    AND
                geanmovh.fecmov &gt;= '01-12-2012'
            </where>
        </select>
    `, pIntCabid);

    if (mIntCount) {
        let mDbName = Ax.db.of('lt_farma_mps');
        mDbName.delete('mps_gcomsoll_erp', 
            {
                'cabid': pIntCabid,
                'linid': pIntLinid
            }
        )
    }

}