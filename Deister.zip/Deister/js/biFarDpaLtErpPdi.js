function biFarDpaLtErpPdi() {
    let mStrPathname = '/mnt/deister_dwh/out/';
    let mDatToday   = new Ax.sql.Date();
    let mDatTimeTasp = mDatToday.format('ddMMyy_HHmmss');

    let mStrFileLogFarprdaW = `${mStrPathname}bi_log_farprda_${mDatTimeTasp}.work`;
    let mStrFileLogFarprdaF = `${mStrPathname}bi_log_farprda_${mDatTimeTasp}.pdi`;
    let mStrFileLogFaralbaW = `${mStrPathname}bi_log_faralba_${mDatTimeTasp}.work`;
    let mStrFileLogFaralbaF = `${mStrPathname}bi_log_faralba_${mDatTimeTasp}.pdi`;
    let mStrFileLogFarsoliW = `${mStrPathname}bi_log_farsoli_${mDatTimeTasp}.work`;
    let mStrFileLogFarsoliF = `${mStrPathname}bi_log_farsoli_${mDatTimeTasp}.pdi`;

    let dbName = Ax.db.of('lt_farma');

    //Carreguem pr_da_hi en la taula temporal @tmp_log_farprda 
    dbName.execute(`DROP TABLE IF EXISTS @tmp_log_farprda`);
    dbName.execute(`
        <select intotemp='@tmp_log_farprda'>
            <columns>*</columns>
            <from table='pr_da_hi' />
            <where>
                fecha_beg between today-weekday(today)-6 and today-weekday(today)
            </where>
        </select>
    `);

    //Carreguem albaranes,lineas en la taula temporal @tmp_log_faralba
    dbName.execute(`DROP TABLE IF EXISTS @tmp_log_faralba`);
    dbName.execute(`
        <select intotemp='@tmp_log_faralba'>
            <columns>
                albaranes.albaran          h_albaran        ,
                albaranes.unidad           h_unidad         ,
                albaranes.fecha_albaran    h_fecha_albaran  ,
                albaranes.fecha_envio      h_fecha_envio    ,
                albaranes.tipo_albaran     h_tipo_albaran   ,
                albaranes.servicio         h_servicio       ,
                albaranes.gfh              h_gfh            ,
                albaranes.pte              h_pte            ,
                albaranes.c_f              h_c_f            ,
                albaranes.almacen_o        h_almacen_o      ,
                albaranes.almacen_d        h_almacen_d      ,
                albaranes.transferido      h_transferido    ,
                albaranes.fecha_tras       h_fecha_tras     ,
                                                
                lineas.albaran          l_albaran        ,
                lineas.linea            l_linea          ,
                lineas.cantidad         l_cantidad       ,
                lineas.articulo         l_articulo       ,
                lineas.stactu           l_stactu         ,
                lineas.lote             l_lote           ,
                lineas.fecha_cad        l_fecha_cad      ,
                lineas.precio_med       l_precio_med     ,
                lineas.unidades_pte     l_unidades_pte   ,
                lineas.unidades_res     l_unidades_res   ,
                lineas.cod_nac          l_cod_nac
            </columns>
            <from table='albaranes'>
                <join table='lineas'>
                    <on>lineas.albaran = albaranes.albaran</on>
                </join>
            </from>
            <where>
                    unidad = "DPA." 
                and albaranes.fecha_albaran between today-weekday(today)-6 and today-weekday(today)
            </where>
        </select>
    `);

    let mFileFarprdaW = new Ax.io.File(mStrFileLogFarprdaW);
    let mFileFaralbaW = new Ax.io.File(mStrFileLogFaralbaW);

    ///<table.unload>
    let mRsTmpLogFarprda = dbName.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_log_farprda'/>
        </select>
    `);

    let mStrContent = '';
    let mArrColumnsNames = mRsTmpLogFarprda.getColumnsNames();

    for ( let mRow of mRsTmpLogFarprda ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    let mBlob = new Ax.sql.Blob(`${mStrFileLogFarprdaW}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    let mFile = new Ax.io.File(`${mStrFileLogFarprdaW}`);
    mFile.write(mBlob);

    ////////////////////////////////////////////////////

    let mRsTmpLogFaralba = dbName.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_log_faralba'/>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsTmpLogFaralba.getColumnsNames();

    for ( let mRow of mRsTmpLogFaralba ) {
        for ( let mStrColumnName of mArrColumnsNames ) {
            mStrContent += `${mRow[mStrColumnName]}|`;
        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrFileLogFaralbaW}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrFileLogFaralbaW}`);
    mFile.write(mBlob);

    ///file.copy & file.delete => file.renameTo
    mFileFarprdaW.renameTo(mStrFileLogFarprdaF)
    mFileFaralbaW.renameTo(mStrFileLogFaralbaF);

    //=================================================================
    //Carreguem gcomsolh,gcomsoll en la taula temporal @tmp_log_farsoli
    //=================================================================
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_log_farsoli`);
    Ax.db.execute(`
        <select intotemp='@tmp_log_farsoli'>
            <columns>
                gcomsolh.cabid           h_cabid        ,
                gcomsolh.tipdoc          h_tipdoc       ,
                gcomsolh.empcode         h_empcode      ,
                gcomsolh.delega          h_delega       ,
                gcomsolh.depart          h_depart       ,
                gcomsolh.fecsol          h_fecsol       ,
                gcomsolh.docser          h_docser       ,
                gcomsolh.tercer          h_tercer       ,
                gcomsolh.tipdir          h_tipdir       ,
                gcomsolh.divisa          h_divisa       ,
                gcomsolh.cambio          h_cambio       ,
                gcomsolh.impres          h_impres       ,
                gcomsolh.codpre          h_codpre       ,
                gcomsolh.codpar          h_codpar       ,
                gcomsolh.solici          h_solici       ,
                gcomsolh.clasif          h_clasif       ,
                gcomsolh.estcab          h_estcab       ,
                gcomsolh.errcab          h_errcab       ,
                gcomsolh.wkfcab          h_wkfcab       ,
                gcomsolh.terexp          h_terexp       ,
                gcomsolh.direxp          h_direxp       ,
                gcomsolh.imptot          h_imptot       ,
                gcomsolh.coment          h_coment       ,
                gcomsolh.codfor          h_codfor       ,
                gcomsolh.fecini          h_fecini       ,
                gcomsolh.fecfin          h_fecfin       ,
                gcomsolh.docori          h_docori       ,
                gcomsolh.dtogen          h_dtogen       ,
                gcomsolh.dtopp           h_dtopp        ,
                gcomsolh.movest          h_movest       ,
                gcomsolh.movhis          h_movhis       ,
                gcomsolh.codalm          h_codalm       ,
                gcomsolh.indmod          h_indmod       ,
                gcomsolh.auxchr1         h_auxchr1      ,
                gcomsolh.auxchr2         h_auxchr2      ,
                gcomsolh.auxchr3         h_auxchr3      ,
                gcomsolh.auxchr4         h_auxchr4      ,
                gcomsolh.auxchr5         h_auxchr5      ,
                gcomsolh.auxnum1         h_auxnum1      ,
                gcomsolh.auxnum2         h_auxnum2      ,
                gcomsolh.auxnum3         h_auxnum3      ,
                gcomsolh.auxnum4         h_auxnum4      ,
                gcomsolh.auxnum5         h_auxnum5      ,
                gcomsolh.user_created    h_user_created ,
                gcomsolh.date_created    h_date_created ,
                gcomsolh.user_updated    h_user_updated ,
                gcomsolh.date_updated    h_date_updated ,
                                                
                gcomsoll.linid           l_linid        ,
                gcomsoll.cabid           l_cabid        ,
                gcomsoll.orden           l_orden        ,
                gcomsoll.codart          l_codart       ,
                gcomsoll.varlog          l_varlog       ,
                gcomsoll.desvar          l_desvar       ,
                gcomsoll.cansol          l_cansol       ,
                gcomsoll.udmsol          l_udmsol       ,
                gcomsoll.canpre          l_canpre       ,
                gcomsoll.udmpre          l_udmpre       ,
                gcomsoll.precio          l_precio       ,
                gcomsoll.dtolin          l_dtolin       ,
                gcomsoll.canped          l_canped       ,
                gcomsoll.canser          l_canser       ,
                gcomsoll.canadj          l_canadj       ,
                gcomsoll.canext          l_canext       ,
                gcomsoll.impnet          l_impnet       ,
                gcomsoll.estlin          l_estlin       ,
                gcomsoll.errlin          l_errlin       ,
                gcomsoll.wkflin          l_wkflin       ,
                gcomsoll.codcom          l_codcom       ,
                gcomsoll.desamp          l_desamp       ,
                gcomsoll.indmod          l_indmod       ,
                gcomsoll.linori          l_linori       ,
                gcomsoll.lincon          l_lincon       ,
                gcomsoll.auxchr1         l_auxchr1      ,
                gcomsoll.auxchr2         l_auxchr2      ,
                gcomsoll.auxchr3         l_auxchr3      ,
                gcomsoll.auxnum1         l_auxnum1      ,
                gcomsoll.auxnum2         l_auxnum2      ,
                gcomsoll.auxnum3         l_auxnum3       
            </columns>
            <from table='gcomsolh'>
                <join table='gcomsoll'>
                    <on>gcomsoll.cabid = gcomsolh.cabid</on>
                </join>
            </from>
            <where>
                    gcomsolh.clasif = "DPA"
                and gcomsolh.tipdoc in ("DEVF","FARM")
                and gcomsolh.docser matches "99*" 
                and gcomsolh.fecsol between today-weekday(today)-6 and today-weekday(today)
            </where>
        </select>
    `);

    ///<file.writer.open>
    let mFileLogFarsoliW = new Ax.io.File(mStrFileLogFarsoliW);

    ///<table.unload>
    let mRsTmpLogFarsoli = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_log_farsoli'/>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsTmpLogFarsoli.getColumnsNames();

    for ( let mRow of mRsTmpLogFarsoli ) {
        for ( let mStrColumnName of mArrColumnsNames ) {
            mStrContent += `${mRow[mStrColumnName]}|`;
        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrPathname}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrPathname}`);
    mFile.write(mBlob);

    ///file.copy & file.delete => file.renameTo
    mFileLogFarsoliW.renameTo(mStrFileLogFarsoliF)

}