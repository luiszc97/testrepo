function mutOmnGeanmovhExport(pIntCabid, pStrDocser) {
    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>
                COUNT(*)
            </columns>
            <from table='mut_omn_geanmovh' />
            <where>
                omn_cabean = ?
            </where>
        </select>
    `, pIntCabid);

    if (!mIntCount) {
        return;
    }

    //Inicializar el log. 
    Ax.db.beginWork();
    mIntClogprohLogId = Ax.db.call('clogproh_ini', 'mutOmnGeanmovhExport', null, 0);

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    let mDate = new Ax.sql.Date();
    mDate = mDate.format('yyyyMMdd');

    let mStrFilename = `/erpsync/farmacia/omn/entrades/mut_geanmovh_${pStrDocser}_${mDate}.dat`;

    let mFile = new Ax.io.File(mStrFilename);
    
    //Recorrem els consums i els escrivim en el fitxer i la taula de detall temporal.
    let mIntNumlin = 0;

    let mArrGeanmovh = Ax.db.executeQuery(`
        <select>
            <columns>
                omn_ordid, omn_fecha, omn_docori, omn_codarmari, omn_codart, omn_canmov, omn_tipdoc,
                omn_cabean, omn_linean, user_created, date_created
            </columns>
            <from table='mut_omn_geanmovh' />
            <where>
                omn_cabean = ?
            </where>
            <order>omn_ordid</order>
        </select>
    `, pIntCabid);

    for (let mRow of mArrGeanmovh) {

        try {
            mIntNumlin++;
            
            let mStrTex = `${mRow.omn_tipdoc}|${mRow.omn_codarmari}|${mRow.omn_docori}|${mRow.omn_fecha}|${mRow.omn_codart}|${mRow.omn_canmov}\n`;

            mFile.write(mStrTex);
    
            Ax.db.call('clogprol_set', 
                mIntClogprohLogId,
                null,
                null,
                null,
                null,
                null,
                null,
                mRow.omn_linean,
                null
            );
            
        } catch (error) {
            Ax.db.rollbackWork();

            Ax.db.call('clogprol_set', 
                mIntClogprohLogId,
                Ax.util.Error.getMessage(error),
                Ax.util.Error.getErrorCode(error),
                null,
                null,
                null,
                null,
                mRow.omn_linean,
                null
            );
        }

    }

    //Volquem els registres del document processat a la taula d'historic. 
    Ax.db.execute(`
        INSERT INTO mut_omn_geanmovh_his 
            (omn_ordid, omn_tipdoc, omn_fecha, omn_docori, omn_codarmari,
             omn_codart, omn_canmov, omn_cabean, omn_linean, user_created, date_created, omn_filename)

            SELECT 
                omn_ordid, omn_tipdoc, omn_fecha, omn_docori, omn_codarmari, omn_codart, omn_canmov, 
                omn_cabean, omn_linean, user_created, date_created, '${mStrFilename}'
            FROM mut_omn_geanmovh
            WHERE omn_cabean = ? 
    `, pIntCabid);

    Ax.db.delete('mut_omn_geanmovh', 
        {
            'omn_cabean': pIntCabid
        }
    );

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    // Cerrar el log de proceso.
    Ax.db.call('clogproh_fin', mIntClogprohLogId);

    return mIntClogprohLogId;

}