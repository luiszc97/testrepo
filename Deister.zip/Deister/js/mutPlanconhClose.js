function mutPlanconhClose() {
    let mArrPlanconh = Ax.db.executeQuery(`
        <select>
            <columns>cabid</columns>
            <from table='mut_planconh' />
            <where>
                estado = 'A' AND
                fecven &lt;= TODAY
            </where>
        </select>    
    `).toJSONArray();

    for (let mRow of mArrPlanconh) {
        Ax.db.update('mut_planconh', 
            {
                'estado': 'C',
                'user_updated': Ax.db.getUser(),
                'date_updated': new Ax.sql.Date()
            }, 
            {
                'cabid': mRow.cabid
            }
        )
    }
}