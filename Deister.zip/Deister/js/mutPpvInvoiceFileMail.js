function mutPpvInvoiceFileMail() {
    let mIntFound = 0;
    let mStrHtmlog = `
        <html>
        <head>
            <style>
            table,th,td {font-family:sans-serif; font-size:8pt; border:1px solid black; border-collapse:collapse; padding-right:20px}
            th {color:white; background-color:black; text-align:left;}
            </style>
        </head>

        <body>
            <table>
                <tr alignment='left'>
                    <th>ID</th>
                    <th>Proveïdor</th>
                    <th>Empresa</th>
                    <th>Document</th>
                    <th>Origen</th>
                    <th>Path</th>
                    <th>Data</th>
                </tr>
    `; 

    let mArrMutFilelnk = Ax.db.executeQuery(`
        <select>
            <columns>
                mut_filelnk.cabid,
                gcomfach.tercer,
                ctercero.nombre,
                gcomfach.empcode,
                gcomfach.refter,
                mut_filelnk.origen,
                mut_filelnk.pathname,
                mut_filelnk.date_created
            </columns>
            <from table='mut_filelnk'>
                <join type='left' table='gcomfach'>
                    <on>mut_filelnk.cabid = gcomfach.cabid</on>
                    <join table='ctercero'>
                        <on>gcomfach.tercer = ctercero.codigo</on>
                    </join>
                </join>
            </from>
            <where>
                mut_filelnk.tabname = 'gcomfach'
            </where>
            <order>date_created</order>
        </select>
    `);

    for (let mRow of mArrMutFilelnk) {
        let mFolder = new Ax.io.File(mRow.pathname);

        if (!(mFolder.isFile() || mFolder.isDirectory())) {
            mIntFound = 1;

            mStrHtmlog = mStrHtmlog + `
                <tr>
                    <td>${mRow.cabid}</td>
                    <td>${mRow.tercer}</td>
                    <td>${mRow.empcode}</td>
                    <td>${mRow.refter}</td>
                    <td>${mRow.origen}</td>
                    <td>${mRow.pathname}</td>
                    <td>${mRow.date_created}</td>
                </tr>
            `;
        }
    }

    if (!mIntFound) {
        return;
    }

    mStrHtmlog = mStrHtmlog + `
                </table>
            </body>
        </html>
    `;

    let mObjMail = Ax.db.call('mutSysMailSelect', 'mutPpvInvoiceFileMail','general');

    let mMail = new Ax.mail.MailerMessage();
    mMail.from(mObjMail.mail_from);
    mMail.to(mObjMail.mail_to);
    mMail.cc(mObjMail.mail_cc);
    mMail.bcc(mObjMail.mail_bcc);
    mMail.subject('Incorporació de Factures: PDFs desapareguts');
    mMail.setHtml(mStrHtmlog);

    //Se hace el envío del email
    let mMailer = new Ax.mail.Mailer();
    mMailer.setSMTPServer("localhost", 25);
    mMailer.send(mMail);      

}