function mutIneIncidencesPrint(pIntCabid) {

    /** Local function __getLabel()
     * 
     *  Return label for field or box.
     * 
     *  PARAMETERS: 
     *  =============
     *      
     *      @param      {string}       pStrLBL              label.
     *      @param      {string}       pStrLang             Lang
     */
    function __getLabel (pStrLBL, pStrLang) {
        return Ax.ext.webapp.getLabel(pStrLBL, pStrLang);
    }

    /** Local function __getColumnLabel()
     * 
     *  Column label of a table that returns a field or box.
     * 
     *  PARAMETERS: 
     *  =============
     *      
     *      @param      {string}       pStrTable            Table name
     *      @param      {string}       pStrColumn           Column name
     *      @param      {string}       pStrLang             Lang
     */

    function __getColumnLabel (pStrTable, pStrColumn, pStrLang) {
        return Ax.ext.webapp.getColumn(pStrTable,  pStrColumn, pStrLang).getColMemo();
    }
    
	// =========================================================================
    // Load mut_inp_incidences data.
    // =========================================================================
    let  mObjIneIncidences = Ax.db.executeQuery(`
        <select>
            <columns>
                mut_ine_incidences.rowid,
                mut_ine_incidences.cabid,
                
                mut_ine_actions.descrp ine_action,
                CASE WHEN mut_ine_incidences.ine_trans = 'C' THEN "CLIENT" ELSE "PROVEÏDOR" END ine_transp,
                mut_ine_incidences.ine_fecha,
                
                cuserids.username ine_contmag,
                mut_ine_incidences.ine_contact ine_contprov,
                
                mut_ine_incidences.ine_tercer ine_nifprov,
                ctercero.nombre ine_prov,
                ctercero.nombre ine_nomter,
                
                cterdire.direcc ine_direcc, 
                <trim><nvl>cterdire.codpos, ''</nvl></trim> || ' ' || <trim><nvl>cterdire.poblac, ''</nvl></trim> ine_cppob,
                cprovinc.nomprv || ', ' || ctiponac.nomnac ine_prvnac,
                
                <nvl>mut_ine_incidences.ine_docser,'ND'</nvl> ine_comand,
                
                mut_ine_types.descrp ine_incid,
                
                mut_ine_incidences.ine_txtres ine_descrp,
                "Segell:" ine_segell,
                CURRENT ine_date,
                "Signatura:" ine_sign
            </columns>
            <from table="mut_ine_incidences">
                <join type='left' table='cuserids'>
                    <on>mut_ine_incidences.user_updated = cuserids.usercode</on>
                </join>
                <join type='left' table='mut_ine_types'>
                    <on>mut_ine_incidences.ine_tipoinc = mut_ine_types.codigo</on>
                </join>
                <join type='left' table='mut_ine_actions'>
                    <on>mut_ine_incidences.ine_accion = mut_ine_actions.codigo</on>
                </join>
                <join table='ctercero'>
                    <on>mut_ine_incidences.ine_tercer = ctercero.codigo</on>
                </join>
                <join type='left' table='cempresa'>
                    <on>mut_ine_incidences.ine_empcode = cempresa.empcode</on>
                </join>
                <join type='left' table='cterdire'>
                    <on>mut_ine_incidences.ine_tercer  = cterdire.codigo</on>
                    <on>mut_ine_incidences.ine_tipdir  = cterdire.tipdir</on>
                    <join type='left' table='ctiponac'>
                        <on>cterdire.codnac  = ctiponac.codigo</on>
                    </join>
                    <join type='left' table='cprovinc'>
                        <on>cterdire.codnac  = cprovinc.codnac</on>
                        <on>cterdire.codprv  = cprovinc.codigo</on>
                    </join>
                </join>
                <join table='cempresa' alias='cempresa2'>
                    <on>cempresa2.empcode = '14'</on>
                </join>
            </from>
            <where>
                cabid = ?
            </where>
        </select>
    `, pIntCabid).toOne();

    // =======================================================================
    // GET IMAGE'S PATH IF EXISTS, OTHERWISE IT RETURNS A DEFAULT PATH
    // =======================================================================
    let FILEPATH = '';

    FILEPATH =  mObjIneIncidences.logo_top_image;

    // =========================================================================
    // STYLE VARIABLES
    // =========================================================================
    const BACKCOLOR  =  mObjIneIncidences.color_primary   ?  mObjIneIncidences.color_primary   : "#000000";
    const TEXTCOLOR  =  "#FFFFFF";
    const FONT_SIZE   = 9;
    const PADDING     ='2pt';
    const BORDERCOLOR = '#000000';
	//Se recupera el idioma del cliente, en caso venga informado; si no se toma el idioma del usuario.
    const LOCALE      = mObjIneIncidences.print_lang != null ? mObjIneIncidences.print_lang : Ax.ext.user.getLang() || 'ca';
    const DATE_FORMAT = LOCALE == "es" ? "dd/MM/yyyy hh.mm:ss" : "MM/dd/yyyy hh.mm:ss";
    const DATE_FORMAT1 = LOCALE == "es" ? "dd/MM/yyyy" : "MM/dd/yyyy";
    const NumFormat = new Ax.text.NumberFormat(LOCALE);
    const FONT_S_REG  = 8;
    const FONT_NAME   =  mObjIneIncidences.font_name       || "Noto Sans";
    const FONT_S_TEX  = 9;
    const BORDERWIDTH = '1';

    /**
     * Se inicializa el espacio para el inicio, que se va a ampliar cuando exista comentario del documento.
     */
    let mSpaceBefore = 8;

    //Se inicializa el espacio para el bloque final.
    let mSpaceAfter = 7.0;

    /********************************************/
	/**             Inicio del fop.           **/
	/********************************************/	
    let template = new Ax.fop.SinglePageTemplate("A4");

    template.setRoot(root => {
        //root.setDebug("*");
        // Default Page layout    
        root.getSimplePageMaster().getRegionBefore().setExtent(mSpaceBefore);
        root.getSimplePageMaster().getRegionAfter().setExtent(1.0);
        root.getSimplePageMaster().getRegionStart().setExtent(1.0);
        root.getSimplePageMaster().getRegionEnd().setExtent(1.0);
        //root.getSimplePageMaster().setMargins(0, 0, 0, 0);
        
        // Get the FOPSimplePageMaster now (we only have one)
        // after adding the first .. we can not call again
        // cause we have two ... and dont know witch one ..
        let spm       = root.getSimplePageMaster();
        let pageOnly  = root.addSimplePageMaster("PageOnly").apply(spm);
        let pageFirst = root.addSimplePageMaster("PageFirst").apply(spm);
        let pageRest  = root.addSimplePageMaster("PageRest").apply(spm);
        let pageLast  = root.addSimplePageMaster("PageLast").apply(spm);
        
        // In last page we need to acommodate Tax and Notes table. So we requie more space
        pageFirst.setMargins(0, 0, 1.0, 0); //TODO AJUSTAR TOTALES SOLO A LA ÚLTIMA PAGINA
        pageFirst.getRegionAfter().setExtent(2);
        pageRest.setMargins(0, 0, 1.0, 0);
        pageRest.getRegionAfter().setExtent(2);
        pageLast.setMargins(0, 0, 1.0, 0);
        pageLast.getRegionAfter().setExtent(mSpaceAfter);
        pageOnly.setMargins(0, 0, 1.0, 0);
        pageOnly.getRegionAfter().setExtent(mSpaceAfter);
        
        // Create a pagesequence master
        let master = root.createPageSequenceMaster("master");    
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageOnly"),  "only");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageFirst"), "first");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageRest"),  "rest");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageLast"),  "last");
        root.addPageSequenceMaster(master);
        root.getPageSequence().setMasterReferenceName("master");

    });

    // =======================================================================
    // CONFIGURE START
    // =======================================================================
    template.setStart(start => {
    });

    // =======================================================================
    // CONFIGURE END
    // =======================================================================
    template.setEnd(end => {
    });

    // =======================================================================
    // CONFIGURE BEFORE
    // =======================================================================
    template.setBefore(before => {
        // =======================================================================
        // Agregamos la imagen de la empresa y los datos
        // =======================================================================
        let mTableImg = before.addTable();             
        
        mTableImg.setFontSize(FONT_SIZE);
        mTableImg.setFontFamily(FONT_NAME);
        mTableImg.addColumn().setColumnWidth(9);
        mTableImg.addColumn().setColumnWidth(1);
        mTableImg.addColumn().setColumnWidth(4.5);
        mTableImg.addColumn().setColumnWidth(4.5);
        let mRowImg  = mTableImg.getBody().addRow();
        let mCellImg     = mRowImg.addCell();
        let mCellBlank   = mRowImg.addCell();
        let mCellEmpData = mRowImg.addCell();
        let mCellEmpData2 = mRowImg.addCell();

        mCellImg.setDisplayAlign("center");
        let bytes = Ax.ext.db.getDatabaseDocLogo();
        
        if (FILEPATH != null) {
           mCellImg.addBlock().setTextAlign("center").addExternalGraphic(FILEPATH).setContentWidth(9).setProperty('content-height','3cm');
        } else {
        	mCellImg.addBlock().setTextAlign("center").addExternalGraphic(bytes).setContentWidth(9).setProperty('content-height','3cm');
        }

        // =======================================================================
		// Datos del albaran 
        // =======================================================================
        mCellEmpData.addBlock(__getColumnLabel('mut_inp_incidences', 'cabid', LOCALE).bold()+ ': ').setPaddingBottom("1pt")
                                                            .setPaddingTop("1pt").setPaddingLeft("1pt").setMarginLeft(0.1).setBorderBottomStyle("solid");
        mCellEmpData2.addBlock(mObjIneIncidences.cabid || '').setPaddingBottom("1pt").setTextAlign('right')
                                                            .setPaddingTop("1pt").setPaddingRight("1pt").setMarginRight(0.1).setBorderBottomStyle("solid");

        if (mObjIneIncidences.inp_action != null) {
            let mTableInfoCompleL = before.addTable();
            mTableInfoCompleL.setFontSize(FONT_SIZE);
            mTableInfoCompleL.setFontFamily(FONT_NAME); 
            mTableInfoCompleL.setSpaceBefore('5px');
            mTableInfoCompleL.addColumn();

            let mRowInfoComp = mTableInfoCompleL.getBody().addRow();

            let mCellInfoComp = mRowInfoComp.addCell();
            mCellInfoComp.addBlock(mObjIneIncidences.ine_action || '').setPaddingBottom("1pt").setPaddingTop("2pt").setMarginLeft(0.1);
        }

        // =======================================================================
		// Cajas para Contacto y Proveedor 
        // =======================================================================
        let mTableContacProve = before.addTable();
        mTableContacProve.setSpaceBefore("0.3cm");
        mTableContacProve.setFontSize(FONT_SIZE);
        mTableContacProve.setFontFamily(FONT_NAME);
        mTableContacProve.addColumn().setColumnWidth(9);
        mTableContacProve.addColumn().setColumnWidth(1);
        mTableContacProve.addColumn().setColumnWidth(9);

        let mRowContacProveL = mTableContacProve.getBody().addRow(); 
        
        let mCellPedPorL = mRowContacProveL.addCell().setBackgroundColor(BACKCOLOR).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        let mCellBlankL  = mRowContacProveL.addCell();
        let mCellEntreL  = mRowContacProveL.addCell().setBackgroundColor(BACKCOLOR).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        
        mCellPedPorL.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_nomter', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);
        mCellEntreL.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_prov', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);

        let mTableContacProve2 = before.addTable();
        mTableContacProve2.setFontSize(FONT_SIZE);
        mTableContacProve2.setFontFamily(FONT_NAME);
        mTableContacProve2.addColumn().setColumnWidth(4.5);
        mTableContacProve2.addColumn().setColumnWidth(4.5);
        mTableContacProve2.addColumn().setColumnWidth(1);
        mTableContacProve2.addColumn().setColumnWidth(9);

        let mRowPedEnt = mTableContacProve2.getBody().addRow();

        let mCellPediPor = mRowPedEnt.addCell().setBorderBottomStyle("solid").setBorderLeftStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        let mCellPediPor2 = mRowPedEnt.addCell().setBorderBottomStyle("solid").setBorderRightStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        let mCellBlank2  = mRowPedEnt.addCell()
        let mCellEntre   = mRowPedEnt.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);

        mCellPediPor.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_transp', LOCALE).bold()).setPaddingBottom("1pt").setPaddingTop("4pt").setMarginLeft(0.2);
        mCellPediPor.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_contmag', LOCALE).bold()).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.2);
        mCellPediPor.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_contprov', LOCALE).bold()).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.2);
        mCellPediPor.addBlock(__getColumnLabel('mut_ine_incidences', 'ine_fecha', LOCALE).bold() + ':').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.2);
        
        mCellPediPor2.addBlock(mObjIneIncidences.ine_transp   || '-').setPaddingBottom("1pt").setPaddingTop("4pt");
        mCellPediPor2.addBlock(mObjIneIncidences.ine_contmag  || '-').setPaddingBottom("1pt").setPaddingTop("1pt");
        mCellPediPor2.addBlock(mObjIneIncidences.ine_contprov || '-').setPaddingBottom("1pt").setPaddingTop("1pt");
        mCellPediPor2.addBlock(new Ax.sql.Date(mObjIneIncidences.ine_fecha).format(DATE_FORMAT1).toString() || '-').setPaddingBottom("1pt").setPaddingTop("1pt");

        mCellEntre.addBlock(mObjIneIncidences.ine_prov   || '-').setPaddingBottom("1pt").setPaddingTop("4pt").setMarginLeft(0.2);
        mCellEntre.addBlock(mObjIneIncidences.ine_direcc || '-').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.2);
        mCellEntre.addBlock(mObjIneIncidences.ine_cppob  || '-').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.2);
        mCellEntre.addBlock(mObjIneIncidences.ine_prvnac || '-').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.2);

        // =======================================================================
		// Cajas para COMANDA y INCIDÈNCIA en
        // =======================================================================
        let mTableComanIncid = before.addTable();
        mTableComanIncid.setSpaceBefore("0.3cm");
        mTableComanIncid.setFontSize(FONT_SIZE);
        mTableComanIncid.setFontFamily(FONT_NAME);
        mTableComanIncid.addColumn().setColumnWidth(9);
        mTableComanIncid.addColumn().setColumnWidth(1);
        mTableComanIncid.addColumn().setColumnWidth(9);

        let mRowComanIncidL = mTableComanIncid.getBody().addRow(); 
        
        let mCellCommanL = mRowComanIncidL.addCell().setBackgroundColor(BACKCOLOR).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        let mCellVacioL  = mRowComanIncidL.addCell();
        let mCellIncidL  = mRowComanIncidL.addCell().setBackgroundColor(BACKCOLOR).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        
        mCellCommanL.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_comand', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);
        mCellIncidL.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_incid', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);

        let mRowComanIncidL2 = mTableComanIncid.getBody().addRow(); 

        let mCellCommanL2 = mRowComanIncidL2.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        let mCellVacioL2  = mRowComanIncidL2.addCell();
        let mCellIncidL2  = mRowComanIncidL2.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);

        mCellCommanL2.addBlock(mObjIneIncidences.ine_comand  || '-').setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);
        mCellIncidL2.addBlock(mObjIneIncidences.ine_incid  || '-').setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0)

    });

    template.setBody(body => { 
        // =======================================================================
		// Caja de comentario 
        // =======================================================================   
        let mTableComent = body.addTable();
        mTableComent.setSpaceBefore("0.3cm");
        mTableComent.setFontSize(FONT_SIZE);
        mTableComent.addColumn();  
        mTableComent.setFontFamily(FONT_NAME);  

        let mRowComentL = mTableComent.getBody().addRow(); 
        let mcellComentL = mRowComentL.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR).setBackgroundColor(BACKCOLOR);

        mcellComentL.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_descrp', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);
        
        let mRowComent = mTableComent.getBody().addRow(); 
        let mcellComent = mRowComent.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
       
        mcellComent.addBlock(mObjIneIncidences.ine_descrp   || '-').setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);
        

    });

    template.setAfter(after => { 
        let mTableComanIncid = after.addTable();
        mTableComanIncid.setSpaceBefore("0.3cm");
        mTableComanIncid.setFontSize(FONT_SIZE);
        mTableComanIncid.setFontFamily(FONT_NAME);
        mTableComanIncid.addColumn().setColumnWidth(9);
        mTableComanIncid.addColumn().setColumnWidth(1);
        mTableComanIncid.addColumn().setColumnWidth(4.5);
        mTableComanIncid.addColumn().setColumnWidth(4.5);

        let mRowComanIncidL = mTableComanIncid.getBody().addRow(); 
        
        let mCellCommanL = mRowComanIncidL.addCell().setBackgroundColor(BACKCOLOR).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        let mCellVacioL  = mRowComanIncidL.addCell();
        let mCellIncidL  = mRowComanIncidL.addCell().setBackgroundColor(BACKCOLOR).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        let mCellIncidL2 = mRowComanIncidL.addCell().setBackgroundColor(BACKCOLOR).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);

        mCellCommanL.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_segell', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);
        mCellIncidL.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_date', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);
        mCellIncidL2.addBlock(__getColumnLabel('mut_ine_incidences_print', 'ine_sign', LOCALE)).setColor(TEXTCOLOR).setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);

        let mRowComanIncidL2 = mTableComanIncid.getBody().addRow(); 

        let mCellCommanL2 = mRowComanIncidL2.addCell();
        let mCellVacioL2  = mRowComanIncidL2.addCell();
        let mCellIncidL22 = mRowComanIncidL2.addCell();
        let mCellIncidL23 = mRowComanIncidL2.addCell();

        mCellIncidL22.addBlock(new Ax.sql.Date(mObjIneIncidences.ine_date).format(DATE_FORMAT).toString() || '-').setPaddingBottom("1pt").setPaddingTop("4pt").setMargins(0.1,0,0,0);

    });

    // ====================================================================
    // GENERATE PDF
    // ====================================================================
    let mFop = template.toFOP();
    let mPdf = new Ax.fop.Processor().transform(mFop);
    return mPdf; 

}

return mutIneIncidencesPrint(1)