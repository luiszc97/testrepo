//Registrar a la taula mut_fac_conhist les dades basiques 
//de l'ultima situacion de la factura (modificada)        
//Nomes registrarem si existeix unaltre registre de la    
//factura a aquesta taula, aixo vol dir que s'ha          
//descomptabilitzat com a minim un cop                    
let mIntNumreg = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*) numreg</columns>
        <from table='mut_fac_conhist' />
        <where>
            naturaleza = 'C' AND
            cabid  = ?
        </where>
    </select>
`, pIntCabid);

if (mIntNumreg) {
    let mArrGcomfach = Ax.db.executeQuery(`
        <select prefix='mut_fac_conhist_'>
            <columns>
                0 orden,
                'C' naturaleza,
                gcomfach.cabid,
                'C' accio,
                gcomfach.empcode,
                ctercero.cif idemisor,
                gcomfach.docser,
                gcomfach.fecha,
                gcomfach.fecope,
                gcomfach.refter,
                gcomfach.tercer,
                gcomfach.imptot,
                gcomfach.impfac,
                essii_facturas.erp_estado,
                essii_facturas.tipocomunicacion,
                essii_facturas.sii_estado,
                essii_facturas.user_updated sii_user_updated,
                essii_facturas.date_updated sii_date_updated,
                <system.user.getCode /> user_created,
                current date_created,
                max(NVL(essii_factuhis.orden,0)) sii_orden
            </columns>
            <from table='gcomfach'>
                <join table='ctercero'>
                    <on>ctercero.codigo = gcomfach.tercer</on>
                </join>
                <join table='essii_facturas' type='left'>
                    <on>gcomfach.empcode = essii_facturas.empcode</on>
                    <on>ctercero.cif     = essii_facturas.idemisor</on>
                    <on>gcomfach.refter  = essii_facturas.numfactura</on>
                    <on>gcomfach.fecha   = essii_facturas.fechafactura</on>
                    <join table='essii_factuhis'>
                        <on>essii_facturas.empcode      = essii_factuhis.empcode</on>
                        <on>essii_facturas.idemisor     = essii_factuhis.idemisor</on>
                        <on>essii_facturas.numfactura   = essii_factuhis.numfactura</on>
                        <on>essii_facturas.fechafactura = essii_factuhis.fechafactura</on>
                    </join>
                </join>
            </from>
            <where>
                gcomfach.cabid = ?
            </where>
            <group>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20</group>
        </select>
    `, pIntCabid);

    
}
