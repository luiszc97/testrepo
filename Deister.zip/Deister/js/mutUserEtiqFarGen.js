function mutUserEtiqFarGen(pStrUserDept, pStrUserSupd, pStrUserCode) {
    //Selecció de dades  

    let mObjUserEtiqFar = {};
    mObjUserEtiqFar.user_pimp = null;
    mObjUserEtiqFar.user_ppor = null;
    mObjUserEtiqFar.user_pout = null;

    mObjUserEtiqFar = Ax.db.executeQuery(`
        <select>
            <columns>
                *    
            </columns>
            <from table='mut_user_etiq_far' />
            <where>
                    mut_user_etiq_far.user_dept = ?
                AND mut_user_etiq_far.user_supd = ?
                AND mut_user_etiq_far.user_code = ?
            </where>
        </select>
    `, pStrUserDept, pStrUserSupd, pStrUserCode);

    if (mObjUserEtiqFar.user_pimp == null) {
        mObjUserEtiqFar.user_pimp = '172.17.10.214';
    }

    if (mObjUserEtiqFar.user_pout == null) {
        mObjUserEtiqFar.user_pout = 5000
    }

    if (mObjUserEtiqFar.user_ppor == null) {
        mObjUserEtiqFar.user_ppor = 9100
    }

    let mStrZplchr = `
        ~CT~~CD,~CC^~CT~
        ^XA~TA000~JSN^LT0^MNW^PON^PMN^LH0,0^JMA^PR4,4~SD15^JUS^LRN^CI0^XZ
        ~DG000.GRF,01536,024,
        ,::::::::::::::::::::::::::::::::::L01FC0R030U03,L01870R030U03,L018180Q030U03,:L0180C0Q030U03,::L0180C0F81FC03EC6EFC0FB1BE3C03E06F8FC0H060,L0180618C1C6063C783018F1E367063078C30I070,L018063061830C1C70303071C3C30C1870C30I060,L018063061818C0C60303031C3830C1870C3,L018063031818C0C6030303181830C0C6063,L01806603181980C603060318183180C6063,L018067FF181980C6030603181831FFC6063,L0180C600181980C60306031818318006063,::L0180C3001818C0C6030303181830C006063,L018183001818C0C6018303181830C00606180,L018183061830C1C6018307181830C18606180H060,L0187018C1C6063C601818F181830630606180H070,M0FC00F81FC03E0I0E0F80K03E0J0E0H060,S0180,L0gYF8,:S0180,:,:~DG001.GRF,01792,028,
        ,::::::::::::::::::::::M03F0O0C0Q060U06,M0E1C0N0C0Q060U06,M0C0C0N0C0Q060U06,L018060N0C0Q060U06,L0180P0C0Q060U06,::M0C003031FC03EC1F03F807D8DDF81F637C7807C0DF1F80H0C0M0E003031C6063C31838C0C78F06031E3C6CE0C60F1860I0E0M03003031830C1C60C3061838E06060E387861830E1860I0C0M01E03031818C0C60C3031818C060606387061830E186,N0303031818C0C6063031818C060606303061818C0C6,N01C303181980CC063033018C060C06303063018C0C6,O0C303181980CFFE3033018C060C06303063FF8C0C6,O06303181980CC003033018C060C063030630H0C0C6,::O063031818C0C6003031818C060606303061800C0C6,O063071818C0C6003031818C030606303061800C0C3,M0C0C30F1830C1C60C3061838C03060E303061830C0C30I0C0M0E1C39B1C6063C31838C0C78C03031E303060C60C0C30I0E0M03F00F01FC03E01F03F807C0H01C1F0L07C0I01C0H0C0S0180M03,L07FhMF0:S0180M03,:,:::::::::::::~DG002.GRF,00768,012,
        ,:::::::::::::::::::::::::::::::K0300C0,:K0380C0,:K03C0C0,:K0360C0,K0360C0F81BE3C0H018,K0H30C18C1E3670H01C,K0H30C3061C3C30H018,K0318C3031C3830,K0318C303181830,K0318C603181830,K030CC603181830,:K0306C603181830,:K0303C303181830,:K0301C306181830H018,K0301C18C181830H01C,P0F80M018,,J01FUFE,:,::::::^XA
        ^MMT
        ^PW480
        ^LL0280
        ^LS0
        ^FT40,192^BQN,2,6
        ^FDLA,<m_user_nif />^FS
        ^FT184,103^A0N,28,28^FH\^FD<m_user_dept />^FS
        ^FT184,186^A0N,28,28^FH\^FD<m_user_supd />^FS
        ^FT40,250^A0N,28,28^FH\^FD<m_user_name />^FS
        ^FT160,64^XG000.GRF,1,1^FS
        ^FT160,160^XG001.GRF,1,1^FS
        ^FT0,224^XG002.GRF,1,1^FS
        ^PQ1,0,1,Y^XZ
        ^XA^ID000.GRF^FS^XZ
        ^XA^ID001.GRF^FS^XZ
        ^XA^ID002.GRF^FS^XZ
    `;

    let mSocket = new Ax.net.SocketClient(mObjUserEtiqFar.user_pimp, mObjUserEtiqFar.user_ppor);

    /* Creamos el fichero blob */
    let ficheroBlob = new Ax.sql.Blob("FileName.txt");
    ficheroBlob.setContentType("text/plain");
    ficheroBlob.setContent(mStrZplchr);

    let mBytes = ficheroBlob.getBytes();

    //get queue state
    mSocket.connect();
    mSocket.write(`${mSocket}${mBytes}`);
    mSocket.await();
    mSocket.setTimeout(mObjUserEtiqFar.user_pout);

}