function mutCatlabImport() {
    let mStrPathname = '/erpsync/catlab/';
    let mStrPathback = '/erpsync/catlab/bak/';

    let mFolder = new Ax.io.File(mStrPathname);

    let mArrFile = mFolder.listFiles();

    if (mArrFile.length == 0) {
        throw new Ax.lang.Exception('No hi ha cap fitxer per processar');
    }

    //1. Esborrar registres
    Ax.db.delete('cexterno', 
        {
            'empcode': '01'
        }
    )
    let mStrFileName;

    for (let mFile of mArrFile) {
        if (mFile.getName().match(/.*\.csv|.*\.CSV|.*\.txt|.*\.TXT/) == null) {
            continue;
        }

        mStrFileName = mFile.getName();

        //Lectura del fitxer.
        let mStrContent = mFile.readString();

        let mObjCatlab = {};
        mObjCatlab.id = 1;

        for(let mStrLine of mStrContent) {
            //S'afegeix un espai al inici i al final del registre per a que l'array tingui sempre 5 columnes
            //encare que les últimes columnes no estiguin informades
            mStrLine = ` ${mStrLine} `;
            let mArrLine = mStrLine.split(';');

            for (let mIdx = 0; mIdx < mArrLine.length; mIdx++) {
                let mElem = mArrLine[mIdx].trim();
                
                if (mIdx == 0 && mElem.length == 0) {
                    continue;
                }

                switch (mIdx) {
                    case '0':
                        mObjCatlab.data = mElem.format('dd/MM/yy');
                    break;
                    case '1':
                        mObjCatlab.seccio = mElem
                    break;
                    case '2':
                        mObjCatlab.compte = mElem
                    break;
                    case '3':
                        mObjCatlab.debe = Number(mElem)
                    break;
                    case '4':
                        mObjCatlab.haber = Number(mElem)
                    break;
                    default:
                    break;
                }
            }

            if (mObjCatlab.id == 1) {
                //Primer registre 
                Ax.db.execute(`
                    INSERT INTO cexterno 
                    (apteid, diario, moneda, cambio, empcode, proyec, 
                     seccio, jusser,  docser, fecha, asient, cuenta, 
                     concep, debe, haber, sistem,  fecval, divdeb,
                     divhab, totim1, totim2, basdiv, ctaexp, centro)
                    SELECT 
                        0 apteid,
                        'DG' diario,
                        'EUR' moneda,
                        1 cambio,
                        '01' empcode, 
                        '010000' proyec,
                        mut_catlab_get_seccio('01', substr('${mObjCatlab.seccio}', 6, 3)) seccio,
                        ('01NOMI' || to_char(CURRENT, "%y") || '-') jusser,
                        ('01NOMI' || to_char(CURRENT, "%y") || '-') docser,
                        date(extend(${mObjCatlab.data}, year to day)) fecha,
                        0 asient,
                        mut_catlab_get_ccuentas('01', ${mObjCatlab.compte}) cuenta,
                        'NOMINA' concep,
                        ${mObjCatlab.debe} debe,
                        0 haber,
                        'A' sistem,
                        date(extend(${mObjCatlab.data}, year to day)) fecval,
                        ${mObjCatlab.debe} divdeb,
                        0 divhab,
                        0 totim1,
                        0 totim2,
                        0 basdiv,
                        'GE' ctaexp,
                        mut_catlab_get_ccosdesc('01', substr('${mObjCatlab.seccio}', 4, 2)) centro
                    FROM cdataemp
                    WHERE ${mObjCatlab.debe} != 0
                `);

                Ax.db.execute(`
                    INSERT INTO cexterno 
                        (apteid, diario, moneda, cambio, empcode, proyec, 
                        seccio, jusser,docser, fecha, asient, cuenta,
                        concep, debe, haber, sistem, fecval, divdeb, 
                        divhab, totim1, totim2, basdiv, ctaexp, centro)
                    SELECT 
                        0 apteid,
                        'DG' diario,
                        'EUR' moneda,
                        1 cambio,
                        '01' empcode,
                        '010000' proyec,
                        mut_catlab_get_seccio('01', substr('${mObjCatlab.seccio}', 6, 3)) seccio,
                        (CASE WHEN ${mObjCatlab.debe} = 0 
                            THEN '01NOMI' || to_char(CURRENT, "%y") || '-' 
                            ELSE '0' 
                        END) jusser,
                        (CASE WHEN ${mObjCatlab.debe} = 0 
                            THEN '01NOMI' || to_char(CURRENT, "%y") || '-' 
                            ELSE '0' 
                        END) docser,
                        date(extend(${mObjCatlab.data}, year to day)) fecha,
                        0 asient,
                        mut_catlab_get_ccuentas('01', ${mObjCatlab.compte}) cuenta,
                        'NOMINA' concep,
                        0 debe,
                        ${mObjCatlab.haber} haber,
                        'A' sistem,
                        date(extend(${mObjCatlab.data}, year to day)) fecval,
                        0 divdeb,
                        ${mObjCatlab.haber} divhab,	
                        0 totim1,
                        0 totim2,
                        0 basdiv,
                        'GE' ctaexp,	
                        mut_catlab_get_ccosdesc('01', substr('${mObjCatlab.seccio}', 4, 2)) centro
                    FROM cdataemp
                    WHERE ${mObjCatlab.haber} != 0
                `);    

            } else {
                Ax.db.execute(`
                    INSERT INTO cexterno 
                        (apteid, diario, moneda, cambio, empcode, proyec,
                         seccio, jusser, docser, fecha, asient, cuenta, 
                         concep, debe, haber, sistem, fecval, divdeb, 
                         divhab, totim1, totim2, basdiv, ctaexp, centro)
                    SELECT 
                        0 apteid,
                        'DG' diario,
                        'EUR' moneda,
                        1 cambio,
                        '01' empcode,
                        '010000' proyec,
                        mut_catlab_get_seccio('01', substr('${mObjCatlab.seccio}', 6, 3)) seccio,
                        '0' jusser,
                        '0' docser,
                        date(extend(${mObjCatlab.data}, year to day)) fecha,
                        0 asient,
                        mut_catlab_get_ccuentas('01', ${mObjCatlab.compte}) cuenta,
                        'NOMINA' concep,
                        ${mObjCatlab.debe} debe,
                        0 haber,
                        'A' sistem,
                        date(extend(${mObjCatlab.data}, year to day)) fecval,
                        ${mObjCatlab.debe} divdeb,
                        0 divhab,
                        0 totim1,
                        0 totim2,
                        0 basdiv,
                        'GE' ctaexp,
                        mut_catlab_get_ccosdesc('01', substr('${mObjCatlab.seccio}', 4, 2)) centro
                    FROM cdataemp
                    WHERE ${mObjCatlab.debe} != 0
                `);

                Ax.db.execute(`
                    INSERT INTO cexterno 
                        (apteid, diario, moneda, cambio, empcode, proyec, 
                            seccio, jusser, docser, fecha, asient, cuenta, 
                            concep, debe, haber, sistem, fecval, divdeb, 
                            divhab, totim1, totim2, basdiv, ctaexp, centro)
                    SELECT 
                        0 apteid,
                        'DG' diario,
                        'EUR' moneda,
                        1 cambio,
                        '01' empcode,
                        '010000' proyec,
                        mut_catlab_get_seccio('01', substr('${mObjCatlab.seccio}', 6, 3)) seccio,
                        '0' jusser,
                        '0' docser,
                        date(extend(${mObjCatlab.data}, year to day)) fecha,
                        0 asient,
                        mut_catlab_get_ccuentas('01',${mObjCatlab.compte}) cuenta,
                        'NOMINA' concep,
                        0 debe,
                        ${mObjCatlab.haber} haber,
                        'A' sistem,
                        date(extend(${mObjCatlab.data}, year to day)) fecval,
                        0 divdeb,
                        ${mObjCatlab.haber} divhab,
                        0 totim1,
                        0 totim2,
                        0 basdiv,
                        'GE' ctaexp,
                        mut_catlab_get_ccosdesc('01', substr('${mObjCatlab.seccio}', 4, 2)) centro
                    FROM cdataemp
                    WHERE ${mObjCatlab.haber} != 0
                `);         

            }

            mObjCatlab.id++;
        }
    }

    //4. actualitzar registres
    Ax.db.execute(`
        UPDATE cexterno
            SET asient = NULL 
        WHERE
            empcode = '01'
            AND docser = ('01NOMI' || TO_CHAR(CURRENT, "%y") || '-')
    `)

    Ax.db.execute(`
        UPDATE cexterno
            SET docser = ('01NOMI' || TO_CHAR(fecha, "%y") || '-'),
                jusser = ('01NOMI' || TO_CHAR(fecha, "%y") || '-')
        WHERE
            empcode = '01'
            AND asient IS NULL
    `)

    Ax.db.execute(`
        UPDATE cexterno
            SET ctaexp = NULL,
                centro = NULL
        WHERE
            empcode = '01'
            AND LEFT(cuenta,1) NOT IN ('2','6','7')
    `)

    mFolder.renameTo(mStrPathback + mStrFileName)

}