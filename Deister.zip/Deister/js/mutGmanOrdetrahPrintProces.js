/////////////////////////////////////////////////
//
// Imprimeix les ordres de treball.
//    
// Funciones locales:          . local_sendfax
//                             . local_sendmail
//                             . local_sendlpr 
//
/////////////////////////////////////////////////
function mutGmanOrdetrahPrintProces(pStrReenvi, pStrSqlcond) {
    //local_sendfax: Genera ficheros .sub i .pdf para ser enviados por ZFAX
    function __local_sendfax(pIntDocidx,
        pStrTerlang,
        pStrDocser,
        pStrTabname,
        pStrSqlcond,
        pStrForimp,
        pStrFaxfrom,
        pStrFaxnum, 
        pStrSystem, 
        pStrNombre, 
        pStrEmpname,
        pStrCodalm
        ) 
    {
        //Número de fax vacío o mal escrito 
        if (pStrFaxnum.length == 0) {
            throw new Ax.lang.Exception('Número de fax vacío o mal escrito.')
        }

        //Variable de localització dels arxius generats
        let mStrFilePath = '';

        //codigos de sistemas de fax (gdataemp.sysfax)
        let mStrSysfaxRfax = 'R';
        let mStrSysfaxOtherfax = 'O';

        //Envio FAX
        let mRegexp = `/SGA.*/`;
        let mStrMailFrom;
            
        if (pStrCodalm.match(mRegexp)){
            mStrMailFrom = 'manteniment@ofimat.int';
        } else {
            throw new Ax.lang.Exception(`Magatzem ${pStrCodalm} no contemplat.`)
        }


        switch (pStrSystem) {
            //Sistema de fax: RIGHTFAX
            case mStrSysfaxRfax:
                let mStrSubject = `${pStrEmpname} ${pStrDocser}`;   
                let mStrText = `'/Name=${mStrSubject}/Fax=${pStrFaxnum}/com=${pStrNombre}/'<rightfaxuser@mutuaterrassa.com>`;

                let mStrMailto  = mStrText.replace(",", " ");
                let mStrMailcc  = null;
                let mStrMailbcc = null;
                let mStrDbsname = Ax.db.getCode();
                let mStrContent = `<FCSFILE:${mStrDbsname}_MAN.DOC>`;

                __local_sendmail(pIntDocidx, pStrTerlang, pStrTabname,
                    pStrSqlcond, pStrForimp, mStrMailFrom, mStrMailto,
                    mStrMailcc, mStrMailbcc, mStrSubject, mStrContent,
                    pStrFaxnum);

            break;
            
            //Sistema de fax: OTHERFAX 
            case mStrSysfaxOtherfax:
                mStrFilePath = 'c:/jas/temp/other/';
            break;
        
            default:
                throw new Ax.lang.Exception(`Sistema de envío de fax [${pStrSystem}] no soportado.`)
            break;
        }

        return new Ax.sql.Date();

    }

    //local_sendmail: Genera fichero .pdf i lo envia por correo electronico
    function __local_sendmail(
        pIntDocidx,
        pStrIdioma,
        pStrTabname,
        pStrSqlcond,
        pStrForimp,
        pStrMailfrom,
        pStrMailto,
        pStrMailcc, 
        pStrMailbcc, 
        pStrSubject, 
        pStrContent,
        pStrFaxNum
    ) 
    {
        //Dirección de correo vacía
        if (pStrMailto.length == 0) {
            throw new Ax.lang.Exception('Dirección de correo vacía.')
        }

        pStrMailfrom = pStrMailfrom.replace(';',',');
        pStrMailto   = pStrMailto.replace(';',',');
        pStrMailcc   = pStrMailcc.replace(';',',');
        pStrMailbcc  = pStrMailbcc.replace(';',',');

        //Creació del document en format PDF
        mStrFilename = `${pStrTabname}.pdf`;

        let mFile = Ax.ext.webapp.fopForm(pStrForimp ,options => {
            options.setType('pdf');                                                         
            options.setCond(pStrSqlcond);
            options.setDatabase('mutua');
        }).out.toBlob().getBytes();

        //Adjuntar fitxers de gdocdocs relacionats amb el registre.
        let mArrAttach = [];
        //let mArrFile = [];

        mArrAttach.push(mFile);
    
        let mArrGdocdocs = Ax.db.execute(`
            <select>
                <columns>
                    gdocdocs.file_type,
                    gdocdocs.file_name,
                    gdocdocs.file_data
                </columns>
                <from table='gdocdocs'/>
                <where>
                        gdocdocs.cabid = ?
                    AND (CASE WHEN gdocdocs.device IN ('1','3') AND ? IS NULL THEN 1
                            WHEN gdocdocs.device IN ('2','3') AND ? IS NOT NULL THEN 1
                            ELSE 0
                        END) = 1
                </where>
            </select>        
        `, pIntDocidx, pStrFaxNum, pStrFaxNum).toJSONArray();

        for (let mRow of mArrGdocdocs) {
            //Construir el fitxer amb el contingut del camp.
            mStrFilename = mRow.file_name;
            let mF = new Ax.io.File(`/tmp/${mStrFilename}`);
            mF.write(mRow.file_data);

            let mOut = Ax.ext.webapp.fopForm(pStrForimp ,options => {
                options.setType(mRow.file_type);                                                         
                options.setCond(pStrSqlcond);
                options.setDatabase('mutua');
            }).out.toBlob().getBytes();

            mArrAttach.push(mOut);
            //mArrFile.push(`/tmp/${mStrFilename}`)
        }

        //Composició del mail: HTML i fitxer adjunt
        let mStrTextBodyMail = `${pStrTabname}`;

        let mMail = new Ax.mail.MailerMessage();
        mMail.from(pStrMailfrom);
        mMail.to(pStrMailto);
        mMail.cc(pStrMailcc)
        mMail.bcc(pStrMailbcc)
        mMail.subject(pStrSubject);
        mMail.setText(pStrContent);
        
        for (let mRow of mArrAttach) {
            mMail.addAttachment(mRow);
        }

        //Se hace el envío del email
        let mMailer = new Ax.mail.Mailer();
        mMailer.setSMTPServer("localhost", 25);
        mMailer.send(mMail);
        
        //Afegim informació de l'enviament a ctermail
        let mObjTabName = Ax.db.executeQuery(`
            <select>
                <columns>${pStrTabname}.tercer, ${pStrTabname}.docser, gdelegac.empcode </columns>
                <from table='${pStrTabname}'>
                    <join table='gdelegac'>
                        <on>gdelegac.codigo = ${pStrTabname}.delega</on>
                    </join>
                </from>
                <where>${pStrSqlcond}</where>
            </select>    
        `).toOne();

        //Registre en les taules de l´aplicació
        if (pStrFaxNum != null) {
            Ax.db.insert('cterfaxs', 
                {
                    'seqno': 0,
                    'tercer': mObjTabName.tercer,
                    'empcode': mObjTabName.empcode,
                    'fecha': new Ax.sql.Date(),
                    'fax_a': mObjTabName.tercer,
                    'fax_de': Ax.db.getUser(),
                    'fax_cc': null,
                    'fax_ref': `COMANDA:${mObjTabName.docser}`,
                    'fax_type': 5,
                    'fax_num': pStrFaxNum
                }
            )
        } else {
            Ax.db.insert('ctermail', 
                {
                    'seqno': 0,
                    'tercer': mObjTabName.tercer,
                    'mail_io': 0,
                    'mail_server': Ax.ext.system.getRequest().getRemoteHost(),
                    'mail_user': Ax.db.getUser(),
                    'mail_uid': Ax.db.getCode(),
                    'mail_from': pStrMailto,
                    'mail_to': pStrMailto,
                    'mail_replyto': null,
                    'mail_sentdate': new Ax.sql.Date(),
                    'mail_subject': pStrSubject,
                    'mail_xmailer': 'DEISTER WebMail',
                    'flag_attach': 1,
                    'mail_message':mMailer
                }
            )
        }

        return new Ax.sql.Date();

    }

    //local_sendlpr: Genera ficheros .sub i .pdf para ser enviados por ZFAX
    function __local_sendlpr(
        pIntSeqno,  
        pIntDocidx, 
        pStrTabname,
        pStrSqlcond,
        pStrForimp,
        pStrUser, 
        pStrPrinter
    ) {
        //Nombre de impresora vacío
        if (pStrPrinter.length == 0) {
            throw new Ax.lang.Exception('Nombre de dispositivo de impresión vacío.');
        }

        let mOut2 = Ax.ext.webapp.fopForm(pStrForimp ,options => {
            options.setType('pdf');                                                         
            options.setCond(pStrSqlcond);
            options.setDatabase('mutua');
        }).out.toBlob().getBytes();

        Ax.ext.printer.sendFile(pStrPrinter, mOut2, pStrForimp+'.pdf' );
  
        return new Ax.sql.Date();

    }

    //
    Ax.db.execute(`
        UPDATE gdoc_imprimir
        SET date_generated = ?
        WHERE ? = '1'
          AND ${pStrSqlcond}
    `, null, pStrReenvi);

    let mArrGdocImprimir = Ax.db.executeQuery(`
        <select>
            <columns>
                gdoc_imprimir.seqno,   gdoc_imprimir.tabname, gdoc_imprimir.printobj,
                gdoc_imprimir.docser,  gdoc_imprimir.docid,   gdoc_imprimir.devfax,
                gdoc_imprimir.devmail, gdoc_imprimir.devmailcc, gdoc_imprimir.devmailcco,
                gdoc_imprimir.devprint,gdoc_imprimir.user_created, gdoc_imprimir.tercer,
                gdoc_imprimir.terlang, gdoc_imprimir.codalm,
                ctercero.nombre,
                cempresa.empname,
                CASE WHEN gdoc_imprimir.terlang not in ('ca','en','es') THEN 'es' ELSE gdoc_imprimir.terlang END idioma
            </columns>
            <from table='gdoc_imprimir'>
                <join type='left' table='ctercero'>
                    <on>ctercero.codigo = gdoc_imprimir.tercer</on>
                </join>
                <join type='left' table='cempresa'>
                    <on>cempresa.empcode = gdoc_imprimir.empcode</on>
                </join>
                <join type='left' table='gproveed'>
                    <on>gproveed.codigo = gdoc_imprimir.tercer</on>
                </join>
            </from>
            <where>
                    gdoc_imprimir.date_generated IS NULL
                AND gdoc_imprimir.printobj IN ('mut_gman_ordetrah_ext_print', 'mut_gman_ordetrah_pre_print')
                AND ${pStrSqlcond}
            </where>
            <order>1 DESC</order>
        </select>    
    `);

    for (let mRow of mArrGdocImprimir) {
        //Mensajes de error i fecha que se actualizan en gdoc_imprimir
        let mStrnewErrfax = null;
        let mStrnewErrmail = null;
        let mStrnewErrprint = null;
        let mDateGenerated = null;
        let mStrcontent = null;
        let mStrsqlcond = `gman_ordetrah.cabid = ${mRow.docid}`;

        //ENVÍO FAX
        if (mRow.devfax) {
            try {
                //Sistema de envío de fax RIGHTFAX
                let mStrSysfax = 'R';

                mDateGenerated = __local_sendfax(mRow.docid, mRow.terlang, mRow.docser,
                    mRow.tabname, mStrsqlcond, mRow.printobj, mRow.user_created, mRow.devfax, mStrSysfax, mRow.nombre, mRow.empname, mRow.codalm
                )

            } catch (error) {
                mStrnewErrfax = Ax.util.Error.getMessage(error);
            }
        }

        //ENVÍO MAIL 
        if (mRow.devmail) {
            try {
                if (mRow.idioma != 'es') {
                    mRow.idioma = 'ca';
                }

                let mStrTextData = Ax.db.executeGet(`
                    <select>
                        <columns>
                            NVL(cdoctext.text_data, (SELECT text_data
                                                    FROM mps:cdoctext
                                                    WHERE tabname   = 'gdoc_imprimir'
                                                        AND text_code = <string trim='true'>${mRow.printobj}_email</string>
                                                        AND idioma    = <string trim='true'>${mRow.idioma}</string>)) text_data
                        </columns>
                        <from table='cdoctext'/>
                        <where>
                                cdoctext.tabname   = 'gdoc_imprimir'
                            AND cdoctext.text_code = <string trim='true'>${mRow.printobj}_email</string>
                            AND cdoctext.idioma    = <string trim='true'>${mRow.idioma}</string>
                        </where>
                    </select>
                `);
                
                let mStrPedido;

                if (mRow.idioma == 'ca') {
                    mStrPedido = 'Ordre de treball';

                } else {
                    mStrPedido = 'Ordre de trabajo';
                }

                if (mStrTextData != null) {
                    mStrTextData = Ax.db.call('textDataVar', mStrTextData, 'gman_ordetrah', mRow.docid, null);
                }

                let mStrSubject = `${mStrPedido}: ${mRow.docser} de ${mRow.empname}`;
                mStrcontent = `\n${mStrTextData}\n\n${mRow.empname}`;

                mDateGenerated = __local_sendmail(mRow.docid, mRow.terlang, 
                    mRow.tabname, mStrsqlcond, mRow.printobj, 
                    mRow.devmailcco, mRow.devmail, mRow,devmailcc,
                    null, mStrSubject, mStrcontent, null);


            } catch (error) {
                mStrnewErrmail = Ax.util.Error.getMessage(error);
            }
        }

        //IMPRESIÓN LPR
        if (mRow.devprint) {
            try {
                mDateGenerated = __local_sendlpr(mRow.seqno, mRow.docid, 
                    mRow.tabname, mStrsqlcond, mRow.printobj, 
                    mRow.user_created, mRow.devprint);

            } catch (error) {
                mStrnewErrprint = Ax.util.Error.getMessage(error);
            }
        }

        //actualizar gdoc_imprimir con errores y fecha de gen.
        Ax.db.update('gdoc_imprimir', 
            {
                'errfax': mStrnewErrfax,
                'errmail': mStrnewErrmail,
                'errprint': mStrnewErrprint,
                'date_generated': mDateGenerated
            }, 
            {
                'seqno': mRow.seqno
            }
        )
        //el fop.form ja el marca com a impres el document a gcompedh

    }

}