function mutOmnConfirmImport() {

    function __localSendErrmail(pStrMessage) {
        let mObjMail = Ax.db.call('mutSysMailSelect', 'mutOmnConfirmImport', 'general');

        let mMail = new Ax.mail.MailerMessage();
        mMail.from(mObjMail.mail_from);
        mMail.to(mObjMail.mail_to);
        mMail.cc(mObjMail.mail_cc);
        mMail.bcc(mObjMail.mail_bcc);
        mMail.subject('Interface Farmàcia OMNICELL-ERP Error Confirmacions');
        mMail.setHtml(pStrMessage);

        //Se hace el envío del email
        let mMailer = new Ax.mail.Mailer();
        mMailer.setSMTPServer("localhost", 25);
        mMailer.send(mMail);   
    }

    Ax.db.beginWork();

    let mStrPathName = '/erpsync/farmacia/omn/confirmacions/';
    let mStrPathBack = '/erpsync/farmacia/omn/confirmacions/bak/';

    let mFolder = new Ax.io.File(mStrPathName);


    let mObjMutOmnConfirm = {};
    mObjMutOmnConfirm.omn_numlin = 0;


    for (let mFile of mFolder.listFiles()) {

        if (!mFile.isFile() || mFile.getName().match(/omn_confirm*.*\.dat/) == null) {
            continue;
        }

        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_omn_confirm' />
                <where>
                    omn_filename = ?
                </where>
            </select>
        `, mFile.getName());

        if (mIntCount) {
            __localSendErrmail(`Fitxer [${mFile.getName()}] ja carregat.`);
            continue;
        }

        //Obtención del contenido en forma de String
        let mStrContent = mFile.readString();

        mObjMutOmnConfirm.omn_filename = mFile.getName();
        mObjMutOmnConfirm.omn_numlin = 0;

        for(let mStrLine of mStrContent) {
            mStrLine = mStrLine.replace("||", "|-|");

            let mArrLine = mStrLine.split('|');

            mObjMutOmnConfirm.omn_ordid = 0;
            mObjMutOmnConfirm.omn_numlin++;

            if (mArrLine.length != 9) {
                __localSendErrmail(`S'esperaven 9 camps a [${mFile.getName()} (${mObjMutOmnConfirm.omn_numlin})].`);

                continue;
            }

            mObjMutOmnConfirm.omn_tipdoc = mArrLine[0];
            mObjMutOmnConfirm.omn_docori = mArrLine[1];

            let mArrCcost = mArrLine[2].split('-');

            mObjMutOmnConfirm.omn_empcode = mArrCcost[0];
            mObjMutOmnConfirm.omn_delega  = mArrCcost[1];
            mObjMutOmnConfirm.omn_depart  = mArrCcost[2];

            mObjMutOmnConfirm.omn_codarmari = mArrLine[3];

            let mMonth = Number(mArrLine[4].slice(3, 5));
            let mDate  = Number(mArrLine[4].slice(0, 2));
            let mAny   = Number(mArrLine[4].slice(6, 10));

            mObjMutOmnConfirm.omn_fecha = new Ax.sql.Date(mAny, mMonth, mDate);

            mObjMutOmnConfirm.omn_clasif = mArrLine[5];
            mObjMutOmnConfirm.omn_codart = mArrLine[6];
            mObjMutOmnConfirm.omn_varlog = mArrLine[7];
            mObjMutOmnConfirm.omn_cancon = mArrLine[8];
            mObjMutOmnConfirm.user_created = Ax.db.getUser();
            mObjMutOmnConfirm.date_created = new Ax.sql.Date();

            let mIntOmnOrdid = Ax.db.insert('mut_omn_confirm', mObjMutOmnConfirm).getSerial();

            // Confirmem registres de l'entrada
            Ax.db.update('mut_omn_geanmovh_his',
                {
                    'date_confirmed': mObjMutOmnConfirm.date_created,
                    'omn_linconfirm': mIntOmnOrdid
                },
                {
                    'omn_docori': mObjMutOmnConfirm.omn_docori,
                    'omn_codart': mObjMutOmnConfirm.omn_codart
                }
            )

            // Confirmem registres de les sol.licitud FMED
            if (mObjMutOmnConfirm.omn_tipdoc == 'FMED') {
                Ax.db.execute(`
                    UPDATE mut_omn_gcomsolh_his
                    SET date_confirmed = ${mObjMutOmnConfirm.date_created},
                    omn_linconfirm = ${mIntOmnOrdid}
                    WHERE date_confirmed IS NULL
                    AND omn_codart = '${mObjMutOmnConfirm.omn_codart}'
                    AND omn_cabsol = (SELECT sl.cabid 
                                       FROM mut_omn_geanmovh_his h, geanmovl l, gcomsoll sl
                                      WHERE h.omn_docori = '${mObjMutOmnConfirm.omn_docori}' 
                                        AND h.omn_linean = l.linid 
                                        AND h.omn_codart = '${mObjMutOmnConfirm.omn_codart}' 
                                                AND h.omn_tipdoc = '${mObjMutOmnConfirm.omn_tipdoc}' 
                                        AND l.linori = sl.linid)
                `);

            }

            // Confirmem registres de les sol.licitud RETP 
            if (mObjMutOmnConfirm.omn_tipdoc == 'RETP') {
                Ax.db.execute(`
                    UPDATE mut_omn_gcomsolh_his
                    SET date_confirmed = ${mObjMutOmnConfirm.date_created},
                    omn_linconfirm = ${mIntOmnOrdid}
                    WHERE omn_tipdoc = '${mObjMutOmnConfirm.omn_tipdoc}'
                    AND date_confirmed IS NULL
                    AND omn_codart = '${mObjMutOmnConfirm.omn_codart}'
                    AND omn_linsol IN (SELECT gcomsoll.linid
                                   FROM gcomsoll,
                                        gcomsolh,
                                        gcompedh,
                                        gcompedl,
                                        gcommovl,
                                        gcommovh
                                  WHERE gcomsoll.cabid  = gcomsolh.cabid
                                    AND gcomsolh.tipdoc = omn_tipdoc
                                    AND gcomsolh.cabid  = omn_cabsol
                                    AND gcomsoll.codart = omn_codart
                                    AND gcompedh.docori = gcomsolh.docser
                                    AND gcompedh.tipdoc = omn_tipdoc
                                    AND gcompedl.cabid  = gcompedh.cabid
                                    AND gcompedl.codart = omn_codart
                                    AND gcompedl.linid  = gcommovl.linori
                                    AND gcommovl.cabid  = gcommovh.cabid
                                    AND gcommovh.docser = '${mObjMutOmnConfirm.omn_docori}')
                `);
            }

        }

        mFile.renameTo(mStrPathBack)
 
    }

    Ax.db.commitWork();

}