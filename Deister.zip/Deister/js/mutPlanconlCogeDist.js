function mutPlanconlCogeDist(pIntCabid, pIntImport) {
    //Sumatori total de l'import actual comptabilitzat.
    let mDecSumtot = Ax.db.executeGet(`
        <select>
            <columns>SUM(impact) sumtot</columns>
            <from table='mut_planconl_coge' />
            <where>
                cabid = ?
            </where>
        </select>
    `, pIntCabid);

    // No permetem distribuir si ja s'ha informat algun import.
    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='mut_planconl_coge' />
            <where>
                cabid  = ? AND
                imprea != 0
            </where>
        </select>
    `, pIntCabid);

    if (mIntCount) {
        throw new Ax.lang.Exception('Existeixen imports informats, no es pot distribuir.');
    }

    if (pIntImport == 0 || mDecSumtot == 0) {
        return;
    }

    //Iterem per les línies de la plantilla. 
    let mIntImpacu = 0;

    let mArrPlaconlCoge = Ax.db.executeQuery(`
        <select>
            <columns>linid, impact, imprea</columns>
            <from table='mut_planconl_coge' />
            <where>
                cabid = ?
            </where>
        </select>   
    `, pIntCabid).toJSONArray();

    for (let mRow of mArrPlaconlCoge) {
        //import real = import actual + % de l'import a distribuir.
        //% import a distribuir = import real / sumatori(import real).
        let mDecResult = pIntImport * (mRow.impact / mDecSumtot)
        let mDecImpinc = mDecResult.toFixed(2);

        mIntImpacu = mIntImpacu + mDecImpinc;
        mRow.imprea = mRow.impact + mDecImpinc;

        Ax.db.update('mut_planconl_coge', 
            {
                'imprea': mRow.imprea
            }, 
            {
                'cabid': pIntCabid,
                'linid': mRow.linid
            }
        )

        Ax.db.update('mut_planconl_coge', 
            {
                'impdif': mRow.impact - mRow.imprea
            }, 
            {
                'cabid': pIntCabid,
                'linid': mRow.linid
            }
        )
    }

    //Si hi ha algun desquadramanet d'1 centim, el sumem a la 1a línia amb major import. 
    let mDecImpdif = pIntImport - mIntImpacu;

    if (mDecImpdif != 0) {
        let mIntLinid = Ax.db.executeGet(`
            <select>
                <columns>MIN(cg1.linid) linid</columns>
                <from table='mut_planconl_coge' alias='cg1' />
                <where>
                    cg1.cabid  = ? AND
                    cg1.imprea = (SELECT MAX(cg2.imprea)
                                    FROM mut_planconl_coge cg2
                                WHERE cg1.cabid = cg2.cabid)
                </where>
            </select>    
        `, pIntCabid);

        Ax.db.execute(`
            UPDATE mut_planconl_coge
            SET imprea = imprea + ${mDecImpdif}
            WHERE cabid = ? 
              AND linid = ?       
        `, pIntCabid, mIntLinid)

    }

}