function biManProductExportPdi() {
    let mStrPathname = '/mnt/deister_dwh/ope/man/';
    let mDatToday = new Ax.sql.Date();
    let mDatTimesTamp = mDatToday.format('ddMMyy_HHmmss');

    let mStrFilecorw =`${mStrPathname}bi_man_prodcor_${mDatTimesTamp}.work`;
    let mStrFilecorf =`${mStrPathname}bi_man_prodcor_${mDatTimesTamp}.pdi`;
    let mStrFileprvw =`${mStrPathname}bi_man_prodprv_${mDatTimesTamp}.work`;
    let mStrFileprvf =`${mStrPathname}bi_man_prodprv_${mDatTimesTamp}.pdi`;
    let mStrFilenfcw =`${mStrPathname}bi_man_prodnfc_${mDatTimesTamp}.work`;
    let mStrFilenfcf =`${mStrPathname}bi_man_prodnfc_${mDatTimesTamp}.pdi`;
    let mStrFileopew =`${mStrPathname}bi_man_prodope_${mDatTimesTamp}.work`;
    let mStrFileopef =`${mStrPathname}bi_man_prodope_${mDatTimesTamp}.pdi`;

    //Carreguem l'associació grup de delegacions+delegació en una taula
    //temporal, eliminant possibles repeticions.
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_delgrp`);
    Ax.db.execute(`
        <select intotemp='@tmp_delgrp'>
            <columns>gdelgrph.codigo codgrp, gdelgrph.nomgrp, gdelgrpl.delgrp</columns>
            <from table='gdelgrph'>
                <join table='gdelgrpl'>
                    <on>gdelgrph.codigo = gdelgrpl.grpdel</on>
                </join>
            </from>
            <where>
                gdelgrpl.grpdel <matches>'G0*'</matches>
            </where>
            <order>1,2</order>
        </select>
    `);

    let mStrLstval = '';

    let mArrTmpDelgrp = Ax.db.executeQuery(`
        <select>
            <columns>codgrp, delgrp</columns>
            <from table='@tmp_delgrp' />
            <where>
                EXISTS (SELECT delgrp
                        FROM @tmp_delgrp
                        WHERE codgrp != codgrp
                        AND delgrp  = delgrp)
            </where>
            <order>2,1</order>
        </select>
    `);

    for (let mRow of mArrTmpDelgrp) {
        if (mRow.delgrp == mStrLstval) {
            Ax.db.delete('@tmp_delgrp', 
                {
                    'codgrp': mRow.codgrp,
                    'delgrp': mRow.delgrp
                }
            )
        }

        mStrLstval = mRow.delgrp;
    }

    //CORRECTIU: Generació.
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_prodcor`);
    Ax.db.execute(`
        <select intotemp='@tmp_prodcor'>
            <columns>
                gman_solitrah.docser,
                gman_solitrah.fecsol fecini,
                gman_solitrah.empcode codemp,
                <nvl>@tmp_delgrp.codgrp, '---'</nvl> codgrp,
                <nvl>@tmp_delgrp.nomgrp, '---'</nvl> nomgrp,
                gman_equinsta.insori,
                CASE WHEN gman_solitrah.estcab = 'C' THEN 'Completada'
                    WHEN gman_solitrah.estcab = 'P' THEN 'Processada'
                    WHEN gman_solitrah.estcab = 'V' THEN 'Validada'
                    ELSE '---'
                END estado,
                MAX(gcommovh.fecmov) fecfin,
                0 temres,
                '-----' clasif
            </columns>
            <from table='gman_solitrah'>
                <join type='left' table='@tmp_delgrp'>
                    <on>gman_solitrah.delega = @tmp_delgrp.delgrp</on>
                </join>
                <join table='gman_ordetrah'>
                    <on>gman_solitrah.docser = gman_ordetrah.docori</on>
                    <join table='gman_equinsta'>
                        <on>gman_ordetrah.codins = gman_equinsta.codins</on>
                    </join>
                    <join type='left' table='gcommovh'>
                        <on>gman_ordetrah.docser = gcommovh.docori</on>
                        <join table='gcommovd'>
                            <on>gcommovh.tipdoc = gcommovd.codigo</on>
                        </join>
                    </join>
                </join>
            </from>
            <where>
                YEAR(gman_solitrah.fecsol) &gt;= 2017 AND
                gman_ordetrah.tipdoc != 'RU' AND
                gman_ordetrah.estcab != 'B' AND
                gman_ordetrah.codope IS NOT NULL AND
                gcommovd.tabori = 'OT'
            </where>
            <group>1,2,3,4,5,6,7</group>
            <order>2,1</order>
        </select> 
    `);

    //CORRECTIU: Càlculs.
    //Estat anul·lat: Consta com a completada pero no disposa de cap albarà.
    Ax.db.execute(`
        UPDATE @tmp_prodcor
           SET estado = 'Anul·lada'
         WHERE fecini IS NOT NULL 
           AND fecfin IS NULL
    `);

    Ax.db.execute(`
        UPDATE @tmp_prodcor
           SET temres = fecfin-fecini
         WHERE fecini IS NOT NULL 
           AND fecfin IS NOT NULL
    `);

    //Estat diferit: finalitzada abans de data de sol·licitud. Com lis dieu? Igualo la diferencia de díes a 0.
    Ax.db.execute(`
        UPDATE @tmp_prodcor
           SET estado = 'Anticipada',
               temres = 0
         WHERE temres < 0
    `);

    Ax.db.execute(`
        UPDATE @tmp_prodcor
           SET clasif = CASE WHEN temres = 0 THEN '00'
                             WHEN temres BETWEEN  1 AND  2 THEN '01-02'
                             WHEN temres BETWEEN  3 AND  4 THEN '03-04'
                             WHEN temres BETWEEN  5 AND  9 THEN '05-09'
                             WHEN temres BETWEEN 10 AND 19 THEN '10-19'
                             WHEN temres BETWEEN 20 AND 39 THEN '20-39'
                             ELSE '40+'
                         END
         WHERE 1=1
    `);

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_prodcor_out`);
    Ax.db.execute(`
        <select intotemp='@tmp_prodcor_out'>
            <columns>
                docser,
                TO_CHAR(fecini, '%Y%m%d') fecini,
                codemp, codgrp, nomgrp, insori, estado,
                TO_CHAR(fecfin, '%Y%m%d') fecfin,
                temres, clasif
            </columns>
            <from table='@tmp_prodcor' />
        </select>
    `);

    //PREVENTIU: Generació. 
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_prodprv`);
    Ax.db.execute(`
        <select intotemp='@tmp_prodprv'>
            <columns>
                gman_ordetrah.docser,
                <nvl>DATE(gman_ordetrah.revini), DATE(gman_ordetrah.preini)</nvl> fecini,
                gman_ordetrah.empcode codemp,
                <nvl>@tmp_delgrp.codgrp, '---'</nvl> codgrp,
                <nvl>@tmp_delgrp.nomgrp, '---'</nvl> nomgrp,
                gman_equinsta.insori,
                CASE WHEN gman_ordetrah.estcab = 'C' THEN 'Completada'
                    WHEN gman_ordetrah.estcab = 'I' THEN 'Iniciada'
                    WHEN gman_ordetrah.estcab = 'V' THEN 'Validada'
                    ELSE '---'
                END estado,
                MAX(gcommovh.fecmov) fecfin,
                0 temres,
                '----------------' clasif
            </columns>
            <from table='gman_ordetrah'>
                <join type='left' table='@tmp_delgrp'>
                    <on>gman_ordetrah.delega = @tmp_delgrp.delgrp</on>
                </join>
                <join table='gman_equinsta'>
                    <on>gman_ordetrah.codins = gman_equinsta.codins</on>
                </join>
                <join type='left' table='gcommovh'>
                    <on>gman_ordetrah.docser = gcommovh.docori</on>
                    <join table='gcommovd'>
                        <on>gcommovh.tipdoc = gcommovd.codigo</on>
                    </join>
                </join>
            </from>
            <where>
                YEAR(gman_ordetrah.fecpre) &gt;= 2017 AND
                gman_ordetrah.tipdoc = 'OP'
            </where>
            <group>1,2,3,4,5,6,7</group>
            <order>2,1</order>
        </select>
    `)

    //PREVENTIU: Càlculs
    //Estat anul·lat: Consta com a completada pero no disposa de cap albarà.
    Ax.db.execute(`
        UPDATE @tmp_prodprv
          SET estado = 'Anul·lada'
        WHERE fecini IS NOT NULL 
          AND fecfin IS NULL
    `);

    Ax.db.execute(`
        UPDATE @tmp_prodprv
          SET temres = fecfin-fecini
        WHERE fecini IS NOT NULL 
          AND fecfin IS NOT NULL
    `);

    //Estat diferit: finalitzada abans de data de sol·licitud. Com lis dieu? Igualo la diferencia de díes a 0.
    Ax.db.execute(`
        UPDATE @tmp_prodprv
          SET estado = 'Anticipada',
              temres = 0
        WHERE temres < 0
    `);

    Ax.db.execute(`
        UPDATE @tmp_prodprv
            SET clasif =  CASE WHEN estado != 'A' AND temres &lt;  7 THEN 'Dins del previst'
            WHEN estado != 'A' AND temres &gt;= 7 THEN 'Fora del previst'
            ELSE 'No realitzat'
        END
        WHERE 1=1
    `);

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_prodprv_out`);
    Ax.db.execute(`
        <select intotemp='@tmp_prodprv_out'>
            <columns>
                docser,
                TO_CHAR(fecini, '%Y%m%d') fecini,
                codemp, codgrp, nomgrp, insori, estado,
                TO_CHAR(fecfin, '%Y%m%d') fecfin,
                temres, clasif
            </columns>
            <from table='@tmp_prodprv' />
        </select>  
    `)

    // OPERARIS: Generació.  
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_prodnfc`);
    Ax.db.execute(`
        <select intotemp='@tmp_prodnfc'>
            <columns>
                TO_CHAR(gman_parteser.fecini, '%Y%m%d') feccom,
                gman_parteser.codope,
                <nvl>cper_empleado.nomemp, '---'</nvl> nomope,
                REPLACE(REPLACE(gman_parteser.codser,'1',''),'2','') codser,
                gman_parteser.docser  doccom,
                gman_ordetrah.empcode codemp,
                gman_equinsta.insori,
                <nvl>@tmp_delgrp.codgrp, '---'</nvl> codgrp,
                <nvl>@tmp_delgrp.nomgrp, '---'</nvl> nomgrp,
                ROUND((mut_nfc_ordetrah.fin_datcon-mut_nfc_ordetrah.ini_datcon)::interval MINUTE(9) TO MINUTE::CHAR(10)::DECIMAL/60,2) temrea,
                ROUND((mut_nfc_ordetrah.fin_datdis-mut_nfc_ordetrah.ini_datdis)::interval MINUTE(9) TO MINUTE::CHAR(10)::DECIMAL/60,2) temjor
            </columns>
            <from table='gman_ordetrah'>
                <join type='left' table='cper_empleado'>
                    <on>gman_parteser.codope = cper_empleado.codigo</on>
                </join>
                <join table='gman_equinsta'>
                    <on>gman_ordetrah.codins = gman_equinsta.codins</on>
                </join>
                <join type='left' table='@tmp_delgrp'>
                    <on>gman_ordetrah.delega = @tmp_delgrp.delgrp</on>
                </join>
                <join table='mut_nfc_ordetrah'>
                    <on>gman_ordetrah.cabid = mut_nfc_ordetrah.cabid</on>
                    <join table='gman_parteser'>
                        <on>mut_nfc_ordetrah.doccom = gman_parteser.docser</on>
                    </join>
                </join>
            </from>
            <where>
                YEAR(mut_nfc_ordetrah.ini_datcon) &gt;= 2017 AND
                gman_ordetrah.tipdoc != 'OA' AND
                mut_nfc_ordetrah.ini_datcon IS NOT NULL AND
                mut_nfc_ordetrah.fin_datcon IS NOT NULL AND
                mut_nfc_ordetrah.ini_datdis IS NOT NULL AND
                mut_nfc_ordetrah.fin_datdis IS NOT NULL AND
                (mut_nfc_ordetrah.fin_datcon-mut_nfc_ordetrah.ini_datcon)::interval MINUTE(9) TO MINUTE::CHAR(10)::INTEGER &lt;= 1440 AND
                gman_parteser.tipdoc != 'MAT'
            </where>
            <order>1,2</order>
        </select> 
    `);

    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_prodope`);
    Ax.db.execute(`
        <select intotemp='@tmp_prodope'>
            <columns>
                codope, nomope, codser, insori, feccom, COUNT(*) numots, SUM(temrea) temrea, SUM(temjor) temjor
            </columns>
            <from table='@tmp_prodnfc' />
            <group>1,2,3,4,5</group>
            <order>1,5</order>
        </select>
    `)

    let mFilecorw = new Ax.io.File(mStrFilecorw);
    let mFileprvw = new Ax.io.File(mStrFileprvw);
    let mFilenfcw = new Ax.io.File(mStrFilenfcw);
    let mFileopew = new Ax.io.File(mStrFileopew);

    ///unload @tmp_prodcor_out
    let mRsTmpProdcorOut = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_prodcor_out'/>
        </select>
    `);

    let mStrContent = '';
    let mArrColumnsNames = mRsTmpProdcorOut.getColumnsNames();

    for ( let mRow of mRsTmpProdcorOut ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    let mBlob = new Ax.sql.Blob(`${mStrFilecorw}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    let mFile = new Ax.io.File(`${mStrFilecorw}`);
    mFile.write(mBlob);

    ///unload @tmp_prodprv_out
    let mRsTmpProdprvOut = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_prodprv_out'/>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsTmpProdprvOut.getColumnsNames();

    for ( let mRow of mRsTmpProdprvOut ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrFileprvw}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrFileprvw}`);
    mFile.write(mBlob);

    ///unload @tmp_prodnfc
    let mRsTmpProdnfc = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_prodnfc'/>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsTmpProdnfc.getColumnsNames();

    for ( let mRow of mRsTmpProdnfc ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrFilenfcw}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrFilenfcw}`);
    mFile.write(mBlob);

    ///unload @tmp_prodope
    let mRsTmpProdope = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_prodope'/>
        </select>
    `);

    mStrContent = '';
    mArrColumnsNames = mRsTmpProdope.getColumnsNames();

    for ( let mRow of mRsTmpProdope ) {

        for ( let mStrColumnName of mArrColumnsNames ) {

            mStrContent += `${mRow[mStrColumnName]}|`;

        }

        // Eliminamos el último caracter '|'
        mStrContent = mStrContent.slice(0, -1);

        mStrContent += '\n';

    }

    // Creamos el fichero blob
    mBlob = new Ax.sql.Blob(`${mStrFileopew}`);
    mBlob.setContent(mStrContent);

    // Guardamos el fichero en el directorio
    mFile = new Ax.io.File(`${mStrFileopew}`);
    mFile.write(mBlob);



    ///file.copy & file.delete => file.renameTo
    mFilecorw.renameTo(mStrFilecorf)
    mFileprvw.renameTo(mStrFileprvf)
    mFilenfcw.renameTo(mStrFilenfcf)
    mFileopew.renameTo(mStrFileopef)

}