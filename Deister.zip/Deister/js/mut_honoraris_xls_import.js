//PRJ #55797 Factures HHMM Honoraris
//PRJ #77008 HHMM ASG
function mut_honoraris_xls_import(pIntSeqno) {
    try {
        Ax.db.beginWork();
        //Volquem els últims valors a la taula d'històric.
        Ax.db.execute(`
            INSERT INTO mut_honoraris_xlsval_his 
            (seqno, hov_cellref, hov_value, user_created, date_created)
            SELECT seqno, hov_cellref, hov_value, user_created, date_created
            FROM mut_honoraris_xlsval
        `);

        Ax.db.execute(`
            DELETE FROM mut_honoraris_xlsval
            WHERE 1=1
        `);

        //Iniciem el procés
        let mObjHonorarisXls = Ax.db.executeQuery(`
            <select>
                <columns>
                    file_data, file_name, circuit, hoc_folder
                </columns>
                <from table='mut_honoraris_xls'>
                    <join table='mut_honoraris_config' alias='c'>
                        <on>circuit=c.hoc_circuit</on>
                    </join>
                </from>
                <where>
                    seqno = ?
                </where>
            </select>
        `, pIntSeqno).toOne();

        Ax.db.update('mut_honoraris_xls', 
            {
                'estat' : 1,
                'errmsg': 'Processant'
            }, 
            {
                'seqno': pIntSeqno
            }
        );

        let mStrFile = `${mObjHonorarisXls.hoc_folder}${mObjHonorarisXls.file_name}`;
        let mF = new Ax.io.File(mStrFile);
        mF.write(mObjHonorarisXls.file_data);

        Ax.db.call('mut_honoraris_xls_process', pIntSeqno);

        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*) count</columns>
                <from table='mut_honoraris_log' />
                <where>
                    seqno = ? AND hol_type = 'ERR'
                </where>
            </select>
        `, pIntSeqno);

        if (mIntCount > 0) {
            Ax.db.update('mut_honoraris_xls', 
                {
                    'estat': 5,
                    'errmsg': 'Error'
                }, 
                {
                    'seqno': pIntSeqno
                }
            )
        } else {
            Ax.db.update('mut_honoraris_xls', 
                {
                    'estat': 2,
                    'errmsg': 'Processat'
                }, 
                {
                    'seqno': pIntSeqno
                }
            )

            Ax.db.call('mut_honoraris_xls_gcomfac', pIntSeqno, mObjHonorarisXls.circuit);

        }

        mF.delete();

        Ax.db.commitWork();

    } catch (error) {
        Ax.db.rollbackWork();
        Ax.db.beginWork();

        Ax.db.update('mut_honoraris_xls', 
            {
                'estat': 5,
                'errmsg': 'Error'
            }, 
            {
                'seqno': pIntSeqno
            }
        )

        let mError = Ax.util.Error.getMessage(error);

        Ax.db.insert("mut_honoraris_log", 
            {
                "seqno": pIntSeqno,
                "hol_type": 'ERR',
                "hol_missatge": `Error no controlat: ${mError}`
            }
        );

        Ax.db.commitWork();
    }
}