function mut_gesmed_file_import(pSeqno){
    try {
        Ax.db.beginWork();

        let mObjGesmedFile = Ax.db.executeQuery(`
            <select>
                <columns>
                    file_data, file_name
                </columns>
                <from table='mut_gesmed_file' />
                <where>
                    seqno = ?
                </where>
            </select>      
        `,pSeqno).toOne();

        Ax.db.update('mut_gesmed_file',
            {
                'estat': 1
            },
            {
                'seqno': pSeqno
            }
        )

        let mFile = `/erpsync/tesis/gesmed/${mObjGesmedFile.file_name}`;

        let mF = new Ax.io.File(mFile);
        mF.write(mObjGesmedFile.file_data);

        Ax.db.call('mut_gesmed_manual', pSeqno);

        Ax.db.update('mut_gesmed_file',
            {
                'estat': 2
            },
            {
                'seqno': pSeqno,
                'estat': 1
            }
        )
        
        Ax.db.commitWork();

    } catch (error) {

        Ax.db.rollbackWork();
        Ax.db.beginWork();

        Ax.db.update('mut_gesmed_file',
            {
                'estat': 5
            },
            {
                'seqno': pSeqno
            }
        )

        Ax.db.commitWork();

        let mError = Ax.util.Error.getMessage(error);

        throw new Ax.lang.Exception(`No se ha procesado debido a [${mError}].`)
        
    }
}