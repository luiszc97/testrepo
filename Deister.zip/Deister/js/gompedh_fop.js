var mTmpGcompeh = Ax.db.getTempTableName('@tmpGcompedh');

Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGcompeh}`);

Ax.db.execute(`
    <select intotemp='@tmp_log_farprda'>
        <columns>
            1 ordre,
            gcompedl.cabid,
            gcompedl.linid,
            gartprov_print_refpro(:{tercer}, :{impref}, :{codalm}, gcompedl.codart, gcompedl.varlog, gcompedl.udmcom) codart, 
            
            CASE WHEN gdoctext.data IS NOT NULL OR gdoctext2.data IS NOT NULL 
                THEN ''
                ELSE gartprov_print_despro(:{tercer}, :{impref}, :{codalm}, gcompedl.codart, gcompedl.varlog, 
                                            gcompedl.udmcom, NVL(gcompedl.desvar, garticul.nomart))
            END nomart,
            gartprov_get_refpro(:{tercer}, :{codalm}, gcompedl.codart, gcompedl.varlog, gcompedl.udmcom) refpro,
            TRUNC(gcompedl.canped) canped,
            
            TRIM(gcompedl.udmcom) ||
            CASE WHEN gartvarl.unicon > 1 
                    THEN ' (' || <char>gartvarl.unicon</char> || ')'
                    ELSE <whitespace />
                END || 
                
            CASE WHEN gart_uniconv.reldes > 1  AND gart_uniconv.reldes IS NOT NULL
                    THEN ' (' || <char>gart_uniconv.reldes</char> || ')'
                    ELSE <whitespace />
                END udmcom,
            ROUND(gcompedl.precio * gcompedl.canpre / CASE WHEN gcompedl.canped = 0
                                                            THEN 1
                                                            ELSE gcompedl.canped
                                                        END , 2) precio,
            gcompedl.impnet,
            TRUNC(garticul_get_tax_porcen('gcompedh',gcompedl.cabid, gcompedl.linid, :{tipdoc}, NULL, NULL,
                                            :{fecha}, :{fecha}, :{empcode}, :{delega}, gcompedh.depart, 
                                            :{tercer},NULL, NULL, :{tipdir}, NULL, gcompedl.codart)) || '%' tax_code,
            pro_gcomsolh.docori, pro_gcomsolh.numlot
        </columns>
        <from table='gcompedh'>
            <join table='gcompedl'>
                <on>gcompedh.cabid=gcompedl.cabid</on>
                <join table='garticul'>
                    <join type='left' table='gdoctext' alias='gdoctext2'>
                        <on>garticul.desamp = gdoctext2.txtid</on>
                    </join>
                    <on>gcompedl.codart = garticul.codigo</on>
                </join>
                <join type='left' table='gdoctext'>
                    <on>gcompedl.desamp = gdoctext.txtid</on>
                </join>
                <join type="left" table="gartvarl">
                    <on>gcompedl.codart = gartvarl.codart</on>
                    <on>gcompedl.varlog = gartvarl.varlog</on>
                </join>                        
                <join type='left' table='gart_unidefs'>
                    <on>gcompedl.codart = gart_unidefs.codart</on>
                    <on>gcompedl.udmcom = gart_unidefs.coduni</on>
                    <join type='left' table='gart_uniconv'>
                        <on>gart_unidefs.codart = gart_uniconv.codart</on>
                        <on>gart_unidefs.coduni = gart_uniconv.udmori</on>
                        <on>garticul.udmbas = gart_uniconv.udmdes</on>
                    </join>
                </join>
                <join type='left' table='pro_gcomsolh'>
                    <on>gcompedl.linid = pro_gcomsolh.linped</on>
                </join>
            </join>
        </from>
        <where>
            gcompedl.cabid = :{cabid}
        </where>
    </select>
`);