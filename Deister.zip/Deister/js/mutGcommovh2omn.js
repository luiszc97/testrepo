/*
// Enviar els gcommovh amb codalm = '14FAR' i bloquejats 25095 a Omnicell    
//                                                                           
// Cridat des de ...                                                         
*/
function mutGcommovh2omn(pStrSqlcond) {
    // Inicializar el log.
    Ax.db.beginWork();

    let mClogprohLogId = Ax.db.call('clogproh_ini', 'mutGcommovh2omn', null,0);

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    let mStrTipdoc = 'RETP';
    let mStrAuxchr1 = 'MTFARMA01';

    // ========================================================================
    // ========================================================================

    let mArrGcommovh = Ax.db.executeQuery(`
        <select>
            <columns>gcommovh.cabid, gcommovh.fecmov, gcommovh.docser, 
                        gcommovl.linid, gcommovl.codart, gcommovl.varlog, gcommovl.canmov canpro, gcommovl.udmcom, garticul.udmbas
            </columns>
            <from table='gcommovh'>
                <join table='gcommovl'>
                    <on>gcommovh.cabid = gcommovl.cabid</on>
                    <join table='garticul' type='left'>
                        <on>garticul.codigo = gcommovl.codart</on>
                    </join>
                </join>
                <join table='gartprov' type='left'>
                    <on>gcommovh.tercer = gartprov.codpro</on>
                    <on>gcommovl.codart = gartprov.codart</on>
                    <on>gcommovl.varlog = gartprov.varlog</on>
                    <on>gcommovl.udmcom = gartprov.udmcom</on>
                </join>
                <join table='gcompedh'>
                    <on>gcommovh.docori = gcompedh.docser</on>
                </join>
            </from>
            <where>
                gcommovh.tipdoc IN ('ENTC') AND
                gcommovh.almori = '14FAR'   AND
                gcompedh.tipdoc IN ('RETP','METP') AND
                NOT EXISTS (SELECT * FROM mut_omn_geanmovh_his WHERE gcommovh.docser=omn_docori) AND
                NOT EXISTS (SELECT * FROM mut_omn_geanmovh WHERE gcommovh.docser=omn_docori AND gcommovl.linid=omn_linean) AND
                ${pStrSqlcond}
            </where>
        </select>    
    `).toJSONArray();

    for (let mRow of mArrGcommovh) {
        try {
            //Obtenim unitats
            let mObjGartUnidefsGetqtys = Ax.db.call('gart_unidefs_getqtys', 
                0,              // Forzar doble unidad            
                0,              // Se informó la unidad de precio
                mRow.codart,    // Artículo                      
                mRow.varlog,    // V. Logística                  
                mRow.udmcom,    // Unidad origen                 
                mRow.udmbas,    // Unidad destino                
                mRow.udmcom,    // Unidad precio                 
                mRow.canpro,    // Cantidad según unidad origen  
                null,           // Cantidad según unidad destino 
                mRow.canpro     // Cantidad según unidad precio  
            )

            let mIntCansol = mObjGartUnidefsGetqtys.cansol; 
            let mIntUdmdes = mObjGartUnidefsGetqtys.udmdes;
            let mIntCanmov = mObjGartUnidefsGetqtys.canmov; 
            let mIntCanpre = mObjGartUnidefsGetqtys.canpre;

            //Insertar la capçalera
            Ax.db.execute(`
                INSERT INTO mut_omn_geanmovh 
                (omn_tipdoc, omn_fecha, omn_docori, omn_codarmari, omn_codart, omn_canmov, omn_cabean, omn_linean)
                VALUES (?,?,?,?,?,?,?,?)
            `, mStrTipdoc, mRow.fecmov, mRow.docser, mStrAuxchr1, mRow.codart, mIntCanmov, mRow.cabid, mRow.linid);

            Ax.db.call('clogprol_set', mClogprohLogId, null, null, null, null, null, null, mRow.cabid, null);
            
        } catch (error) {
            Ax.db.rollbackWork();

            Ax.db.call('clogprol_set', mClogprohLogId, Ax.util.Error.getMessage(error), Ax.util.Error.getErrorCode(error), null, null, null, null, mRow.cabid, null)
        }
    }

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    //Cerrar el log de proceso.
    Ax.db.call('clogproh_fin', mClogprohLogId);

    return mClogprohLogId;

}
