function mut_nfc_marcopeh(pStrEvent, pIntRowid){
    if (pStrEvent == 'D') {
        return;
    }

    let mObjMarcopeh = Ax.db.executeQuery(`
        <select>
            <columns>
                fecmar, tercer, estado
            </columns>
            <from table='mut_nfc_marcopeh' />
            <where>
                rowid = ?
            </where>
        </select>
    `, pIntRowid).toOne();

    if (mObjMarcopeh.estado == 'P') {
        return;
    }

    let mObjtMarcopel = Ax.db.executeQuery(`
    <select>
        <columns>
            rowid
        </columns>
        <from table='mut_nfc_marcopel' />
        <where>
            fecmar = ? AND
            tercer = ?
        </where>
    </select>
    `, mObjMarcopeh.fecmar, mObjMarcopeh.tercer).toJSONArray();

    for(let element of mObjtMarcopel){
        Ax.db.call('mut_nfc_marcopel', 'V', element.rowid)
    }

    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='mut_nfc_marcopel' />
            <where>
                fecmar = ? AND
                tercer = ? AND
                estado = 'E'
            </where>
        </select>
    `, mObjMarcopeh.fecmar, mObjMarcopeh.tercer);

    if (mIntCount) {
        Ax.db.update('mut_nfc_marcopeh', 
            {
                'estado': 'E'
            },
            {
                'fecmar': mObjMarcopeh.fecmar,
                'tercer': mObjMarcopeh.tercer
            }
        )

        return;
    }

    Ax.db.update('mut_nfc_marcopeh', 
        {
            'estado': 'V'
        },
        {
            'fecmar': mObjMarcopeh.fecmar,
            'tercer': mObjMarcopeh.tercer
        }
    )

}