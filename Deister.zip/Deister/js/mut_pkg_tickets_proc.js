function mut_pkg_tickets_proc(pIntNumany, pIntNummes) {
    Ax.db.beginWork();

    //Estructura de sortida del procés.
    let mRsFactures = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['cabid','docser','tipdoc','empcode','delega','depart','fecha','tercer']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.VARCHAR,Ax.sql.Types.VARCHAR,Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, Ax.sql.Types.DATE, Ax.sql.Types.VARCHAR]);
	});

    //Càlcul de dates d'inici i fi (que serà data de factura).
    let mStrFecini = new Ax.sql.Date(pIntNumany,pIntNummes,1);
    mStrFecini = mStrFecini.format('yyyyMMdd');

    let mDateFecha;

    if (pIntNummes != 12) {
        mDateFecha = Ax.db.executeGet(`
            <select>
                <columns>
                    MDY(${pIntNummes}+1,1,${pIntNumany}) - 1 units day
                </columns>
                <from table='wic_dual'/>
            </select>
        `);
        mDateFecha = new Ax.sql.Date(mDateFecha);

    } else {
        mDateFecha = Ax.db.executeGet(`
            <select>
                <columns>
                    MDY(1,1,${pIntNumany}+1) - 1 units day
                </columns>
                <from table='wic_dual'/>
            </select>
        `);

        mDateFecha = new Ax.sql.Date(mDateFecha);

    }

    let mStrFecfin = mDateFecha.format('yyyyMMdd');

    //Recorrem per ordre les línies del fitxer.
    let mArrTickets = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='mut_pkg_tickets' />
            <where>
                tabdes = 'gvenfach' AND
                cabdes IS NULL AND
                datexp BETWEEN ? AND ?
            </where>
            <order>datexp, numseq DESC</order>
        </select>        
    `, mStrFecini, mStrFecfin).toJSONArray();

    for (let mRow of mArrTickets) {
        //Parametrització del document a generar.
        let mObjConfdoc = Ax.db.executePreparedQuery(`
            <union type='all'>
                <select>
                    <columns>
                        h.tipfac, h.tipdoc,
                        h.empcode,h.delega, h.depart,
                        h.tercer, h.tipdir,
                        h.tipefe, h.frmefe frmpag, 
                        h.tiptar, h.frmtar, 
                        h.artefe codart, h.varefe varlog, 
                        h.arttar, h.vartar
                    </columns>
                    <from table='mut_pkg_confdoc' alias='h' />
                    <where>
                        :{modpag} = 'CO'     AND
                        h.nifexp = :{nifexp} AND
                        h.codtpv = :{codtpv} AND
                        h.modpag = :{modpag}
                    </where>
                </select>
                <select>
                    <columns>
                        h.tipfac, h.tipdoc,
                        h.empcode,h.delega, h.depart,
                        v.tercer, v.tipdir, 
                        v.tipefe, v.frmpag, 
                        <null type='char' /> tiptar, <null type='char' /> frmtar, 
                        v.codart, v.varlog, 
                        <null type='char' /> arttar, <null type='char' /> vartar
                    </columns>
                    <from table='mut_pkg_confdoc' alias='h'>
                        <join table='mut_pkg_confvia' alias='v'>
                            <on>h.nifexp = v.nifexp</on>
                            <on>h.codtpv = v.codtpv</on>
                            <on>h.modpag = v.modpag</on>
                        </join>
                    </from>
                    <where>
                        :{modpag} != 'CO'    AND
                        h.nifexp = :{nifexp} AND
                        h.codtpv = :{codtpv} AND
                        h.modpag = :{modpag} AND
                        v.comerc = :{comerc}
                    </where>
                </select> 
            </union> 
        `, 
            {
                'modpag': mRow.modpag,
                'nifexp': mRow.nifexp,
                'codtpv': mRow.codtpv,
                'comerc': mRow.comerc
            }
        ).toOne();

        //Assegurem que ha trobat la paramétrica.
        if (mObjConfdoc.tipdoc == null) {
            throw new Ax.lang.Exception(`Configuració de document inexistent per [${mRow.nifexp}/${mRow.codtpv}/${mRow.modpag}].`);
        }

        if (mRow.modpag != 'CO' && mObjConfdoc.tercer == null) {
            throw new Ax.lang.Exception(`Configuració de comercialitzadora inexistent per [${mRow.nifexp}/${mRow.codtpv}/${mRow.modpag}/${mRow.comerc}].`);
        }

        mRow.tabdes = null;
        mRow.cabdes = null;
        mRow.lindes = null;
        mRow.linaux = null;

        //Només es crea factura si el tipus de facturació és "Diaria". En
        //cas contrari els tickets es guarden en la taula definitiva de
        //tiquets amb els camps tabdes, cabdes, lindes, linaux a nul.
        if (mObjConfdoc.tipfac == 'M') {
            //Convertim el camp Data d'Expedició d'Integer a Date.
            let mIntCabid = null;
            
            mIntCabid = Ax.db.executeGet(`
                <select>
                    <columns>cabid</columns>
                    <from table='gvenfach' />
                    <where>
                        tipdoc  = ? AND
                        empcode = ? AND
                        delega  = ? AND
                        depart  = ? AND
                        fecha   = ? AND
                        tercer  = ? AND
                        tipdir  = ? AND
                        docser MATCHES '${mRow.codtpv}${mRow.modpag}*'
                    </where>
                </select>
            `, mObjConfdoc.tipdoc, mObjConfdoc.empcode,
               mObjConfdoc.delega, mObjConfdoc.depart,
               mDateFecha,         mObjConfdoc.tercer,
               mObjConfdoc.tipdir
            )

            //Creació de la capçalera si no existeix.
            if (mIntCabid == null) {
                let mRsGvenfach = Ax.db.call('gvenfach_init');

                mRsGvenfach.rows().add([ mObjConfdoc.tipdoc, mObjConfdoc.empcode, mObjConfdoc.delega, 
                mObjConfdoc.depart, mDateFecha, mObjConfdoc.tercer,
                mObjConfdoc.tipdir, 
                `${mRow.codtpv}${mRow.modpag}${mRow.numtiq}`,
                mObjConfdoc.tipefe, mObjConfdoc.frmpag
                ]);

                mIntCabid = Ax.db.call('gvenfach_insert', 'I', mRsGvenfach);
            }

            mRow.cabdes = mIntCabid;

            //Ens guardem l'id de capçalera per tal de validar-la a 
            //posteriori
            for (let item of mRsFactures) {
                if (item.cabid != mIntCabid) {
                    mRsFactures.rows().add([ mIntCabid, `${mRow.codtpv}${mRow.modpag}${mRow.numtiq}`,
                    mObjConfdoc.tipdoc, mObjConfdoc.empcode,
                    mObjConfdoc.delega, mObjConfdoc.depart,
                    mDateFecha, mObjConfdoc.tercer
                    ]);
                }
            }

            //Comprovem existencia de la línia de factura.
            let mIntLinid = null;

            mIntLinid = Ax.db.executeGet(`
                <select>
                    <columns>gvenfacl.linid</columns>
                    <from table='gvenfach'>
                        <join table='gvenfacl'>
                            <on>gvenfach.cabid = gvenfacl.cabid</on>
                        </join>
                    </from>
                    <where>
                        gvenfach.cabid = ? AND
                        gvenfacl.codart  = ?
                    </where>
                </select>            
            `, mIntCabid, mObjConfdoc.codart);

            //Si existeix, sumem preu. 
            if (mIntLinid != null) {
                Ax.db.execute(`
                    UPDATE gvenfacl
                    SET canfac = 1, 
                        udmven = 'UNI',
                        precio = precio + ${mRow.basimp},
                        estlin = 'E',
                        errlin = 0
                    WHERE
                        linid  = ${mIntLinid} 
                `)

                mRow.lindes = mIntLinid;

            } else {
                //Creació de línia de document, si no existeix.
                let mIntOrden = null;
                
                mIntOrden = Ax.db.executeGet(`
                    <select>
                        <columns>MAX(orden)+1 orden</columns>
                        <from table='gvenfacl' />
                        <where>
                            cabid = ?
                        </where>
                    </select>            
                `, mIntCabid);

                if (mIntOrden == null) {
                    mIntOrden = 1;
                }

                let mIntSerial = Ax.db.insert('gvenfacl',
                    {
                        'linid': 0,
                        'cabid':  mIntCabid,
                        'orden':  mIntOrden,
                        'codart': mObjConfdoc.codart,
                        'varlog': mObjConfdoc.varlog,
                        'numlot': '0',
                        'canfac': 1,
                        'udmven': 'UNI',
                        'precio': mRow.basimp,
                        'dtolin': 0,
                        'impnet': 0,
                        'estlin': 'E',
                        'errlin': 0,
                        'indmod': 'N'
                    }
                ).getSerial();

                mRow.lindes = mIntSerial;

            }

        }

        //Actualitzar enllaços al registre de la taula de tiquets.
        Ax.db.update('mut_pkg_tickets', 
            {
                'cabdes': mRow.cabdes,
                'lindes': mRow.lindes,
                'user_updated': Ax.db.getUser(),
                'date_updated': new Ax.sql.Date()
            }, 
            {
                'numseq': mRow.numseq
            }
        )

    }

    //Validació de les factures generades/utilitzades, segons hem anat
    //guardant a l'vtable v_factures.
    for (let mRow of mRsFactures) {
        //Validació del document.
        //Atenció: Al final de la validació es fan 2 modificacions
        //especials per les factures de Parking.
        //1) Per evitar desquadraments entre el que calcula l'ERP i el que
        //s'informa en els rebuts als clientd, es modifica la quota
        //impositiva [cuoimp1] calculada automàticament per la suma de
        //quotes informades en els tickets generats per l'interface.
        //2) En les factures "Al comptat", a diferència del que fa
        //l'estandar, s'han de generar 2 venciments pel mateix día, 1
        //per Efectiu i 1 altre per Targeta.
        let mIntRowid = Ax.db.executeGet(`
            <select>
                <columns>rowid</columns>
                <from table='gvenfach' />
                <where>
                    cabid = ?
                </where>
            </select>        
        `, mRow.cabid);

        Ax.db.call('gvenfach','V', mIntRowid)

    }

    Ax.db.commitWork();

    return mRsFactures;
}