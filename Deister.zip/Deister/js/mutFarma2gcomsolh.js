function mutFarma2gcomsolh(pStrSqlcond) {
    //FUNCTION __local_gcomsolh_insert
    function __local_gcomsolh_insert(pObjGcomsolh) {
        let mIntCabsol = null;
        let mIntRowsol = null;
        let mIntCabean = null;
        let mIntRowean = null;

        // Marca la capçalera i les línies en procés. 
        let mTabfarh = pObjGcomsolh.tabfarh;
        let mTabfarl = pObjGcomsolh.tabfarl;

        let dbName = Ax.db.of('lt_farma_mps');
        dbName.update(`${mTabfarh}`, 
            {
                'estado': 'P'
            }, 
            {
                'docser': pObjGcomsolh.cabid
            }
        )

        dbName.update(`${mTabfarl}`, 
            {
                'estado': 'P'
            }, 
            {
                'cabid': pObjGcomsolh.cabid
            }
        )

        // Excepció: sollicitud traspassada. 
        if (pObjGcomsolh.cabid_des != null) {
            throw new Ax.lang.Exception('Sol.licitud ja traspassada')
        }

        //Inicialització de valors.   
        ///Map
        let mmMapDelega = Ax.util.Map.of('A', '01',
                                         'B', '02',
                                         'C', '03',
                                         'D', '04',
                                         'E', '05',
                                         'F', '06',
                                         'G', '07',
                                         'H', '08',
                                         'I', '09',
                                         'J', '10',
                                         'K', '11',
                                         'L', '12',
                                         'M', '13',
                                         'N', '14',
                                         'O', '15',
                                         'P', '16',
                                         'Q', '17',
                                         'R', '18',
                                         'S', '19',
                                         'T', '20',
                                         'U', '21',
                                         'V', '22',
                                         'W', '23',
                                         'X', '24',
                                         'Y', '25',
                                         'Z', '26'
        );

        let mStrEmpcode, mStrDelega;

        if (pObjGcomsolh.delega.length == 5) {
            mStrEmpcode = mmMapDelega.get(pObjGcomsolh.delega.slice(0, 1));
            if (mStrEmpcode == null) {
                throw new Ax.lang.Exception(`Delegació: [${pObjGcomsolh.delega}] no contemplada`)
            }
            mStrDelega = `${mStrEmpcode}${pObjGcomsolh.delega.slice(1)}`;
        } else {
            mStrEmpcode = '14';
            mStrDelega  = pObjGcomsolh.delega;
        }

        let mStrCodalm = `${mStrEmpcode}FAR`;

        // Insert de gcomsolh. 
        let mRsGcomsolh = Ax.db.call('gcomsolh_init');

        mRsGcomsolh.rows().add([pObjGcomsolh.tipdoc, mStrEmpcode, 
        mStrDelega, pObjGcomsolh.depart, pObjGcomsolh.fecsol, 
        pObjGcomsolh.docser, pObjGcomsolh.clasif, pObjGcomsolh.estcab,
        pObjGcomsolh.errcab, pObjGcomsolh.imptot, pObjGcomsolh.fecini,
        pObjGcomsolh.fecfin, mStrCodalm, 'N', pObjGcomsolh.username,
        pObjGcomsolh.username]);

        mIntCabsol = Ax.db.call('gcomsolh_insert', 'MUT_FARMA', mRsGcomsolh);

        mIntRowsol = Ax.db.executeGet(`
            <select>
                <columns>
                    <rowid table='gcomsolh' /> rowsol
                </columns>
                <from table='gcomsolh' />
                <where>
                    cabid = ?
                </where>
            </select>
        `, mIntCabsol);

        // Insert de geanmovh. 
        if (pObjGcomsolh.tipdoc == 'DEVF') {
            mIntCabean = Ax.db.executeFunction('geanmovh_inserta', 
                mStrDelega,             //delega
                pObjGcomsolh.depart,    //depart
                mStrCodalm,             //almori
                null,                   //almdes
                'DESC',                 //tipdoc
                new Ax.sql.Date(),      //fecmov
                null,                   //docser
                null,                   //refter
                pObjGcomsolh.docser,    //docori
                null,                   //oriaux
                null,                   //terexp
                null,                   //direxp
                null,                   //coment
                0,                      //genrf
                'N'                     //indmod
            )

            mIntRowean = Ax.db.executeGet(`
                <select>
                    <columns>
                        <rowid table='geanmovh' /> rowean
                    </columns>
                    <from table='geanmovh' />
                    <where>
                        cabid = ?
                    </where>
                </select>    
            `, mIntCabean);

        }

        let mObjReturn = {};
        mObjReturn.cabsol = mIntCabsol;
        mObjReturn.rowsol = mIntRowsol;
        mObjReturn.cabean = mIntCabean;
        mObjReturn.rowean = mIntRowean;

        return mObjReturn;  
    }

    let mdbname = Ax.db.getCode();

    //Inicializar el log.   
    Ax.db.beginWork();

    let mIntClogprohLogId = Ax.db.call('clogproh_ini', 'mutFarma2gcomsolh', null, 0);

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    // Struct per el call a la funció local.
    let mObjGcomsolh = {
        tabfarh:   null, 
        tabfarl:   null,
        cabid  :   null,  
        cabid_des: null,
        tipdoc  :  null, 
        delega  :  null,  
        depart  :  null, 
        fecsol  :  null, 
        docser  :  null, 
        clasif  :  null, 
        estcab  :  null, 
        errcab  :  null, 
        imptot  :  null, 
        fecini  :  null, 
        fecfin  :  null, 
        username:  null
    }

    let mBoolErrorhead;
    let mBoolErrorline;
    let mObjLocal = {};

    let dbName = Ax.db.of('lt_farma_mps');
    let mRsFarsol = dbName.executeQuery(`
        <select>
            <columns>
                gcomsolh.cabid,  gcomsolh.tipdoc, gcomsolh.delega, gcomsolh.depart,
                gcomsolh.fecsol, gcomsolh.docser, gcomsolh.clasif, gcomsolh.estcab,
                gcomsolh.errcab, gcomsolh.imptot, gcomsolh.fecini, gcomsolh.fecfin,
                gcomsolh.username,  l.linid,  l.codart, l.varlog, l.desvar, l.cansol,
                l.precio, l.canped, l.canser, l.estlin, l.errlin, l.desamp, l.estado
            </columns>
            <from table='mps_gcomsolh' alias='gcomsolh'>
                <join table='mps_gcomsoll' alias='l'>
                    <on>l.cabid = gcomsolh.cabid</on>
                </join>
            </from>
            <where>
                gcomsolh.fecsol &gt;= <eval-date d='-45'><today /></eval-date> AND
                gcomsolh.estado IN ('N','E') AND
                NOT EXISTS(SELECT *
                            FROM mps_gcomsoll ll
                            WHERE ll.cabid = l.cabid
                            AND ll.estado = 'Z') AND
                ${pStrSqlcond}
            </where>
            <order>docser, tipdoc</order>
        </select>
    `);


    mRsFarsol.cursor()
    .group("docser, tipdoc")
        .before(mRow => {

            try {
                mBoolErrorhead = false;
                mBoolErrorline = false;
    
                let mIntCabdes = Ax.db.executeQuery(`
                    <select>
                        <columns>cabid cabid_des</columns>
                        <from table='gcomsolh' />
                        <where>
                            docser = <cast type='char' size='20'>${mRow.cabid}</cast>
                        </where>
                    </select>    
                `);
    
                mObjGcomsolh.tabfarh   =  'mps_gcomsolh'; 
                mObjGcomsolh.tabfarl   =  'mps_gcomsoll';
                mObjGcomsolh.cabid     =  mRow.cabid,  
                mObjGcomsolh.cabid_des =  mIntCabdes,
                mObjGcomsolh.tipdoc    =  mRow.tipdoc; 
                mObjGcomsolh.delega    =  mRow.delega;  
                mObjGcomsolh.depart    =  mRow.depart; 
                mObjGcomsolh.fecsol    =  mRow.fecsol; 
                mObjGcomsolh.docser    =  mRow.docser; 
                mObjGcomsolh.clasif    =  mRow.clasif; 
                mObjGcomsolh.estcab    =  mRow.estcab; 
                mObjGcomsolh.errcab    =  mRow.errcab; 
                mObjGcomsolh.imptot    =  mRow.imptot; 
                mObjGcomsolh.fecini    =  mRow.fecini; 
                mObjGcomsolh.fecfin    =  mRow.fecfin; 
                mObjGcomsolh.username  =  mRow.username;
               
                // Insert de gcomsolh.
                mObjLocal = __local_gcomsolh_insert(mObjGcomsolh);
    
                Ax.db.call('clogprol_set', 
                    mIntClogprohLogId,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    mObjReturn.cabsol,
                    mObjReturn.cabean
                ) 

            } catch (error) {
                let mStrErrmsg = Ax.util.Error.getMessage(error);
                let mIntErrno  = Ax.util.Error.getErrorCode(error);

                let dbName = Ax.db.of('lt_farma_mps');
                dbName.update('mps_gcomsolh', 
                    {
                        'estado': 'E',
                        'errno': mIntErrno,
                        'errmsg': mStrErrmsg,
                        'date_updated': new Ax.sql.Date()
                    }, 
                    {
                        'cabid': mRow.cabid
                    }
                )

                Ax.db.call('clogprol_set',
                    mIntClogprohLogId,
                    mStrErrmsg,
                    mIntErrno,
                    null,
                    null,
                    null,
                    null,
                    mRow.cabid,
                    null
                )

                mBoolErrorhead = true;

            }
            
        })
        .after(mRow => {
            try {
                //Hi hagut error en les línies. Esborra els possibles
                //gcomsolh i geanmovh.
                if (mBoolErrorline) {
                    if (mObjLocal.cabean != null) {
                        Ax.db.delete('geanmovl', 
                            {
                                'cabid': mObjLocal.cabean
                            }
                        );

                        Ax.db.delete('geanmovh', 
                            {
                                'cabid': mObjLocal.cabean
                            }
                        ); 
                    }

                    Ax.db.delete('gcomsolh', 
                        {
                            'cabid': mObjLocal.cabsol
                        }
                    ); 

                    let dbName = Ax.db.of('lt_farma_mps');
                    dbName.update('mps_gcomsolh', 
                        {
                            'estado': 'E',
                            'errno': -746,
                            'errmsg': 'Error en línies',
                            'date_updated': new Ax.sql.Date()
                        }, 
                        {
                            'cabid': mRow.cabid
                        }
                    )

                } else {
                    if (!mBoolErrorhead) {
                        // Línies processades.
                        let dbName = Ax.db.of('lt_farma_mps');
                        dbName.update('mps_gcomsoll', 
                            {
                                'estado': 'S',
                                'errno' : null,
                                'isamno': null,
                                'errmsg': null,
                                'date_updated': new Ax.sql.Date()
                            }, 
                            {
                                'cabid': mRow.cabid
                            }
                        )

                        // Validar els documents generats.    
                        Ax.db.call('gcomsolh', 'I', mObjLocal.rowsol);

                        let mIntmCabid = null;

                        mIntmCabid = Ax.db.executeGet(`
                            <select>
                                <columns>UNIQUE h.cabid</columns>
                                <from table='gcomsolh' alias='h'>
                                    <join table='gcomsoll' alias='l'>
                                        <on>l.cabid = h.cabid</on>
                                    </join>
                                </from>
                                <where>
                                    h.rowid = ? AND
                                    l.estlin = 'E' AND
                                    l.errlin = 2
                                </where>
                            </select>
                        `, mObjLocal.rowsol)

                        if (mIntmCabid != null) {
                            Ax.db.update('gcomsolh',
                                {
                                    'indmod': 'S'
                                },
                                {
                                    'cabid': mIntmCabid
                                }
                            )

                            Ax.db.update('gcomsoll',
                                {
                                    'indmod': 'S'
                                },
                                {
                                    'cabid': mIntmCabid,
                                    'estlin': 'E',
                                    'errlin': 2
                                }
                            )
                        }

                        if (mObjLocal.rowean != null) {
                            Ax.db.call('geanmovh', 'I', mObjLocal.rowean)
                        }

                        // Capçalera processada.  
                        dbName = Ax.db.of('lt_farma_mps');
                        dbName.update('mps_gcomsolh',
                            {
                                'estado': 'S',
                                'errno': null,
                                'errmsg': null,
                                'date_updated': new Ax.sql.Date()
                            },
                            {
                                'cabid': mRow.cabid
                            }
                        )
                    }
                }

                if (Ax.db.isOnTransaction()) {
                    Ax.db.commitWork();
                }

            } catch (error) {
                if (Ax.db.isOnTransaction()) {
                    Ax.db.rollbackWork();
                }

                let dbName = Ax.db.of('lt_farma_mps');
                dbName.update('mps_gcomsolh',
                    {
                        'estado': 'E',
                        'errno': Ax.util.Error.getErrorCode(error),
                        'errmsg': Ax.util.Error.getMessage(error),
                        'date_updated': new Ax.sql.Date()
                    },
                    {
                        'cabid': mRow.cabid
                    }
                )
            }


    })
    .forEach(mRow => {
        try {
            let mStrCodigoOut = Ax.db.executeGet(`
                <select>
                    <columns>codigo codigo_out</columns>
                    <from table='garticul' />
                    <where>
                        auxchr2 = ? AND
                        estado  = "A"
                    </where>
                </select>
            `, mRow.codart);

            let mStrAuxchr2 = mRow.codart;

            let mStrCodigoIn = Ax.db.executeGet(`
                <select>
                    <columns>codigo codigo_in</columns>
                    <from table='garticul' />
                    <where>
                        codigo = <m_codart /> AND
                        estado = "A"
                    </where>
                </select>
            `, mRow.codart);

            if (mStrCodigoOut != null) {
                mRow.codart = mStrCodigoOut;
            }

            let mObjGartvarl = Ax.db.executeQuery(`
                <select>
                    <columns>gartvarl.udmcom udmsol, gartvarl.udmpre</columns>
                    <from table='gartvarl' />
                    <where>
                        codart = ? AND
                        varlog = ?
                    </where>
                </select>    
            `, mRow.codart, mRow.varlog).toOne();

            //Error en el mateix head. 
            if (mBoolErrorhead) {
                return;
            }

            //Insert de gcomsoll.
            let mObjGcomsoll = {};
            mObjGcomsoll.linid  = 0;
            mObjGcomsoll.cabid  = mObjLocal.cabsol;
            mObjGcomsoll.orden  = 0;
            mObjGcomsoll.codart = mRow.codart;
            mObjGcomsoll.varlog = mRow.varlog;
            mObjGcomsoll.cansol = mRow.cansol;
            mObjGcomsoll.udmsol = mObjGartvarl.udmsol;
            mObjGcomsoll.canpre = mRow.cansol;
            mObjGcomsoll.udmpre = mObjGartvarl.udmpre;
            mObjGcomsoll.precio = mRow.precio;
            mObjGcomsoll.canped = mRow.canped;
            mObjGcomsoll.canser = mRow.canser;
            mObjGcomsoll.estlin = mRow.estlin;
            mObjGcomsoll.errlin = mRow.errlin;
            mObjGcomsoll.indmod = 'N';
            mObjGcomsoll.auxchr2 = mStrAuxchr2;

            mObjGcomsoll.linid = Ax.db.insert('gcomsoll', mObjGcomsoll).getSerial();

            let dbName = Ax.db.of('lt_farma_mps');
            dbName.update('mps_gcomsoll', 
                {
                    'desvar': mStrCodigoOut
                },
                {
                    'cabid': mRow.cabid,
                    'linid': mRow.linid
                }
            );

        } catch (error) {
            mBoolErrorLine = true;
            let mStrErrmsg = Ax.util.Error.getMessage(error);
            let mIntErrno  = Ax.util.Error.getErrorCode(error);

            let dbName = Ax.db.of('lt_farma_mps');
            dbName.update('mps_gcomsoll', 
                {
                    'desvar': mStrCodigoOut
                },
                {
                    'cabid': mRow.cabid,
                    'linid': mRow.linid
                }
            );

            Ax.db.call('clogprol_set', 
                mIntClogprohLogId,
                mStrErrmsg,
                mIntErrno,
                null, 
                null, 
                null, 
                null, 
                mRow.cabid,
                mRow.linid
            )

        }

    });

    // Cerrar el log de proceso.
    Ax.db.call('clogproh_fin', mIntClogprohLogId);

    return mIntClogprohLogId;   

}