function mut_sys_mail_select(pProces, pCode){

    let mObjMutSysMailconf = Ax.db.executeQuery(`
        <select>
            <columns>
                mai_from, mai_to, mai_cc, mai_bcc
            </columns>
            <from table='mut_sys_mailconf' />
            <where>
                mai_proces = ? AND
                mai_code = ?
            </where>
        </select>
    `, pProces, pCode).toOne();

    if (mObjMutSysMailconf.mai_to == '@variable_script') {
        mObjMutSysMailconf.mai_to = null;
    }

    return mObjMutSysMailconf;
}