function mut_nfc_ordetrah_time_agr(pIntSeqno) {
    //Nº de segons total de la tasca agrupadora.
    let mObjOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                docser, ini_datcon, fin_datcon
            </columns>
            <from table='mut_nfc_ordetrah' />
            <where>
                seqno = ?
            </where>
        </select>
    `, pIntSeqno).toOne();

    if (mObjOrdetrah.fin_datcon) {
        throw new Ax.ext.Exception(`OT [${mObjOrdetrah.docser}] no finalitzada.`);
    }

    let mDateFinpar = mObjOrdetrah.fin_datcon;
    let mIntSegtot  = new Ax.util.Date(mObjOrdetrah.fin_datcon) - new Ax.util.Date(mObjOrdetrah.ini_datcon);

    //Nº de fills.
    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>
                COUNT(*) numreg
            </columns>
            <from table='mut_nfc_ordetrah' />
            <where>
                seqori = ?
            </where>
        </select>
    `, pIntSeqno);

    if (!mIntCount) {
        return;
    }

    //Mitja de segons per cada fill.
    let mDobSegavg = mIntSegtot/mIntCount;

    //Assignació de la data d'inici i final per cadascun dels fills.
    let mDateFecFin = mObjOrdetrah.ini_datcon;

    let mArrOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                ini_datcon, fin_datcon, seqno
            </columns>
            <from table='mut_nfc_ordetrah' />
            <where>
                seqori = ?
            </where>
            <order>seqno</order>
        </select>
    `, pIntSeqno).toJSONArray();

    let mDateFecIni;

    for (let mRow of mArrOrdetrah) {
        mDateFecIni = mDateFecFin;

        let mDateSegundos = new Ax.util.Date(mDateFecIni);

        mDateFecFin = mDateSegundos.addSecond(mDobSegavg);

        Ax.db.update('mut_nfc_ordetrah',
            {
                'ini_datcon': mDateFecIni,
                'fin_datcon': mDateFecFin
            },
            {
                'seqno': mRow.seqno
            }
        );
    }

    //Correcció de la data de fi de l'últim fill.
    if (mDateFecFin != mObjOrdetrah.fin_datcon) {
        mDateFecFin = mDateFinpar;

        Ax.db.update('mut_nfc_ordetrah',
            {
                'ini_datcon': mDateFecIni,
                'fin_datcon': mDateFinpar
            },
            {
                'seqno': pIntSeqno
            }
        )
    }

}