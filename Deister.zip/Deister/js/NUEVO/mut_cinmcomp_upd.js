
var pStrSistem  = Ax.context.variable.SISTEM;
var pStrCtaexp  = Ax.context.variable.CTAEXP;
var pStrCcoste  = Ax.context.variable.CCOSTE;
var pDatFecini  = Ax.context.variable.FECINI;
var pDatFecfin  = Ax.context.variable.FECFIN;
var pStrSeccio  = Ax.context.variable.SECCIO;
var pStrNulos   = Ax.context.variable.NULOS;
var pStrSqlcond = Ax.context.property.COND;

pDatFecini = new Ax.sql.Date(pDatFecini);
pDatFecfin = new Ax.sql.Date(pDatFecfin);

var mTmpCimpcomp = Ax.db.getTempTableName('tmp_cimpcomp');
Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpCimpcomp}`);

Ax.db.execute(`
    <select intotemp='${mTmpCimpcomp}'>
        <columns>
            cinmcomp.rowid cinid,
			cinmelem.empcode,
            cinmelem.ctaexp, cinmelem.seccio, cinmelem.centro[1,3] seccio1,
            cinmelem.centro, cinmcomp.codinm, cinmcomp.codele,
            cinmcomp.codcom, cinmcomp.nomcom, cinmcomp.numhis,
            cinmelem.codcta,
            cinmcomp.fecha,  cinmcomp.fecini, cinmcval.estado,
            cinmcval.porcen, cinmcval.inicom valhoy,
            cinmcval.invcom  valinv, cinmcval.rescom valres,
            cinmcval.acucom  valacu, cinmcval.netcom valnet,
            ROUND(0,3) acuprv, ROUND(0,3) netprv,
            cinmcomp.tercer, cinmcomp.notas,
            ROUND(0,3) dotamoc, ROUND(0,3) dotamon
        </columns>
        <from table='cinmcomp'>
            <join table='cinmcval'>
                <on>cinmcomp.empcode = cinmcval.empcode</on>
                <on>cinmcomp.codinm  = cinmcval.codinm</on>
                <on>cinmcomp.codele  = cinmcval.codele</on>
                <on>cinmcomp.codcom  = cinmcval.codcom</on>
                <on>cinmcomp.numhis  = cinmcval.numhis</on>
            </join>
            <join table='cinmelem'>
                <on>cinmcomp.empcode = cinmelem.empcode</on>
                <on>cinmcomp.codinm  = cinmelem.codinm</on>
                <on>cinmcomp.codele  = cinmelem.codele</on>
            </join>
        </from>
        <where>
           (cinmelem.ctaexp <matches>'${pStrCtaexp}'</matches> OR ('${pStrNulos}' = 'S' AND cinmelem.ctaexp      IS NULL)) AND
           (cinmelem.centro <matches>'${pStrCcoste}'</matches> OR ('${pStrNulos}' = 'S' AND cinmelem.centro      IS NULL)) AND
           (cinmelem.seccio           ${pStrSeccio}            OR ('${pStrNulos}' = 'S' AND cinmelem.seccio      IS NULL)) AND
           (cinmelem.centro[1,3]      ${pStrSeccio}            OR ('${pStrNulos}' = 'S' AND cinmelem.centro[1,3] IS NULL)) AND
            cinmcval.sistem = '${pStrSistem}' AND
            ${pStrSqlcond}
        </where>
        <order>1,2,3,4,5,6,7,8</order>
    </select>  
`);

var mArrTmpCimp = Ax.db.executeQuery(`
    <select>
        <columns>empcode, codinm, codele, codcom, numhis</columns>
        <from table='${mTmpCimpcomp}' />
    </select> 
`).toMemory();

var mArrCinmamor;
var mNumDiesam;
var mNumDiespr;
var mNumRes;
var mDatfin;
var mDatini;

for (var mRow of mArrTmpCimp) {
    var mNumDotamoc = 0;
    var mNumDotamon = 0;

    /**
     *  [X][     ][ ]    
     */
    mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>estado, fecini, fecfin, import</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
               (${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
            NOT(${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                sistem  = '${pStrSistem}'
            </where>
            <order>1</order>
        </select>        
    `, mRow.empcode, mRow.codinm, mRow.codele, mRow.codcom, mRow.numhis).toMemory();

    

    for (var mObjCinmamor of mArrCinmamor) {
        if (mObjCinmamor.fecini != null) {
            mDatfin = new Ax.sql.Date(mObjCinmamor.fecfin);
            mDatini = new Ax.sql.Date(mObjCinmamor.fecini);

            mNumDiesam = mDatfin.days(mDatini) + 1;
            mNumDiespr = mDatfin.days(pDatFecini) + 1;

            if (mObjCinmamor.estado == 'C') {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);

                mNumDotamoc = mNumDotamoc + mNumRes;
            } else {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);
                mNumDotamon = mNumDotamon + mNumRes;
            }
        }
    }

    /**
     *  [ ][XXXXX][ ]  
     */
    mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>estado, MIN(fecini) fecini, MAX(fecfin) fecfin, SUM(import) import</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
            NOT(${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
            NOT(${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                cinmamor.fecini &gt;= ${pDatFecini} AND
                cinmamor.fecfin &lt;= ${pDatFecfin} AND
                sistem  = '${pStrSistem}'
            </where>
            <group>1</group>
            <order>1</order>
        </select>      
    `, mRow.empcode, mRow.codinm, mRow.codele, mRow.codcom, mRow.numhis).toMemory();

    for (var mObjCinmamor of mArrCinmamor) {
        if (mObjCinmamor.fecini != null) {
            mDatfin = new Ax.sql.Date(mObjCinmamor.fecfin);
            mDatini = new Ax.sql.Date(mObjCinmamor.fecini);

            mNumDiesam = mDatfin.days(mDatini) + 1;
            mNumDiespr = mNumDiesam;

            if (mObjCinmamor.estado == 'C') {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);

                mNumDotamoc = mNumDotamoc + mNumRes;
            } else {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);
                mNumDotamon = mNumDotamon + mNumRes;
            }
        }
    }

    /**
     *  [ ][     ][X] 
     */
    mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>estado, fecini, fecfin, import</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
            NOT(${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
               (${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                sistem  = '${pStrSistem}'
            </where>
            <order>1</order>
        </select>        
    `, mRow.empcode, mRow.codinm, mRow.codele, mRow.codcom, mRow.numhis).toMemory();

    for (var mObjCinmamor of mArrCinmamor) {
        if (mObjCinmamor.fecini != null) {
            mDatfin = new Ax.sql.Date(mObjCinmamor.fecfin);
            mDatini = new Ax.sql.Date(mObjCinmamor.fecini);

            mNumDiesam = mDatfin.days(mDatini) + 1;
            mNumDiespr = pDatFecfin.days(mDatini) + 1;

            if (mObjCinmamor.estado == 'C') {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);

                mNumDotamoc = mNumDotamoc + mNumRes;
            } else {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);
                mNumDotamon = mNumDotamon + mNumRes;
            }
        }
    }

    /**
     *  [XXXXXXXXXXX]   
     */
    mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>estado, MIN(fecini) fecini, MAX(fecfin) fecfin, SUM(import) import</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
               (${pDatFecini} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
               (${pDatFecfin} BETWEEN cinmamor.fecini AND cinmamor.fecfin) AND
                sistem  = '${pStrSistem}'
            </where>
            <group>1</group>
            <order>1</order>
        </select>   
    `, mRow.empcode, mRow.codinm, mRow.codele, mRow.codcom, mRow.numhis).toMemory();

    for (var mObjCinmamor of mArrCinmamor) {
        if (mObjCinmamor.fecini != null) {
            mDatfin = new Ax.sql.Date(mObjCinmamor.fecfin);
            mDatini = new Ax.sql.Date(mObjCinmamor.fecini);

            mNumDiesam = mDatfin.days(mDatini) + 1; 
            mNumDiespr = pDatFecfin.days(pDatFecini) + 1;

            if (mObjCinmamor.estado == 'C') {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);

                mNumDotamoc = mNumDotamoc + mNumRes;
            } else {
                mNumRes = (mObjCinmamor.import * mNumDiespr) / mNumDiesam
                mNumRes = mNumRes.toFixed(2);
                mNumDotamon = mNumDotamon + mNumRes;
            }
        }
    }

    Ax.db.execute(`
        UPDATE ${mTmpCimpcomp}
        SET acuprv = valacu + ${mNumDotamon.toFixed(3)},
            netprv = valnet - ${mNumDotamon.toFixed(3)},
            dotamoc = ${mNumDotamoc.toFixed(3)},
            dotamon = ${mNumDotamon.toFixed(3)}
         WHERE 
            empcode = '${mRow.empcode}' AND
            codinm  = '${mRow.codinm}' AND
            codele  = '${mRow.codele}' AND
            codcom  = '${mRow.codcom}' AND
            numhis  = '${mRow.numhis}'
    `);

    return Ax.db.executeQuery(`
        <select>
            <columns>cinmcomp.rowid, ${mTmpCimpcomp}.*</columns>
            <from table='cinmcomp'>
                <join table='${mTmpCimpcomp}'>
                    <on>cinmcomp.rowid = ${mTmpCimpcomp}.cinid</on>
                </join>
            </from>
        </select>       
    `)

}