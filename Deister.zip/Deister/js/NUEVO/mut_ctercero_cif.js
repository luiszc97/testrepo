var mStrSqlCond = '1=1';
	
var mRsData = Ax.db.executeQuery(`
    SELECT
            DISTINCT cif cifgrp
      FROM  ctercero
     WHERE      
                estado = 'A' 
            AND cif != '0'
            AND ${mStrSqlCond}
    `);

var mStrLength;
var mArrCtercer = [];
var mArrayCif    = [];
var mArrayPreCif = [];
var mArraySufCif = [];

for (var mRowData of mRsData) {
    //<set name='m_length'><string.length><m_cifgrp /></string.length></set>
    mStrLength = mRowData.cifgrp.length;
    var mStrPreCif = mRowData.cifgrp.trim().substring(1, mStrLength);
    var mStrSufCif = mRowData.cifgrp.trim().substring(0, mStrLength-1);
    /** 
     *  mArrayCif.push(`'${mRowData.cifgrp}'`);
     *  mArrayPreCif.push(`'?${mStrPreCif}'`);
     *  mArraySufCif.push(`'${mStrSufCif}?'`);
     */

    var mTmpSimcif = Ax.db.getTempTableName('tmp_simcif');
    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpSimcif}`);

    Ax.db.execute(`
        <select intotemp='${mTmpSimcif}'>
            <columns>cif cifter, codigo, nombre, estado, codare</columns>
            <from table='ctercero' />
            <where>
                1=0
            </where>
        </select>    
    `)

    mArrCtercer = Ax.db.executeQuery(`
        <select>
            <columns>cif cifter, codigo, nombre, estado, codare</columns>
            <from table='ctercero' />
            <where>
                estado = 'A' AND
                cif = ?
            </where>
            <order>1</order>
        </select>        
    `, mRowData.cifgrp);

    for (var mRow of mArrCtercer) {
        Ax.db.insert(mTmpSimcif, mRow);
    }
   
    mArrCtercer = Ax.db.executeQuery(`
        <select>
            <columns>cif cifter, codigo, nombre, estado, codare</columns>
            <from table='ctercero' />
            <where>
                estado = 'A' AND
                cif = ?
            </where>
            <order>1</order>
        </select>        
    `, mRowData.cifgrp);
    
}

return Ax.db.executeQuery(sqlQuery);