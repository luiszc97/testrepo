function pro_gcomsolh_mod(
    pIntProid,
    pStrHisold,
    pStrLotold,
    pStrEstold,
    pStrHisnew,
    pStrLotnew,
    pStrEstnew
) {
    /**
     *  Sortida si no hi cap canvi. 
     */
    if (pStrHisold == pStrHisnew && pStrLotold == pStrLotnew && pStrEstold == pStrEstnew) {
        return;
    }

    /**
     *  Només es permet passar d'estat 1 a 9, de 2 a 9, i de 9 a 1. 
     */
    if (pStrEstold == pStrEstnew && ((pStrEstold == '1' && pStrEstnew == '9') || 
                                     (pStrEstold == '2' && pStrEstnew == '9') || 
                                     (pStrEstold == '9' && pStrEstnew == '1'))) {

        throw new Ax.lang.Exception(`Canvi d'estat [${pStrEstold} a ${pStrEstnew}] no permès.`);
    }

    /**
     *  Dades addicionals de pro_gcomsolh.                                                              
     */
    var mObjProGcomsolh = Ax.db.executeQuery(`
        <select>
            <columns>linsol, linped</columns>
            <from table='pro_gcomsolh' />
            <where>
                proid = ?
            </where>
        </select>        
    `, pIntProid).toOne();

    /**
     *  Només es permet passar d'estat 2 a 9 si no hi ha línia de sol·licitud 
     *  informada.                                                            
     */
    if (pStrEstold == 2 && pStrEstnew == 9 && mObjProGcomsolh.linsol == null) {
        throw new Ax.lang.Exception(`Registre en estat 2 sense línies de sol·licitud informada. No es pot anul·lar.`);
    }

    /**
     *  Només es permet passar d'estat 2 a 9 si no està enllaçada a cap línia de 
     *  comanda.                                                                 
     */
    var mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='gcompedl_orig' />
            <where>
                tabori = 'gcomsolh' AND
                linori = ?
            </where>
        </select>       
    `, mObjProGcomsolh.linsol);
    

    if (pStrEstold == '2' && pStrEstnew == '9' && mIntCount) {
        var mStrDocser = Ax.db.executeGet(`
            <select>
                <columns>gcompedh.docser</columns>
                <from table='gcompedh'>
                    <join table='gcompedl'>
                        <on>gcompedh.cabid = gcompedl.cabid</on>
                        <join table='gcompedl_lnk'>
                            <on>gcompedl.linid = gcompedl_lnk.linid</on>
                        </join>
                    </join>
                </from>
                <where>
                    gcompedl_lnk.lnk_tabori = 'gcomsolh' AND
                    gcompedl_lnk.lnk_linori = ?
                </where>
            </select>           
        `, mObjProGcomsolh.linsol);

        throw new Ax.lang.Exception(`Línia de comanda [${mStrDocser}] generada, no es pot anul·lar.`);
    }

    /**
     *  Només es permet passar d'estat 9 a 1 si no hi han documents vinculats. 
     */
    if ((pStrEstold == '9' && pStrEstnew == '1') && (mObjGcompedh.linsol != null || mObjGcompedh.linped != null)) {
        throw new Ax.lang.Exception(`Canvi d'estat [${pStrEstold} a ${pStrEstnew}] no permès. Existeixen documents vinculats.`);
    }

    /**
     *  Esborrar línia de sol·licitud al passar d'estat 2 a 9. 
     */
    if (pStrEstold == '2' && pStrEstnew == '9') {
        var mIntCabsol = Ax.db.executeGet(`
            <select>
                <columns>cabid cabsol</columns>
                <from table='gcomsoll' />
                <where>
                    linid = ?
                </where>
            </select>
        `, mObjProGcomsolh.linsol);

        Ax.db.delete('gcomsoll', {linid: mObjProGcomsolh.linsol});

        /**
         *  Si encara queden línies a la sol·licitud, revalidem, si no 
         *  l'esborrem.                                                
         */
        var mIntContador = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gcomsoll' />
                <where>
                    cabid = ?
                </where>
            </select>
        `, mIntCabsol);

        if (mIntContador) {
           Ax.db.call('gcomsolh_Valida', mIntCabsol);          
        } else {
            Ax.db.delete('gcomsolh', {cabid: mIntCabsol});
        }

        mObjProGcomsolh.linsol = null;
    }

    /**
     *  Enregistrar modificació a pro_gcomsolh.  
     */
    Ax.db.update('pro_gcomsolh', 
        {
            numhis: pStrHisnew,
            numlot: pStrLotnew,
            estado: pStrEstnew,
            linsol: mObjProGcomsolh.linsol,
            user_updated: Ax.db.getUser(),
            date_updated: new Ax.util.Date()
        },
        {
            proid: pIntProid
        }
    )

    /**
     *  Insertar en la taula de log.   
     */
    Ax.db.insert('pro_gcomsolh_mod', 
        {
            seqno: 0,
            proid: pIntProid,
            estold: pStrEstold,
            lotold: pStrLotold,
            hisold: pStrHisold,
            estnew: pStrEstnew,
            lotnew: pStrLotnew,
            hisnew: pStrHisnew,
            user_updated: Ax.db.getUser(),
            date_updated: new Ax.util.Date()
        }
    )
}