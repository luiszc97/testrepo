function mut_nfc_ordetrah_proc_fin() {
    //Actualitzar data de sincronització.
    let mArrOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                n.seqno, a.date_of_sync, a.task_code
            </columns>
            <from table='mut_nfc_ordetrah' alias='n'>
                <join table='apps_sfa_task_assign' alias='a'>
                    <on>n.assign_user = a.assign_user</on>
                    <on>n.assign_type = a.assign_type</on>
                    <on>n.fin_number  = a.assign_number</on>
                </join>
            </from>
            <where>
                n.estado IN (1,2,11,12) AND
                n.fin_datsyn IS NULL AND
                a.task_code IN ('COF','COFD','PRF','PRFD','PAF','TRF','TRFD','SU') AND
                a.assign_state &gt;= 1
            </where>
            <order>n.seqno</order>
        </select>
    `).toMemory();

    for (let mRow of mArrOrdetrah) {
        Ax.db.beginWork();

        Ax.db.update('mut_nfc_ordetrah', 
            {
                'fin_datsyn': mRow.date_of_sync
            }, 
            {
                'seqno': mRow.seqno
            }
        )
        
        Ax.db.commitWork();
    }

    //Mapa d'estats.
    let mMapEstats = Ax.util.Map.of(
        null, null, 
        1, 'Finalitzada', 
        2, 'Pendent', 
        3, 'Irrecuperable', 
        4, 'Pendent material', 
        5, 'Coordinació', 
        6, 'Servei extern'
    );

    //Cursor principal per tasques de Finalització.
    let mArrNfcOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                CASE WHEN a.task_code = 'SU'  THEN 1
                    ELSE 2
                END orden, n.seqno, n.cabid, n.docser,
                a.assign_user, a.assign_type, a.assign_number,
                a.task_code
            </columns>
            <from table='mut_nfc_ordetrah' alias='n'>
                <join table='apps_sfa_task_assign' alias='a'>
                    <on>n.assign_user = a.assign_user</on>
                    <on>n.assign_type = a.assign_type</on>
                    <on>n.fin_number  = a.assign_number</on>
                </join>
            </from>
            <where>
                n.estado IN (2,12) AND
                a.task_code IN ('SU','COF','COFD','PRF','PRFD','PAF','TRF','TRFD') AND
                a.assign_state = 2 AND
                EXISTS (SELECT r.assign_number
                        FROM apps_sfa_task_resh r, apps_sfa_task_resl l
                        WHERE a.assign_user   = r.assign_user
                        AND a.assign_type   = r.assign_type
                        AND a.assign_number = r.assign_number
                        AND r.assign_user   = l.assign_user
                        AND r.assign_type   = l.assign_type
                        AND r.assign_number = l.assign_number)
            </where>
            <order>1,2</order>
        </select>
    `).toMemory();

    for (let mRow of mArrNfcOrdetrah) {
        let mObjTaskResh = Ax.db.executeQuery(`
            <select>
                <columns>
                    h.response_date_end fin_datcon,
                    l.response_text fin_tagnfc
                </columns>
                <from table='apps_sfa_task_resh' alias='h'>
                    <join type='left' table='apps_sfa_task_resl' alias='l'>
                        <on>h.assign_user   = l.assign_user</on>
                        <on>h.assign_type   = l.assign_type</on>
                        <on>h.assign_number = l.assign_number</on>
                    </join>
                </from>
                <where>
                    h.assign_user    = ? AND
                    h.assign_type    = ? AND
                    h.assign_number  = ? AND
                    h.response_state = 1     AND
                    l.ask_code       = 'TAG' AND
                    l.response_state = 1
                </where>
            </select>        
        `, mRow.assign_user, mRow.assign_type, mRow.assign_number).toOne();

        if (mObjTaskResh.fin_datcon == null) {
            continue;
        }

        Ax.db.update('mut_nfc_ordetrah', 
            {
                'fin_datcon': mObjTaskResh.fin_datcon,
                'fin_tagnfc': mObjTaskResh.fin_tagnfc
            }, 
            {
                'seqno': mRow.seqno
            }
        )

        if (mObjTaskResh.fin_tagnfc != null) {
            let mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='gman_equidefs' />
                    <where>
                        codmaq  = ? AND
                        auxnum1 = 1
                    </where>
                </select>
            `, mObjTaskResh.fin_tagnfc);

            if (mIntCount) {
                Ax.db.execute(`
                    update gman_equidefs 
                    set auxnum2 = auxnum2 + 1 
                    where codmaq = ?
                `, mObjTaskResh.fin_tagnfc)
            }            

        }

        //Ajustar data prevista d'inici, si està avançada al dia actual.
        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gman_ordetrah' />
                <where>
                    cabid = ? AND
                    fecpre &gt; TODAY
                </where>
            </select>
        `, mRow.cabid);

        if (mIntCount) {
            Ax.db.update('gman_ordetrah', 
                {
                    'fecpre': new Ax.sql.Date()
                }, 
                {
                    'cabid': mRow.cabid
                }
            )
        }

        //Determinar tipus de comunicat.
        let mStrTercer = Ax.db.executeGet(`
            <select>
                <columns>tercer</columns>
                <from table='cper_empleado' />
                <where>
                    codigo = ?
                </where>
            </select>
        `, mRow.assign_user);

        let mStrTipdoc;

        switch (mStrTercer) {
            case 'A58477712':
                let mYear = new Ax.sql.Date();
                if (mYear.getFullYear() >= 2021) {
                    mStrTipdoc = 'EXI';
                } else {
                    mStrTipdoc = 'EXT';
                }
                break;
            
            case 'A28061737':
                mStrTipdoc = 'EXE';
                break;
            
            case 'V65928277':
                mStrTipdoc = 'MODE';
                break;

            case 'PLS':
                mStrTipdoc = 'MODB';

                let mIntContador = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gman_ordetrah' />
                        <where>
                            docser = ? AND
                            empcode = '07' AND
                            tercer IN ('A08642142', 'PLS')
                        </where>
                    </select>
                `, mRow.docser);

                if (mIntContador) {
                    mStrTipdoc = 'MOBP';
                }
                break;

            case 'A08642142':
            case 'G59747535':
                mStrTipdoc = 'MODI';

                let mIntCant = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gman_ordetrah' />
                        <where>
                            docser  = ? AND
                            empcode = '10' AND
                            tercer  ='G59747535'
                        </where>
                    </select>
                `, mRow.docser);

                if (mIntCant) {
                    mStrTipdoc = 'MODP';
                }
                break;
        
            default:
                mStrTipdoc = 'MODI';
                break;
        }

        let mIntGmanParteserRowid = Ax.db.call('gman_ordetrah_gman_parteser', mRow.cabid, mStrTipdoc);

        Ax.db.update('gman_parteser', 
            {
                'fecini': mObjTaskResh.fin_datcon
            }, 
            {
                'rowid': mIntGmanParteserRowid
            }
        )

        /*Construcció del camp de comentari del comunicat de servei:
        S'indica estat, nota, avís (s'envia per correu a central) i 
        l'equip informat per l'operari, que s'actualitza a la OT.*/
        let mObjAppsSfaTaskResl = Ax.db.executeQuery(`
            <select>
                <columns>response_text state</columns>
                <from table='apps_sfa_task_resl' />
                <where>
                    assign_user    = ? AND
                    assign_type    = ? AND
                    assign_number  = ? AND
                    ask_code       = 'STATE' AND
                    response_state = 1
                </where>
            </select>
        `, mRow.assign_user, mRow.assign_type, mRow.assign_number).toOne()
            .setRequired(`[${mRow.assign_user},${mRow.assign_type},${mRow.assign_number}] Resposta STATE no disponible.`);

        let mStrComent = Ax.db.executeGet(`
            <select>
                <columns>response_text coment</columns>
                <from table='apps_sfa_task_resl' />
                <where>
                    assign_user    = ? AND
                    assign_type    = ? AND
                    assign_number  = ? AND
                    ask_code       = 'NOTES'
                </where>
            </select>
        `,  mRow.assign_user, mRow.assign_type, mRow.assign_number);

        let mStrWarning = Ax.db.executeGet(`
            <select>
                <columns>response_text warning</columns>
                <from table='apps_sfa_task_resl' />
                <where>
                    assign_user    = ? AND
                    assign_type    = ? AND
                    assign_number  = ? AND
                    ask_code       = 'WARNING'
                </where>
            </select>
        `, mRow.assign_user, mRow.assign_type, mRow.assign_number);

        let mStrCodmaq = Ax.db.executeGet(`
            <select>
                <columns>response_text codmaq</columns>
                <from table='apps_sfa_task_resl' />
                <where>
                    assign_user    = ? AND
                    assign_type    = ? AND
                    assign_number  = ? AND
                    ask_code       = 'EQUIPMENT'
                </where>
            </select>           
        `, mRow.assign_user, mRow.assign_type, mRow.assign_number);

        let mStrPhoto = Ax.db.executeGet(`
            <select>
                <columns>response_text photo</columns>
                <from table='apps_sfa_task_resl' />
                <where>
                    assign_user    = ? AND
                    assign_type    = ? AND
                    assign_number  = ? AND
                    ask_code       = 'PHOTO'
                </where>
            </select>
        `, mRow.assign_user, mRow.assign_type, mRow.assign_number);

        let mStrGmanParteserComent = `Estat: ${mMapEstats.get(parseInt(mObjAppsSfaTaskResl.state))}`;

        let mIntFinIndcom = 0;
        let mIntFinIndwar = 0;
        let mIntFinIndpho = 0;
        let mIntFinIndequ = 0;

        if (mStrComent != null) {
            mIntFinIndcom = 1;
            mStrGmanParteserComent = `${mStrGmanParteserComent} 
            Nota: ${mStrComent}`;
        }

        if (mStrWarning != null) {
            mIntFinIndwar = 1;
            mStrGmanParteserComent = `${mStrGmanParteserComent} 
            Avís: ${mStrWarning}`;
        }

        if (mStrPhoto != null) {
            mIntFinIndpho = 1;
        }

        let mStrCodmaqChg = '';

        let mIntCant = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gman_equidefs' />
                <where>
                    codmaq = ?
                </where>
            </select>
        `, mStrCodmaq);


        if (mStrCodmaq != null && mIntCant) {
            mIntFinIndequ = 1;

            let mStrPrvmaq = Ax.db.executeGet(`
                <select>
                    <columns>codmaq prvmaq</columns>
                    <from table='gman_ordetrah' />
                    <where>
                        docser = ?
                    </where>
                </select>
            `, mRow.docser);

            let mObjEquidefs = Ax.db.executeQuery(`
                <select>
                    <columns>nommaq, codins, famili</columns>
                    <from table='gman_equidefs' />
                    <where>
                        codmaq = ?
                    </where>
                </select>            
            `, mStrCodmaq);

            //Modificar l'equip de l'OT origen.
            Ax.db.update('gman_ordetrah', 
                {
                    'codmaq'      : mStrCodmaq,
                    'codins'      : mObjEquidefs.codins,
                    'auxchr2'     : mObjEquidefs.famili,
                    'user_updated': mRow.assign_user,
                    'date_updated': new Ax.sql.Date()
                },
                {
                    'docser': mRow.docser
                }
            )

            //Modificar l'equip del comunicat generat.
            Ax.db.update('gman_parteser', 
                {
                    'codmaq'      : mStrCodmaq,
                    'user_updated': mRow.assign_user,
                    'date_updated': new Ax.sql.Date()
                },
                {
                    'rowid': mIntGmanParteserRowid
                }
            )

            if (mStrPrvmaq == null) {
                mStrCodmaqChg = `Equip modificat: ${mStrCodmaq} [${mObjEquidefs.nommaq}]`;
            } else {
                mStrCodmaqChg = `Equip modificat: ${mStrCodmaq} [${mObjEquidefs.nommaq}] (previament: ${mStrPrvmaq})`;
            }

            mStrGmanParteserComent = `${mStrGmanParteserComent}${mStrCodmaqChg}`

        }

        //Modificar comentari del comunicat generat.
        Ax.db.update('gman_parteser', 
            {
                'coment': mStrGmanParteserComent
            },
            {
                'rowid': mIntGmanParteserRowid
            }
        )

        let mObjGmanParteser = Ax.db.executeQuery(`
            <select>
                <columns>docser, docord</columns>
                <from table='gman_parteser' />
                <where>
                    rowid = ?
                </where>
            </select>
        `, mIntGmanParteserRowid).toOne();

        //Insertar foto al comunicat de servei.
        if (mIntFinIndpho) {
            let mIntGmanParteserCabid = Ax.db.executeGet(`
                <select>
                    <columns>cabid</columns>
                    <from table='gman_parteser' />
                    <where>
                        rowid = ?
                    </where>
                </select>
            `, mIntGmanParteserRowid);

            //Crida a Webservice al servidor de Mobile que inserta
            //imatge a gman_parteser_docs. 
            Ax.db.call('ws_gman_parteser_get_photo', mIntGmanParteserCabid, mRow.assign_user, mRow.assign_type, mRow.assign_number);

        }

        //Finalitzar l'OT segons l'estat indicat.
        switch (mObjAppsSfaTaskResl.state) {
            case '1':
            case '3':
            case '6':
                let mIntCount = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gman_parteser' />
                        <where>
                            rowid   = ? AND
                            estcab != 'E'
                        </where>
                    </select>
                `, mIntGmanParteserRowid);

                if (mIntCount) {
                    Ax.db.call('gman_ordetrah_set_completed', mObjGmanParteser.docord);
                }
                
                break;
        
            default:
                break;
        }

        //Deixar l'assignació de tasca com a revisada.
        Ax.db.update('apps_sfa_task_assign', 
            {
                'assign_state': 5
            }, 
            {
                'assign_user'  : mRow.assign_user,
                'assign_type'  : mRow.assign_type,
                'assign_number': mRow.assign_number
            }
        )

        //Cancel·lar subtasques associades a l'ordre de treball. 
        if (mRow.task_code == 'PAF') {
            let mArrOrde = Ax.db.executeQuery(`
                <select>
                    <columns>
                        seqno seqdes, cabid cabdes, docser docsub,
                        assign_user usrdes, assign_type typdes, fin_number numdes
                    </columns>
                    <from table='mut_nfc_ordetrah' />
                    <where>
                        seqori = ? AND
                        estado IN (10,11,12)
                    </where>
                </select>
            `, mRow.seqno).toMemory();

            for (let item of mArrOrde) {
                Ax.db.update('mut_nfc_ordetrah', 
                    {
                        'fin_datcon': mObjTaskResh.fin_datcon,
                        'fin_tagnfc': mObjTaskResh.fin_tagnfc
                    }, 
                    {
                        'seqno': item.seqdes
                    }
                )  
                
                //Ajustar data prevista d'inici, si està avançada al dia actual.
                let mIntContador = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gman_ordetrah' />
                        <where>
                            cabid = ? AND
                            fecpre &gt; TODAY
                        </where>
                    </select>
                `, item.cabdes);

                if (mIntContador) {
                    Ax.db.update('gman_ordetrah', 
                        {
                            'fecpre': new Ax.sql.Date()
                        }, 
                        {
                            'cabid': item.cabdes
                        }
                    )
                }

                mIntGmanParteserRowid = Ax.db.call('gman_ordetrah_gman_parteser', item.cabdes, mStrTipdoc);

                Ax.db.update('gman_parteser', 
                    {
                        'fecini': mObjTaskResh.fin_datcon
                    }, 
                    {
                        'rowid': mIntGmanParteserRowid
                    }
                );

                let mStrDocgen = Ax.db.executeGet(`
                    <select>
                        <columns>docser docgen</columns>
                        <from table='gman_parteser' />
                        <where>
                            rowid = ?
                        </where>
                    </select>
                `, mIntGmanParteserRowid);

                Ax.db.update('gman_parteser', 
                    {
                        'coment': `Finalitzat automàticament pel tancament de l'OT agrupada ${mObjGmanParteser.docord}.`
                    }, 
                    {
                        'rowid': mIntGmanParteserRowid
                    }
                );

                switch (mObjAppsSfaTaskResl.state) {
                    case '1':
                    case '3':
                    case '6':
                        let mIntCount = Ax.db.executeGet(`
                            <select>
                                <columns>COUNT(*)</columns>
                                <from table='gman_parteser' />
                                <where>
                                    rowid   = ? AND
                                    estcab != 'E'
                                </where>
                            </select>
                        `, mIntGmanParteserRowid);

                        if (mIntCount) {
                            Ax.db.call('gman_ordetrah_set_completed', item.docsub)
                        }
                        
                        break;
                
                    default:
                        break;
                }

                //Cancel·lar l'assignació.
                Ax.db.update('apps_sfa_task_assign', 
                    {
                        'assign_state': 3
                    }, 
                    {
                        'assign_user'  : item.usrdes,
                        'assign_type'  : item.typdes,
                        'assign_number': item.numdes
                    }
                )

                Ax.db.update('mut_nfc_ordetrah', 
                    {
                        'fin_estado': mObjAppsSfaTaskResl.state,
                        'fin_indcom': 0,
                        'fin_indwar': 0,
                        'fin_indpho': 0,
                        'fin_indequ': 0,
                        'estado': 13,
                        'doccom': mStrDocgen,
                    }, 
                    {
                        'seqno'  : item.seqdes
                    }
                )

            }

        }

        //Registrar l'OT com a realitzada en la taula de log NFC.
        Ax.db.update('mut_nfc_ordetrah', 
            {
                'fin_estado': mObjAppsSfaTaskResl.state,
                'fin_indcom': mIntFinIndcom,
                'fin_indwar': mIntFinIndwar,
                'fin_indpho': mIntFinIndpho,
                'fin_indequ': mIntFinIndequ,
                'estado': 3,
                'doccom': mObjGmanParteser.docser,
            }, 
            {
                'seqno'  : mRow.seqno
            }
        )

        //Enviar correu si hi ha nota d'avís o estats no Finalitzat ni Pendent.
        let mObjCperEmpleado = Ax.db.executeQuery(`
            <select>
                <columns>nomemp, codres</columns>
                <from table='cper_empleado' />
                <where>
                    codigo = ?
                </where>
            </select>
        `, mRow.assign_user).toOne();

        let mStrLinkot = `<![CDATA[http://erpmutua2012/coreapps/wic_mutua/formauto_s.jsp?code=gman_ordetrah&dbms=]]>${Ax.db.getCode()}<![CDATA[&cond=gman_ordetrah.docser+%3D+%27]]>${mObjGmanParteser.docord}<![CDATA[%27]]>`;

        let mStrLinkcs = `<![CDATA[http://erpmutua2012/coreapps/wic_mutua/formauto_s.jsp?code=gman_parteser&dbms=]]>${Ax.db.getCode()}<![CDATA[&cond=gman_parteser.docser+%3D+%27]]>${mObjGmanParteser.docser}<![CDATA[%27]]>`;

        if (mStrWarning != null || (mObjAppsSfaTaskResl.state >= 3 && mObjAppsSfaTaskResl.state <= 6)) {
            let mObjGmanOrdetrah = Ax.db.executeQuery(`
                <select>
                    <columns>gdepgrph.nomgrp locali, gman_ordetrah.operac</columns>
                    <from table='gman_ordetrah'>
                        <join table='gdepgrpl'>
                            <on>gman_ordetrah.delega = gdepgrpl.delega</on>
                            <on>gman_ordetrah.depart = gdepgrpl.depart</on>
                            <join table='gdepgrph'>
                                <on>gdepgrpl.codgru = gdepgrph.codigo</on>
                            </join>
                        </join>
                    </from>
                    <where>
                        gman_ordetrah.docser = ?
                    </where>
                    <order>gdepgrph.codigo</order>
                </select>
            `, mObjGmanParteser.docord).toOne();

            let mObjMail =  Ax.db.call('mut_sys_mail_select', 'mut_nfc_ordetrah_proc_fin','general');
            let mStrMailFrom = mObjMail.mail_from; 
            let mStrMailTo   = mObjMail.mail_to; 
            let mStrMailCc   = mObjMail.mail_cc;
            let mStrMailBcc  = mObjMail.mail_bcc;

            mStrMailTo = Ax.db.call('mut_nfc_get_mailconf', mStrTercer, mObjAppsSfaTaskResl.state);

            switch (mObjAppsSfaTaskResl.state) {
                case '4':
                case '5':
                case '6':
                    if (mObjCperEmpleado.codres != null) {
                        let mStrEmail = Ax.db.executeGet(`
                            <select>
                                <columns>email</columns>
                                <from table='cper_empleado' />
                                <where>
                                    codigo = ?
                                </where>
                            </select>
                        `, mObjCperEmpleado.codres);

                        if (mStrEmail != null) {
                            mStrMailTo = `${mStrEmail || ''}, ${mStrMailTo}`;
                        }
                    }

                    break;
            
                default:
                    break;
            }

            let mStrSubject = `NFC Mobile - ${mObjGmanParteser.docord} ${mMapEstats.get(parseInt(mObjAppsSfaTaskResl.state))}`

            if (mStrWarning != null) {
                mStrSubject = `${mStrSubject} amb Avís`;
            }

            if (mStrMailTo.length != 0) {
                let mMail = new Ax.mail.MailerMessage();
                mMail.from(mStrMailFrom);
                mMail.to(mStrMailto);
                mMail.cc(mStrMailCc);
                mMail.bcc(mStrMailBcc);
                mMail.subject(mStrSubject);
                mMail.setHtml(`
                    <html>
                        <body>
                            <p>Localització: ${mObjGmanOrdetrah.locali || ''}</p>
                            <p>Ordre de treball: <a href='${mStrLinkot}'>${mObjGmanParteser.docord}</a></p>
                            <p>Operació: ${mObjGmanOrdetrah.operac}</p>
                            <p>Comunicat de servei: <a href='${mStrLinkcs}'>${mObjGmanParteser.docser}</a></p>
                            <p>Operari: ${mRow.assign_user} ${mObjCperEmpleado.nomemp || ''}</p>
                            <p>${mStrCodmaqChg}</p>
                            <p />
                            <p>Estat: ${mMapEstats.get(parseInt(mObjAppsSfaTaskResl.state))}</p>
                            <p />
                            <p>${mStrWarning || ''}</p>
                        </body>
                    </html>
                `);
    
                //Se hace el envío del email
                let mMailer = new Ax.mail.Mailer();
                mMailer.setSMTPServer("localhost", 25);
                mMailer.send(mMail); 
            }
           
        }

        //Reenviar immediatament les tasques finalitzades com a Pendent.
        if (mObjAppsSfaTaskResl.state == '2' && mRow.task_code != 'SU') {
            let mObjGmanOrdetrah = Ax.db.executeQuery(`
                <select>
                    <columns>delega, depart, codope</columns>
                    <from table='gman_ordetrah' />
                    <where>
                        cabid = <m_cabid />
                    </where>
                </select>
            `.toOne());

            let mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='gdepgrpl' />
                    <where>
                        delega = ? AND
                        depart = ? AND
                        estado = 'A'
                    </where>
                </select>
            `, mObjGmanOrdetrah.delega, mObjGmanOrdetrah.depart);

            if (!mIntCount) {
                throw new Ax.lang.Exception(`Departament [${mObjGmanOrdetrah.delega}/${mObjGmanOrdetrah.depart}] no definit a Grups de Departaments.`);
            }

            if (mObjGmanOrdetrah.codope.length != 3) {
                throw new Ax.lang.Exception(`Operari [${mObjGmanOrdetrah.codope}] sense dispositiu mòbil.`);
            }

            //Programació.
            mRow.seqno = Ax.db.call('mut_gman_ordetrah_prg_tfa', mRow.cabid);
            Ax.db.call('mut_gman_ordetrah_syn_tfa', mRow.seqno, 'I');
            Ax.db.call('mut_gman_ordetrah_syn_tfa', mRow.seqno, 'F');

        }

    }

}

