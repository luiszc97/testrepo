function mutGmanEquidefsInfPreve(
    pStrCodmaq,
    pDateFecini,
    pDateFecfin,
    pStrTipplaCond,
    pStrCodgamCond,
    pStrCodserCond,
    pStrTipdocCond
) {
    let mRsLine = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['codgam','nomgam','tipfre','empult',
        'fecult','docult','emppre','fecpre','docpre']);
		options.setColumnTypes([Ax.sql.Types.VARCHAR, 
        Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR, 
        Ax.sql.Types.VARCHAR, Ax.sql.Types.DATE, 
        Ax.sql.Types.VARCHAR, Ax.sql.Types.VARCHAR,
        Ax.sql.Types.DATE, Ax.sql.Types.VARCHAR]);
	});

    let mArrGamaequi = Ax.db.executeQuery(`
        <select>
            <columns>
                gman_gamaequi.codgam,
                gman_gamadefs.nomgam,
                ROUND(gman_gamadefs.numfre) || gman_gamadefs.tipfre tipfre
            </columns>
            <from table='gman_gamaequi'>
                <join table='gman_gamadefs'>
                    <on>gman_gamadefs.codgam = gman_gamaequi.codgam</on>
                </join>
            </from>
            <where>
                    gman_gamaequi.codmaq = ?
                AND gman_gamadefs.codgam ${pStrCodgamCond}
            </where>
            <order>
                gman_gamaequi.codgam
            </order>
        </select>    
    `, pStrCodmaq).toJSONArray();

    for (let mRow of mArrGamaequi) {

        let mStrEmpult  = null;
        let mDateFecult = null;
        let mStrDocult  = null;
        let mStrEmppre  = null;
        let mDateFecpre = null;
        let mDateFecpre1= null;
        let mStrDocpre  = null;

        //última intervenció
        let mObjGcommovh = Ax.db.executeQuery(`
            <select>
                <columns>
                    first 1 gcommovh.fecmov, gcommovh.docori, ctercero.nombre tercer,
                    gman_ordetrah.fecpre fecpre1
                </columns>
                <from table='gcommovh'>
                    <join table='gman_ordetrah'>
                        <on>gcommovh.docori = gman_ordetrah.docser</on>
                    </join>
                    <join table='gman_ordetrad'>
                        <on>gman_ordetrad.codigo = gman_ordetrah.tipdoc</on>
                    </join>
                    <join table='ctercero'>
                        <on>ctercero.codigo = gcommovh.tercer</on>
                    </join>
                </from>
                <where>
                        gman_ordetrah.codmaq =  ?
                    AND gman_ordetrah.fecpre BETWEEN ? AND ?
                    AND gman_ordetrah.codgam =  ?
                    AND gman_ordetrad.tippla ${pStrTipplaCond}
                    AND gman_ordetrah.codser ${pStrCodserCond}
                    AND gcommovh.tipdoc ${pStrTipdocCond}
                </where>
                <order>fecmov DESC</order>
            </select>
        `, pStrCodmaq, pDateFecini, pDateFecfin, mRow.codgam).toOne();

        mStrEmpult  = mObjGcommovh.tercer;
        mDateFecult = mObjGcommovh.fecmov;
        mStrDocult  = mObjGcommovh.docori;
        mDateFecpre1 = mObjGcommovh.fecpre1;

        //propera intervenció
        let mObjOrdetrah = Ax.db.executeQuery(`
            <select>
                <columns>
                    first 1 gman_ordetrah.fecpre, gman_ordetrah.docser,
                    ctercero.nombre tercer
                </columns>
                <from table='gman_ordetrah'>
                    <join table='gman_ordetrad'>
                        <on>gman_ordetrad.codigo = gman_ordetrah.tipdoc</on>
                    </join>
                    <join table='ctercero'>
                        <on>ctercero.codigo = gman_ordetrah.tercer</on>
                    </join>
                </from>
                <where>
                        gman_ordetrah.codmaq =  ?
                    AND gman_ordetrah.codgam =  ?
                    AND gman_ordetrad.tippla ${pStrTipplaCond}
                    AND gman_ordetrah.fecpre &gt;= ?
                    AND gman_ordetrah.codser ${pStrCodserCond}
                    AND NOT EXISTS(SELECT *
                                    FROM gcommovh
                                    WHERE gcommovh.docori = gman_ordetrah.docser
                                    AND gcommovh.tipdoc ${pStrTipdocCond})
                </where>
                <order>fecpre ASC</order>
            </select>
        `, pStrCodmaq, mRow.codgam, mDateFecpre1).toOne();

        mStrEmppre  = mObjOrdetrah.tercer;
        mDateFecpre = mObjOrdetrah.fecpre;
        mStrDocpre  = mObjOrdetrah.docser;

        mRsLine.rows().add([ mRow.codgam, mRow.nomgam, , mRow.tipfre, mStrEmpult, mDateFecult, mStrDocult, mStrEmppre, mDateFecpre, mStrDocpre]);

    }

    return mRsLine;

}