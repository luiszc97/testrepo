/**
 *  Js: gdwh_lexpdocd_vdel                                              
 *                                                                        
 *  Script que carga la tabla gdwh_vdelartd desde la tabla gdwh_lexpdocd  
 *  (Logística expediciones-documento) siempre  y cuando la informacion   
 *  hubiera sido cargada con el parametro p_valida = 'N' y los movimientos
 *  sean consumos por delegación                                          
 */
function gdwh_lexpdocd_vdel(pStrEmpcode, pStrCodalm, pDatFecha, pStrIndagr) {
    /**
     *  Control de errores                                       
     *  Borrar los errores producidos en ejecuciones anteriores. 
     */
    var mStrProname = 'LEXPVDEL';       //Logística Expediciones Ventas delegación

    Ax.db.delete('gdwh_interr', {proname: mStrProname});

    /**
     *  Procesar registros de gdwh_lexpdocd.  
     */
    var mArrLexpdocd = Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT delega, depart, tabori, tipdoc
            </columns>
            <from table='gdwh_lexpdocd' />
            <where>
                fecha   = ${pDatFecha}  AND
                empcode = ? AND
                codalm  = ? AND
                valida  = 'N'
            </where>
            <order>
                delega, depart, tabori, tipdoc
            </order>
        </select>
    `, pStrEmpcode, pStrCodalm).toMemory();

    var mStrTabname;
    var mIntCount;
    var ArrGdwhLexpdocd = [];
    var ArrGdwhVdelartd = [];

    for (var mRow of mArrLexpdocd) {
        /**
         *  Solo se cargan los movimientos de consumo 
         */
        switch (mRow.tabori) {
            case 'EA':
                mStrTabname = 'geanmovd';
            break;

            case 'TV':
                mStrTabname = 'gvenmovd';
            break;

            case 'TC':
                mStrTabname = 'gcommovd';
            break;
        
            default:
            break;
        }

        mIntCount = Ax.db.executeGet(`
            <select>
                <columns>
                    COUNT(*)
                </columns>
                <from table='${mStrTabname}'/>
                <where>
                        codigo = ?
                    AND consum NOT IN ('L', 'E')
                </where>
            </select>        
        `, mRow.tipdoc);

        if (mIntCount) {
            continue;
        }

        /**
         *  LOGÍSTICA MOVIMIENTOS-ARTÍCULOS-DIA.     
         */
        mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gdwh_vdelartd' />
                <where>
                    empcode = ? AND
                    codalm  = ? AND
                    delega  = ? AND
                    depart  = ? AND
                    tabori  = ? AND
                    tipdoc  = ? AND
                    fecha   = ?
                </where>
            </select>    
        `, pStrEmpcode, pStrCodalm, mRow.delega, mRow.depart, mRow.tabori, mRow.tipdoc, pDatFecha)

        if (pStrIndagr == 'N' && !mIntCount) {
            ArrGdwhLexpdocd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        fecha,  empcode,codalm, delega, depart, tabori,
                        tipdoc, cladoc, seccio, codfam, codart, varstk,
                        coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                        SUM(canmov) canmov, SUM(0) impbru, SUM(0) impnet, SUM(0) impdto,
                        SUM(impcos) impcos, SUM(0) imprap,
                        SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, 
                        SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                        SUM(auxnu4) auxnu4, 
                        SUM(0), SUM(0), SUM(0),
                        SUM(0), SUM(0),
                        semmes, agrega, valida
                    </columns>
                    <from table='gdwh_lexpdocd' />
                    <where>
                        empcode = ? AND
                        codalm  = ? AND
                        fecha   = ? AND
                        delega  = ? AND
                        depart  = ? AND
                        tabori  = ? AND
                        tipdoc  = ? AND
                        valida  = 'N'
                    </where>
                    <group>
                        fecha,  empcode,codalm, delega, depart, tabori, tipdoc, cladoc,
                        seccio, codfam, codart, varstk, coduni, auxal0, auxal1, auxal2,
                        auxal3, auxal4, semmes, agrega, valida
                    </group>
                </select> 
            `, pStrEmpcode, pStrCodalm, pDatFecha, mRow.delega, mRow.depart, mRow.tabori, mRow.tipdoc).toMemory();

            for (var mIdxGL of ArrGdwhLexpdocd) {
                Ax.db.insert('gdwh_vdelartd', 
                    {
                        fecha: mIdxGL.fecha,
                        empcode: mIdxGL.empcode,
                        codalm: mIdxGL.codalm,
                        delega: mIdxGL.delega,
                        depart: mIdxGL.depart,
                        tabori: mIdxGL.tabori,
                        tipdoc: mIdxGL.tipdoc,
                        cladoc: mIdxGL.cladoc,
                        seccio: mIdxGL.seccio,
                        codfam: mIdxGL.codfam,
                        codart: mIdxGL.codart,
                        varstk: mIdxGL.varstk,
                        coduni: mIdxGL.coduni,
                        auxal0: mIdxGL.auxal0,
                        auxal1: mIdxGL.auxal1,
                        auxal2: mIdxGL.auxal2,
                        auxal3: mIdxGL.auxal3,
                        auxal4: mIdxGL.auxal4,
                        canmov: mIdxGL.canmov,
                        impbru: mIdxGL.impbru,
                        impnet: mIdxGL.impnet,
                        impdto: mIdxGL.impdto,
                        impcos: mIdxGL.impcos,
                        imprap: mIdxGL.imprap,
                        auxnu0: mIdxGL.auxnu0,
                        auxnu1: mIdxGL.auxnu1,
                        auxnu2: mIdxGL.auxnu2,
                        auxnu3: mIdxGL.auxnu3,
                        auxnu4: mIdxGL.auxnu4,
                        auxnu5: mIdxGL.auxnu5,
                        auxnu6: mIdxGL.auxnu6,
                        auxnu7: mIdxGL.auxnu7,
                        auxnu8: mIdxGL.auxnu8,
                        auxnu9: mIdxGL.auxnu9,
                        semmes: mIdxGL.semmes,
                        agrega: mIdxGL.agrega,
                        valida: mIdxGL.valida
                    }
                )
            }
        } else {
            ArrGdwhVdelartd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        fecha,  empcode,codalm, delega, depart, tabori,
                        tipdoc, cladoc, seccio, codfam, codart, varstk,
                        coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                        SUM(canmov) canmov, SUM(0) impbru, SUM(0) impnet,
                        SUM(0) impdto, SUM(impcos) impcos, SUM(0) imprap,
                        SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                        SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                        SUM(auxnu4) auxnu4, SUM(0) auxnu5,
                        SUM(0) auxnu6, SUM(0) auxnu7,
                        SUM(0) auxnu8, SUM(0) auxnu9,
                        semmes, agrega, valida
                    </columns>
                    <from table='gdwh_lexpdocd' />
                    <where>
                        codalm = ? AND
                        delega = ? AND
                        depart = ? AND
                        tabori = ? AND
                        tipdoc = ? AND
                        fecha  = ? AND
                        valida = 'N'
                    </where>
                    <group>
                        fecha,  empcode,codalm, delega, depart, tabori,
                        tipdoc, cladoc, seccio, codfam, codart, varstk,
                        coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                        semmes, agrega, valida
                    </group>
                </select>
            `, pStrCodalm, mRow.delega, mRow.depart, mRow.tabori, mRow.tipdoc, pDatFecha).toMemory();

            for (var mRwVL of ArrGdwhVdelartd) {

                for (var idx = 1; idx <= 11; idx++) {
                    /**
                     *  Control de que las iteraciones no sean más de 10. 
                     */
                    if (idx > 10) {
                        throw new Ax.lang.Exception("gdwh_lexpdocd_vdel: Número de iteraciones superada. Máximo 10.");
                    }

                    mIntCount = Ax.db.executeGet(`
                        <select>
                            <columns>
                                COUNT(*) count
                            </columns>
                            <from table='gdwh_vdelartd'/>
                            <where>
                                fecha   = ${mRwVL.fecha}  AND
                                empcode = '${mRwVL.empcode}' AND
                                codalm  = '${mRwVL.codalm}' AND
                                delega  = '${mRwVL.delega}' AND
                                depart  = '${mRwVL.depart}' AND
                                tabori  = '${mRwVL.tabori}' AND
                                tipdoc  = '${mRwVL.tipdoc}' AND
                                cladoc  = '${mRwVL.cladoc}' AND
                                seccio  = '${mRwVL.seccio}' AND
                                codfam  = '${mRwVL.codfam} 'AND
                                codart  = '${mRwVL.codart}' AND
                                varstk  = '${mRwVL.varstk}' AND
                                coduni  = '${mRwVL.coduni}' AND
                                auxal0  = '${mRwVL.auxal0}' AND
                                auxal1  = '${mRwVL.auxal1}' AND
                                auxal2  = '${mRwVL.auxal2}' AND
                                auxal3  = '${mRwVL.auxal3}' AND
                                auxal4  = '${mRwVL.auxal4}' AND
                                semmes  = '${mRwVL.semmes}'                                
                            </where>
                        </select>
                    `);
    
                    Ax.db.execute(`
                        UPDATE gdwh_vdelartd
                        SET canmov = canmov + ${mRwVL.canmov},
                            impcos = impcos + ${mRwVL.impcos},
                            auxnu0 = auxnu0 + ${mRwVL.auxnu0},
                            auxnu1 = auxnu1 + ${mRwVL.auxnu1},
                            auxnu2 = auxnu2 + ${mRwVL.auxnu2},
                            auxnu3 = auxnu3 + ${mRwVL.auxnu3},
                            auxnu4 = auxnu4 + ${mRwVL.auxnu4}
                        WHERE 
                            fecha   = ${mRwVL.fecha}  AND
                            empcode = '${mRwVL.empcode}' AND
                            codalm  = '${mRwVL.codalm}' AND
                            delega  = '${mRwVL.delega}' AND
                            depart  = '${mRwVL.depart}' AND
                            tabori  = '${mRwVL.tabori}' AND
                            tipdoc  = '${mRwVL.tipdoc}' AND
                            cladoc  = '${mRwVL.cladoc}' AND
                            seccio  = '${mRwVL.seccio}' AND
                            codfam  = '${mRwVL.codfam} 'AND
                            codart  = '${mRwVL.codart}' AND
                            varstk  = '${mRwVL.varstk}' AND
                            coduni  = '${mRwVL.coduni}' AND
                            auxal0  = '${mRwVL.auxal0}' AND
                            auxal1  = '${mRwVL.auxal1}' AND
                            auxal2  = '${mRwVL.auxal2}' AND
                            auxal3  = '${mRwVL.auxal3}' AND
                            auxal4  = '${mRwVL.auxal4}' AND
                            semmes  = '${mRwVL.semmes}'
                    `);

                    if (mIntCount == 0) {
                        Ax.db.insert('gdwh_vdelartd', mRwVL)
                    }

                    if (pStrIndagr == 'S') {
                        var mObjAgrega = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    tipagr tipdoc, claagr cladoc
                                </columns>
                                <from table='gdwh_agrega' />
                                <where>
                                    tipdoc  = '${mRwVL.tipdoc}' AND
                                    cladoc  = '${mRwVL.cladoc}'
                                </where>
                            </select>
                        `).toOne();

                        mRwVL.tipdoc = mObjAgrega.tipdoc;
                        mRwVL.cladoc = mObjAgrega.cladoc;

                        if (mRwVL.tipdoc == null) {
                            break;
                        }
                    } else {
                        break;
                    }

                }

            }

        }

    }

}