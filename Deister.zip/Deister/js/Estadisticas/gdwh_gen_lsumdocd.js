var pStrEmpcode = Ax.context.variable.EMPCODE;
var pStrCodalm  = Ax.context.variable.CODALM;
var pStrFecini  = Ax.context.variable.FECINI;
var pStrFecfin  = Ax.context.variable.FECFIN;

Ax.db.call('gdwh_gen_lsumdocd', 
    pStrEmpcode,
    pStrCodalm,
    new Ax.sql.Date(pStrFecini),
    new Ax.sql.Date(pStrFecfin),
    'N'
)

return Ax.db.executeQuery(`
    <union type='all'>
        <select>
            <columns>
                codigo <alias name='docser' />, fecinf <alias name='fecmov' />, errmsg
            </columns>
            <from table='gdwh_interr' />
            <where>
                proname IN ('WLSUDOC','LSUMDOCA','LMOVSECT','LMOVFAMS') AND
                delalm  ${pStrCodalm}
            </where>
        </select>

        <select>
        <columns>
                <cast type='char'>NULL</cast>, <today />, 'Generación terminada.'
        </columns>
        <from table='cdataemp' />
        </select>
        <order>docser DESC</order>
    </union>   
`);