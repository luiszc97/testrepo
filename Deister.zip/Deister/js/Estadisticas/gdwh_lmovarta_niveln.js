/**
 *  =================================================================================
 *                                                                                  
 *  Js: gdwh_lmovartd_niveln                                                  
 *                                                                                  
 *  Deja el resultado del select sobre gdwh_lmovartd en la tabla temporal         
 *  @tmp_resultado. Los distintos valores de los argumentos p_nivel? determinan   
 *  el número de niveles que se mostrarán en la temporal.                         
 *                                                                                  
 *  =================================================================================
 */
function gdwh_lmovartd_niveln(
    pStrNivfam,  pStrNivel1,  pStrNivel2, 
    pStrNivel3,  pStrNivel4,  pStrNivel5, 
    pStrTipval1, pStrTipval2, pStrConsum, 
    pStrSqlcond){

    /**
     *  Mapa para obtener las descripciones según el nivel. 
     */
    var mMapGdwhGetDescrip = Ax.util.Map.of(
        'GRPDEL','gdelgrph',
        'GRPALM','galmgrph',
        'CODALM','galmacen',
        'DELEGA','gdelegac',
        'DEPART','gdeparta',
        'CUENTA','galmctas',
        'CLADOC','DEPENDE CLASE DOCUMENTO',
        'TIPDOC','DEPENDE TIPO DOCUMENTO',
        'SECCIO','gseccana',
        `CODFAM[1,${pStrNivfam}]`, 'gartfami',
        'CODART','garticul');

    /**
     * Seleccionar solo los distintos niveles informados.            
     *                                                               
     * n1='GRPDEL',n2='GRPDEL',n3='CODALM' :: n1='GRPDEL',n2='CODALM'
     *                                                               
     * n1='GRPDEL',n2='GRPDEL',n3='CODALM',n4='CODALM',n5='CUENTA' ::
     * n1='GRPDEL',n2='CODALM',n3='CUENTA'  
     */
    var mRsNivel = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['order','nivel']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR]);
	});

    var mIntJdx = 0;
    var mStrNivel;
    for (var index = 1; index <= 5; index++) {
        mStrNivel = `pStrNivel${index}`;

        var mBoolCont = false;

        mRsNivel.forEach(row => {
            if (row.nivel == mStrNivel) {
                mBoolCont = true;
            }
        })

        if (!mBoolCont) {
            mIntJdx = mIntJdx + 1;
            mRsNivel.rows().add([mIntJdx, mStrNivel]);
        }

    }

    /**
     *  Determinar las columnas en función de los niveles. 
     */
    mRsNivel.rows().sort(["order"]);
    var mStrColumns = ' ';
    var mStrColgrp = '';
    var mIntIdx = 0;
    var mStrDescrip;

    mRsNivel.forEach(mRow => {
        mStrNivel = mRow.nivel;

        mIntIdx = mIntIdx + 1;

        /**
         *  Recuperar la descripción del nivel.
         */
        if(mMapGdwhGetDescrip.get(mStrNivel) == null) mStrDescrip = ' ';

        if (Ax.db.existsTable(mStrDescrip)) {
            mStrDescrip = `gdwh_get_descrip('${mStrDescrip}', ${mStrNivel})`
        } else {
            mStrDescrip = `${mStrDescrip}`;
        }

        /**
         *  Caso particular para el nivel con el valor CODFAM[1,$NIVFAM]. 
         */
        if (mRow.nivel == `CODFAM[1,${pStrNivfam}]`) {
            mStrNivel  = `SUBSTR(codfam, 1, ${pStrNivfam})`;
        }

        /**
         *  Construir el string de columnas para el columns del select. 
         */
        var mStrColumns = `${mStrColumns}${mStrNivel} nivel${mIntIdx}, <nvl>${mStrDescrip}, ''</nvl> desniv${mIntIdx},`;

        if (Ax.db.getDriver() == 'ids') {
            //  informix : Para group by emitimos solo su alias. 
            mStrColgrp = `${mStrColgrp}nivel${mIntIdx}, desniv${mIntIdx},`;
        } else {
            //  oracle / postges : sin alias 
            mStrColgrp = `${mStrColgrp}${mStrNivel}, <nvl>${mStrDescrip}, ''</nvl>,`
        }

    })

    /**
     *  Determinar el group del select. 
     */
    if (Ax.db.getDriver() == 'ids') {
        //  informix : Para group by emitimos solo su alias.
        mStrColgrp = `${mStrColgrp} ejerci, period, nommes, fecha`;
    } else {
        //  oracle / postges : sin alias
        mStrColgrp = `${mStrColgrp} <year>gdwh_lmovartd.fecha</year>, <month>gdwh_lmovartd.fecha</month>, nommes, fecha`;
    }

    /**
     *  Determinar el order del select. 
     */
    var mStrOrder = 'nivel1';

    for (var index = 2; index < mIntIdx; index++) {
        mStrOrder = `${mStrOrder}, nivel${index}`;
    }

    mStrOrder = `${mStrOrder}, ejerci DESC, period DESC, fecha DESC`;

    /**
     *  Select definitivo. 
     */
    var mTmpResul = Ax.db.getTempTableName('tmp_resultado');

    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpResul}`);

    Ax.db.execute(`
        <select intotemp='${mTmpResul}'>
            <columns>
                ${mIntIdx} nivel,
                ${mStrColumns}
                <year>gdwh_lmovartd.fecha</year> ejerci,
                <month>gdwh_lmovartd.fecha</month> period,
                gdwh_mesdia.nommes,
                gdwh_lmovartd.fecha,
                SUM(${pStrTipval1}) valor1,
                SUM(${pStrTipval2}) valor2
            </columns>
            <from table='gdwh_lmovartd'>
                <join table='gdelgrpl'>
                    <on>gdwh_lmovartd.delega = gdelgrpl.delgrp</on>
                </join>
                <join table='galmgrpl'>
                    <on>gdwh_lmovartd.codalm = galmgrpl.almgrp</on>
                </join>
                <join table='gdwh_mesdia'>
                    <on>gdwh_mesdia.anymes = <char><year>gdwh_lmovartd.fecha</year></char>||LPAD(<month>gdwh_lmovartd.fecha</month>,2,'0')</on>
                </join>
            </from>
            <where>
                gdwh_lmovartd.consum = (CASE WHEN '${pStrConsum}' = '0' THEN 0
                                             WHEN '${pStrConsum}' = '1' THEN 1
                                             ELSE gdwh_lmovartd.consum
                                         END) AND
                ${pStrSqlcond}
            </where>
            <group>${mStrColgrp}</group>
        </select>   
    `);

    return mStrOrder;

}