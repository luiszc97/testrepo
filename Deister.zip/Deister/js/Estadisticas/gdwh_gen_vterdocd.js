/**
 *  Js: gdwh_gen_vterdocd                                             
 *                                                                      
 *  Procesa las facturas de ventas que pertenezcan a las delegaciones   
 *  indicadas y se encuentren en la tabla de tracking (gdoc_traspaso),  
 *  para generar el DWH de Ventas.                                      
 *                                                                      
 *  ATENCIÓN!!!                                                         
 *                                                                      
 *  Si p_valida = "N" entonces agregará los restantes niveles de        
 *  información vía proceso, de lo contrario lo hará la propia inserción
 *  de registros vía trigger, pero esta esta última opción no es la más 
 *  aconsejable porque tiene un mayor coste, ya que realiza una         
 *  actualización de todos los niveles por cada registro insertado,     
 *  mientras que por proceso, cada nivel superior se actualiza con la   
 *  información agrupada del nivel inferior, por ello es más rápida.     
 */
function gdwh_gen_vterdocd(pStrEmpcode, pStrDelega, pDatFecini, pDatFecfin, pStrValida) {
    /**
     *  FUNC: local_gdwh_vdtoartd                                               
     *                                                                          
     *  Función que procesa los descuentos de facturas de ventas para generar el
     *  DWH de Descuentos de ventas, es por ello que recibe el p_cabid de la    
     *  factura a procesar.                                                      
     */
    function __local_gdwh_vdtoartd(pIntCabid, pStrEmpcode, pStrDelega, pStrDocser) {
        /**
         *  Inicialización de variables  
         */
        var mCharNull = '-';                        // Campos char que no se informan  
        var mDatNull  = new Ax.sql.Date(1900,1,1);  // Campos date que no se informan
        var mNumNull  = 0;                          // Campos numéricos que no se informan

        /**
         *  Lamada al script gvendtos_get_cosinfo, el cual necesita recibir una   
         *  tabla temporal como parámetro con las lineas de la factura a procesar 
         *  y devuelve resultados en la temporal @tmp_gvendtll.                   
         */
        var mTmpLinproc = Ax.db.getTempTableName('tmp_linproc');

        Ax.db.execute(`
            <select intotemp='${mTmpLinproc}'>
                <columns>
                   gvenfacl.cabid, gvenfacl.linid
                </columns>
                <from table='gvenfacl'>
                    <join table='gvenfach'>
                        <on>gvenfacl.cabid  = gvenfach.cabid</on>
                    </join>
                </from>
                <where>
                    gvenfach.cabid   = ${pIntCabid}   AND
                    gvenfach.docser  = ${pStrDocser}  AND
                    gvenfach.empcode = ${pStrEmpcode} AND
                    gvenfach.delega  = ${pStrDelega}  AND
                    gvenfach.movest  = 0
                </where>
            </select>
        `);

        Ax.db.call('gvendtos_get_cosinfo', mTmpLinproc,'gvenfach');

        /**
         *  Si hay registros en @tmp_gvendtll borra las entradas anteriores 
         *  y se procesan descuentos.                                       
         */
        var mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='@tmp_gvendtll' />
            </select> 
        `);

        if (mIntCount) {
            Ax.db.delete('gdwh_vdtoartd', 
                {
                    docser : pStrDocser,
                    empcode: pStrEmpcode,
                    delega : pStrDelega
                }
            )
        }

        /**
         *  Inserción de la información.    
         */
        var mArrGdwhVdtoartd = Ax.db.executeQuery(`
            <select>
                <columns>
                    gvenfach.fecha,
                    gvenfach.empcode,
                    galmdele_get_almacen('gvenfach',
                                         gvenfach.cabid,
                                         gvenfach.delega,
                                         gvenfach.depart,
                                         gvenfach.tercer,
                                         gvenfach.tercer,
                                         gvenfach.tipdir,
                                         gvenfach.tipdoc) codalm,
                    gvenfach.delega,
                    gvenfach.depart,
                    'FV',
                    <nvl>gartfami.secana,'${mCharNull}'</nvl> seccio,
                    <nvl>garticul.codfam,'${mCharNull}'</nvl> codfam,
                    gvenfacl.codart,
                    gvenfacl.varlog,
                    gvenfacl.udmven,
                    gvenfach.tercer,
                    gvenfach.tipdir,
                    gvenfach.terfac,
                    <nvl>gcliente.tergrp,'${mCharNull}'</nvl> tergrp,
                    <nvl>gcliente.terfed,'${mCharNull}'</nvl> terfed,
                    <nvl>gcliente.tercom,'${mCharNull}'</nvl> tercom,
                    <nvl>cterdire.codnac,'${mCharNull}'</nvl> codnac,
                    <nvl>cterdire.codpos,'${mCharNull}'</nvl> codpos,
                    <nvl>cterdire.codzon,'${mCharNull}'</nvl> codzon,
                    <nvl>gvenfach.agente,'${mCharNull}'</nvl> agente,
                    gvenfach.tipdoc,
                    <nvl>gvenfach.clasif,'${mCharNull}'</nvl> clasif,
                    gvenfach.docser,
                    '${mCharNull}' auxal0,
                    '${mCharNull}' auxal1,
                    '${mCharNull}' auxal2,
                    '${mCharNull}' auxal3,
                    '${mCharNull}' auxal4,
                    @tmp_gvendtll.coddto,
                    @tmp_gvendtll.import,
                    ${mNumNull} import,
                    ${mNumNull} auxnu0,
                    ${mNumNull} auxnu1,
                    ${mNumNull} auxnu2,
                    ${mNumNull} auxnu3,
                    ${mNumNull} auxnu4,
                    'A',
                    'N',
                    'N'
                </columns>
                <from table='@tmp_gvendtll'>
                    <join table='gvenfacl'>
                        <on>@tmp_gvendtll.linid = gvenfacl.linid</on>
                    </join>
                    <join table='gvenfach'>
                        <on>gvenfacl.cabid = gvenfach.cabid</on>
                    </join>
                    <join table='gdelegac'>
                        <on>gvenfach.delega = gdelegac.codigo</on>
                    </join>
                    <join type='left' table='gvenmovl'>
                        <on>gvenfacl.linori = gvenmovl.linid</on>
                        <join type='left' table='gvenmovh'>
                            <on>gvenmovl.cabid = gvenmovh.cabid</on>
                            <join type='left' table='cterdire'>
                                <on>gvenmovh.terenv = cterdire.codigo</on>
                                <on>gvenmovh.direnv = cterdire.tipdir</on>
                            </join>
                        </join>
                    </join>
                    <join type='left' table='garticul'>
                        <on>gvenfacl.codart = garticul.codigo</on>
                        <join type='left' table='gartfami'>
                            <on>garticul.codfam = gartfami.codigo</on>
                        </join>
                    </join>
                    <join type='left' table='gcliente'>
                        <on>gvenfach.tercer = gcliente.codigo</on>
                    </join>
                </from>
                <where>
                    @tmp_gvendtll.coddto IS NOT NULL    AND
                    @tmp_gvendtll.import != 0           AND
                    gvenfach.cabid       = ${pIntCabid}  AND
                    gvenfach.delega      = '${pStrDelega}' AND
                    gvenfach.docser      = '${pStrDocser}'
                </where>
            </select>        
        `).toMemory();

        for (var mRow of mArrGdwhVdtoartd) {
            Ax.db.insert('gdwh_vdtoartd', 
                {
                    fecha:  mRow.fecha,  
                    empcode:mRow.empcode,
                    codalm: mRow.codalm, 
                    delega: mRow.delega,
                    depart: mRow.depart, 
                    tabori: 'FV', 
                    seccio: mRow.seccio, 
                    codfam: mRow.codfam,
                    codart: mRow.codart, 
                    varstk: mRow.varlog, 
                    coduni: mRow.udmven, 
                    tercer: mRow.tercer,
                    tipdir: mRow.tipdir, 
                    terfac: mRow.terfac, 
                    tergrp: mRow.tergrp, 
                    terfed: mRow.terfed,
                    tercom: mRow.tercom, 
                    codnac: mRow.codnac, 
                    codpro: mRow.codpos, 
                    codzon: mRow.codzon,
                    agente: mRow.agente, 
                    tipdoc: mRow.tipdoc, 
                    cladoc: mRow.clasif, 
                    docser: mRow.docser,
                    auxal0: mRow.auxal0, 
                    auxal1: mRow.auxal1, 
                    auxal2: mRow.auxal2, 
                    auxal3: mRow.auxal3,
                    auxal4: mRow.auxal4, 
                    dtoven: mRow.coddto, 
                    impdto: mRow.import, 
                    import: mRow.import,
                    auxnu0: mRow.auxnu0, 
                    auxnu1: mRow.auxnu1, 
                    auxnu2: mRow.auxnu2, 
                    auxnu3: mRow.auxnu3,
                    auxnu4: mRow.auxnu4, 
                    semmes: 'A', 
                    agrega: 'N', 
                    valida: 'N'
                }
            )
        }

        /**
         *  Borrado de las tablas temporales.       
         */
        Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpLinproc}`);
        Ax.db.execute(`DROP TABLE IF EXISTS @tmp_gvendtll`);

    }

    /**
     *  Inicialización de variables 
     */
    var mCharNull = '-';                        // Campos char que no se informan  
    var mDatNull  = new Ax.sql.Date(1900,1,1);  // Campos date que no se informan
    var mNumNull  = 0;                          // Campos numéricos que no se informan
    var mStrProname = 'WVTERDF';                // Ventas Terceros Documento Facturas 
    var mObjGdwhVterdocd = {};
    mObjGdwhVterdocd.semmes = 'A';              // Indicativo de actualización de semanas/meses
    mObjGdwhVterdocd.agrega = 'N';              // Indicativo de agregación        
    
    /**
     *  Control de errores                                                    
     *                                                                        
     *  Borrar los errores producidos en ejecuciones anteriores de facturas y 
     *  sus descuentos.                                                       
     */
    Ax.db.delete('gdwh_interr',
        `
            proname IN ('WVTERDF','WVDTOAF') AND
            delalm  ${pStrDelega}
        `
    );

    /**
     *  Procesa las facturas existentes en la tabla de tracking.                 
     *                                                                   
     *  El join con la tabla gvenfach se hace porque es necesario procesar los   
     *  documentos ordenados cronológicamente (fecha), porque en los niveles     
     *  mensual y anual del DWH, por cada registro del período actual, se guarda 
     *  el mismo dato del mismo período del año anterior. Esto es muy eficiente  
     *  cuando se realizan informes comparativos de un año frente al anterior.    
     */
    var mArrGdwhVterdocd = Ax.db.executeQuery(`
        <select>
            <columns>
                gvenfach.fecha, gvenfach.docser, gdoc_traspaso.colval,
                MAX(gdoc_traspaso.tipope) tipope
            </columns>
            <from table='gdoc_traspaso'>
                <join table='gvenfach'>
                    <on>gdoc_traspaso.colval = gvenfach.cabid</on>
                </join>
            </from>
            <where>
                gdoc_traspaso.tabname = 'gvenfach' AND
                gdoc_traspaso.colname = 'cabid'    AND
                gdoc_traspaso.tippro  = 0          AND
                gvenfach.fecha        BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                gvenfach.empcode ${pStrEmpcode} AND
                gvenfach.delega ${pStrDelega}
            </where>
            <group>
                fecha, docser, colval
            </group>
            <order>
                fecha, colval
            </order>
        </select>
    `).toMemory();

    for (mObjGdwhVterdocd of mArrGdwhVterdocd) {
        /**
         *  Control de error y transacción por documento.   
         */
        try {
            //  Se abre transaccion por documento.
            Ax.db.beginWork();

            /**
             *  Borrado del documento en caso de Delete (tipope = 2) y salir.
             */
            if (mObjGdwhVterdocd.tipope == 2) {
                Ax.db.delete('gdwh_vterdocd', 
                    {
                        docser: mObjGdwhVterdocd.docser
                    }
                )

                //  Eliminamos el registro del tracking. 
                Ax.db.delete('gdoc_traspaso', 
                    {
                        tabname: 'gvenfach',
                        colname: 'cabid',      
                        colval : mObjGdwhVterdocd.colval, 
                        tippro : 0,            
                        tipope : 2
                    }
                )

                //  Se cierra la transaccion.  
                Ax.db.commitWork();

                continue;
            }

            /**
             *  Borrado del documento en caso de Update (tipope = 1).    
             */
            if (mObjGdwhVterdocd.tipope == 1) {
                Ax.db.delete('gdwh_vterdocd', 
                    {
                        docser: mObjGdwhVterdocd.docser
                    }
                )
            }

            /**
             *  Selección de datos de cabecera. 
             */
            mObjGdwhVterdocd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        gvenfach.cabid,
                        gvenfach.fecha,
                        gvenfach.empcode,
                        gvenfach.delega,
                        gvenfach.depart,
                        gvenfach.tipdoc,
                        <nvl>gvenfach.clasif,'${mCharNull}'</nvl> cladoc,
                        gvenfach.tercer,
                        gvenfach.tipdir,
                        gvenfach.terfac,
                        <nvl>gcliente.tergrp,'${mCharNull}'</nvl> tergrp,
                        <nvl>gcliente.terfed,'${mCharNull}'</nvl> terfed,
                        <nvl>gcliente.tercom,'${mCharNull}'</nvl> tercom,
                        CASE WHEN gvenfach.agente IS NULL OR
                                  <length>gvenfach.agente</length> = 0
                             THEN '${mCharNull}'
                             ELSE gvenfach.agente
                         END agente,
                        gvenfach.tipefe,
                        gvenfach.frmpag,
                        gvenfach.divisa,
                        gvenfach.docser,
                        CASE WHEN gvenfach.docori IS NULL OR
                                  <length>gvenfach.docori</length> = 0
                             THEN '${mCharNull}'
                             ELSE gvenfach.docori
                         END docori,
                        gvenfach.docser docfac,
                        ${mDatNull} fecini,
                        ${mDatNull} fecfin,
                        CASE WHEN gvenfacd.abono = 'S'
                             THEN -1
                             ELSE 1
                         END abono,
                        gvenfacd.dtoesp,
                        gvenfach.cambio,
                        gvenfach.dtoge1,
                        gvenfach.dtopp
                    </columns>
                    <from table='gvenfach'>
                        <join type='left' table='gcliente'>
                            <on>gvenfach.tercer = gcliente.codigo</on>
                        </join>
                        <join type='left' table='gvenfacd'>
                            <on>gvenfach.tipdoc = gvenfacd.codigo</on>
                        </join>
                    </from>
                    <where>
                        gvenfach.cabid = ?
                    </where>
                </select>  
            `, mObjGdwhVterdocd.colval);

            /**
             *  Seteo y unseteo de variables no pertenecientes a la tabla pero que 
             *  se necesitan.                                                      
             */
            var mNumAbono = mObjGdwhVterdocd.abono;
            delete mObjGdwhVterdocd.abono;
            var mStrDtoesp = mObjGdwhVterdocd.dtoesp;
            delete mObjGdwhVterdocd.dtoesp;
            var mNumCambio = mObjGdwhVterdocd.cambio;
            delete mObjGdwhVterdocd.cambio;
            var mNumDtoge1 = mObjGdwhVterdocd.dtoge1;
            delete mObjGdwhVterdocd.dtoge1;
            var mNumDtopp = mObjGdwhVterdocd.dtopp;
            delete mObjGdwhVterdocd.dtopp;

            /**
             *  Obtención del almacén prioritario.  
             */
            mObjGdwhVterdocd.codalm = Ax.db.executeFunction('galmdele_get_almacen',
                'gvenfach',
                mObjGdwhVterdocd.cabid,
                mObjGdwhVterdocd.delega,
                mObjGdwhVterdocd.depart,
                mObjGdwhVterdocd.tercer,
                null,
                null,
                mObjGdwhVterdocd.tipdoc
            ).toValue();

            /**
             *  Cuando la fecha de la factura que vamos a cargar es inferior a la 
             *  fecha de la ultima valoracion de almacen, modificamos la variable 
             *  "mDatFecval" con la fecha final del mes al que pertenece la factura,
             *  para que la carga de los costes lo haga con la valoracion de ese  
             *  mes.                                                              
             */
            var mDatFecval = Ax.db.executeGet(`
                <select cache='true'>
                    <columns>fecval</columns>
                    <from table='galmacen' />
                    <where>
                        codigo = ?
                    </where>
                </select>
            `, mObjGdwhVterdocd.codalm);

            if (mObjGdwhVterdocd.fecha < mDatFecval || mDatFecval == null) {
                mDatFecval = Ax.db.executeGet(`
                    <select cache='true'>
                        <columns>
                            cperiodo.fecfin fecval
                        </columns>
                        <from table='cperiodo' />
                        <where>
                            cperiodo.empcode = '${mObjGdwhVterdocd.empcode}' AND
                            cperiodo.ejerci  = YEAR(${mObjGdwhVterdocd.fecha}) AND
                            cperiodo.codigo  = MONTH(${mObjGdwhVterdocd.fecha})
                        </where>
                    </select>
                `);
            }

            /**
             *  Asigna valores a variables no informadas.      
             */
            for (var index = 0; index <= 4; index++) {
                mObjGdwhVterdocd[`auxal${index}`] = mCharNull;                
            }

            for (var index = 0; index <= 9; index++) {
                mObjGdwhVterdocd[`auxnu${index}`] = mNumNull;                
            }

            /**
             *  Include de customización. 
             */
            // #include "gdwh_gen_vterdocd_before_insert"

            /**
             *  Insertar lineas del documento.  
             */
            var mArrGvenfacl = Ax.db.executeQuery(`
                <select>
                    <columns>
                        CASE WHEN gvenmovh.almori IS NOT NULL
                             THEN gvenmovh.almori
                             ELSE '${mObjGdwhVterdocd.codalm}'
                         END codalm,
                        'FV' tabori,
                        <nvl>gvenmovh.terenv,'${mCharNull}'</nvl> terenv,
                        <nvl>cterdire.codnac,'${mCharNull}'</nvl> codnac,
                        <nvl>cterdire.codpos,'${mCharNull}'</nvl> codpos,
                        <nvl>cterdire.codzon,'${mCharNull}'</nvl> codzon,
                        CASE WHEN gvenmovh.docser IS NOT NULL
                             THEN gvenmovh.docser
                             ELSE '${mObjGdwhVterdocd.docori}'
                         END docori,
                        CASE WHEN gvenmovh.refter IS NULL OR
                                  <length>gvenmovh.refter</length> = 0
                             THEN '${mCharNull}'
                             ELSE gvenmovh.refter
                         END,
                        <nvl>gvenmovh.fecmov,${mDatNull}</nvl> fecmov,
                        <nvl>gvenmovh.fecent,${mDatNull}</nvl>    fecent,
                        <nvl>gartfami.secana,'${mCharNull}'</nvl> secana,
                        <nvl>garticul.codfam,'${mCharNull}'</nvl> codfam,
                        gvenfacl.codart,
                        gvenfacl.varlog,
                        gvenfacl.udmven,
                        gvenfacl.canfac * ${mNumAbono} canmov,
                        icon_get_imploc(0,
                                        '${mObjGdwhVterdocd.empcode}',
                                        '${mObjGdwhVterdocd.divisa}',
                                        ${mObjGdwhVterdocd.fecha},
                                        ${mNumCambio},
                                        <nvl>gvenfacl.pretar * gvenfacl.canfac,
                                             gvenfacl.precio * gvenfacl.canfac</nvl>) impbru,
                        icon_get_imploc(0,
                                        ${mObjGdwhVterdocd.empcode},
                                        '${mObjGdwhVterdocd.divisa}',
                                        ${mObjGdwhVterdocd.fecha},
                                        ${mNumCambio},
                                        (gvenfacl.impnet * (1 + (${mNumDtoge1} / 100)))) impnet,
                        CASE WHEN '${mStrDtoesp}' = 'S'
                             THEN <nvl>(SELECT SUM(gvenfacl_dtll.import)
                                          FROM gvenfacl_dtll
                                         WHERE gvenfacl_dtll.aplfac != 0
                                           AND gvenfacl_dtll.linid  = gvenfacl.linid),0</nvl>
                             ELSE icon_get_imploc(0,
                                                  '${mObjGdwhVterdocd.empcode}',
                                                  '${mObjGdwhVterdocd.divisa}',
                                                  ${mObjGdwhVterdocd.fecha},
                                                  ${mNumCambio},
                                                  ((gvenfacl.canfac * gvenfacl.precio
                                                    * (gvenfacl.dtolin / 100)) +
                                                   (gvenfacl.impnet * (gvenfacl.dtolin / 100)
                                                    * (${mNumDtoge1} / 100))))
                         END impdto,
                        CASE WHEN (garticul.stock = 'N' AND garticul.vencom = 'N')
                             THEN ${mNumNull}
                             ELSE galmvalo_get_coste('${mObjGdwhVterdocd.codalm}',
                                                     gvenfacl.codart,
                                                     gvenfacl.varlog,
                                                     ${mDatFecval},
                                                     gvenfacl.canfac,
                                                     garticul.vencom,
                                                     ${mNumAbono})
                         END impcos,
                        icon_get_imploc(0,
                                        '${mObjGdwhVterdocd.empcode}',
                                        '${mObjGdwhVterdocd.divisa}',
                                        ${mObjGdwhVterdocd.fecha},
                                        ${mNumCambio},
                                        (gvenfacl.impnet * (1 + (${mNumDtoge1} / 100)))
                                                         * (1 + (${mNumDtopp} / 100))) imprap
                    </columns>
                    <from table='gvenfacl'>
                        <join type='left' table='gvenmovl'>
                            <on>gvenfacl.linori = gvenmovl.linid</on>
                            <join type='left' table='gvenmovh'>
                                <on>gvenmovl.cabid = gvenmovh.cabid</on>
                                <join type='left' table='cterdire'>
                                    <on>gvenmovh.terenv = cterdire.codigo</on>
                                    <on>gvenmovh.direnv = cterdire.tipdir</on>
                                </join>
                            </join>
                        </join>
                        <join type='left' table='garticul'>
                            <on>gvenfacl.codart = garticul.codigo</on>
                            <join type='left' table='gartfami'>
                                <on>garticul.codfam = gartfami.codigo</on>
                            </join>
                        </join>
                    </from>
                    <where>
                        gvenfacl.cabid = ${mObjGdwhVterdocd.cabid}
                    </where>
                </select>
            `).toMemory();

            for (var mRow of mArrGvenfacl) {
                Ax.db.insert('gdwh_vterdocd', 
                    {
                        'fecha' : mObjGdwhVterdocd.fecha,   'empcode': mObjGdwhVterdocd.empcode,    'codalm': mRow.codalm,              'delega': mObjGdwhVterdocd.delega,
                        'depart': mObjGdwhVterdocd.depart,  'tabori' : mRow.tabori,                 'tipdoc': mObjGdwhVterdocd.tipdoc,  'cladoc': mObjGdwhVterdocd.cladoc,
                        'tercer': mObjGdwhVterdocd.tercer,  'tipdir' : mObjGdwhVterdocd.tipdir,     'terfac': mObjGdwhVterdocd.terfac,  'tergrp': mObjGdwhVterdocd.tergrp,
                        'terfed': mObjGdwhVterdocd.terfed,  'tercom' : mObjGdwhVterdocd.tercom,     'terenv': mRow.terenv,              'codnac': mRow.codnac,
                        'codpro': mRow.codpos,              'codzon' : mRow.codzon,                 'agente': mObjGdwhVterdocd.agente,  'tipefe': mObjGdwhVterdocd.tipefe,
                        'frmpag': mObjGdwhVterdocd.frmpag,  'divisa' : mObjGdwhVterdocd.divisa,     'cabid':  mObjGdwhVterdocd.cabid,   'docser': mObjGdwhVterdocd.docser,
                        'docori': mRow.docori,              'docfac' : mObjGdwhVterdocd.docfac,     'refter': mRow.refter,              'fecori': mRow.fecmov,
                        'fecini': mObjGdwhVterdocd.fecini,  'fecfin' : mObjGdwhVterdocd.fecfin,     'fecent': mRow.fecent,              'seccio': mRow.secana,
                        'codfam': mRow.codfam,              'codart' : mRow.codart,                 'varstk': mRow.varlog,              'coduni': mRow.udmven,
                        'auxal0': mObjGdwhVterdocd.auxal0,  'auxal1' : mObjGdwhVterdocd.auxal1,     'auxal2': mObjGdwhVterdocd.auxal2,  'auxal3': mObjGdwhVterdocd.auxal3,
                        'auxal4': mObjGdwhVterdocd.auxal4,  'canped' : mNumNull,                    'canmov': mRow.canmov,              'impbru': mRow.impbru,
                        'impnet': mRow.impnet,              'impdto' : mRow.impdto,                 'impcos': mRow.impcos,              'imprap': mRow.imprap,
                        'auxnu0': mObjGdwhVterdocd.auxnu0,  'auxnu1' : mObjGdwhVterdocd.auxnu1,     'auxnu2': mObjGdwhVterdocd.auxnu2,  'auxnu3': mObjGdwhVterdocd.auxnu3,
                        'auxnu4': mObjGdwhVterdocd.auxnu4,  'auxnu5' : mObjGdwhVterdocd.auxnu5,     'auxnu6': mObjGdwhVterdocd.auxnu6,  'auxnu7': mObjGdwhVterdocd.auxnu7,
                        'auxnu8': mObjGdwhVterdocd.auxnu8,  'auxnu9' : mObjGdwhVterdocd.auxnu9,     'semmes': mObjGdwhVterdocd.semmes,  'agrega': mObjGdwhVterdocd.agrega,
                        'valida': mObjGdwhVterdocd.valida
                    }
                )
            }

            /**
             *  Control de errores                                                    
             *  Seteamos la variable m_proname con WVDTOAF para en caso de error de la
             *  función local_gdwh_vdtoartd, se guarde en gdwh_interr dicho           
             *  identificador.  
             */
            mStrProname = 'WVDTOAF';         // Descuentos Ventas Articulos Facturas

            /**
             *  Enlaza con la carga de descuentos de facturas, siempre y cuando el
             *  tipo de documento tenga tratamiento de descuentos especiales      
             *  (m_dtoesp = 'S').                                                  
             */
            if (mStrDtoesp == 'S') {
                __local_gdwh_vdtoartd(mObjGdwhVterdocd.cabid, mObjGdwhVterdocd.empcode, mObjGdwhVterdocd.delega, mObjGdwhVterdocd.docser)
            }

            /**
             *  Control de errores                                                     
             *  Volvemos a setear la variable m_proname con WVTERDF para en caso de no 
             *  haber habido error de la función local_gdwh_vdtoartd, se guarde en     
             *  gdwh_interr el identificador de este proceso gdwh_gen_vterdocd.         
             */
            mStrProname = 'WVTERDF';         // Descuentos Ventas Articulos Facturas

            //  Eliminamos el registro del tracking.   
            Ax.db.delete('gdoc_traspaso', 
                {
                    tabname: 'gvenfach',
                    colname: 'cabid',   
                    colval:  mObjGdwhVterdocd.cabid, 
                    tippro:  0
                }
            )

            //  Marcamos la factura como traspasada.
            Ax.db.update('gvenfach', {movest: 1}, {cabid: mObjGdwhVterdocd.cabid});

            // Se cierra la transaccion. 
            Ax.db.commitWork();


        } catch (error) {
            /**
             *  Se retrocede la transaccion.     
             */
            Ax.db.rollbackWork();

            Ax.db.insert('gdwh_interr', 
                {
                   proname:mStrProname,
                   delalm: mObjGdwhVterdocd.delega,
                   codigo: mObjGdwhVterdocd.docser,
                   fecinf: mObjGdwhVterdocd.fecha,
                   fecerr: new Ax.sql.Date(),
                   nsql:   0,
                   nisam:  0,
                   errmsg: Ax.util.Error.getMessage(error)                   
                }
            )
            
        }

        Ax.db.commitWork();

    }

    /**
     *  Agregar el resto de piramides, o sea a partir de 'gdwh_vterdocd' 
     *  cargar 'gdwh_vterartd' y a su vez cargar 'gdwh_vterfamd' a traves
     *  de la función 'local_gdwh_vterartd_famd' que es llamada por la   
     *  función 'local_gdwh_vterdocd_artd' al ser el tercer parámetro una
     *  'S'.                                                             
     *                                                                  
     *  También se agregan los descuentos.                                
     */
    if (pStrValida == 'N') {
        /**
         *  Ventas Terceros-Artículos-Día a partir de Terceros-Documentos-Día. 
         */
        Ax.db.call('gdwh_vterdocd_artd', pStrEmpcode, pStrDelega, pDatFecini, pDatFecfin, 'S', 'N');

        /**
         *  Descuentos Familias-Día a partir de Artículos-Día.  
         */
        Ax.db.call('gdwh_vdtoartd_famd', pStrEmpcode, pStrDelega, pDatFecini, pDatFecfin, 'S', 'N');
    }

}
