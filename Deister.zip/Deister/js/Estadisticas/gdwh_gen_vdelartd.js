/**
 *  Js: gdwh_gen_vdelartd                                                  
 *                                                                       
 *  Este script se basa en un ejemplo que realiza la carga de información de 
 *  ventas por cajeras (Retail), procedente de la tabla gdwh_tpv_interface,  
 *  en el registro de Ventas Delegaciones Artículos-día (gdwh_vdelartd) del  
 *  Datawarehouse, y a su vez cargar el resto de piramides de ventas.        
 *                                                                           
 *  ATENCIÓN!!!                                                              
 *                                                                           
 *  Se parte de que la tabla gdwh_tpv_interface contiene la información      
 *  de los ficheros de ventas por tickets (cajeras). Generalmente en esta    
 *  tabla se cargarán las ventas de UN DIA y tienda. De esta forma si se     
 *  produce cualquier error en la carga o en la insercion hacia las tablas   
 *  del Datawarehouse, no se cargará NINGUN registro de esta tabla.          
 *                                                                           
 *  La tabla gdwh_tpv_interface será una tabla fija que contendrá los        
 *  datos generados por el proceso de carga de la información procedente     
 *  de los ficheros de ventas por cajeras (tickets). Una vez alimentada,     
 *  este script la procesará y traspasará su información al                  
 *  Datawarehouse.                                                           
 *                                                                           
 *  El borrado de los registros de la tabla gdwh_tpv_interface se deja a     
 *  voluntad del cliente, para que decida el momento y la manera que         
 *  considere adecuados.                                                     
 */
function gdwh_gen_vdelartd(pStrEmpcode, pStrDelega, pDatFecini, pDatFecfin) {
    /**
     *  Verificación de existencia de registros en la tabla gdwh_tpv_interface.
     *  Si no hay, salimos.                                                    
     */
    var mNumCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='gdwh_tpv_interface' />
            <where>
                delega ${pStrDelega} AND
                fecha BETWEEN ${pDatFecini} AND ${pDatFecfin}
            </where>
        </select>
    `);

    if (!mNumCount) {
        return;
    }

    var mObjGdwhVdelartd = {};

    //  Asigna valores por defecto.
    mObjGdwhVdelartd.tabori = 'RT';
    mObjGdwhVdelartd.depart = '0';
    mObjGdwhVdelartd.auxal0 = '-';
    mObjGdwhVdelartd.auxal1 = '-';
    mObjGdwhVdelartd.auxal2 = '-';
    mObjGdwhVdelartd.auxal3 = '-';
    mObjGdwhVdelartd.auxal4 = '-';
    mObjGdwhVdelartd.impdto = 0;
    mObjGdwhVdelartd.imprap = 0;
    mObjGdwhVdelartd.auxnu0 = 0;
    mObjGdwhVdelartd.auxnu1 = 0;
    mObjGdwhVdelartd.auxnu2 = 0;
    mObjGdwhVdelartd.auxnu3 = 0;
    mObjGdwhVdelartd.auxnu4 = 0;
    mObjGdwhVdelartd.auxnu5 = 0;
    mObjGdwhVdelartd.auxnu6 = 0;
    mObjGdwhVdelartd.auxnu7 = 0;
    mObjGdwhVdelartd.auxnu8 = 0;
    mObjGdwhVdelartd.auxnu9 = 0;
    mObjGdwhVdelartd.semmes = 'A';
    mObjGdwhVdelartd.agrega = 'S';
    mObjGdwhVdelartd.valida = 'N';

    //  Permite modificar los valores por defecto.   
    // #include "gdwh_gen_vdelartd_begin"

    /**
     *  Cursor que agrupar los registros del fichero del TPV por delegacion,  
     *  fecha de venta y articulo, genera un regsitro en gdwh_vdelartd.       
     */
    var mArrGdwhVdelartd = Ax.db.executeQuery(`
        <select prefix='gdwh_vdelartd_'>
            <columns>
                gdwh_tpv_interface.delega,        gdwh_tpv_interface.fecha,
                gdwh_tpv_interface.codart,        gdwh_tpv_interface.varlog varstk,
                gdwh_tpv_interface.udmven coduni, gdelegac.tercer,
                gdelegac.dirdlg,                  gdelegac.delcat,
                gdelegac.empcode,                 garticul.codfam,
                gartfami.secana seccio,           gartvarl.unicon,

                icon_get_divred(icon_get_moneda(gdelegac.empcode)) tipred,

                garticul_get_imppor('gtpv_ticketh',            0,                         0,
                                    'C',                       NULL,                      gdwh_tpv_interface.fecha,
                                    gdwh_tpv_interface.delega, gdelegac.tercer,           gdelegac.dirdlg,
                                    gdelegac.tercer,           gdelegac.dirdlg,           NULL,
                                    gdwh_tpv_interface.codart, gdwh_tpv_interface.varlog, NULL) imppor,

                SUM(gdwh_tpv_interface.impven) impven,
                SUM(gdwh_tpv_interface.canven) canmov
            </columns>
            <from table='gdwh_tpv_interface'>
                <join type='left' table='gdelegac'>
                    <on>gdwh_tpv_interface.delega = gdelegac.codigo</on>
                </join>
                <join type='left' table='garticul'>
                    <on>gdwh_tpv_interface.codart = garticul.codigo</on>
                    <join type='left' table='gartfami'>
                        <on>garticul.codfam = gartfami.codigo</on>
                    </join>
                </join>
                <join type='left' table='gartvarl'>
                    <on>gdwh_tpv_interface.codart = gartvarl.codart</on>
                    <on>gdwh_tpv_interface.varlog = gartvarl.varlog</on>
                </join>
            </from>
            <where>
                gdwh_tpv_interface.delega ${pStrDelega} AND
                gdwh_tpv_interface.fecha BETWEEN ${pDatFecini} AND ${pDatFecfin}
            </where>
            <group>1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13</group>
            </select>        
    `).toMemory();

    const LOCALE = Ax.ext.user.getLang()

    for (mObjGdwhVdelartd of mArrGdwhVdelartd) {
        mStrTercer = mObjGdwhVdelartd.tercer;
        mStrDirdlg = mObjGdwhVdelartd.dirdlg;
        mStrDelcat = mObjGdwhVdelartd.delcat;
        mDecTipred = mObjGdwhVdelartd.tipred;
        mIntUnicon = mObjGdwhVdelartd.unicon;
        mDecImpven = mObjGdwhVdelartd.impven;
        mDecImppor = mObjGdwhVdelartd.imppor;
        delete mObjGdwhVdelartd.tercer;
        delete mObjGdwhVdelartd.dirdlg;
        delete mObjGdwhVdelartd.delcat;
        delete mObjGdwhVdelartd.tipred;
        delete mObjGdwhVdelartd.unicon;
        delete mObjGdwhVdelartd.impven;
        delete mObjGdwhVdelartd.imppor;

        //  Comprobar existencia de delegacion. 
        if (mStrTercer == null) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`Delegación [${mObjGdwhVdelartd.delega}] no definida en mestro de delegaciones'.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`Delegació [${mObjGdwhVdelartd.delega}] no definida en el mestre de delegacions'.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`Local office [${mObjGdwhVdelartd.delega}] not defined in master of local offices'.`);
            }
        }

        if (mObjGdwhVdelartd.codfam == null) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`Artículo [${mObjGdwhVdelartd.codart}] no definido en maestro de artículos.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`Article [${mObjGdwhVdelartd.codart}] no definit al mestre d'articles.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`Article [${mObjGdwhVdelartd.codart}] not defined in master of articles.`);
            }
        }

        if (mObjGdwhVdelartd.seccio == null) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`Familia [${mObjGdwhVdelartd.codfam}] sin sección analítica informada.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`Familia [${mObjGdwhVdelartd.codfam}] sense secció analítica informada.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`Family [${mObjGdwhVdelartd.codfam}], not analytical section declared.`);
            }
        }

        //  Verificar que no se encuentren ya cargadas las ventas. 
        var mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gdwh_vdelartd' />
                <where>
                    delega = ${mObjGdwhVdelartd.delega} AND
                    fecha  = ${mObjGdwhVdelartd.fecha} AND
                    codart = ${mObjGdwhVdelartd.codart} AND
                    varstk = ${mObjGdwhVdelartd.varstk} AND
                    coduni = ${mObjGdwhVdelartd.coduni}
                </where>
            </select>
        `);
        if (mIntCount) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`DEL: [${mObjGdwhVdelartd.delega}] - FECHA: [${mObjGdwhVdelartd.fecha}] - ARTICULO: [${mObjGdwhVdelartd.codart}] Existen ventas cargadas en datawarehouse.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`DEL: [${mObjGdwhVdelartd.delega}] - DATA: [${mObjGdwhVdelartd.fecha}] - ARTICLE: [${mObjGdwhVdelartd.codart}] Existeixen vendes carregades al datawarehouse.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`DEL: [${mObjGdwhVdelartd.delega}] - DATE: [${mObjGdwhVdelartd.fecha}] - ARTICLE: [${mObjGdwhVdelartd.codart}] Existing loaded sales at datawarehouse.`);
            }            
        }

        //   No se encontro registro en ctipoimp.
        if (mDecImppor == null) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`Delegación [${mObjGdwhVdelartd.delega}] - Artículo [${mObjGdwhVdelartd.codart}]: sin iva vigente.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`Delegació [${mObjGdwhVdelartd.delega}] - Article [${mObjGdwhVdelartd.codart}]: sense iva vigent.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`Local office [${mObjGdwhVdelartd.delega}] - Article [${mObjGdwhVdelartd.codart}]: not current VAT.`);
            } 
        }

        /**
         *  1) Buscar el coste para la tienda. 
         */
        var mObjGretPvparti = Ax.db.executeQuery(`
            <select cache='true'>
                <columns>
                    tipdoc, cladoc, precos
                </columns>
                <from table='gret_pvparti' />
                <where>
                    delega = '${mObjGdwhVdelartd.delega}' AND
                    codart = '${mObjGdwhVdelartd.codart}' AND
                    <nvl>varlog, '${mObjGdwhVdelartd.varstk}'</nvl> = '${mObjGdwhVdelartd.varstk}' AND
                    <nvl>udmven, '${mObjGdwhVdelartd.coduni}'</nvl> = '${mObjGdwhVdelartd.coduni}' AND
                    fecini &lt;= ${mObjGdwhVdelartd.fecha} AND
                    fecfin &gt;= ${mObjGdwhVdelartd.fecha} AND
                    tarpre = 'N'                        <!-- Normal -->
                </where>
                <group>
                    tipdoc, cladoc, precos
                </group>
            </select>            
        `).toOne();

        /**
         *  2) La tienda tiene asociada una delegacion/tienda catalogo.  
         *     Buscar coste en la delegacion catalogo.                   
         */
        if (mObjGretPvparti.precos == null && mStrDelcat != null) {
            mObjGretPvparti = Ax.db.executeQuery(`
                <select cache='true'>
                    <columns>
                        tipdoc, cladoc, precos
                    </columns>
                    <from table='gret_pvparti' />
                    <where>
                        delega = ${mStrDelcat} AND
                        codart = '${mObjGdwhVdelartd.codart}' AND
                        <nvl>varlog, '${mObjGdwhVdelartd.varstk}'</nvl> = '${mObjGdwhVdelartd.varstk}' AND
                        <nvl>udmven, '${mObjGdwhVdelartd.coduni}'</nvl> = '${mObjGdwhVdelartd.coduni}' AND
                        fecini &lt;= ${mObjGdwhVdelartd.fecha} AND
                        fecfin &gt;= ${mObjGdwhVdelartd.fecha} AND
                        tarpre = 'N'                        <!-- Normal -->
                    </where>
                    <group>
                        tipdoc, cladoc, precos
                    </group>
                </select>           
            `).toOne();
        }

        /**
         *  3) Buscar el coste en alguna de las otras tiendas. 
         */
        if (mObjGretPvparti.precos == null) {
            mObjGretPvparti = Ax.db.executeQuery(`
                <select>
                    <columns>
                        tipdoc, cladoc, precos
                    </columns>
                    <from table='gret_pvparti' />
                    <where>
                        <rowid table='gret_pvparti' /> = (SELECT MAX(<rowid table='gret_pvparti' />)
                                                            FROM gret_pvparti
                                                           WHERE codart = '${mObjGdwhVdelartd.codart}' AND
                                                                 fecini &lt;= ${mObjGdwhVdelartd.fecha} AND
                                                                 fecfin &gt;= ${mObjGdwhVdelartd.fecha} AND
                                                                 tarpre = 'N')   <!-- Normal -->
                    </where>
                </select>                
            `).toOne();
        }

        //  Obtiene almacén prioritario de la delegación. 
        mObjGdwhVdelartd.codalm = Ax.db.executeFunction('galmdele_get_almacen', 
            'gvenfach',
            null,
            mObjGdwhVdelartd.delega,
            null,
            null,
            null,
            null,
            mObjGretPvparti.tipdoc
        );

        /**
         *  Añade el prefijo 'gdwh_vdelartd_' a las variables para el  
         *  insert en la tabla gdwh_vdelartd                           
         */
        mObjGdwhVdelartd.tipdoc = mObjGretPvparti.tipdoc;
        mObjGdwhVdelartd.cladoc = mObjGretPvparti.cladoc;

        //  Permite modificar los campos a añadir a gdwh_vdelartd.
        // #include "gdwh_gen_vdelartd_before_dwh_insert"

        if (mObjGdwhVdelartd.codalm == null) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`Delegación [${mObjGdwhVdelartd.delega}]: No se pudo determinar almacén prioritario.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`Delegació [${mObjGdwhVdelartd.delega}]: No s'ha pogut determinar el magatzem prioritari.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`Local office [${mObjGdwhVdelartd.delega}]: Cannot find priority warehouse.`);
            } 
        }

        if (mObjGretPvparti.precos == null) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`Artículo [${mObjGdwhVdelartd.codart}] sin coste en definición de PVP.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`Article [${mObjGdwhVdelartd.codart}] sense cost a la definició de PVP.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`Article [${mObjGdwhVdelartd.codart}] without cost at PVP definition.`);
            } 
        }

        //  Cálculo importe venta SIN IVA.
        mObjGdwhVdelartd.impnet =  mDecImpven / (1 + (mDecImppor/100));
        mObjGdwhVdelartd.impnet = mObjGdwhVdelartd.impnet.toFixed(mDecTipred);

        mObjGdwhVdelartd.impbru = mObjGdwhVdelartd.impnet;

        //  Cácula el importe del coste. 
        mObjGdwhVdelartd.impcos = mObjGretPvparti.precos * mObjGdwhVdelartd.canmov;
        mObjGdwhVdelartd.impcos = mObjGdwhVdelartd.impcos.toFixed(mDecTipred);

        //  Inserción en gdwh_vdelartd. 
        Ax.db.insert('gdwh_vdelartd', mObjGdwhVdelartd)

    }

    /**
     *  RETAIL                                                                
     *                                                                
     *  Cursor para agrupar los registros del TPV por fecha de venta y cajera 
     *  y generar un registro en gret_caja y gret_tipcobr. Esta ultima es una 
     *  relacion de venta por tipo de cobro, (es una hija de gret_caja).       
     */
    var mArrGdwhTpvInter = Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT delega, fecha, codcaj, codemp
            </columns>
            <from table='gdwh_tpv_interface' />
            <where>
                delega ${pStrDelega} AND
                fecha BETWEEN ${pDatFecini} AND ${pDatFecfin}
            </where>
            <order>
                delega, fecha, codcaj
            </order>
        </select>
    `).toMemory();

    for (var mRow of mArrGdwhTpvInter) {
        /**
         *  Ver si existe la tienda en "gret_delegac".    
         */
        var mIntCount1 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gret_delegac' />
                <where>
                    codigo = '${mRow.delega}'
                </where>
            </select>
        `);

        if (!mIntCount1) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`Delegación [${mRow.delega}]: no definida como delegación de retail.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`Delegació [${mRow.delega}]: no definida como delegació de retail.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`Local office [${mRow.delega}]: not defined as retail local office.`);
            } 
        }

        mIntCount1 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gret_caja' />
                <where>
                    fecven = ${mRow.fecha}  AND
                    delega = ? AND
                    numtpv = ? AND
                    zcaja  = 0
                </where>
            </select>
        `, mRow.delega, mRow.codcaj);

        if (mIntCount1) {
            if (LOCALE == 'es') {
                throw new Ax.lang.Exception(`DEL: [${mRow.delega}] - FECHA: [${mRow.fecha}] - CAJA: [${mRow.codcaj}] ya traspasada.`);
            } else if (LOCALE == 'ca') {
                throw new Ax.lang.Exception(`DEL: [${mRow.delega}] - DATA: [${mRow.fecha}] - CAIXA: [${mRow.codcaj}] ja traspassada.`);
            } else if (LOCALE == 'en') {
                throw new Ax.lang.Exception(`DEL: [${mRow.delega}] - DATE: [${mRow.fecha}] - CASH: [${mRow.codcaj}] yet transfered.`);
            } 
        }

        //  Insertar en la cajera.
        var mIntLiqid = Ax.db.insert('gret_caja', 
            {
                delega: mRow.delega,
                codemp: mRow.codemp,
                turno:  0,
                fecven: mRow.fecha,
                numtpv: mRow.codcaj,
                zcaja:  0,
                jusser: 0,
                artsca: 0,
                artman: 0,
                artdir: 0,
                artdev: 0,
                numtiq: 0,
                venoff: 0,
                venon:  0,
                apertu: 0,
                revtpv: 0,
                comisi: 0,
                fecinc: mRow.fecha,
                fecini: mRow.fecha,
                fecfin: mRow.fecha,
                estado: 'A',
                errnum: 0,
                user_created: Ax.db.getUser(),
                date_created: new Ax.sql.Date(),
                user_updated: Ax.db.getUser(),
                date_updated: new Ax.sql.Date()
            }
        ).getSerial();

        /**
         *  Insertar en gret_tipcobr: tipos de cobro por delegacion, cajera
         *  y fecha de venta.                                              
         *                                                              
         *  EJEMPLO con dos tipos de cobro:                                
         *                                                              
         *  CRE (Venta crédito - Cliente: 999999999999)                    
         *  CON (Venta contado)                                             
         */
        var mArrGdwhTpvInterface = Ax.db.executeQuery(`
            <select>
                <columns>
                    tipcob, SUM(impven) impven, SUM(canven) canven
                </columns>
                <from table='gdwh_tpv_interface' />
                <where>
                    delega = ? AND
                    fecha  = ${mRow.fecha} AND
                    codcaj = ?
                </where>
                <group>1</group>
            </select>
        `, mRow.delega, mRow.codcaj).toMemory();

        for (var mRow1 of mArrGdwhTpvInterface) {
            var mIntCount2 = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='gret_tipcobr' />
                    <where>
                        codigo = ?
                    </where>
                </select>
            `, mRow1.tipcob);

            if (!mIntCount2) {
                if (LOCALE == 'es') {
                    throw new Ax.lang.Exception(`Tipo de cobro [${mRow1.tipcob}] no definido.`);
                } else if (LOCALE == 'ca') {
                    throw new Ax.lang.Exception(`Tipus de cobrament [${mRow1.tipcob}] no definit.`);
                } else if (LOCALE == 'en') {
                    throw new Ax.lang.Exception(`Undefined charge type [${mRow1.tipcob}].`);
                } 
            }

            Ax.db.insert('gret_cajcobr', 
                {
                    cobid: 0,
                    liqid:  mIntLiqid,
                    tipcob: mRow1.tipcob,
                    impdec: mRow1.impven,
                    impteo: mRow1.impven,
                    cantid: mRow1.canven
                }
            )
        }
    }

    /**
     *  Subir los niveles superiores del datawarehouse.
     */
    Ax.db.call('gdwh_vdelartd_famd', 
        pStrEmpcode,
        pStrDelega,
        p_fecini,
        p_fecfin,
        'S',
        'N'
    )

    /**
     *  Permite añadir acciones al final del proceso, como el borrado de  
     *  registros de gdwh_tpv_interface.                                  
     */
    // #include "gdwh_gen_vdelartd_end"

}