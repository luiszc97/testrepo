/**
 *  Js: gdwh_lmovsecs_comp                                           
 *                                                                     
 *  Obtiene los datos para el objeto y para el canal de comparativo de 
 *  logística semanal.                                                 
 *                                                                     
 *  El script es llamado indistintamente para ser ejecutado desde menu 
 *  de objetos o desde canales.                                        
 *                                                                     
 *  Llamada desde:                                                     
 *  ==============                                                     
 *     OBJETO   gdwh_lmovsecs_comp                                     
 *     CANAL    gdwh_lmovsecs_comp                                     
 */
function gdwh_lmovsecs_comp(pIntAnysemAct, pIntAnysemCom, pStrSqlcond, pStrSqlSeca) {
    /**
     *  FUNCT : __local_get_anysem                                       
     *                                                              
     *  Devuelve la semana que corresponde a n semanas anteriores a una
     *  semana.                                                         
     */
    function __local_get_anysem(pIntNumber, pIntAnysem) {
        var mIntAnySem = pIntAnysem;

        var mArrGdwhSemdia = Ax.db.executeQuery(`
            <select first='${pIntNumber}'>
               <columns>
                   gdwh_semdia.anysem
               </columns>
               <from table='gdwh_semdia' />
               <where>
                   gdwh_semdia.anysem &lt;= ${pIntAnysem}
               </where>
               <order>1 DESC</order>
            /select>
        `).toMemory();

        for (var mRow of mArrGdwhSemdia) {
            mIntAnySem = mRow.anysem;
        }   

        return mIntAnySem;    
    }

    /**
     *  FUNCT : __local_get_fecha                                  
     *                                                   
     *  Devuelve la fecha de inicio o fin de una semana concreta. 
     */
    function __local_get_fecha(pStrType, pIntAnysem) {
        var mDatFecha = null;

        var mObjGdwhSemdia = Ax.db.executeQuery(`
            <select>
                <columns>
                    gdwh_semdia.fecini, gdwh_semdia.fecfin
                </columns>
                <from table='gdwh_semdia' />
                <where>
                    gdwh_semdia.anysem = ${pIntAnysem}
                </where>
            </select>        
        `).toOne();

        if (pStrType == 'I') {
            mDatFecha = new Ax.sql.Date(mObjGdwhSemdia.fecini);
        } else {
            mDatFecha = new Ax.sql.Date(mObjGdwhSemdia.fecfin);
        }

        return mDatFecha;

    }

    var mStrSqlcond = pStrSqlcond || '1=1';
    var mStrSqlseca = `gseccana.codigo ${pStrSqlSeca || '=gseccana.codigo'}`;

    var mToday = new Ax.sql.Date();
    var mYear = mToday.getFullYear();
    var mYearAnt = mToday.getFullYear() - 1;

    //date.weekOfYear
    var mFirstDayOfYear = new Ax.util.Date(new Ax.util.Date().getFullYear(), 1, 1);
    var mWeekOfYear = mFirstDayOfYear.weeks(mToday);

    var firstDayOfYearAnt = new Ax.util.Date(new Ax.util.Date().getFullYear() - 1, 1, 1);
    var todayAnt = new Ax.util.Date(new Ax.util.Date().getFullYear() - 1, new Ax.util.Date().getMonth()+1, new Ax.util.Date().getDate());
    var weekOfYearAnt = firstDayOfYearAnt.weeks(todayAnt);

    var mIntAnysemAct = pIntAnysemAct || ((mYear * 100) + mWeekOfYear);
    var mIntAnysemCom = pIntAnysemCom || ((mYearAnt * 100) + weekOfYearAnt);

    /**
     *  Set de variables para poder utilizarlas en el select. 
     */
    var mStrVarName;
    for (var m_idx = 1; m_idx <= 5; m_idx++) {
        mStrVarName = `mIntAnysemAct${m_idx}`;
        eval(`var ${mStrVarName} = __local_get_anysem(m_idx, mIntAnysemAct)`);
        mStrVarName = `mIntAnysemCom${m_idx}`;
        eval(`var ${mStrVarName} = __local_get_anysem(m_idx, mIntAnysemCom)`);
    }

    /**
     *  Límites en fechas para poder filtrar en el campo fecha. 
     */
    var mIntAnysemiAct = __local_get_anysem(5,mIntAnysemAct);
    var mIntAnysemfAct = mIntAnysemAct;

    var mIntAnysemiCom = __local_get_anysem(5, mIntAnysemCom);
    var mIntAnysemfCom = mIntAnysemCom;

    var mDatFeciniAct = __local_get_fecha('I', mIntAnysemiAct);
    var mDatFecfinAct = __local_get_fecha('F', mIntAnysemfAct);

    var mDatFeciniCom = __local_get_fecha('I', mIntAnysemiCom);
    var mDatFecfinCom = __local_get_fecha('F', mIntAnysemfCom);

    /**
     *  Cuenta el número de clientes por día.  
     */
    var mBoolExistsTpv = false;

    return Ax.db.executeQuery(`
        <select>
            <columns>
                <nvl>ctipozon.nomzon, '-'</nvl> <alias name='nomzon'/>,                                                                    <!-- 1  -->
                galmacen.nomalm,                                                                                                           <!-- 2  -->
                gseccana.nomsec,                                                                                                           <!-- 3  -->

                <!-- ============================================================ -->
                <!-- Importe costes                                               -->
                <!-- ============================================================ -->
                <!-- Semana actual -->                                                                                                     
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct5} THEN gdwh_lmovsecs.impcos ELSE 0 END) cosact1, <!--  4 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct4} THEN gdwh_lmovsecs.impcos ELSE 0 END) cosact2, <!--  5 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct3} THEN gdwh_lmovsecs.impcos ELSE 0 END) cosact3, <!--  6 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct2} THEN gdwh_lmovsecs.impcos ELSE 0 END) cosact4, <!--  7 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct1} THEN gdwh_lmovsecs.impcos ELSE 0 END) cosact5, <!--  8 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom5} THEN gdwh_lmovsecs.impcos ELSE 0 END) coscom1, <!-- 9 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom4} THEN gdwh_lmovsecs.impcos ELSE 0 END) coscom2, <!-- 10 --> 
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom3} THEN gdwh_lmovsecs.impcos ELSE 0 END) coscom3, <!-- 11 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom2} THEN gdwh_lmovsecs.impcos ELSE 0 END) coscom4, <!-- 12 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom1} THEN gdwh_lmovsecs.impcos ELSE 0 END) coscom5, <!-- 13 -->

                <!-- ============================================================ -->
                <!-- Unidades                                                     -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct5}  THEN gdwh_lmovsecs.canmov ELSE 0 END) uniact1, <!-- 14 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct4}  THEN gdwh_lmovsecs.canmov ELSE 0 END) uniact2, <!-- 15 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct3}  THEN gdwh_lmovsecs.canmov ELSE 0 END) uniact3, <!-- 16 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct2}  THEN gdwh_lmovsecs.canmov ELSE 0 END) uniact4, <!-- 17 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct1}  THEN gdwh_lmovsecs.canmov ELSE 0 END) uniact5, <!-- 18 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom5}  THEN gdwh_lmovsecs.canmov ELSE 0 END) unicom1, <!-- 19 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom4}  THEN gdwh_lmovsecs.canmov ELSE 0 END) unicom2, <!-- 20 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom3}  THEN gdwh_lmovsecs.canmov ELSE 0 END) unicom3, <!-- 21 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom2}  THEN gdwh_lmovsecs.canmov ELSE 0 END) unicom4, <!-- 22 -->
                SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom1}  THEN gdwh_lmovsecs.canmov ELSE 0 END) unicom5, <!-- 23 -->

                <!-- ============================================================ -->
                <!-- Variación total                                              -->
                <!-- ============================================================ -->
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecs.anysem BETWEEN ${mIntAnysemiCom} AND ${mIntAnysemfCom} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecs.anysem BETWEEN ${mIntAnysemiAct} AND ${mIntAnysemfAct} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecs.anysem BETWEEN ${mIntAnysemiCom} AND ${mIntAnysemfCom} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) datvar,                                                                                                             <!-- 24 -->

                <!-- ============================================================ -->
                <!-- Evolución ventas                                             -->
                <!-- ============================================================ -->
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom5} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct5} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom5} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evocos1,                                                                                                            <!-- 25 -->                                                                                                             

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom4} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct4} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom4} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evocos2,                                                                                                            <!-- 26 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom3} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct3} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom3} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evocos3,                                                                                                            <!-- 27 -->       

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom4} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct4} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom4} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evocos4,                                                                                                            <!-- 28 -->                                                                                               

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom5} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemAct5} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecs.anysem = ${mIntAnysemCom5} THEN <nvl>gdwh_lmovsecs.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evocos5,                                                                                                            <!-- 29 -->

                <!-- ============================================================ -->
                <!-- Campos para el link a gdwh_lmovsecd_comp                     -->
                <!-- ============================================================ -->
                cterdire.codzon,                                                                                                                             <!-- 30 -->
                galmacen.codigo codalm,                                                                                                      <!-- 31 -->
                gseccana.codigo secana,                                                                                                     <!-- 32 -->

                <!-- Semana actual -->
                gdwh_get_dia('F', ${mIntAnysemAct5}) diaact1,
                gdwh_get_dia('F', ${mIntAnysemAct4}) diaact2,
                gdwh_get_dia('F', ${mIntAnysemAct3}) diaact3,
                gdwh_get_dia('F', ${mIntAnysemAct2}) diaact4,
                gdwh_get_dia('F', ${mIntAnysemAct1}) diaact5,

                <!-- Semana comparativa -->
                gdwh_get_dia('F', ${mIntAnysemCom5}) diacom1,
                gdwh_get_dia('F', ${mIntAnysemCom4}) diacom2,
                gdwh_get_dia('F', ${mIntAnysemCom3}) diacom3,
                gdwh_get_dia('F', ${mIntAnysemCom2}) diacom4,
                gdwh_get_dia('F', ${mIntAnysemCom1}) diacom5
            </columns>
            <from table='gdwh_lmovsecs'>
                <join table='galmacen'>
                    <on>galmacen.codigo = gdwh_lmovsecs.codalm</on>
                    <join table='cterdire'>
                        <on>galmacen.tercer = cterdire.codigo</on>
                        <on>galmacen.tipdir = cterdire.tipdir</on>
                        <join type='left' table='ctipozon'>
                            <on>cterdire.codzon = ctipozon.codigo</on>
                        </join>
                    </join>
                </join>
                <join type='left' table='gseccana'>
                    <on>gseccana.codigo = gdwh_lmovsecs.seccio</on>
                </join>
            </from>
            <where>
                    ${mStrSqlcond}
                AND gdwh_lmovsecs.seccio IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlseca})
                AND (gdwh_lmovsecs.anysem BETWEEN ${mIntAnysemiAct} AND ${mIntAnysemfAct} OR
                     gdwh_lmovsecs.anysem BETWEEN ${mIntAnysemiCom} AND ${mIntAnysemfCom})                   
            </where>
            <group>1, 2, 3, 30, 31, 32</group>
            <order>1, 2, 3</order>
        </select> 
    `);

}