/**
 *  Js: gdwh_lmovfams_comp_niveln                                             
 *                                                                              
 *                                                                              
 *  Deja el resultado del select sobre gdwh_lmovfams en la tabla temporal       
 *  @tmp_resultado. Los distintos valores de los argumentos p_nivel? determinan 
 *  el número de niveles que se mostrarán en la temporal.                        
 */
function gdwh_lmovfams_comp_niveln(
    pIntNivfam, pStrcodpre, pIntNumrev,
    pIntEjerci, pIntSemana, pStrnivel1,
    pStrnivel2, pStrnivel3, pStrnivel4,
    pStrnivel5, pStrtipval, pStrconsum,
    pStrsqlcond
) {
    /**
     *  Mapa para obtener las descripciones según el nivel.    
     */
    var mMapGdwhGetDescrip = Ax.util.Map.of(
        'GRPDEL','gdelgrph',
        'GRPALM','galmgrph',
        'CODALM','galmacen',
        'DELEGA','gdelegac',
        'DEPART','gdeparta',
        'CUENTA','galmctas',
        'CLADOC','DEPENDE CLASE DOCUMENTO',
        'TIPDOC','DEPENDE TIPO DOCUMENTO',
        'SECCIO','gseccana',
        `CODFAM[1,${pIntNivfam}]`, 'gartfami'
    );

    /**
     *  Seleccionar solo los distintos niveles informados.              
     *                                                          
     *  n1='GRPDEL',n2='GRPDEL',n3='CODALM' :: n1='GRPDEL',n2='CODALM'  
     *                                                                  
     *  n1='GRPDEL',n2='GRPDEL',n3='CODALM',n4='CODALM',n5='CUENTA' ::  
     *  n1='GRPDEL',n2='CODALM',n3='CUENTA'                              
     */
    var mRsNivel = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['order','nivel']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR]);
	});

    var mRsNivelU = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['order','nivel']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR]);
	});

    for (var index = 1; index <= 5; index++) {
        eval(`var aux = pStrNivel${index};`);
        mRsNivel.rows().add([index, aux]);        
    }

    /**
     *  Selección de los valores únicos de nivel.  
     */
    mRsNivel.rows().sort(["nivel"]);

    mRsNivel.cursor()
    .group("nivel")
    .before(row => {
        mRsNivelU.rows().add([row.order, row.nivel]);
    }).forEach(row => {
        
    });

    /**
     *  Determinar las columnas en función de los niveles. 
     */
    mRsNivelU.rows().sort(["order"]);
    var mStrColumns = ' ';
    var mStrColgrp = '';
    var mIntIdx = 0;
    var mStrDescrip;
    var mStrNivel;

    mRsNivelU.forEach(mRow => {
        mStrNivel = mRow.nivel;
        mIntIdx = mIntIdx + 1;

        if(mMapGdwhGetDescrip.get(mStrNivel) == null) mStrDescrip = ' '; 

        //  Caso particular para el nivel con el valor CODFAM[1,${pIntNivfam}].        
        if (mStrNivel == `CODFAM[1,${pIntNivfam}]`) {
            mStrNivel = `SUBSTR(codfam, 1, ${pIntNivfam})`;
        } 
        
        //  Recuperar la descripción del nivel.
        if (Ax.db.existsTable(mStrDescrip)) {
            mStrDescrip = `gdwh_get_descrip('${mStrDescrip}', ${mStrNivel})`;
        } else {
            mStrDescrip = `${mStrDescrip}`;
        }

        //  Construir el string de columnas para el columns del select. 
        mStrColumns = `${mStrColumns}${mStrNivel} nivel${mIntIdx}, <nvl>${mStrDescrip}, ''</nvl> desniv${mIntIdx},`;

        if (Ax.db.getDriver() == 'ids' ) {
            //  informix : Para group by emitimos solo su alias.
            mStrColgrp = `${mStrColgrp}nivel${mIntIdx}, desniv${mIntIdx},`;
        } else {
            //  oracle / postges : sin alias
            mStrColgrp = `${mStrColgrp}${mStrNivel}, <nvl>${mStrDescrip}, ''</nvl>,`;
        }

    });

    /**
     *  Determinar el group del select. 
     */
    if (Ax.db.getDriver() == 'ids' ) {
        //  informix : Para group by emitimos solo su alias.
        mStrColgrp = `${mStrColgrp} feciniact, fecfinact, feciniant, fecfinant`;
    } else {
        //  oracle / postges : sin alias
        mStrColgrp = `${mStrColgrp} a.fecini, a.fecfin,  b.fecini, b.fecfin`;
    }

    /**
     *  Determinar el order del select.  
     */
    var mStrOrder = 'nivel1';

    for (var i = 2; i <= mIntIdx; i++) {
        mStrOrder = `${mStrOrder}, nivel${i}`;
    }
    mStrOrder = `${mStrOrder}`; 

    /**
     *  Select definitivo.  
     */
    var mTmpResult = Ax.db.getTempTableName('tmp_resultado');
    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpResult}`);

    Ax.db.execute(`
        <select intotemp='${mTmpResult}'>
            <columns>
                ${mIntIdx} nivel,
                ${mStrColumns}
                a.fecini feciniact, a.fecfin fecfinact,
                b.fecini feciniant, b.fecfin fecfinant,
                <char>((${pIntEjerci} * 100) + 1)</char> || ':' || <char>((${pIntEjerci} * 100) + ${pIntSemana})</char> anymesact,
                <char>(((${pIntEjerci} - 1) * 100) + 1)</char> || ':' || <char>(((${pIntEjerci} - 1) * 100) + ${pIntSemana})</char> anymesant,
                SUM(CASE WHEN gdwh_lmovfams.anysem = ((${pIntEjerci} * 100) + ${pIntSemana})
                         THEN CASE WHEN '${pStrtipval}' = 'CANMOV' THEN canmov
                                   WHEN '${pStrtipval}' = 'IMPCOS' THEN impcos
                               END
                     END) valsct,
                SUM(CASE WHEN '${pStrtipval}' = 'CANMOV' THEN canmov
                         WHEN '${pStrtipval}' = 'IMPCOS' THEN impcos
                     END) valsca,
                SUM(CASE WHEN gdwh_lmovfams.anysem = ((${pIntEjerci} * 100) + ${pIntSemana})
                         THEN CASE WHEN '${pStrtipval}' = 'CANMOV' THEN canmov
                                   WHEN '${pStrtipval}' = 'IMPCOS' THEN canmov
                               END
                     END) presct,
                SUM(CASE WHEN '${pStrtipval}' = 'CANMOV' THEN canmov
                         WHEN '${pStrtipval}' = 'IMPCOS' THEN canmov
                     END) presca,
                SUM(CASE WHEN gdwh_lmovfams.anysem = (((${pIntEjerci} - 1) * 100) + ${pIntSemana})
                         THEN CASE WHEN '${pStrtipval}' = 'CANMOV' THEN canmov
                                   WHEN '${pStrtipval}' = 'IMPCOS' THEN impcos
                               END
                     END) valsnt,
                SUM(CASE WHEN '${pStrtipval}' = 'CANMOV' THEN canmov
                         WHEN '${pStrtipval}' = 'IMPCOS' THEN impcos
                     END) valsna
            </columns>
            <from table='gdwh_lmovfams'>
                <join table='gdelgrpl'>
                    <on>gdwh_lmovfams.delega = gdelgrpl.delgrp</on>
                </join>
                <join table='galmgrpl'>
                    <on>gdwh_lmovfams.codalm = galmgrpl.almgrp</on>
                </join>
                <join table='gdwh_semdia' alias='a'>
                    <on>a.anysem = ((${pIntEjerci} * 100) + ${pIntSemana})</on>
                </join>
                <join table='gdwh_semdia' alias='b'>
                    <on>b.anysem = (((${pIntEjerci} - 1) * 100) + ${pIntSemana})</on>
                </join>
            </from>
            <where>
                gdwh_lmovfams.anysem BETWEEN (((${pIntEjerci} - 1) * 100) + 1) AND ((${pIntEjerci} * 100) + ${pIntSemana}) AND
                gdwh_lmovfams.consum = (CASE WHEN '${pStrconsum}' = '0' THEN 0
                                             WHEN '${pStrconsum}' = '1' THEN 1
                                             ELSE gdwh_lmovfams.consum
                                         END) AND
                ${pStrsqlcond}
            </where>
            <group>${mStrColgrp}</group>
        </select>  
    `);

    return mStrOrder;

}