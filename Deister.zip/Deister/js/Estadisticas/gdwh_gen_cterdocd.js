var pStrEmpcode = Ax.context.variable.EMPCODE;
var pStrDelega  = Ax.context.variable.DELEGA;
var pStrFecini  = Ax.context.variable.FECINI;
var pStrFecfin  = Ax.context.variable.FECFIN;

Ax.db.call('gdwh_gen_cterdocd', 
    pStrEmpcode,
    pStrDelega,
    new Ax.sql.Date(pStrFecini),
    new Ax.sql.Date(pStrFecfin),
    'N'
);

return Ax.db.executeQuery(`
    <select>
        <columns>proname, COUNT(*) numerr</columns>
        <from table='gdwh_interr' />
        <where>
            proname IN ('CDELSECT','CDELFAMS','CDELARTF','CDTOSECT',
                        'CDTOFAMS','CDTOARTF','CTERSECT','CTERFAMS',
                        'CTERARTA','CTERDOCA','WCTERDF','WCDTOAF') AND
            fecinf  BETWEEN ${new Ax.sql.Date(pStrFecini)} AND ${new Ax.sql.Date(pStrFecfin)} AND
            ${Ax.context.property.COND}
        </where>
        <group>
            proname
        </group>
    </select>
`);
