/**
 *  Js: gdwh_vdtoartd_famd                                           
 *                                                                     
 *  Script de carga del maestro de 'Ventas descuentos - familia diario'
 *  desde la tabla 'Ventas descuentos - artículo diario'               
 *  siempre y cuando la informacion hubiera sido cargada con el        
 *  parametro valida = 'N'.                                             
 */
function gdwh_vdtoartd_famd(
    pStrEmpcode, pStrDelega, pDatFecini,
    pDatFecfin,  pStrCargar, pStrIndagr
) {
    /**
     *  FUNC: __local_gdwh_vdtosecd_totd                                       
     *                                                                      
     *  Función que carga la tabla gdwh_vdtototd (Descuentos totales-diario) 
     *  desde la tabla gdwh_vdtosecd (Descuentos secciones-diario), siempre y
     *  cuando la informacion hubiera sido cargada con el parametro          
     *  p_valida = 'N'.                                                      
     */
    function __local_gdwh_vdtosecd_totd(
        pStrEmpcode, pStrDelega, pDatFecini,
        pDatFecfin,  pStrIndagr){
        /**
         *  Control de errores                                        
         *  Borrar los errores producidos en ejecuciones anteriores.  
         */
        var mStrProname = 'VDTOSECT';        // Descuentos Secciones-Totales
        Ax.db.delete('gdwh_interr', {proname: mStrProname});

        var mIntCount;

        /**
         *  Procesar registros de gdwh_vdtosecd. 
         */
        var mArrGdwhVdtosecd = Ax.db.executeQuery(`
            <select>
                <columns>
                    DISTINCT empcode, delega, fecha
                </columns>
                <from table='gdwh_vdtosecd' />
                <where>
                    fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    empcode ${pStrEmpcode} AND
                    delega ${pStrDelega} AND
                    valida = 'N'
                </where>
                <order>
                    empcode, delega, fecha
                </order>
            </select>
        `).toMemory();

        for (var mRow of mArrGdwhVdtosecd) {
            /**
             *  Control de error y transacción por delegación-día.  
             */
            try {
                /**
                 *  Se abre transaccion por delegación-día. 
                 */
                Ax.db.beginWork();

                /**
                 *  DESCUENTOS SECCIONES-DIA. 
                 */
                mIntCount = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gdwh_vdtototd' />
                        <where>
                            empcode = ? AND
                            delega  = ? AND
                            fecha  = ${mRow.fecha}
                        </where>
                    </select>
                `, mRow.empcode, mRow.delega);

                if (pStrIndagr == 'N' && !mIntCount) {
                    var mArrGdwhVdtototd = Ax.db.executeQuery(`
                        <select>
                            <columns>
                                fecha,  empcode,codalm, delega, depart, tercer, tipdir,
                                terfac, tergrp, terfed, tercom, codnac, codpro,
                                codzon, agente, 'FV' tabori,    tipdoc, cladoc, auxal0,
                                auxal1, auxal2, auxal3, auxal4, dtoven,
                                SUM(impdto) impdto, SUM(import) import, SUM(auxnu0) auxnu0,
                                SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                SUM(auxnu4) auxnu4, semmes,             'N' grpest
                            </columns>
                            <from table='gdwh_vdtosecd' />
                            <where>
                                empcode = ? AND
                                delega  = ? AND
                                fecha   = ${mRow.fecha}  AND
                                valida  = 'N'
                            </where>
                            <group>
                                fecha,  empcode,codalm, delega, depart, tercer, tipdir,
                                terfac, tergrp, terfed, tercom, codnac, codpro,
                                codzon, agente, tipdoc, cladoc, auxal0, auxal1,
                                auxal2, auxal3, auxal4, dtoven, semmes
                            </group>
                        </select>
                    `, mRow.empcode, mRow.delega).toMemory();

                    for (var mObjGdwhVdtototd of mArrGdwhVdtototd) {
                        Ax.db.insert('gdwh_vdtototd', mObjGdwhVdtototd)
                    }
                } else {
                    var mArrGdwhVdtod = Ax.db.executeQuery(`
                        <select>
                            <columns>
                                fecha,  empcode,codalm, delega, depart, tercer,
                                tipdir, terfac, tergrp, terfed, tercom, codnac,
                                codpro, codzon, agente, 'FV' tabori,    tipdoc,
                                cladoc, auxal0, auxal1, auxal2, auxal3,
                                auxal4, dtoven,
                                SUM(impdto) impdto, SUM(import) import,
                                SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                SUM(auxnu4) auxnu4, semmes, 'N' grpest
                            </columns>
                            <from table='gdwh_vdtosecd' />
                            <where>
                                empcode = ? AND
                                delega  = ? AND
                                fecha   = ${mRow.fecha} AND
                                valida  = 'N'
                            </where>
                            <group>
                                fecha,  empcode,codalm, delega, depart, tercer,
                                tipdir, terfac, tergrp, terfed, tercom,
                                codnac, codpro, codzon, agente, tipdoc,
                                cladoc, auxal0, auxal1, auxal2, auxal3,
                                auxal4, dtoven, semmes
                            </group>
                        </select>
                    `, mRow.empcode, mRow.delega).toMemory();

                    for (var mObjGdwhVdtototd of mArrGdwhVdtod) {
                        for (let m_iter = 1; m_iter <= 11; m_iter++) {
                            /**
                             *  Control de que las iteraciones no sean más de 10. 
                             */
                            if (m_iter > 10) {
                                throw new Ax.lang.Exception(`local_gdwh_vdtosecd_totd: Número de iteraciones superada. Máximo 10.`);
                            }

                            var mNumCount = Ax.db.executeGet(`
                                <select>
                                    <columns>
                                        COUNT(*)
                                    </columns>
                                    <from table='gdwh_vdtototd'/>
                                    <where>
                                        fecha   = ${mObjGdwhVdtototd.fecha}  AND
                                        empcode = '${mObjGdwhVdtototd.empcode}' AND
                                        codalm  = '${mObjGdwhVdtototd.codalm}' AND
                                        delega  = '${mObjGdwhVdtototd.delega}' AND
                                        depart  = '${mObjGdwhVdtototd.depart}' AND
                                        tercer  = '${mObjGdwhVdtototd.tercer}' AND
                                        tipdir  = '${mObjGdwhVdtototd.tipdir}' AND
                                        terfac  = '${mObjGdwhVdtototd.terfac}' AND
                                        codnac  = '${mObjGdwhVdtototd.codnac}' AND
                                        codpro  = '${mObjGdwhVdtototd.codpro}' AND
                                        codzon  = '${mObjGdwhVdtototd.codzon}' AND
                                        agente  = '${mObjGdwhVdtototd.agente}' AND
                                        tabori  = '${mObjGdwhVdtototd.tabori}' AND
                                        tipdoc  = '${mObjGdwhVdtototd.tipdoc}' AND
                                        cladoc  = '${mObjGdwhVdtototd.cladoc}' AND
                                        auxal0  = '${mObjGdwhVdtototd.auxal0}' AND
                                        auxal1  = '${mObjGdwhVdtototd.auxal1}' AND
                                        auxal2  = '${mObjGdwhVdtototd.auxal2}' AND
                                        auxal3  = '${mObjGdwhVdtototd.auxal3}' AND
                                        auxal4  = '${mObjGdwhVdtototd.auxal4}' AND
                                        dtoven  = '${mObjGdwhVdtototd.dtoven}' AND
                                        semmes  = '${mObjGdwhVdtototd.semmes}'
                                    </where>
                                </select>
                            `);

                            Ax.db.execute(`
                                UPDATE gdwh_vdtototd
                                SET impdto = impdto + ${mObjGdwhVdtototd.impdto},
                                    import = import + ${mObjGdwhVdtototd.import},
                                    auxnu0 = auxnu0 + ${mObjGdwhVdtototd.auxnu0},
                                    auxnu1 = auxnu1 + ${mObjGdwhVdtototd.auxnu1},
                                    auxnu2 = auxnu2 + ${mObjGdwhVdtototd.auxnu2},
                                    auxnu3 = auxnu3 + ${mObjGdwhVdtototd.auxnu3},
                                    auxnu4 = auxnu4 + ${mObjGdwhVdtototd.auxnu4}
                                WHERE 
                                   fecha   = ${mObjGdwhVdtototd.fecha}  AND
                                   empcode = '${mObjGdwhVdtototd.empcode}' AND
                                   codalm  = '${mObjGdwhVdtototd.codalm}' AND
                                   delega  = '${mObjGdwhVdtototd.delega}' AND
                                   depart  = '${mObjGdwhVdtototd.depart}' AND
                                   tercer  = '${mObjGdwhVdtototd.tercer}' AND
                                   tipdir  = '${mObjGdwhVdtototd.tipdir}' AND
                                   terfac  = '${mObjGdwhVdtototd.terfac}' AND
                                   codnac  = '${mObjGdwhVdtototd.codnac}' AND
                                   codpro  = '${mObjGdwhVdtototd.codpro}' AND
                                   codzon  = '${mObjGdwhVdtototd.codzon}' AND
                                   agente  = '${mObjGdwhVdtototd.agente}' AND
                                   tabori  = '${mObjGdwhVdtototd.tabori}' AND
                                   tipdoc  = '${mObjGdwhVdtototd.tipdoc}' AND
                                   cladoc  = '${mObjGdwhVdtototd.cladoc}' AND
                                   auxal0  = '${mObjGdwhVdtototd.auxal0}' AND
                                   auxal1  = '${mObjGdwhVdtototd.auxal1}' AND
                                   auxal2  = '${mObjGdwhVdtototd.auxal2}' AND
                                   auxal3  = '${mObjGdwhVdtototd.auxal3}' AND
                                   auxal4  = '${mObjGdwhVdtototd.auxal4}' AND
                                   dtoven  = '${mObjGdwhVdtototd.dtoven}' AND
                                   semmes  = '${mObjGdwhVdtototd.semmes}'
                            `);

                            if (mNumCount = 0) {
                                Ax.db.insert('gdwh_vdtototd', mObjGdwhVdtototd)
                            }

                            if (pStrIndagr == 'S') {
                                var mObjAgrega = Ax.db.executeQuery(`
                                    <select>
                                        <columns>
                                            tipagr tipdoc, claagr cladoc
                                        </columns>
                                        <from table='gdwh_agrega' />
                                        <where>
                                            tipdoc = '${mObjGdwhVdtototd.tipdoc}' AND
                                            cladoc = '${mObjGdwhVdtototd.cladoc}'
                                        </where>
                                    </select>
                                `).toOne();

                                mObjGdwhVdtototd.tipdoc = mObjAgrega.tipdoc;
                                mObjGdwhVdtototd.cladoc = mObjAgrega.cladoc;

                                if (mObjGdwhVdtototd.tipdoc == null) {
                                    break;
                                }
                            } else {
                                break;
                            }
                            
                        }
                    }
                }

                /**
                 *  Se marcan los registros procesados.    
                 */
                Ax.db.update('gdwh_vdtosecd', 
                    {
                        valida: 'S'
                    }, 
                    {
                        empcode: mRow.empcode,      
                        delega:  mRow.delega,
                        fecha:   new Ax.sql.Date(mRow.fecha),
                        valida:  'N'  
                    }
                )

                /**
                 *  Se cierra la transaccion. 
                 */
                Ax.db.commitWork();
                
            } catch (error) {
                /**
                 *  Se retrocede la transaccion. 
                 */
                Ax.db.rollbackWork();

                Ax.db.insert('gdwh_interr', 
                    {
                        proname: mStrProname,
                        delalm : mRow.delega,
                        codigo : '',
                        fecinf : new Ax.sql.Date(mRow.fecha),
                        fecerr : new Ax.sql.Date(),
                        nsql   : 0,
                        nisam  : 0,
                        errmsg : Ax.util.Error.getMessage(error)
                    }
                )
            }

            Ax.db.commitWork();
        }
    }

    /**
     *  FUNC: __local_gdwh_vdtofamd_secd                                        
     *                                                                      
     *  Función que carga la tabla gdwh_vdtosecd (Descuentos secciones-diario)
     *  desde la tabla gdwh_vdtofamd (Descuentos familia-diario), siempre y   
     *  cuando la informacion hubiera sido cargada con el parametro           
     *  p_valida = 'N'.                                                       
     */
    function __local_gdwh_vdtofamd_secd(
        pStrEmpcode, pStrDelega, pDatFecini,
        pDatFecfin,  pStrCargar, pStrIndagr){
        /**
         *  Control de errores                                        
         *  Borrar los errores producidos en ejecuciones anteriores.  
         */
        mStrProname = 'VDTOFAMS'        // Descuentos Familias-Secciones
        Ax.db.delete('gdwh_interr',{proname: mStrProname});

        /**
         *  Procesar registros de gdwh_vdtofamd. 
         */
        var mArrGdwhVdtofamd = Ax.db.executeQuery(`
            <select>
                <columns>
                    DISTINCT empcode, delega, fecha
                </columns>
                <from table='gdwh_vdtofamd' />
                <where>
                    fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    empcode ${pStrEmpcode} AND
                    delega ${pStrDelega} AND
                    valida = 'N'
                </where>
                <order>
                    empcode, delega, fecha
                </order>
            </select>
        `).toMemory();

        for (var mRow of mArrGdwhVdtofamd) {
            /**
             *  Control de error y transacción por delegación-día.
             */
            try {
                /**
                 *  Se abre transaccion por delegación-día.
                 */
                Ax.db.beginWork();

                /**
                 *  DESCUENTOS FAMILIAS-DIA. 
                 */
                var mIntCount = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gdwh_vdtosecd' />
                        <where>
                            empcode = ? AND
                            delega  = ? AND
                            fecha   = ${mRow.fecha}
                        </where>
                    </select>
                `, mRow.empcode, mRow.delega);

                if (pStrIndagr == 'N' && !mIntCount) {
                    var mArrGdwhVdtofamd = Ax.db.executeQuery(`
                        <select>
                            <columns>
                                fecha,  empcode,codalm, delega, depart, seccio,
                                tercer, tipdir, terfac, tergrp, terfed, tercom,
                                codnac, codpro, codzon, agente, 'FV'    tabori,
                                tipdoc, cladoc, auxal0, auxal1, auxal2, auxal3,
                                auxal4, dtoven,
                                SUM(impdto) impdto, SUM(import) import, SUM(auxnu0) auxnu0,
                                SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                SUM(auxnu4) auxnu4, semmes,             valida
                            </columns>
                            <from table='gdwh_vdtofamd' />
                            <where>
                                empcode = ? AND
                                delega  = ? AND
                                fecha   = ${mRow.fecha} AND
                                valida  = 'N'
                            </where>
                            <group>
                                fecha,  empcode,codalm, delega, depart, seccio, tercer,
                                tipdir, terfac, tergrp, terfed, tercom, codnac,
                                codpro, codzon, agente, tipdoc, cladoc, auxal0,
                                auxal1, auxal2, auxal3, auxal4, dtoven, semmes,
                                valida
                            </group>
                        </select>
                    `, mRow.empcode, mRow.delega).toMemory();

                    for (var mObjGdwhVdtosecd of mArrGdwhVdtofamd) {
                        Ax.db.insert('gdwh_vdtosecd', mObjGdwhVdtosecd)
                    }
                } else {
                    var mArrGdwhVdtosecd = Ax.db.executeQuery(`
                        <select>
                            <columns>
                                fecha,  empcode,codalm, delega, depart,
                                seccio, tercer, tipdir, terfac, tergrp,
                                terfed, tercom, codnac, codpro, codzon,
                                agente, 'FV' tabori,    tipdoc, cladoc,
                                auxal0, auxal1, auxal2, auxal3, auxal4,
                                dtoven,
                                SUM(impdto) impdto, SUM(import) import,
                                SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                SUM(auxnu4) auxnu4, semmes, valida
                            </columns>
                            <from table='gdwh_vdtofamd' />
                            <where>
                                empcode = ? AND
                                delega  = ? AND
                                fecha   = ${mRow.fecha} AND
                                valida  = 'N'
                            </where>
                            <group>
                                fecha,  empcode,codalm, delega, depart, seccio,
                                tercer, tipdir, terfac, tergrp, terfed,
                                tercom, codnac, codpro, codzon, agente,
                                tipdoc, cladoc, auxal0, auxal1, auxal2,
                                auxal3, auxal4, dtoven, semmes, valida
                            </group>
                        </select>
                    `, mRow.empcode, mRow.delega).toMemory();

                    for (var mObjGdwhVdtosecd of mArrGdwhVdtosecd) {
                        for (var m_iter = 0; m_iter < array.length; m_iter++) {
                            /**
                             *  Control de que las iteraciones no sean más de 10. 
                             */
                            if (m_iter > 10) {
                                throw new Ax.lang.Exception(`__local_gdwh_vdtofamd_secd: Número de iteraciones superada. Máximo 10.`);
                            }

                            var mNumCount = Ax.db.executeGet(`
                                <select>
                                    <columns>COUNT(*)</columns>
                                    <from table='gdwh_vdtosecd' />
                                    <where>
                                        fecha   = ${mObjGdwhVdtosecd.fecha}  AND
                                        empcode = '${mObjGdwhVdtosecd.empcode}' AND
                                        codalm  = '${mObjGdwhVdtosecd.codalm}' AND
                                        delega  = '${mObjGdwhVdtosecd.delega}' AND
                                        depart  = '${mObjGdwhVdtosecd.depart}' AND
                                        seccio  = '${mObjGdwhVdtosecd.seccio}' AND
                                        tercer  = '${mObjGdwhVdtosecd.tercer}' AND
                                        tipdir  = '${mObjGdwhVdtosecd.tipdir}' AND
                                        terfac  = '${mObjGdwhVdtosecd.terfac}' AND
                                        codnac  = '${mObjGdwhVdtosecd.codnac}' AND
                                        codpro  = '${mObjGdwhVdtosecd.codpro}' AND
                                        codzon  = '${mObjGdwhVdtosecd.codzon}' AND
                                        agente  = '${mObjGdwhVdtosecd.agente}' AND
                                        tabori  = '${mObjGdwhVdtosecd.tabori}' AND
                                        tipdoc  = '${mObjGdwhVdtosecd.tipdoc}' AND
                                        cladoc  = '${mObjGdwhVdtosecd.cladoc}' AND
                                        auxal0  = '${mObjGdwhVdtosecd.auxal0}' AND
                                        auxal1  = '${mObjGdwhVdtosecd.auxal1}' AND
                                        auxal2  = '${mObjGdwhVdtosecd.auxal2}' AND
                                        auxal3  = '${mObjGdwhVdtosecd.auxal3}' AND
                                        auxal4  = '${mObjGdwhVdtosecd.auxal4}' AND
                                        dtoven  = '${mObjGdwhVdtosecd.dtoven}' AND
                                        semmes  = '${mObjGdwhVdtosecd.semmes}'
                                    </where>
                                </select>
                            `);
        
                            Ax.db.execute(`
                                UPDATE gdwh_vdtosecd
                                   SET impdto = impdto + ${mObjGdwhVdtosecd.impdto},
                                       import = import + ${mObjGdwhVdtosecd.import},
                                       auxnu0 = auxnu0 + ${mObjGdwhVdtosecd.auxnu0},
                                       auxnu1 = auxnu1 + ${mObjGdwhVdtosecd.auxnu1},
                                       auxnu2 = auxnu2 + ${mObjGdwhVdtosecd.auxnu2},
                                       auxnu3 = auxnu3 + ${mObjGdwhVdtosecd.auxnu3},
                                       auxnu4 = auxnu4 + ${mObjGdwhVdtosecd.auxnu4}
                                    WHERE 
                                       fecha   = ${mObjGdwhVdtosecd.fecha}  AND
                                       empcode = '${mObjGdwhVdtosecd.empcode}' AND
                                       codalm  = '${mObjGdwhVdtosecd.codalm}' AND
                                       delega  = '${mObjGdwhVdtosecd.delega}' AND
                                       depart  = '${mObjGdwhVdtosecd.depart}' AND
                                       seccio  = '${mObjGdwhVdtosecd.seccio}' AND
                                       tercer  = '${mObjGdwhVdtosecd.tercer}' AND
                                       tipdir  = '${mObjGdwhVdtosecd.tipdir}' AND
                                       terfac  = '${mObjGdwhVdtosecd.terfac}' AND
                                       codnac  = '${mObjGdwhVdtosecd.codnac}' AND
                                       codpro  = '${mObjGdwhVdtosecd.codpro}' AND
                                       codzon  = '${mObjGdwhVdtosecd.codzon}' AND
                                       agente  = '${mObjGdwhVdtosecd.agente}' AND
                                       tabori  = '${mObjGdwhVdtosecd.tabori}' AND
                                       tipdoc  = '${mObjGdwhVdtosecd.tipdoc}' AND
                                       cladoc  = '${mObjGdwhVdtosecd.cladoc}' AND
                                       auxal0  = '${mObjGdwhVdtosecd.auxal0}' AND
                                       auxal1  = '${mObjGdwhVdtosecd.auxal1}' AND
                                       auxal2  = '${mObjGdwhVdtosecd.auxal2}' AND
                                       auxal3  = '${mObjGdwhVdtosecd.auxal3}' AND
                                       auxal4  = '${mObjGdwhVdtosecd.auxal4}' AND
                                       dtoven  = '${mObjGdwhVdtosecd.dtoven}' AND
                                       semmes  = '${mObjGdwhVdtosecd.semmes}'
                            `);

                            if (mNumCount == 0) {
                                Ax.db.insert('gdwh_vdtosecd', mObjGdwhVdtosecd)
                            }

                            if (pStrIndagr == 'S') {
                                var mObjAgrega = Ax.db.executeQuery(`
                                    <select>
                                       <columns>
                                           tipagr tipdoc, claagr cladoc
                                       </columns>
                                       <from table='gdwh_agrega' />
                                       <where>
                                           tipdoc = '${mObjGdwhVdtosecd.tipdoc}' AND
                                           cladoc = '${mObjGdwhVdtosecd.cladoc}'
                                       </where>
                                    /select>    
                                `).toOne();

                                mObjGdwhVdtosecd.tipdoc = mObjAgrega.tipdoc;
                                mObjGdwhVdtosecd.cladoc = mObjAgrega.cladoc;

                                if (mObjGdwhVdtosecd.tipdoc == null) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                    }
                }

                /**
                 *  Se marcan los registros procesados. 
                 */
                Ax.db.update('gdwh_vdtofamd', 
                    {
                        valida: 'S'
                    }, 
                    {
                        empcode: mRow.empcode,
                        delega : mRow.delega,
                        fecha  : mRow.fecha,
                        valida : 'N'
                    }
                );

                /**
                 *  Se cierra la transaccion. 
                 */
                Ax.db.commitWork();                                
            } catch (error) {
                /**
                 *  Se retrocede la transaccion.  
                 */
                Ax.db.rollbackWork();

                Ax.db.insert('', 
                    {
                        proname: mStrProname,
                        delalm : mRow.delega,
                        codigo : '',
                        fecinf : new Ax.sql.Date(mRow.fecha),
                        fecerr : new Ax.sql.Date(),
                        nsql   : 0,
                        nisam  : 0,
                        errmsg : Ax.util.Error.getMessage(error)
                    }
                )
                
            }

            Ax.db.commitWork();
        }

        /**
         *  Agregar el resto de piramides.   
         */
        if (pStrCargar == 'S') {
            /**
             *  Descuentos Totales-Día a partir de Descuentos Secciones-Día. 
             */
            __local_gdwh_vdtosecd_totd(
                pStrEmpcode,
                pStrDelega,
                pDatFecini,
                pDatFecfin,
                'N'
            )
        }

    }

    /**
     *  Control de errores                                       
     *  Borrar los errores producidos en ejecuciones anteriores. 
     */
    var mStrProname = 'VDTOARTF';       // Descuentos Artículos-Familias
    Ax.db.delete('gdwh_interr', {proname: mStrProname});

    var mIntCount;
    /**
     *  Procesar registros de gdwh_vdtoartd. 
     */
    var mArrGdwhVdtoartd = Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT empcode, delega, fecha
            </columns>
            <from table='gdwh_vdtoartd' />
            <where>
                fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                empcode ${pStrEmpcode} AND
                delega ${pStrDelega} AND
                valida = 'N'
            </where>
            <order>
                empcode, delega, fecha
            </order>
        </select>
    `).toMemory();

    for (var mRow of mArrGdwhVdtoartd) {
        /**
         *  Control de error y transacción por delegación-día. 
         */
        try {
            /**
             *  Se abre transaccion por delegación-día. 
             */
            Ax.db.beginWork();

            /**
             *  DESCUENTOS ARTÍCULOS-DIA. 
             */
            mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='gdwh_vdtofamd' />
                    <where>
                        empcode = ? AND
                        delega  = ? AND
                        fecha   = ${mRow.fecha}
                    </where>
                </select>    
            `, mRow.empcode, mRow.delega);

            if (pStrIndagr == 'N' && !mIntCount) {
                var mArrGdwhVdtofamd = Ax.db.executeQuery(`
                    <select>
                        <columns>
                            fecha,  empcode,codalm, delega, depart,
                            seccio, codfam, tercer, tipdir, terfac,
                            tergrp, terfed, tercom, codnac, codpro,
                            codzon, agente, 'FV' tabori,    tipdoc,
                            cladoc, auxal0, auxal1, auxal2, auxal3,
                            auxal4, dtoven,
                            SUM(impdto) impdto, SUM(import) import, SUM(auxnu0) auxnu0,
                            SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                            SUM(auxnu4) auxnu4, semmes, valida
                        </columns>
                        <from table='gdwh_vdtoartd' />
                        <where>
                            empcode = ? AND
                            delega = ? AND
                            fecha  = ${mRow.fecha} AND
                            valida = 'N'
                        </where>
                        <group>
                            fecha,  empcode,codalm, delega, depart, seccio, codfam,
                            tercer, tipdir, terfac, tergrp, terfed, tercom,
                            codnac, codpro, codzon, agente, tipdoc, cladoc,
                            auxal0, auxal1, auxal2, auxal3, auxal4, dtoven,
                            semmes, valida
                        </group>
                    </select>        
                `, mRow.empcode, mRow.delega).toMemory();

                for (var mObjGdwhVdtofamd of mArrGdwhVdtofamd) {
                    Ax.db.insert('gdwh_vdtofamd', mObjGdwhVdtofamd)
                }
            } else {
                var mArrVdtofamd = Ax.db.executeQuery(`
                    <select>
                        <columns>
                            fecha,  empcode,codalm, delega, depart, seccio,
                            codfam, tercer, tipdir, terfac, tergrp, terfed,
                            tercom, codnac, codpro, codzon, agente, 'FV' tabori,
                            tipdoc, cladoc, auxal0, auxal1, auxal2, auxal3,
                            auxal4, dtoven,
                            SUM(impdto) impdto, SUM(import) import,
                            SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                            SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                            SUM(auxnu4) auxnu4, semmes, valida
                        </columns>
                        <from table='gdwh_vdtoartd' />
                        <where>
                            empcode = ? AND
                            delega = ? AND
                            fecha  = ${mRow.fecha} AND
                            valida = 'N'
                        </where>
                        <group>
                            fecha,  empcode,codalm, delega, depart, seccio,
                            codfam, tercer, tipdir, terfac, tergrp,
                            terfed, tercom, codnac, codpro, codzon,
                            agente, tipdoc, cladoc, auxal0, auxal1,
                            auxal2, auxal3, auxal4, dtoven, semmes,
                            valida
                        </group>
                    </select>    
                `, mRow.empcode, mRow.delega).toMemory();

                for (var mObjVdtofamd of mArrVdtofamd) {
                    for (var mIntIter = 1; mIntIter <= 11; mIntIter++) {
                        /**
                         *  Control de que las iteraciones no sean más de 10. 
                         */
                        if (mIntIter > 10) {
                            throw new Ax.lang.Exception(`gdwh_vdtoartd_famd: Número de iteraciones superada. Máximo 10.`)
                        }

                        var mNumCount = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    COUNT(*)
                                </columns>
                                <from table='gdwh_vdtofamd' />
                                <where>
                                    fecha   = ${mObjVdtofamd.fecha} AND
                                    empcode = '${mObjVdtofamd.empcode}' AND
                                    codalm  = '${mObjVdtofamd.codalm}' AND
                                    delega  = '${mObjVdtofamd.delega}' AND
                                    depart  = '${mObjVdtofamd.depart}' AND
                                    seccio  = '${mObjVdtofamd.seccio}' AND
                                    codfam  = '${mObjVdtofamd.codfam}' AND
                                    tercer  = '${mObjVdtofamd.tercer}' AND
                                    tipdir  = '${mObjVdtofamd.tipdir}' AND
                                    terfac  = '${mObjVdtofamd.terfac}' AND
                                    codnac  = '${mObjVdtofamd.codnac}' AND
                                    codpro  = '${mObjVdtofamd.codpro}' AND
                                    codzon  = '${mObjVdtofamd.codzon}' AND
                                    agente  = '${mObjVdtofamd.agente}' AND
                                    tabori  = '${mObjVdtofamd.tabori}' AND
                                    tipdoc  = '${mObjVdtofamd.tipdoc}' AND
                                    cladoc  = '${mObjVdtofamd.cladoc}' AND
                                    auxal0  = '${mObjVdtofamd.auxal0}' AND
                                    auxal1  = '${mObjVdtofamd.auxal1}' AND
                                    auxal2  = '${mObjVdtofamd.auxal2}' AND
                                    auxal3  = '${mObjVdtofamd.auxal3}' AND
                                    auxal4  = '${mObjVdtofamd.auxal4}' AND
                                    dtoven  = '${mObjVdtofamd.dtoven}' AND
                                    semmes  = '${mObjVdtofamd.semmes}'
                                </where>
                            </select>    
                        `);

                        Ax.db.execute(`
                            UPDATE gdwh_vdelfamd
                            SET impdto = impdto + ${mObjVdtofamd.impdto},
                                import = import + ${mObjVdtofamd.import},
                                auxnu0 = auxnu0 + ${mObjVdtofamd.auxnu0},
                                auxnu1 = auxnu1 + ${mObjVdtofamd.auxnu1},
                                auxnu2 = auxnu2 + ${mObjVdtofamd.auxnu2},
                                auxnu3 = auxnu3 + ${mObjVdtofamd.auxnu3},
                                auxnu4 = auxnu4 + ${mObjVdtofamd.auxnu4}
                            WHERE 
                                fecha   = ${mObjVdtofamd.fecha} AND
                                empcode = '${mObjVdtofamd.empcode}' AND
                                codalm  = '${mObjVdtofamd.codalm}' AND
                                delega  = '${mObjVdtofamd.delega}' AND
                                depart  = '${mObjVdtofamd.depart}' AND
                                seccio  = '${mObjVdtofamd.seccio}' AND
                                codfam  = '${mObjVdtofamd.codfam}' AND
                                tercer  = '${mObjVdtofamd.tercer}' AND
                                tipdir  = '${mObjVdtofamd.tipdir}' AND
                                terfac  = '${mObjVdtofamd.terfac}' AND
                                codnac  = '${mObjVdtofamd.codnac}' AND
                                codpro  = '${mObjVdtofamd.codpro}' AND
                                codzon  = '${mObjVdtofamd.codzon}' AND
                                agente  = '${mObjVdtofamd.agente}' AND
                                tabori  = '${mObjVdtofamd.tabori}' AND
                                tipdoc  = '${mObjVdtofamd.tipdoc}' AND
                                cladoc  = '${mObjVdtofamd.cladoc}' AND
                                auxal0  = '${mObjVdtofamd.auxal0}' AND
                                auxal1  = '${mObjVdtofamd.auxal1}' AND
                                auxal2  = '${mObjVdtofamd.auxal2}' AND
                                auxal3  = '${mObjVdtofamd.auxal3}' AND
                                auxal4  = '${mObjVdtofamd.auxal4}' AND
                                dtoven  = '${mObjVdtofamd.dtoven}' AND
                                semmes  = '${mObjVdtofamd.semmes}'
                        `);

                        if (mNumCount == 0) {
                            Ax.db.insert('gdwh_vdtofamd', mObjVdtofamd);
                        }

                        if (pStrIndagr == 'S') {
                            var mObjAgrega = Ax.db.executeQuery(`
                                <select>
                                    <columns>
                                        tipagr tipdoc, claagr cladoc
                                    </columns>
                                    <from table='gdwh_agrega' />
                                    <where>
                                        tipdoc = '${mObjVdtofamd.tipdoc}' AND
                                        cladoc = '${mObjVdtofamd.cladoc}'
                                    </where>
                                </select>        
                            `).toOne();

                            mObjVdtofamd.tipdoc = mObjAgrega.tipdoc;
                            mObjVdtofamd.cladoc = mObjAgrega.cladoc;

                            if (mObjVdtofamd.tipdoc == null) {
                                break;
                            }
                        } else {
                            break;
                        }
                        
                    }
                }
            }

            /**
             *  Se marcan los registros procesados.   
             */
            Ax.db.update('gdwh_vdtoartd', 
                {
                    valida: 'S'
                }, 
                {
                    empcode: mRow.empcode,
                    delega : mRow.delega,
                    fecha  : new Ax.sql.Date(mRow.fecha),
                    valida : 'N'
                }
            )

            /**
             *  Se cierra la transaccion. 
             */
            Ax.db.commitWork();            
        } catch (error) {
            /**
             *  Se retrocede la transaccion. 
             */
            Ax.db.rollbackWork();

            Ax.db.insert('gdwh_interr', 
                {
                    proname: mStrProname,
                    delalm: mRow.delega,
                    codigo: '',
                    fecinf: new Ax.sql.Date(mRow.fecha),
                    fecerr: new Ax.sql.Date(),
                    nsql: 0,
                    nisam: 0,
                    errmsg: Ax.util.Error.getMessage(error)      
                }
            )
        }

        Ax.db.commitWork();
    }

    /**
     *  Agregar el resto de piramides.    
     */
    if (pStrCargar == 'S') {
        /**
         *  Descuentos Secciones-Día a partir de Descuentos Familias-Día. 
         */
        __local_gdwh_vdtofamd_secd(
            pStrEmpcode,
            pStrDelega,
            pDatFecini,
            pDatFecfin,
            pStrCargar,
            'N'
        );
    }

}