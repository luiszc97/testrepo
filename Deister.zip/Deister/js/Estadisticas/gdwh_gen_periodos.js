function gdwh_gen_periodos(pIntAnyo) {
    /**
     *  Js: gdwh_gen_periodos (Antes se llamaba gdwh_gen_per)
     *                                                         
     *  Generacion de periodos del DWH.                        
     */
    var mMapNombreMes = Ax.util.Map.of(
        1,  'Enero',
        2,  'Febrero',
        3,  'Marzo',
        4,  'Abril',
        5,  'Mayo',
        6,  'Junio',
        7,  'Julio',
        8,  'Agosto',
        9,  'Septiembre',
        10, 'Octubre',
        11, 'Noviembre',
        12, 'Diciembre'
    );

    /**
     *  Generar MESES  
     */
    var mIntMesAny; 
    var mStrNommes; 
    var mDatVigini;
    var mDatVigfin;

    for (var idx = 1; idx <= 12; idx++) {
        mIntMesAny = (pIntAnyo * 100) + idx;
        mStrNommes = mMapNombreMes.get(idx);
        mDatVigini = new Ax.sql.Date(pIntAnyo, idx, 1);
        mDatVigfin = new Ax.sql.Date(pIntAnyo, idx+1, 1-1);

        Ax.db.delete('gdwh_mesdia', {anymes : mIntMesAny});

        Ax.db.insert('gdwh_mesdia', 
            {
                anymes: mIntMesAny,
                nommes: mStrNommes,
                fecini: mDatVigini,
                fecfin: mDatVigfin,
            }
        )
    }

    /**
     * Generar SEMANAS 
     */
    var mNumAnyoIni = Number(`${pIntAnyo}00`);
    var mNumAnyoFin = Number(`${pIntAnyo}99`);

    Ax.db.delete('gdwh_mesdia', 
        `
            anysem BETWEEN ${mNumAnyoIni} AND ${mNumAnyoFin}
        `
    );

    var mIntSemana = 0;
    var mNumAnySem;
    var mNumMntdys;
    var mNumMonth;

    for (var mIdxMonth = 1; mIdxMonth <= 12; mIdxMonth++) {

        mIntSemana = mIntSemana + 1;  
        mNumAnySem = Number(`${pIntAnyo}${mIntSemana.lpad('0', 2)}`);
        
        Ax.db.insert('gdwh_semdia', 
            {
                anysem: mNumAnySem,
                fecini: new Ax.sql.Date(pIntAnyo, mIdxMonth, 1),
                fecfin: new Ax.sql.Date(pIntAnyo, mIdxMonth, 7)
            }
        );

        mIntSemana = mIntSemana + 1;
        Ax.db.insert('gdwh_semdia', 
            {
                anysem: mNumAnySem,
                fecini: new Ax.sql.Date(pIntAnyo, mIdxMonth, 8),
                fecfin: new Ax.sql.Date(pIntAnyo, mIdxMonth, 14)
            }
        );

        mIntSemana = mIntSemana + 1;
        Ax.db.insert('gdwh_semdia', 
            {
                anysem: mNumAnySem,
                fecini: new Ax.sql.Date(pIntAnyo, mIdxMonth, 15),
                fecfin: new Ax.sql.Date(pIntAnyo, mIdxMonth, 21)
            }
        );

        mIntSemana = mIntSemana + 1;
        Ax.db.insert('gdwh_semdia', 
            {
                anysem: mNumAnySem,
                fecini: new Ax.sql.Date(pIntAnyo, mIdxMonth, 22),
                fecfin: new Ax.sql.Date(pIntAnyo, mIdxMonth, 28)
            }
        );

        if (mIdxMonth == 2 && 
            !(
                (pIntAnyo % 4 === 0 && pIntAnyo % 100 !== 0) || 
                (pIntAnyo % 400 === 0)
            )) {

            continue;
        }

        mNumMntdys = 29;

        mNumMonth = new Ax.sql.Date(pIntAnyo, mIdxMonth, mNumMntdys + 1).getMonth() + 1;

        while (mNumMntdys < 31) {
            if (mNumMonth != mIdxMonth) {
                break;
            }

            mNumMntdys = mNumMntdys + 1;
        }

        mIntSemana = mIntSemana + 1;

        Ax.db.delete('gdwh_semdia',
            {
                anysem: Number(`${pIntAnyo}${mIntSemana.lpad('0', 2)}`),
                fecini: new Ax.sql.Date(pIntAnyo, mNumMonth, 29),
                fecfin: new Ax.sql.Date(pIntAnyo, mNumMonth, mNumMntdys) 
            }
        )
    }

    /**
     *  Generar DIAS  
     */
    var mDatFecha;
    var mIntDia;

    for (var idx = 1; idx <= 400; idx++) {
        mDatFecha = new Ax.sql.Date(pIntAnyo - 1, 12, 31+1);

        if (mDatFecha.getFullYear() != pIntAnyo) {
            break;
        }

        if (mDatFecha.getMonth() + 1 < 10) {

            if (mDatFecha.getDate() < 10) {
                mIntDia = Number(`${mDatFecha.getFullYear()}0${mDatFecha.getMonth() + 1}0${mDatFecha.getDate()}`);
            } else {
                mIntDia = Number(`${mDatFecha.getFullYear()}0${mDatFecha.getMonth() + 1}${mDatFecha.getDate()}`);
            }

        } else {
            if (mDatFecha.getDate() < 10) {
                mIntDia = Number(`${mDatFecha.getFullYear()}${mDatFecha.getMonth() + 1}0${mDatFecha.getDate()}`);            
            } else {
                mIntDia = Number(`${mDatFecha.getFullYear()}${mDatFecha.getMonth() + 1}${mDatFecha.getDate()}`);
            }
        }

        Ax.db.delete('gdwh_anydia', {anydia: mDatFecha});

        Ax.db.insert('gdwh_anydia', 
            {
                anydia: mDatFecha,
                diaint: mIntDia
            }
        )
        
    }

}