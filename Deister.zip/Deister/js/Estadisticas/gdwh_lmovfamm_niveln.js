/**
 *  Js: gdwh_lmovfamm_niveln                                                  
 *                                                                              
 *                                                                              
 *  Deja el resultado del select sobre gdwh_lmovfamm en la tabla temporal       
 *  @tmp_resultado. Los distintos valores de los argumentos p_nivel? determinan 
 *  el número de niveles que se mostrarán en la temporal.                       
 */
function gdwh_lmovfamm_niveln(
    pStrAnymes, pStrNivfam, pStrNivel1,
    pStrNivel2, pStrNivel3, pStrNivel4,
    pStrNivel5, pStrTipval1,pStrTipval2,
    pStrConsum, pStrSqlcond,   
) {
    /**
     *  Mapa para obtener las descripciones según el nivel. 
     */
    var mMapGdwhGetDescrip = Ax.util.Map.of(
        'GRPDEL','gdelgrph',
        'GRPALM','galmgrph',
        'CODALM','galmacen',
        'DELEGA','gdelegac',
        'DEPART','gdeparta',
        'CUENTA','galmctas',
        'CLADOC','DEPENDE CLASE DOCUMENTO',
        'TIPDOC','DEPENDE TIPO DOCUMENTO',
        'SECCIO','gseccana',
        `CODFAM[1,${pStrNivfam}]`, 'gartfami'
    );

    /**
     *  Seleccionar solo los distintos niveles informados.            
     *                                                        
     *  n1='GRPDEL',n2='GRPDEL',n3='CODALM' :: n1='GRPDEL',n2='CODALM'
     *                                                              
     *  n1='GRPDEL',n2='GRPDEL',n3='CODALM',n4='CODALM',n5='CUENTA' ::
     *  n1='GRPDEL',n2='CODALM',n3='CUENTA'                            
     */
    var mRsNivel = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['order','nivel']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR]);
	});

    var mRsNivelU = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['order','nivel']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR]);
	});

    for (var index = 1; index <= 5; index++) {
        eval(`var aux = pStrNivel${index};`);
        mRsNivel.rows().add([index, aux]);        
    }

    /**
     *  Selección de los valores únicos de nivel.  
     */
    mRsNivel.rows().sort(["nivel"]);

    mRsNivel.cursor()
    .group("nivel")
    .before(row => {
        mRsNivelU.rows().add([row.order, row.nivel]);
    }).forEach(row => {
        
    });

    /**
     *  Determinar las columnas en función de los niveles. 
     */
    mRsNivelU.rows().sort(["order"]);
    var mStrColumns = ' ';
    var mStrColgrp = '';
    var mIntIdx = 0;
    var mStrDescrip;
    var mStrNivel;

    mRsNivelU.forEach(mRow => {
        mStrNivel = mRow.nivel;
        mIntIdx = mIntIdx + 1;

        if(mMapGdwhGetDescrip.get(mStrNivel) == null) mStrDescrip = ' '; 

        //  Caso particular para el nivel con el valor CODFAM[1,${pStrNivfam}].        
        if (mStrDescrip == 'gartfami') {
            mStrNivel = `SUBSTR(codfam, 1, ${pStrNivfam})`;
        } 
        
        //  Recuperar la descripción del nivel.
        if (Ax.db.existsTable(mStrDescrip)) {
            mStrDescrip = `gdwh_get_descrip('${mStrDescrip}', ${mStrNivel})`;
        } else {
            mStrDescrip = `${mStrDescrip}`;
        }

        //  Construir el string de columnas para el columns del select. 
        mStrColumns = `${mStrColumns}${mStrNivel} nivel${mIntIdx}, <nvl>${mStrDescrip}, ''</nvl> desniv${mIntIdx},`;

        if (Ax.db.getDriver() == 'ids' ) {
            //  informix : Para group by emitimos solo su alias.
            mStrColgrp = `${mStrColgrp}nivel${mIntIdx}, desniv${mIntIdx},`;
        } else {
            //  oracle / postges : sin alias
            mStrColgrp = `${mStrColgrp}${mStrNivel}, <nvl>${mStrDescrip}, ''</nvl>,`;
        }

    });

    /**
     *  Determinar el group del select.  
     */
    if (Ax.db.getDriver() == 'ids' ) {
        //  informix : Para group by emitimos solo su alias.
        mStrColgrp = `${mStrColgrp} ejerci, period, gdwh_lmovfamm.anymes, gdwh_mesdia.fecini, gdwh_mesdia.fecfin`;
    } else {
        //  oracle / postges : sin alias
        mStrColgrp = `${mStrColgrp} ROUND((gdwh_mesdia.anymes/100),0), MOD(gdwh_mesdia.anymes,100), gdwh_lmovfamm.anymes, gdwh_mesdia.fecini, gdwh_mesdia.fecfin`;
    }

    /**
     *  Determinar el order del select.  
     */
    var mStrOrder = 'nivel1';

    for (var i = 2; i <= mIntIdx; i++) {
        mStrOrder = `${mStrOrder}, nivel${i}`;
    }
    mStrOrder = `${mStrOrder}, ejerci DESC, period DESC, fecha DESC`;

    /**
     *  Select definitivo.  
     */
    var mTmpResult = Ax.db.getTempTableName('tmp_resultado');
    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpResult}`);

    Ax.db.execute(`
         <select intotemp='${mTmpResult}'>
            <columns>
                ${mIntIdx} nivel,
                ${mStrColumns}
                ROUND((gdwh_mesdia.anymes/100),0) ejerci,
                MOD(gdwh_mesdia.anymes,100) period,
                gdwh_lmovfamm.anymes,
                gdwh_mesdia.fecini,
                gdwh_mesdia.fecfin,
                SUM(${pStrTipval1}) valor1,
                SUM(${pStrTipval2}) valor2
            </columns>
            <from table='gdwh_lmovfamm'>
                <join table='gdwh_mesdia'>
                    <on>gdwh_lmovfamm.anymes = gdwh_mesdia.anymes</on>
                </join>
                <join table='gdelgrpl'>
                    <on>gdwh_lmovfamm.delega = gdelgrpl.delgrp</on>
                </join>
                <join table='galmgrpl'>
                    <on>gdwh_lmovfamm.codalm = galmgrpl.almgrp</on>
                </join>
            </from>
            <where>
                gdwh_mesdia.anymes ${pStrAnymes} AND
                gdwh_lmovfamm.consum = (CASE WHEN '${pStrConsum}' = '0' THEN 0
                                             WHEN '${pStrConsum}' = '1' THEN 1
                                             ELSE gdwh_lmovfamm.consum
                                         END) AND
                ${pStrSqlcond}
            </where>
            <group>${mStrColgrp}</group>
        </select>       
    `);

    return mStrOrder;

}