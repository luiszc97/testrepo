function gdwh_vdelartm_export_pdi_bak() {

    var mDateAux = new Ax.util.Date();
    mDateAux.setDate(1);
    var mStrNummes = mDateAux.addDay(-1).format('yyyyMM');

    var mStrPathname = `/mnt/deister_dwh/log/`;

    var mStrTimestamp = new Ax.util.Date().format('ddMMyy_HHmmss');

    var mStrFiltempr = `${mStrPathname}bi_log_empresa_${mStrTimestamp}.work`;
    var mStrFiltdele = `${mStrPathname}bi_log_delegac_${mStrTimestamp}.work`;
    var mStrFiltarti = `${mStrPathname}bi_log_article_${mStrTimestamp}.work`;
    var mStrFiltcons = `${mStrPathname}bi_log_concent_${mStrTimestamp}.work`;
    var mStrFilfempr = `${mStrPathname}bi_log_empresa_${mStrTimestamp}.pdi`;
    var mStrFilfdele = `${mStrPathname}bi_log_delegac_${mStrTimestamp}.pdi`;
    var mStrFilfarti = `${mStrPathname}bi_log_article_${mStrTimestamp}.pdi`;
    var mStrFilfcons = `${mStrPathname}bi_log_concent_${mStrTimestamp}.pdi`;

    /**
     * tmp_cempresa
     */
    var mStrTmpCEmpresa = Ax.db.getTempTableName('tmp_cempresa');

    Ax.db.execute(`DROP TABLE IF EXISTS ${mStrTmpCEmpresa}`);

    Ax.db.execute(`
        <select intotemp='${mStrTmpCEmpresa}'>
            <columns>DISTINCT cempresa.empcode, cempresa.empname</columns>
            <from table='cempresa'>
                <join table='gdwh_vdelartm'>
                    <on>cempresa.empcode = gdwh_vdelartm.empcode</on>
                </join>
            </from>
            <where>
                gdwh_vdelartm.anymes = ?
            </where>
            <order>1</order>
        </select>
    `, mStrNummes);

    var mRsTmpCEmpresa = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='${mStrTmpCEmpresa}'/>
        </select>
    `);

    new Ax.rs.Writer(mRsTmpCEmpresa).csv(options => {
        options.setDelimiter("|");
        options.setHeader(false);
        options.setFileResource(mStrFiltempr);
    });

    mRsTmpCEmpresa.close();

    new Ax.io.File(mStrFiltempr).renameTo(mStrFilfempr);

    /**
     * tmp_gdeparta
     */

    var mStrTmpGDeparta = Ax.db.getTempTableName('tmp_gdeparta');

    Ax.db.execute(`DROP TABLE IF EXISTS ${mStrTmpGDeparta}`);

    Ax.db.execute(`
        <select intotemp='${mStrTmpGDeparta}'>
            <columns>DISTINCT gdeparta.delega, gdeparta.depart, gdelegac.nomdlg, gdeparta.nomdep</columns>
            <from table='gdeparta'>
                <join table='gdelegac'>
                    <on>gdeparta.delega = gdelegac.codigo</on>
                </join>
                <join table='gdwh_vdelartm'>
                    <on>gdeparta.delega = gdwh_vdelartm.delega</on>
                    <on>gdeparta.depart = gdwh_vdelartm.depart</on>
                </join>
            </from>
            <where>
                gdwh_vdelartm.anymes = ?
            </where>
            <order>1,2</order>
        </select>
    `, mStrNummes);

    var mRsTmpGDeparta = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='${mStrTmpGDeparta}'/>
        </select>
    `);

    new Ax.rs.Writer(mRsTmpGDeparta).csv(options => {
        options.setDelimiter("|");
        options.setHeader(false);
        options.setFileResource(mStrFiltdele);
    });

    mRsTmpGDeparta.close();

    new Ax.io.File(mStrFiltdele).renameTo(mStrFilfdele);

    /**
     * tmp_garticul
     */

    var mStrTmpGarticul = Ax.db.getTempTableName('tmp_garticul');

    Ax.db.execute(`DROP TABLE IF EXISTS ${mStrTmpGarticul}`);

    Ax.db.execute(`
        <select intotemp='${mStrTmpGarticul}'>
            <columns>DISTINCT garticul.codigo, garticul.nomart, gartfami.codigo codfam, gartfami.nomfam</columns>
            <from table='garticul'>
                <join table='gartfami'>
                    <on>garticul.codfam = gartfami.codigo</on>
                </join>
                <join table='gdwh_vdelartm'>
                    <on>garticul.codigo = gdwh_vdelartm.codart</on>
                </join>
            </from>
            <where>
                gdwh_vdelartm.anymes = ?
            </where>
            <order>1</order>
        </select>
    `, mStrNummes);

    var mRsTmpGArticul = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='${mStrTmpGarticul}'/>
        </select>
    `);

    new Ax.rs.Writer(mRsTmpGArticul).csv(options => {
        options.setDelimiter("|");
        options.setHeader(false);
        options.setFileResource(mStrFiltarti);
    });

    mRsTmpGArticul.close();

    new Ax.io.File(mStrFiltarti).renameTo(mStrFilfarti);

    /**
     * tmp_gdwh_vdelartm
     */

    var mStrTmpGDwhVdelartm = Ax.db.getTempTableName('tmp_gdwh_vdelartm');

    Ax.db.execute(`DROP TABLE IF EXISTS ${mStrTmpGDwhVdelartm}`);

    Ax.db.execute(`
        <select intotemp='${mStrTmpGDwhVdelartm}'>
            <columns>
                anymes, empcode, codalm, delega,
                depart, tipdoc,  codfam, codart,
                -SUM(canmov) canmov, -SUM(impcos) impcos
            </columns>
            <from table='gdwh_vdelartm' />
            <where>
                anymes = ?
            </where>
            <group>1,2,3,4,5,6,7,8</group>
            <order>1,2,3,4,5,6,7,8</order>
        </select>
    `, mStrNummes);

    var mRsTmpGDwhVdelartm = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='${mStrTmpGDwhVdelartm}'/>
        </select>
    `);

    new Ax.rs.Writer(mRsTmpGDwhVdelartm).csv(options => {
        options.setDelimiter("|");
        options.setHeader(false);
        options.setFileResource(mStrFiltcons);
    });

    mRsTmpGDwhVdelartm.close();

    new Ax.io.File(mStrFiltcons).renameTo(mStrFilfcons);

}