/**
 *                                                                             
 *  Js: gdwh_lmovfama_niveln                                                 
 *                                                                             
 *                                                                             
 *  Deja el resultado del select sobre gdwh_lmovfama en la tabla temporal      
 *  @tmp_resultado. Los distintos valores de los argumentos p_nivel? determinan
 *  el número de niveles que se mostrarán en la temporal.                      
 *                                                                             
 */
function gdwh_lmovfama_niveln(
    pStrAnyo,   pStrNivfam,     pStrNivel1, 
    pStrNivel2, pStrNivel3,     pStrNivel4, 
    pStrNivel5, pStrTipval1,    pStrTipval2, 
    pStrConsum, pStrSqlcond){
    /**
     *  Mapa para obtener las descripciones según el nivel.      
     */
    var mMapGdwhGetDescrip = Ax.util.Map.of(
        'GRPDEL','gdelgrph',
        'GRPALM','galmgrph',
        'CODALM','galmacen',
        'DELEGA','gdelegac',
        'DEPART','gdeparta',
        'CUENTA','galmctas',
        'CLADOC','DEPENDE CLASE DOCUMENTO',
        'TIPDOC','DEPENDE TIPO DOCUMENTO',
        'SECCIO','gseccana',
        `CODFAM[1,${pStrNivfam}]`, 'gartfami'
    );

    /**
     *  Seleccionar solo los distintos niveles informados.               
     *                                                           
     *  n1='GRPDEL',n2='GRPDEL',n3='CODALM' :: n1='GRPDEL',n2='CODALM'   
     *                                                                  
     *  n1='GRPDEL',n2='GRPDEL',n3='CODALM',n4='CODALM',n5='CUENTA' ::   
     *  n1='GRPDEL',n2='CODALM',n3='CUENTA'                              
     */
    var mRsNivel = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['order','nivel']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR]);
	});

    var mRsNivelU = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['order','nivel']);
		options.setColumnTypes([Ax.sql.Types.INTEGER, Ax.sql.Types.CHAR]);
	});

    for (var index = 1; index <= 5; index++) {
        eval(`var aux = pStrNivel${index};`);
        mRsNivel.rows().add([index, aux]);        
    }

    /**
     *  Selección de los valores únicos de nivel.  
     */
    mRsNivel.rows().sort(["nivel"]);

    mRsNivel.cursor()
    .group("nivel")
    .before(row => {
        mRsNivelU.rows().add([row.order, row.nivel]);
    }).forEach(row => {
        
    });

    /**
     *  Determinar las columnas en función de los niveles.  
     */
    mRsNivelU.rows().sort(["nivel"]);
    var mStrColumns = ' ';
    var mStrColgrp = '';
    var mIntIdx = 0;
    var mStrDescrip;
    var mStrNivel;

    mRsNivelU.forEach(mRow => {
        mStrNivel = mRow.nivel;
        mIntIdx = mIntIdx + 1;

        if(mMapGdwhGetDescrip.get(mStrNivel) == null) mStrDescrip = ' '; 

        /**
         *  Caso particular para el nivel con el valor CODFAM[1,<p_nivfam />].
         */
        if (mStrDescrip == 'gartfami') {
            mStrNivel = `SUBSTR(codfam, 1, ${pStrNivfam})`;
        } 
        
        //  Recuperar la descripción del nivel.
        if (Ax.db.existsTable(mStrDescrip)) {
            mStrDescrip = `gdwh_get_descrip('${mStrDescrip}', ${mStrNivel})`;
        } else {
            mStrDescrip = `${mStrDescrip}`;
        }

        /**
         *  Construir el string de columnas para el columns del select. 
         */
        mStrColgrp = `${mStrColgrp}${mStrNivel} nivel${mIntIdx}, <nvl>${mStrDescrip}, ''</nvl> desniv${mIntIdx},`;

        if (Ax.db.getDriver() == 'ids' ) {
            //  informix : Para group by emitimos solo su alias.
            mStrColgrp = `${mStrColgrp}nivel${mIntIdx}, desniv${mIntIdx},`;
        } else {
            //  oracle / postges : sin alias
            mStrColgrp = `${mStrColgrp}${mStrNivel}, <nvl>${mStrDescrip}, ''</nvl>,`;
        }

    });

    /**
     *  Determinar el order del select.   
     */
    var mStrOrder = 'nivel1';
    for (var index = 2; index <= mIntIdx; index++) {
        mStrOrder = `${mStrOrder}, nivel${index}`;
    }
    mStrOrder = `${mStrOrder}, ejerci DESC, period DESC, fecha DESC`;

    /**
     *  Select definitivo.  
     */
    var mTmpResul = Ax.db.getTempTableName('tmp_resultado');

    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpResul}`);

    Ax.db.execute(`
        <select intotemp='@tmp_resultado'>
            <columns>
                ${mIntIdx} nivel,
                ${mStrColumns}
                anyo,
                <char>((anyo*100)+1)</char>||':'||<char>((anyo*100)+12)</char> <alias name='anymes'/>,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_ene
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_ene
                    END) ene1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_ene
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_ene
                    END) ene2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_feb
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_feb
                    END) feb1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_feb
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_feb
                    END) feb2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_mar
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_mar
                    END) mar1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_mar
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_mar
                    END) mar2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_abr
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_abr
                    END) abr1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_abr
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_abr
                    END) abr2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_may
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_may
                    END) may1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_may
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_may
                    END) may2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_jun
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_jun
                    END) jun1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_jun
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_jun
                    END) jun2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_jul
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_jul
                    END) jul1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_jul
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_jul
                    END) jul2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_ago
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_ago
                    END) ago1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_ago
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_ago
                    END) ago2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_sep
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_sep
                    END) sep1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_sep
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_sep
                    END) sep2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_oct
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_oct
                    END) oct1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_oct
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_oct
                    END) oct2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_nov
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_nov
                    END) nov1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_nov
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_nov
                    END) nov2,
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_dic
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_dic
                    END) dic1,
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_dic
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_dic
                    END) dic2,

                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_ene
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_ene
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_feb
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_feb
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_mar
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_mar
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_abr
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_abr
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_may
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_may
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_jun
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_jun
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_jul
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_jul
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_ago
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_ago
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_sep
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_sep
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_oct
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_oct
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_nov
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_nov
                    END) +
                SUM(CASE WHEN '${pStrTipval1}' = 'CANMOV' THEN canmov_dic
                         WHEN '${pStrTipval1}' = 'IMPCOS' THEN impcos_dic
                    END) total1,


                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_ene
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_ene
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_feb
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_feb
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_mar
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_mar
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_abr
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_abr
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_may
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_may
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_jun
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_jun
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_jul
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_jul
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_ago
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_ago
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_sep
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_sep
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_oct
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_oct
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_nov
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_nov
                    END) +
                SUM(CASE WHEN '${pStrTipval2}' = 'CANMOV' THEN canmov_dic
                         WHEN '${pStrTipval2}' = 'IMPCOS' THEN impcos_dic
                    END) total2
            </columns>
            <from table='gdwh_lmovfama'>
                <join table='galmgrpl'>
                    <on>gdwh_lmovfama.codalm = galmgrpl.almgrp</on>
                </join>
                <join table='gdelgrpl'>
                    <on>gdwh_lmovfama.delega = gdelgrpl.delgrp</on>
                </join>
            </from>
            <where>
                gdwh_lmovfama.anyo ${pStrAnyo} AND
                gdwh_lmovfama.consum = (CASE WHEN '${pStrConsum}' = '0' THEN 0
                                             WHEN '${pStrConsum}' = '1' THEN 1
                                             ELSE gdwh_lmovfama.consum
                                         END) AND
                ${pStrSqlcond}
            </where>
            <group>${mStrColgrp} anyo</group>
        </select>    
    `);

    return mStrOrder;

}