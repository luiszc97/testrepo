/**
 *  Js: gdwh_lmovsecm_comp                                                      
 *                                                                                
 *  Obtiene los datos para el canal de comparativo de movimientos mensuales.      
 *                                                                                
 *  El script es llamado indistintamente para ser ejecutado desde menú de objetos 
 *  o desde canales.                                                              
 *                                                                                
 *  Llamada desde:                                                                
 *  ==============                                                                
 *     OBJETO   gdwh_lmovsecm_comp                                                
 *     CANAL    gdwh_lmovsecm_comp                                                 
 */
function gdwh_lmovsecm_comp(pIntAnyAct, pIntAnyCom, pStrSqlCond, pStrSqlSeca) {
    var mStrSqlCond, mStrSqlSeca, mIntAnyAct, mIntAnyCom;

    mStrSqlCond = pStrSqlCond || '1=1';
    mStrSqlSeca = `gseccana.codigo ${pStrSqlSeca || '=gseccana.codigo'}`;

    var mToday = new Ax.sql.Date();
    var mYear = mToday.getFullYear();

    mIntAnyAct = pIntAnyAct || mYear;
    mIntAnyCom = pIntAnyCom || mIntAnyAct - 1;

    var mDatFecini = new Ax.sql.Date(mIntAnyCom,1,1);
    var mDatFecfin = new Ax.sql.Date(mIntAnyAct,12,31);

    return Ax.db.executeQuery(`
        <select>
            <columns>
                <nvl>ctipozon.nomzon, '-'</nvl> nomzon,                                                                                    <!-- 1  -->
                galmacen.nomalm,                                                                                                           <!-- 2  -->
                gseccana.nomsec,                                                                                                           <!-- 3  -->

                <!-- ============================================================ -->
                <!-- Importe costes                                               -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 1  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact1'/>,  <!-- 4  -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 2  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact2'/>,  <!-- 5  -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 3  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact3'/>,  <!-- 6  -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 4  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact4'/>,  <!-- 7  -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 5  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact5'/>,  <!-- 8  -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 6  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact6'/>,  <!-- 9  -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 7  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact7'/>,  <!-- 10 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 8  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact8'/>,  <!-- 11 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 9  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact9'/>,  <!-- 12 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 10 THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact10'/>, <!-- 13 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 11 THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact11'/>, <!-- 14 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 12 THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='cosact12'/>, <!-- 15 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 1  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom1'/>,  <!-- 16 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 2  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom2'/>,  <!-- 17 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 3  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom3'/>,  <!-- 18 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 4  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom4'/>,  <!-- 19 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 5  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom5'/>,  <!-- 20 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 6  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom6'/>,  <!-- 21 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 7  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom7'/>,  <!-- 22 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 8  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom8'/>,  <!-- 23 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 9  THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom9'/>,  <!-- 24 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 10 THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom10'/>, <!-- 25 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 11 THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom11'/>, <!-- 26 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 12 THEN gdwh_lmovsecm.impcos ELSE 0 END) <alias name='coscom12'/>, <!-- 27 -->

                <!-- ============================================================ -->
                <!-- Unidades                                                     -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 1  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact1'/>,  <!-- 28 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 2  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact2'/>,  <!-- 29 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 3  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact3'/>,  <!-- 30 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 4  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact4'/>,  <!-- 31 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 5  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact5'/>,  <!-- 32 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 6  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact6'/>,  <!-- 33 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 7  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact7'/>,  <!-- 34 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 8  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact8'/>,  <!-- 35 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 9  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact9'/>,  <!-- 36 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 10 THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact10'/>, <!-- 37 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 11 THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact11'/>, <!-- 38 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 12 THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='uniact12'/>, <!-- 39 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 1  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom1'/>,  <!-- 40 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 2  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom2'/>,  <!-- 41 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 3  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom3'/>,  <!-- 42 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 4  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom4'/>,  <!-- 43 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 5  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom5'/>,  <!-- 44 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 6  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom6'/>,  <!-- 45 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 7  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom7'/>,  <!-- 46 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 8  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom8'/>,  <!-- 47 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 9  THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom9'/>,  <!-- 48 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 10 THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom10'/>, <!-- 49 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 11 THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom11'/>, <!-- 50 -->
                SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 12 THEN gdwh_lmovsecm.canmov ELSE 0 END) <alias name='unicom12'/>, <!-- 51 -->

                <!-- ============================================================ -->
                <!-- Variación total                                              -->
                <!-- ============================================================ -->
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes BETWEEN ${mIntAnyCom}*100 + 1 AND ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes BETWEEN ${mIntAnyAct}*100 + 1 AND ${mIntAnyAct}*100 + 12 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes BETWEEN ${mIntAnyCom}*100 + 1 AND ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='datvar'/>,                                                                   <!-- 52 -->

                <!-- ============================================================ -->
                <!-- Evolución.                                                   -->
                <!-- ============================================================ -->
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 1 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 1 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 1 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos1'/>,                                                                   <!-- 53 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 2 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 2 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 2 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos2'/>,                                                                   <!-- 54 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 3 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 3 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 3 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos3'/>,                                                                   <!-- 55 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 4 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 4 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 4 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos4'/>,                                                                   <!-- 56 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 5 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 5 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 5 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos5'/>,                                                                   <!-- 57 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 6 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 6 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 6 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos6'/>,                                                                   <!-- 58 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 7 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 7 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 7 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos7'/>,                                                                   <!-- 59 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 8 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 8 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 8 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos8'/>,                                                                   <!-- 60 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 9 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 9 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 9 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos9'/>,                                                                   <!-- 61 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 10 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 10 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 10 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos10'/>,                                                                  <!-- 62 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 11 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 11 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 11 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos11'/>,                                                                  <!-- 63 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyAct}*100 + 12 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_lmovsecm.anymes = ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_lmovsecm.impcos, 0</nvl> ELSE 0 END)* 100)
                 END, 0) <alias name='evocos12'/>,                                                                  <!-- 64 -->

                <!-- ============================================================ -->
                <!-- Semanas para el link a gdwh_lmovsecs_comp                    -->
                <!-- ============================================================ -->
                cterdire.codzon,                                                                                     <!-- 65 -->
                galmacen.codigo <alias name='codalm'/>,                                                              <!-- 66 -->
                gseccana.codigo <alias name='secana'/>,                                                              <!-- 67 -->

                <!-- Mes actual -->
                gdwh_get_anysem(<mdy><m>1</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact1'/>,
                gdwh_get_anysem(<mdy><m>2</m><d>28</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact2'/>,
                gdwh_get_anysem(<mdy><m>3</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact3'/>,
                gdwh_get_anysem(<mdy><m>4</m><d>30</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact4'/>,
                gdwh_get_anysem(<mdy><m>5</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact5'/>,
                gdwh_get_anysem(<mdy><m>6</m><d>30</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact6'/>,
                gdwh_get_anysem(<mdy><m>7</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact7'/>,
                gdwh_get_anysem(<mdy><m>8</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact8'/>,
                gdwh_get_anysem(<mdy><m>9</m><d>30</d><y>${mIntAnyAct}</y></mdy>)  <alias name='semact9'/>,
                gdwh_get_anysem(<mdy><m>10</m><d>31</d><y>${mIntAnyAct}</y></mdy>) <alias name='semact10'/>,
                gdwh_get_anysem(<mdy><m>11</m><d>30</d><y>${mIntAnyAct}</y></mdy>) <alias name='semact11'/>,
                gdwh_get_anysem(<mdy><m>12</m><d>31</d><y>${mIntAnyAct}</y></mdy>) <alias name='semact12'/>,

                <!-- Mes comparativo -->
                gdwh_get_anysem(<mdy><m>1</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom1'/>,
                gdwh_get_anysem(<mdy><m>2</m><d>28</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom2'/>,
                gdwh_get_anysem(<mdy><m>3</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom3'/>,
                gdwh_get_anysem(<mdy><m>4</m><d>30</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom4'/>,
                gdwh_get_anysem(<mdy><m>5</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom5'/>,
                gdwh_get_anysem(<mdy><m>6</m><d>30</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom6'/>,
                gdwh_get_anysem(<mdy><m>7</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom7'/>,
                gdwh_get_anysem(<mdy><m>8</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom8'/>,
                gdwh_get_anysem(<mdy><m>9</m><d>30</d><y>${mIntAnyCom}</y></mdy>)  <alias name='semcom9'/>,
                gdwh_get_anysem(<mdy><m>10</m><d>31</d><y>${mIntAnyCom}</y></mdy>) <alias name='semcom10'/>,
                gdwh_get_anysem(<mdy><m>11</m><d>30</d><y>${mIntAnyCom}</y></mdy>) <alias name='semcom11'/>,
                gdwh_get_anysem(<mdy><m>12</m><d>31</d><y>${mIntAnyCom}</y></mdy>) <alias name='semcom12'/>

            </columns>
            <from table='gdwh_lmovsecm'>
                <join table='galmacen'>
                    <on>galmacen.codigo = gdwh_lmovsecm.codalm</on>
                    <join table='cterdire'>
                        <on>galmacen.tercer = cterdire.codigo</on>
                        <on>galmacen.tipdir = cterdire.tipdir</on>
                        <join type='left' table='ctipozon'>
                            <on>cterdire.codzon = ctipozon.codigo</on>
                        </join>
                    </join>
                </join>
                <join type='left' table='gseccana'>
                    <on>gseccana.codigo = gdwh_lmovsecm.seccio</on>
                </join>
            </from>
            <where>
                    ${mStrSqlCond}
                AND gdwh_lmovsecm.seccio IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlSeca})
                AND gdwh_lmovsecm.anymes BETWEEN ${mIntAnyCom}*100 + 1 AND ${mIntAnyAct}*100 + 12
            </where>
            <group>1, 2, 3, 65, 66, 67</group>
            <order>1, 2, 3</order>
        </select>        
    `);

}