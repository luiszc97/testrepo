/**
 *  Js: gdwh_vdelsect_tpv_comp                                      
 *                                                                    
 *  Obtiene los datos para el objeto y para el canal de comparativo de
 *  ventas por temporada.                                             
 *                                                                    
 *  El script es llamado indistintamente para ser ejecutado desde menu
 *  de objetos o desde canales.                                       
 *                                                                    
 *  Llamada desde:                                                    
 *  ==============                                                    
 *     OBJETO   gdwh_vdelsect_tpv_comp                                
 *     CANAL    gdwh_vdelsect_tpv_comp                                
 */
function gdwh_vdelsect_tpv_comp(
    pStrCladocAct,  pStrCladocCom,  pIntTpv,
    pStrSqlcond,    pStrSqlseca    
) {
    /**
     *  FUNCT : __local_get_cladoc 
     */
    function __local_get_cladoc(pDatFecha) {
        var mStrCladoc = null;

        var mObjGclasdoc = Ax.db.executeQuery(`
            <select>
                <columns>
                    gclasdoc.codigo cladoc
                </columns>
                <from table='gclasdoc' />
                <where>
                        gclasdoc.tabid = 'gtpv_ticketh' 
                    AND ${pDatFecha} BETWEEN gclasdoc.fecini AND gclasdoc.fecfin
                </where>
            </select>
        `).toOne().setRequired(`Temporada no definida para el dia: [${pDatFecha}]`);

        mStrCladoc = mObjGclasdoc.cladoc

        return mStrCladoc;
    }

    /**
     *  FUNCT : __local_get_anymes                                             
     *                                                                      
     *  Devuelve el año mes anterior a  un número de meses respecto al inicio
     *  de temporada.                                                         
     */
    function __local_get_anymes(
        pIntNumber,         // # meses anteriores 
        pStrCladoc          // temporada         
    ) {
        var mIntAnymes = null;

        var mArrGdwhMesdia = Ax.db.executeQuery(`
            <select first='${pIntNumber}'>
                <columns>
                    gdwh_mesdia.anymes
                </columns>
                <from table='gdwh_mesdia'>
                    <join table='gclasdoc'>
                        <on>gdwh_mesdia.fecini &gt;= gclasdoc.fecini</on>
                        <on>gdwh_mesdia.fecini &lt;= gclasdoc.fecfin</on>
                    </join>
                </from>
                <where>
                     gclasdoc.codigo = '${pStrCladoc}'
                </where>
                <order>1 DESC</order>
             </select>
        `).toMemory();

        for (var mRow of mArrGdwhMesdia) {
            mIntAnymes = mRow.anymes;
        }
        
        return mIntAnymes;
    }

    /**
     *  FUNCT : __local_get_fecha                                   
     *                                                          
     *  Devuelve la fecha de inicio o fin de una año mes concreto.
     */
    function __local_get_fecha(pStrType, pIntAnymes) {
        var mDatFecha = null;

        var mObjGdwhMesdia = Ax.db.executeQuery(`
            <select>
                <columns>
                    gdwh_mesdia.fecini, gdwh_mesdia.fecfin
                </columns>
                <from table='gdwh_mesdia' />
                <where>
                    gdwh_mesdia.anymes = ${pIntAnymes}
                </where>
            </select>    
        `).toOne();

        if (pStrType == 'I') {
            mDatFecha = new Ax.sql.Date(mObjGdwhMesdia.fecini);
        } else {
            mDatFecha = new Ax.sql.Date(mObjGdwhMesdia.fecfin);
        }

        return mDatFecha;
    }

    var mStrSqlCond = pStrSqlcond || '1=1';
    var mStrSqlSeca = `gseccana.codigo ${pStrSqlseca || '=gseccana.codigo'}`;

    var mStrCladocAct = pStrCladocAct || __local_get_cladoc(new Ax.sql.Date());
    var mStrCladocCom = pStrCladocCom || __local_get_cladoc(new Ax.util.Date(new Ax.util.Date().getFullYear() - 1, new Ax.util.Date().getMonth()+1, new Ax.util.Date().getDate()));

    /**
     *  Set de variables para poder utilizarlas en el select. 
     */
    var mStrVarName;
    for (var m_idx = 1; m_idx <= 6; m_idx++) {
        mStrVarName = `mIntAnymesAct${m_idx}`;
        eval(`var ${mStrVarName} = __local_get_anymes(m_idx, mStrCladocAct)`);
        mStrVarName = `mIntAnymesCom${m_idx}`;
        eval(`var ${mStrVarName} = __local_get_anymes(m_idx, mStrCladocCom)`);
    }

    var mDatFeciniAct = __local_get_fecha('I', mIntAnymesAct6);
    var mDatFecfinAct = __local_get_fecha('F', mIntAnymesAct1);

    var mDatFeciniCom = __local_get_fecha('I', mIntAnymesCom6);
    var mDatFecfinCom = __local_get_fecha('I', mIntAnymesCom1);

    /**
     *  Cuenta el número de tiquets por dia. 
     */
    var mBoolExistsTpv = false;

    if (Ax.db.existsTable('gtpv_ticketh')) {
        mBoolExistsTpv = true;
    }

    var mTmpGtpvTicketh = Ax.db.getTempTableName('tmp_gtpv_ticketh');

    if (pIntTpv == 0 || !mBoolExistsTpv) {
        Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGtpvTicketh}`);

        Ax.db.execute(`  
            CREATE TEMP TABLE ${mTmpGtpvTicketh} (
                anymes INTEGER,
                fecha  DATE,
                delega CHAR(6), 
                secana CHAR(12),
                fecven DATE,
                numtic INTEGER
            )
            WITH NO LOG;
        `);  
    } else {
        Ax.db.execute(`
            <select intotemp='${mTmpGtpvTicketh}'>
                <columns>
                    <year>gtpv_ticketh.fecha</year>*100 + <month>gtpv_ticketh.fecha</month> anymes,                         
                    gtpv_ticketh.fecha, 
                    gtpv_ticketh.delega,
                    <nvl>gartfami.secana, '-'</nvl> secana,                         
                    MAX(<eval-datetime>
                            <val unit='h'><hour>gtpv_ticketh.horfin</hour></val>
                            <val unit='min'><minute>gtpv_ticketh.horfin</minute></val>
                            <val unit='s'><second>gtpv_ticketh.horfin</second></val>
                            <val unit='datetime'><extend from='year' to='second'>gtpv_ticketh.fecha</extend></val>
                        </eval-datetime>) fecven,
                    COUNT(DISTINCT gtpv_ticketl.cabid) numtic
                </columns>
                <from table='gtpv_ticketh'>
                    <join table='gtpv_ticketd'>
                        <on>gtpv_ticketh.tipdoc = gtpv_ticketd.codigo</on>
                    </join>
                    <join table='gtpv_ticketl'>
                        <on>gtpv_ticketh.cabid = gtpv_ticketl.cabid</on>
                        <join table='garticul'>
                            <on>gtpv_ticketl.codart = garticul.codigo</on>
                            <join table='gartfami'>
                                <on>garticul.codfam = gartfami.codigo</on>
                            </join>
                        </join>
                    </join>
                </from>
                <where>
                    gtpv_ticketh.delega IN (SELECT gdelgrpl.delgrp 
                                              FROM gdelgrph, gdelgrpl, gdelegac, cterdire
                                             WHERE ${mStrSqlCond} 
                                               AND gdelgrpl.grpdel = gdelgrph.codigo
                                               AND gdelegac.codigo = gdelgrpl.delgrp
                                               AND cterdire.codigo = gdelegac.tercer
                                               AND cterdire.tipdir = gdelegac.dirdlg) AND                       
                    (gtpv_ticketh.fecha BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct} OR 
                     gtpv_ticketh.fecha BETWEEN ${mDatFeciniCom} AND ${mDatFecfinCom})AND
                    gtpv_ticketd.indest != 0  AND
                    gtpv_ticketd.abono  = 0   AND
                    gtpv_ticketh.esttra = 0   AND
                    gtpv_ticketd.valdoc = 'S' AND
                    gartfami.secana IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlSeca})
                </where>
                <group>1, 2, 3, 4</group>
            </select> 
        `);

        Ax.db.execute(`CREATE INDEX i_${mTmpGtpvTicketh} ON ${mTmpGtpvTicketh}(delega, secana)`)
    }

    return Ax.db.executeQuery(`
        <select>
            <columns>
                <nvl>ctipozon.nomzon, '-'</nvl> nomzon,                                                                <!-- 1  -->
                gdelegac.nomdlg,                                                                                       <!-- 2  -->
                gseccana.nomsec,                                                                                       <!-- 3  -->

                <!-- ============================================================ -->
                <!-- Facturación                                                  -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct6} THEN gdwh_vdelsecm.impnet ELSE 0 END) facact1,  <!-- 4  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct5} THEN gdwh_vdelsecm.impnet ELSE 0 END) facact2,  <!-- 5  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct4} THEN gdwh_vdelsecm.impnet ELSE 0 END) facact3,  <!-- 6  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct3} THEN gdwh_vdelsecm.impnet ELSE 0 END) facact4,  <!-- 7  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct2} THEN gdwh_vdelsecm.impnet ELSE 0 END) facact5,  <!-- 8  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct1} THEN gdwh_vdelsecm.impnet ELSE 0 END) facact6,  <!-- 9  -->
                        <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom6} THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom1,  <!-- 10 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom5} THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom2,  <!-- 11 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom4} THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom3,  <!-- 12 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom3} THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom4,  <!-- 13 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom2} THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom5,  <!-- 14 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom1} THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom6,  <!-- 15 -->

                <!-- ============================================================ -->
                <!-- Unidades                                                     -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct6} THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact1,  <!-- 16  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct5} THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact2,  <!-- 17  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct4} THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact3,  <!-- 18  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct3} THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact4,  <!-- 19  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct2} THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact5,  <!-- 20  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct1} THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact6,  <!-- 21  -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom6} THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom1,  <!-- 22  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom5} THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom2,  <!-- 23  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom4} THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom3,  <!-- 24  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom3} THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom4,  <!-- 25  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom2} THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom5,  <!-- 26  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom1} THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom6,  <!-- 27  -->

                <!-- ============================================================ -->
                <!-- Clientes                                                     -->
                <!-- ============================================================ -->                    
                <!-- Semana actual -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesAct6} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact1,  <!-- 28 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesAct5} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact2,  <!-- 29 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesAct4} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact3,  <!-- 30 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesAct3} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact4,  <!-- 31 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesAct2} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact5,  <!-- 32 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesAct1} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact6,  <!-- 33 -->
                                
                <!-- Semana comparativa -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesCom6} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom1,  <!-- 34 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesCom5} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom2,  <!-- 35 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesCom4} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom3,  <!-- 36 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesCom3} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom4,  <!-- 37 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesCom2} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom5,  <!-- 38 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnymesCom1} THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom6,  <!-- 39 -->

                <!-- ============================================================ -->
                <!-- Beneficios                                                   -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct6}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact1,  <!-- 40 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct5}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact2,  <!-- 41 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct4}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact3,  <!-- 42-->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct3}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact4,  <!-- 43 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct2}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact5,  <!-- 44 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct1}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact6,  <!-- 45 -->
        
                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom6}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom1,  <!-- 46 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom5}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom2,  <!-- 47 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom4}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom3,  <!-- 48 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom3}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom4,  <!-- 49 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom2}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom5,  <!-- 50 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom1}  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom6,  <!-- 51 -->
                          
                <!-- ============================================================ -->
                <!-- Dias abiertos & datos                                        -->
                <!-- ============================================================ --> 
                (SELECT COUNT(DISTINCT ${mTmpGtpvTicketh}.fecha) 
                   FROM ${mTmpGtpvTicketh} 
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecm.delega
                    AND ${mTmpGtpvTicketh}.fecha BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct}) openact,                   <!-- 52 -->                                                         
                                                                                                                  
                (SELECT COUNT(DISTINCT ${mTmpGtpvTicketh}.fecha)                                                   
                   FROM ${mTmpGtpvTicketh}                                                                         
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecm.delega                                           
                    AND ${mTmpGtpvTicketh}.fecha BETWEEN ${mDatFeciniCom} AND ${mDatFecfinCom}) opencom,                  <!-- 53 -->
    

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes BETWEEN ${mIntAnymesCom6} AND ${mIntAnymesCom1} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE                     
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes BETWEEN ${mIntAnymesAct6} AND ${mIntAnymesAct1} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes BETWEEN ${mIntAnymesCom6} AND ${mIntAnymesCom1} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) datvar,                                                                                        <!-- 54 -->
                                                                                                                   
                <current /> datact,                                                                                     <!-- 55 -->
                                                                                                                   
                (SELECT MAX(${mTmpGtpvTicketh}.fecven)                                                              
                   FROM ${mTmpGtpvTicketh}                                                                          
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecm.delega) datult,                                        <!-- 56 -->
    
                (SELECT COUNT(*) 
                   FROM gtpv_emplepar
                  WHERE gtpv_emplepar.delega = gdwh_vdelsecm.delega
                    AND gtpv_emplepar.estado != 'B'
                    AND gtpv_emplepar.fecalt BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct}
                    AND NOT(gtpv_emplepar.fecbaj BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct})) numemp,                <!-- 57 -->
                    

                <!-- ============================================================ -->
                <!-- Evolución ventas                                             -->
                <!-- ============================================================ -->            
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom6} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE                     
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct6} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom6} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven1,                                                                                       <!-- 58 -->                                                                                         

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom5} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE                     
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct5} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom5} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven2,                                                                                       <!-- 59 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom4} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE                     
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct4} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom4} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven3,                                                                                       <!-- 60 -->
                 
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom3} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE                     
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct3} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom3} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven4,                                                                                       <!-- 61 -->
    
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom2} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE                     
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct2} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom2} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven5,                                                                                       <!-- 62 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom1} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE                     
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesAct1} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnymesCom1} THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven6,                                                                                       <!-- 63 -->                                       

                <!-- ============================================================ -->
                <!-- Semanas para el link a gdwh_vdelsec_tpv_comp_s               -->
                <!-- ============================================================ -->
                cterdire.codzon,                                                                                        <!-- 64 -->
                gdelegac.codigo delega,                                                                                 <!-- 65 -->
                gseccana.codigo secana,                                                                                 <!-- 66 -->

                <!-- Mes actual -->
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesAct6} - ROUND(${mIntAnymesAct6}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesAct6}/100)</y></mdy></eval-date>) semact1,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesAct5} - ROUND(${mIntAnymesAct5}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesAct5}/100)</y></mdy></eval-date>) semact2,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesAct4} - ROUND(${mIntAnymesAct4}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesAct4}/100)</y></mdy></eval-date>) semact3,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesAct3} - ROUND(${mIntAnymesAct3}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesAct3}/100)</y></mdy></eval-date>) semact4,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesAct2} - ROUND(${mIntAnymesAct2}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesAct2}/100)</y></mdy></eval-date>) semact5,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesAct1} - ROUND(${mIntAnymesAct1}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesAct1}/100)</y></mdy></eval-date>) semact6,

                <!-- Mes comparativo -->
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesCom6} - ROUND(${mIntAnymesCom6}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesCom6}/100)</y></mdy></eval-date>) semcom1,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesCom5} - ROUND(${mIntAnymesCom5}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesCom5}/100)</y></mdy></eval-date>) semcom2,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesCom4} - ROUND(${mIntAnymesCom4}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesCom4}/100)</y></mdy></eval-date>) semcom3,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesCom3} - ROUND(${mIntAnymesCom3}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesCom3}/100)</y></mdy></eval-date>) semcom4,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesCom2} - ROUND(${mIntAnymesCom2}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesCom2}/100)</y></mdy></eval-date>) semcom5,
                gdwh_get_anysem(<eval-date m='1'><mdy><m>${mIntAnymesCom1} - ROUND(${mIntAnymesCom1}/100)*100</m><d>1</d><y>ROUND(${mIntAnymesCom1}/100)</y></mdy></eval-date>) semcom6                    

            </columns>
            <from table='gdwh_vdelsecm'>
                <join type='left' table='gdelegac'>
                    <on>gdelegac.codigo = gdwh_vdelsecm.delega</on>
                    <join table='cterdire'>
                        <on>gdelegac.tercer = cterdire.codigo</on>
                        <on>gdelegac.dirdlg = cterdire.tipdir</on>
                        <join type='left' table='ctipozon'>
                            <on>cterdire.codzon = ctipozon.codigo</on>
                        </join>
                    </join>
                </join>
                <join type='left' table='gseccana'>
                    <on>gseccana.codigo = gdwh_vdelsecm.seccio</on>
                </join>
                <join type='left' table='${mTmpGtpvTicketh}'>
                    <on>gdwh_vdelsecm.delega = ${mTmpGtpvTicketh}.delega</on>
                    <on>gdwh_vdelsecm.seccio = ${mTmpGtpvTicketh}.secana</on>
                    <on>gdwh_vdelsecm.anymes = ${mTmpGtpvTicketh}.anymes</on>
                </join>
            </from>
            <where>
                    gdwh_vdelsecm.delega IN (SELECT gdelgrpl.delgrp 
                                               FROM gdelgrph, gdelgrpl, gdelegac, cterdire
                                              WHERE ${mStrSqlCond} 
                                                AND gdelgrpl.grpdel = gdelgrph.codigo
                                                AND gdelegac.codigo = gdelgrpl.delgrp
                                                AND cterdire.codigo = gdelegac.tercer
                                                AND cterdire.tipdir = gdelegac.dirdlg) 
                AND gdwh_vdelsecm.seccio IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlSeca}) 
                AND (gdwh_vdelsecm.anymes BETWEEN ${mIntAnymesAct6} AND ${mIntAnymesAct1} OR
                     gdwh_vdelsecm.anymes BETWEEN ${mIntAnymesCom6} AND ${mIntAnymesCom1})
            </where>   
            <group>1, 2, 3, 52, 53, 55, 56, 57, 64, 65, 66</group>
            <order>1, 2, 3</order>
        </select>        
    `);

}