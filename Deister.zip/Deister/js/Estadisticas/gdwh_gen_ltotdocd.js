/**
 *  =========================================================================
 *                                                                        
 *  Js: gdwh_gen_ltotdocd                                               
 *                                                                        
 *  Procesa todos los movimientos logisticos tanto de suministros, como   
 *  expediciones y movimientos internos de los almacenes indicados que se 
 *  quieren procesar.                                                     
 *                                                                        
 *  ATENCION :                                                            
 *  Procesa de una sola vez los tres procesos individuales de integración 
 *  de estadísticas de logística.                                         
 *                                                                        
 *  Por tanto, procesa los siguientes procesos:                           
 *                                                                        
 *  1.- gdwh_gen_lsumdocd   : Entradas                                    
 *                                                                        
 *  2.- gdwh_gen_lexpdocd   : Salidas                                     
 *                                                                        
 *  3.- gdwh_gen_lintdocd   : Movimientos Internos                        
 *                                                                        
 *                                                                        
 *  Si p_valida = 'N' entonces agregara los restantes niveles de          
 *  información via proceso, de lo contrario lo hara la propia inserción  
 *  de registros via trigger, pero esta esta ultima opción no es la mas   
 *  aconsejable porque tiene un mayor coste, ya que realiza una           
 *  actualización de todos los niveles por cada registro insertado,       
 *  mientras que por proceso, cada nivel superior se actualiza con la     
 *  información agrupada del nivel inferior, por ello es mas rapida.      
 *                                                                        
 *  =========================================================================
 */
function gdwh_gen_ltotdocd(pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, pStrValida) {
    /**
     *  Inicialitzem el registre de log de processos.                
     *  S'inicialitza com a procés exclusiu. (tercer argument=1).    
     */
    Ax.db.beginWork();

    var mStrType = `remapalex_global_${pStrtype}`;

    var mObjProcLog = require("clogproh");
    Ax.db.beginWork();        
    mObjProcLog.start(mStrType, null, 1);
    Ax.db.commitWork();

    Ax.db.commitWork();

    // Procés de càrrega dels registres de la BD.  
    Ax.db.call('gdwh_gen_lsumdocd', pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, pStrValida);

    Ax.db.call('gdwh_gen_lexpdocd', pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, pStrValida);

    Ax.db.call('gdwh_gen_lintdocd', pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, pStrValida);

    /**
     * Closing the log process.
     */
    mObjProcLog.end();

    return mObjProcLog.getLogId(); 
}