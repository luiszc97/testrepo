/**
 * =========================================================================
 *                                                                          
 *    Js: gdwh_gen_lvalartd                                               
 *                                                                          
 *    Procesa las valoraciones de almacenes para las fechas y almacenes     
 *    indicados.                                                            
 *                                                                          
 *    ATENCIÓN!!!                                                           
 *                                                                          
 *    Si p_valida = "N" entonces agregará los restantes niveles de          
 *    información vía proceso, de lo contrario lo hará la propia inserción  
 *    de registros vía trigger, pero esta esta última opción no es la más   
 *    aconsejable porque tiene un mayor coste, ya que realiza una           
 *    actualización de todos los niveles por cada registro insertado,       
 *    mientras que por proceso, cada nivel superior se actualiza con la     
 *    información agrupada del nivel inferior, por ello es más rápida.      
 *                                                                          
 * =========================================================================
 */
function gdwh_gen_lvalartd(pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, pStrRegene, pStrValida){
    /**
     *   Inicialización de variables
     */
    var mStrNull = '-';                             //  Campos char que no se informan
    var mDatNull = Ax.sql.Date(1900,1,1);           //  Campos date que no se informan                    
    var mNumNull = 0;                               //  Campos numéricos que no se informan
    var mStrProname = 'WLVAART';                    //  Valoraciones de Stock artículos-diario          
    var mObjGdwhLvalartd = {};                      
    mObjGdwhLvalartd.semmes = 'A';                  //  Indicativo de actualización de semanas/meses
    mObjGdwhLvalartd.valida = pStrValida;           //  Indicativo de validación       
    
    /**
     *  Asigna valores a variables auxiliares no informadas.              
     *  Si se quisieran informar, se habrian de setear dentro del foreach 
     *  de los registros para asignar el valor segun el registro que se   
     *  este procesando en cada momento.                                   
     */
    for (var index = 0; index <= 4; index++) {
        mObjGdwhLvalartd[`auxal${index}`] = mStrNull;
        mObjGdwhLvalartd[`auxnu${index}`] = mNumNull;
    }

    /**
     *   Control de errores                                       
     *                                                            
     *   Borrar los errores producidos en ejecuciones anteriores. 
     */
    Ax.db.delete('gdwh_interr', 
        `
            proname = '${mStrProname}' AND
            delalm  ${pStrCodalm}

        `
    )

    /**
     *  ACCIONES A REALIZAR EN CASO DE REGENERACIÓN:                           
     *                                                                      
     *  · Modificación de registros de galmvalo de posibles incorporaciones    
     *    anteriores.                                                          
     *                                                                      
     *  · Eliminación de registros de gdwh_lvalartd de posibles incorporaciones
     *    anteriores.                                                           
     */
    if (pStrRegene == '5') {
        //  Modificación
        Ax.db.update('galmvalo', 
            {
                movest: 0
            },
            `
                galmvalo.codalm ${pStrCodalm} AND
                galmvalo.fecval BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                EXISTS(SELECT *
                         FROM galmacen
                        WHERE galmacen.codigo = galmvalo.codalm
                          AND galmacen.empcode ${pStrEmpcode})
            `
        );

        //  Eliminación
        Ax.db.delete('gdwh_lvalartd', 
            `
                gdwh_lvalartd.empcode ${pStrEmpcode} AND
                gdwh_lvalartd.codalm ${pStrCodalm} AND
                gdwh_lvalartd.fecha  BETWEEN ${pDatFecini} AND ${pDatFecfin}
            `
        );
    }

    /**
     *  Procesar datos de galmvalo.
     */
    var mArrGdwhLvalartd = Ax.db.executeQuery(`
        <select>
            <columns>
                galmvalo.fecval fecha, galmacen.empcode, galmvalo.codalm, galmvalo.cuenta,
                <nvl>gartfami.secana,'${mStrNull}'</nvl> seccio,
                <nvl>garticul.codfam,'${mStrNull}'</nvl> codfam,
                galmvalo.codart, galmvalo.varlog varstk, galmvalo.numlot,
                galmvalo.codean, galmvalo.terdep, galmvalo.codubi,
                SUM(galmvalo.stock) stkval,
                SUM(galmvalo.stock * galmvalo.coste) cosval
            </columns>
            <from table='galmvalo'>
                <join table='galmacen'>
                    <on>galmacen.codigo = galmvalo.codalm</on>
                </join>
                <join type='left' table='garticul'>
                    <on>galmvalo.codart = garticul.codigo</on>
                    <join type='left' table='gartfami'>
                        <on>garticul.codfam = gartfami.codigo</on>
                    </join>
                </join>
            </from>
            <where>
                galmvalo.codalm ${pStrCodalm} AND
                galmvalo.movest = 0 AND
                galmvalo.fecval BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                galmacen.empcode ${pStrEmpcode}
            </where>
            <group>
                galmvalo.fecval, galmacen.empcode, galmvalo.codalm, galmvalo.cuenta,
                gartfami.secana, garticul.codfam,  galmvalo.codart, galmvalo.varlog,
                galmvalo.numlot, galmvalo.codean,  galmvalo.terdep, galmvalo.codubi
            </group>
            <order>
                fecha, galmvalo.codart, galmvalo.varlog
            </order>
        </select>
    `).toMemory();

    for (mObjGdwhLvalartd of mArrGdwhLvalartd) {
        /**
         *  Control de error y transacción por registro.     
         */
        try {
            //  Se abre transaccion por registro.  
            Ax.db.beginWork();

            //  Inserción de la información.
            Ax.db.insert('gdwh_lvalartd', mObjGdwhLvalartd);

            //  Marcamos los registros como traspasados.  
            Ax.db.update('galmvalo', 
                {
                    movest: 1 
                }, 
                {
                    codalm: mObjGdwhLvalartd.codalm,
                    cuenta: mObjGdwhLvalartd.cuenta,
                    codart: mObjGdwhLvalartd.codart,
                    varlog: mObjGdwhLvalartd.varstk,
                    numlot: mObjGdwhLvalartd.numlot,
                    codean: mObjGdwhLvalartd.codean,
                    terdep: mObjGdwhLvalartd.terdep,
                    codubi: mObjGdwhLvalartd.codubi,
                    fecval: mObjGdwhLvalartd.fecha
                }
            )

            //  Se cierra la transaccion. 
            Ax.db.commitWork();

        } catch (error) {
            /**
             *  Se retrocede la transaccion.                                      
             *                                                    
             *  Ojo en gdwh_interr grabamos el codalm y el articulo... la PK de   
             *  galmvalo para identificar el registro es demasiado larga para     
             *  ponerla en interr. Por lo tanto habrá que seleccionar de galmvalo 
             *  los registros para el almacen-fecha-articulo y cuyo campo         
             *  movest = 0 para identificar los posibles errores.                  
             */
            Ax.db.rollbackWork();

            Ax.db.insert('gdwh_interr', 
                {
                    'proname':mStrProname,
                    'delalm': mObjGdwhLvalartd.codalm,   
                    'codigo': mObjGdwhLvalartd.codart,
                    'fecinf': mObjGdwhLvalartd.fecha,
                    'fecerr': new Ax.sql.Date(),
                    'nsql'  : 0,
                    'nisam' : 0,
                    'errmsg': Ax.util.Error.getMessage(error)
                }
            )
        }
        
        Ax.db.commitWork();
    }

    /**
     *  Agregar el resto de piramides, o sea a partir de 'gdwh_lvalartd'  
     *  cargar 'gdwh_lvalfamd', que a su vez cargará las restantes        
     *  pirámides llamando a gdwh_lvalfamd_secd al ser el cuarto parámetro
     *  una 'S'.                                                          
     */
    if (pStrValida ='N') {
        //  Valoraciones-Familias-Día a partir de Valoraciones-Artículos-Día.
        Ax.db.call('gdwh_lvalartd_famd', pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, 'S');
    }

}