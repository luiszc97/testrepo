/**
 * =========================================================================
 *                                                                       
 * Js: gdwh_gen_lintdocd                                                 
 *                                                                       
 * Procesa los movimientos logisticos de internos de los                 
 * almacenes indicados que se quieren procesar.                          
 *                                                                       
 * ATENCION :                                                            
 * Procesa informacion proviniente de tres tablas :                      
 *                                                                       
 * 1.- geanmovh-l   : Movimientos EAN                                    
 *                    geanmovd.tipmov IN ('I','T','A','B','N')           
 * 2.- gcommovh-l   : Suministros                                        
 *                    gcommovd.tipmov IN ('I','T','C')                   
 * 3.- gvenmovh-l   : Expediciones                                       
 *                    gvenmovd.tipmov IN ('I','T','P')                   
 *                                                                       
 * Si p_valida = 'N' entonces agregara los restantes niveles de          
 * información via proceso, de lo contrario lo hara la propia inserción  
 * de registros via trigger, pero esta esta ultima opción no es la mas   
 * aconsejable porque tiene un mayor coste, ya que realiza una           
 * actualización de todos los niveles por cada registro insertado,       
 * mientras que por proceso, cada nivel superior se actualiza con la     
 * información agrupada del nivel inferior, por ello es mas rapida.                                                                            
 * ======================================================================== 
 */
function gdwh_gen_lintdocd(pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, pStrValida) {

    /**
     * ========================================================================
     *                                                                          
     *  FUNC: __local_check_grabar                                                
     *                                                                          
     *  Función que evalua y chequea la logica de movimientos-contramovimientos 
     *  para su inserción.                                                      
     *                                                                          
     *          ctaori    ctades                    m_grabar                   
     *          ======    ======                    ========                   
     *  INDDWH     1         1    movimiento+                                   
     *                          contramovimiento   [A]mbos                    
     *          1         0    movimiento         [M]ovimiento               
     *          0         1    contramovimiento   [C]ontramovimiento         
     *          0         0    ninguno            [N]inguno                  
     *                                                                          
     *  ATENCION : Esta logica es valida para cualquier tipo de documento       
     *                                                                          
     * ========================================================================
     */
    function __local_check_grabar(pStrCtaori, pStrCtades) {
        // Controla el indicativo de saldo de la cuenta origen
        var mNumCtaori_dwh = Ax.db.executeGet(`
            <select cache='true'>
                <columns>
                    <nvl>galmctas.inddwh, 0</nvl> ctaori_dwh
                </columns>
                <from table='galmctas' />
                <where>
                    galmctas.codigo = ?
                </where>
            </select>
        `, pStrCtaori);

        //Controla el indicativo de saldo de la cuenta destino
        var mNumCtades_dwh = Ax.db.executeGet(`
            <select cache='true'>
                <columns>
                    <nvl>galmctas.inddwh, 0</nvl> ctades_dwh
                </columns>
                <from table='galmctas' />
                <where>
                    galmctas.codigo = ?
                </where>
            </select> 
        `, pStrCtades);

        //Analizamos si se puede grabar o no
        var mStrGrabar = 'N';

        if (mNumCtaori_dwh != 0 && mNumCtades_dwh != 0) {
            mStrGrabar = 'A';
        } else if (mNumCtaori_dwh != 0 && mNumCtades_dwh == 0) {
            mStrGrabar = 'M';
        } else if (mNumCtaori_dwh == 0 && mNumCtades_dwh != 0) {
            mStrGrabar = 'C';
        }

        return mStrGrabar        
    }

    /**
     * ======================================================================== 
     *                                                                           
     *  FUNC: __local_gdwh_gen_geanmovh                                            
     *                                                                           
     *  Función que procesa los Movimientos EAN a generar.                       
     *                                                                           
     * ======================================================================== 
     */
    function __local_gdwh_gen_geanmovh(pIntCabid, pStrValida) {
        // Inicialización de variables
        var mCharNull = '-';                        // Campos char que no se informan
        var mDatNull  = new Ax.sql.Date(1900,1,1)   // Campos date que no se informan
        var mNumNull  = 0;                          // Campos numericos que no se informan
        var mObjGdwhLintdocd = {};
        mObjGdwhLintdocd.semmes = 'A';              // Indicativo de actualización de semanas/meses
        mObjGdwhLintdocd.agrega = 'N';              // Indicativo de agregación                    
        mObjGdwhLintdocd.valida = pStrValida;       // Indicativo de validación     
        
        /**
         *  Asigna valores a variables auxiliares no informadas.              
         *  Si se quisieran informar, se habrian de setear dentro del foreach 
         *  de los documentos para asignar el valor segun el documento que se 
         *  este procesando en cada momento.                                  
         */
        for (var i = 0; i <= 4; i++) {
            mObjGdwhLintdocd[`auxal${i}`] = mCharNull;
            mObjGdwhLintdocd[`auxnu${i}`] = mNumNull;
        }

        // Selección de datos de cabecera.
        mObjGdwhLintdocd = Ax.db.executeQuery(`
            <select>
                <columns>
                    geanmovh.cabid,
                    'EA' tabori,
                    geanmovh.fecmov fecha,
                    geanmovh.empcode,
                    geanmovh.almori codalm,
                    CASE WHEN geanmovh.almdes IS NULL OR
                              <length>geanmovh.almdes</length> = 0
                         THEN '${mCharNull}'
                         ELSE geanmovh.almdes
                     END almaux,
                    geanmovh.delega,
                    geanmovh.depart,
                    geanmovh.tipdoc,
                    '${mCharNull}' cladoc,
                    geanmovh.docser,
                    CASE WHEN geanmovh.docori IS NULL OR
                              <length>geanmovh.docori</length> = 0
                         THEN '${mCharNull}'
                         ELSE geanmovh.docori
                     END docori,
                    CASE WHEN geanmovh.refter IS NULL OR
                              <length>geanmovh.refter</length> = 0
                         THEN '${mCharNull}'
                         ELSE geanmovh.refter
                     END refter,
                    ${mDatNull} fecori,
                    geanmovd.ctaori cuenta,
                    geanmovd.ctades cueaux,
                    geanmovd.tipmov,
                    geanmovd.tabori tabori2,
                    geanmovd.terstk,
                    geanmovd.consum
                </columns>
                <from table='geanmovh'>
                    <join table='geanmovd'>
                        <on>geanmovh.tipdoc = geanmovd.codigo</on>
                    </join>
                </from>
                <where>
                    geanmovh.cabid = ?
                </where>
            </select>  
        `, pIntCabid).toOne();

        /**
         *  Si es un consumo, geanmovd.consum = 'S' o geanmovd.consum = 'L', 
         *  se marca como consumo el movimiento del origen.                  
         *  Si es una devolución de consumo, geanmovd.consum = 'D' o         
         *  geanmovd.consum = 'E' se marca el destino como consumo.          
         */
        var mStrOriConsum = mObjGdwhLintdocd.consum == 'S' || mObjGdwhLintdocd.consum == 'L' ? 1 : 0;
        var mStrDesConsum = mObjGdwhLintdocd.consum == 'D' || mObjGdwhLintdocd.consum == 'E' ? 1 : 0;

        /**
         *  Seteo y unseteo de variables no pertenecientes a la tabla pero que
         *  se necesitan.                                                     
         */
        var mStrTipmov = mObjGdwhLintdocd.tipmov;
        delete mObjGdwhLintdocd.tipmov;
        var mStrTabori = mObjGdwhLintdocd.tabori2;
        delete mObjGdwhLintdocd.tabori2;
        var mStrTerstk = mObjGdwhLintdocd.terstk;
        delete mObjGdwhLintdocd.terstk;
        var mStrAlmori = mObjGdwhLintdocd.codalm; 
        var mStrAlmdes = mObjGdwhLintdocd.almaux;
        var mStrCtaori = mObjGdwhLintdocd.cuenta;
        var mStrCtades = mObjGdwhLintdocd.cueaux; 

        //  Comprobación de saldo de las cuentas intervienientes.
        var mStrGrabar = __local_check_grabar(mObjGdwhLintdocd.cuenta, mObjGdwhLintdocd.cueaux);

        /**
         * ==================================================================
         *  Logica de montaje del contramovimiento                            
         *                                                                  
         *  Al construir el contramovimiento tenemos que dar la vuelta a      
         *  ciertos valores-campos :                                          
         *                                                                  
         *  Cruzar codalm-almaux : Solo si el movimiento es de tipmov='T'     
         *  Cruzar cuenta-cueaux                                              
         *  Cruzar codubi-ubiaux                                              
         *  Cambiar el signo aritmetico a canmov-impcos                       
         *                                                                  
         *  Las variables de contramovimiento se asignan dentro del           
         *  FOREACH de lineas.                                                
         *                                                                  
         *  ==================================================================
         */

        // Se procede a grabar el documento si procede.
        
        if (mStrGrabar != 'N') {
            /**
             *  Asignacion de valores provenientes de los documentos origen.  
             *  Busca fecori en los posibles documentos origen.               
             */
            if (mObjGdwhLintdocd.docori != null && mObjGdwhLintdocd.docori != mCharNull) {
                switch (mStrTabori) {
                    //  Suministros de Compras.
                    case 'TC':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gcommovh.fecmov, ${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gcommovh' />
                                <where>
                                    gcommovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    //  Expediciones de Ventas.   
                    case 'TV':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gvenmovh.fecmov, ${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gvenmovh' />
                                <where>
                                    gvenmovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    //  Propuestas de movimiento. 
                    case 'gmovproh':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gmovproh.fecha, ${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gmovproh' />
                                <where>
                                    gmovproh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    //  Pedidos de venta.
                    case 'PV':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gvenpedh.fecha, ${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gvenpedh' />
                                <where>
                                    gvenpedh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    //  Solicitudes de consumo/compra.   
                    case 'gcomsolh':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gcomsolh.fecsol, ${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gcomsolh' />
                                <where>
                                    gcomsolh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    //  Movimientos EAN.   
                    case 'EA':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>geanmovh.fecmov, ${mDatNull}</nvl> fecori
                                </columns>
                                <from table='geanmovh' />
                                <where>
                                    geanmovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;
                    
                    default:
                        throw new Ax.lang.Exception(`__local_gdwh_gen_geanmovh: Tabla [${mStrTabori}] no contemplada.`);                     

                    break;
                }
            }

            /**
             *  Si no ha encontrado el documento origen lintdocd_fecori,
             *  le asignamos el valor constante m_datenull.             
             */
            if (mObjGdwhLintdocd.fecori == null) {
                mObjGdwhLintdocd.fecori = mDatNull;
            }

            var mArrGdwhLintdocd = Ax.db.executeQuery(`
                <select prefix='gdwh_lintdocd_'>
                    <columns>
                        <nvl>gartfami.secana,'${mCharNull}'</nvl> seccio,
                        <nvl>garticul.codfam,'${mCharNull}'</nvl> codfam,
                        geanmovl.codart,
                        geanmovl.varstk,
                        geanmovl.udmori,
                        geanmovl.udmdes,
                        geanmovl.numlot,
                        geanmovl.codean,
                        geanmovl.terdep,
                        geanmovl.ubiori codubi,
                        geanmovl.ubides ubiaux,
                        -1 * geanmovl.canmov canmov,
                        <nvl>geanmovl.impcos, 0</nvl> *
                        gart_unidefs_get_canbase(1,
                                geanmovl.codart, geanmovl.varstk, geanmovl.udmori,
                                NULL,            geanmovl.canmov, NULL) *
                        gartvarl.unicon * -1 impcos,
                        garticul.stock
                    </columns>
                    <from table='geanmovl'>
                        <join type='left' table='garticul'>
                            <on>geanmovl.codart = garticul.codigo</on>
                            <join type='left' table='gartfami'>
                                <on>garticul.codfam = gartfami.codigo</on>
                            </join>
                        </join>
                        <join type='left' table='gartvarl'>
                            <on>geanmovl.codart = gartvarl.codart</on>
                            <on>geanmovl.varstk = gartvarl.varlog</on>
                        </join>
                    </from>
                    <where>
                        geanmovl.cabid = ?
                    </where>
                </select>
            `, mObjGdwhLintdocd.cabid).toMemory();

            //  Inserción de las lineas.
            for (mObjGdwhLintdocd of mArrGdwhLintdocd) {
                /**
                 *  Seteo y unseteo de variables no pertenecientes a la tabla pero que 
                 *  se necesitan.                                                      
                 */
                var mStrUdmori = mObjGdwhLintdocd.udmori;
                var mStrUdmdes = mObjGdwhLintdocd.udmdes || mObjGdwhLintdocd.udmori;
                delete mObjGdwhLintdocd.udmori;
                delete mObjGdwhLintdocd.udmdes;

                var mStrStock = mObjGdwhLintdocd.stock;
                delete mObjGdwhLintdocd.stock;
                var mStrUbiori = mObjGdwhLintdocd.codubi;
                var mStrUbides = mObjGdwhLintdocd.ubiaux;

                // OJO!. Si mStrStock = 'N' no se graba el registro.  
                if (mStrStock == null || mStrStock == 'N') {
                    continue;
                }

                //  Realiza el/los insert/s  en gdwh_lintdocd. 
                var mRegexp = /(A|M)/;
                if (mRegexp.test(mStrGrabar)){
                    mRegexp = /(O|A)/;
                    if (!mRegexp.test(mStrTerstk)){
                        mObjGdwhLintdocd.terdep = mCharNull;
                    }

                    //  Unidad de medida
                    mObjGdwhLintdocd.coduni = mStrUdmori;
                    mObjGdwhLintdocd.consum = mStrOriConsum;
                    
                    Ax.db.insert('gdwh_lintdocd', mObjGdwhLintdocd);
                }

                mRegexp = /(A|C)/;
                if (mRegexp.test(mStrGrabar)){
                    mRegexp = /(D|A)/;
                    if (!mRegexp.test(mStrTerstk)){
                        mObjGdwhLintdocd.terdep = mCharNull;
                    }

                    //  Almacenes
                    if (mStrTipmov == 'T') {    //  Traspasos
                        mObjGdwhLintdocd.codalm = mStrAlmdes;
                        mObjGdwhLintdocd.almaux = mStrAlmori;
                    }

                    // Cuentas
                    mObjGdwhLintdocd.cuenta = mStrCtades;
                    mObjGdwhLintdocd.cueaux = mStrCtaori;

                    //  Ubicaciones
                    mObjGdwhLintdocd.codubi = mStrUbides;
                    mObjGdwhLintdocd.ubiaux = mStrUbiori;

                    //  Cantidad-coste
                    mObjGdwhLintdocd.canmov = -mObjGdwhLintdocd.canmov;
                    mObjGdwhLintdocd.impcos = -mObjGdwhLintdocd.impcos;

                    mObjGdwhLintdocd.consum = mStrDesConsum;

                    Ax.db.insert('gdwh_lintdocd', mObjGdwhLintdocd);

                    /**
                     *  Restauramos los valores originales de las variables para el 
                     *  siguiente insert.                                           
                     */
                    mObjGdwhLintdocd.codalm = mStrAlmori;
                    mObjGdwhLintdocd.almaux = mStrAlmdes;
                    mObjGdwhLintdocd.cuenta = mStrCtaori;
                    mObjGdwhLintdocd.cueaux = mStrCtades;
                }
            }
        }
    }

    /**
     * ======================================================================== 
     *                                                               
     *  FUNC: __local_gdwh_gen_gvenmovh                                  
     *                                                                 
     *  Función que procesa las Expediciones a generar.                
     * 
     * ========================================================================                                                                 
     */
    function __local_gdwh_gen_gvenmovh(pIntCabid, pStrValida) {

        //  Inicialización de variables 
        var mCharNull = '-';                        // Campos char que no se informan  
        var mDatNull = new Ax.sql.Date(1900,1,1);   // Campos date que no se informan
        var mNumNull = 0;                           // Campos numericos que no se informan         
        var mObjGdwhLintdocd = {};                        
        mObjGdwhLintdocd.semmes = 'A';              // Indicativo de actualización de semanas/meses                       
        mObjGdwhLintdocd.agrega = 'N';              // Indicativo de agregación                                           
        mObjGdwhLintdocd.valida = pStrValida;       // Indicativo de validación

        /**
         *  Asigna valores a variables auxiliares no informadas.                
         *  Si se quisieran informar, se habrian de setear dentro del foreach   
         *  de los documentos para asignar el valor segun el documento que se   
         *  este procesando en cada momento.                                    
         */
        for (var index = 0; index <= 4; index++) {      // Alfanumericas 
            mObjGdwhLintdocd[`auxal${index}`] = mCharNull;
            mObjGdwhLintdocd[`auxnu${index}`] = mNumNull;            
        }

        // Selección de datos de cabecera. 
        mObjGdwhLintdocd = Ax.db.executeQuery(`
            <select>
                <columns>
                    gvenmovh.cabid,
                    'TV' tabori,
                    gvenmovh.fecmov fecha,
                    gvenmovh.empcode,
                    gvenmovh.almori codalm,
                    CASE WHEN gvenmovh.almdes IS NULL OR
                              <length>gvenmovh.almdes</length> = 0
                         THEN '${mCharNull}'
                         ELSE gvenmovh.almdes
                     END almaux,
                    gvenmovh.delega,
                    gvenmovh.depart,
                    gvenmovh.tipdoc,
                    CASE WHEN gvenmovh.clasif IS NULL OR
                              <length>gvenmovh.clasif</length> = 0
                         THEN '${mCharNull}'
                         ELSE gvenmovh.clasif
                     END cladoc,
                    gvenmovh.docser,
                    CASE WHEN gvenmovh.docori IS NULL OR
                              <length>gvenmovh.docori</length> = 0
                         THEN '${mCharNull}'
                         ELSE gvenmovh.docori
                     END docori,
                    CASE WHEN gvenmovh.refter IS NULL OR
                              <length>gvenmovh.refter</length> = 0
                         THEN '${mCharNull}'
                         ELSE gvenmovh.refter
                     END refter,
                    ${mDatNull} fecori,
                    gvenmovd.ctaori cuenta,
                    gvenmovd.ctades cueaux,
                    gvenmovd.tipmov,
                    gvenmovd.tabori tabori2,
                    gvenmovd.terstk,
                    gvenmovd.consum
                </columns>
                <from table='gvenmovh'>
                    <join table='gvenmovd'>
                        <on>gvenmovh.tipdoc = gvenmovd.codigo</on>
                    </join>
                </from>
                <where>
                    gvenmovh.cabid = ?
                </where>
            </select>            
        `, pIntCabid).toOne();

        /**
         *  Seteo y unseteo de variables no pertenecientes a la tabla pero que 
         *  se necesitan.                                                      
         */
        var mStrTipmov = mObjGdwhLintdocd.tipmov;
        delete mObjGdwhLintdocd.tipmov;
        var mStrTabori = mObjGdwhLintdocd.tabori2;
        delete mObjGdwhLintdocd.tabori2; 
        var mStrTerstk = mObjGdwhLintdocd.terstk;
        delete mObjGdwhLintdocd.terstk;
        var mStrAlmori = mObjGdwhLintdocd.codalm;
        var mStrAlmdes = mObjGdwhLintdocd.almaux;
        var mStrCtaori = mObjGdwhLintdocd.cuenta;
        var mStrCtades = mObjGdwhLintdocd.cueaux;

        /**
         *  Si es un consumo, gvenmovd.consum = 'S' o gvenmovd.consum = 'L',  
         *  se marca como consumo el movimiento del origen.                   
         *  Si es una devolución de consumo, gvenmovd.consum = 'D' o          
         *  gvenmovd.consum = 'E' se marca el destino como consumo.           
         */
        var mStrOriConsum = mObjGdwhLintdocd.consum == 'S' || mObjGdwhLintdocd.consum == 'L' ? 1 : 0;
        var mStrDesConsum = mObjGdwhLintdocd.consum == 'D' || mObjGdwhLintdocd.consum == 'E' ? 1 : 0;

        //  Comprobación de saldo de las cuentas intervienientes.
        var mStrGrabar = __local_check_grabar(mObjGdwhLintdocd.cuenta, mObjGdwhLintdocd.cueaux);

        /**
         *  Logica de montaje del contramovimiento                       
         *                                                              
         *  Al construir el contramovimiento tenemos que dar la vuelta a 
         *  ciertos valores-campos :                                     
         *                                                              
         *  Cruzar codalm-almaux : Solo si el movimiento es de tipmov='T'
         *  Cruzar cuenta-cueaux                                         
         *  Cruzar codubi-ubiaux                                         
         *  Cambiar el signo aritmetico a canmov-impcos                  
         *                                                              
         *  Las variables de contramovimiento se asignan dentro del      
         *  FOREACH de lineas.                                                
         */

        // Se procede a grabar el documento si procede.   
        if (mStrGrabar != 'N') {
            /**
             *  Asignacion de valores provenientes de los documentos origen. 
             *  Busca fecori en los posibles documentos origen.              
             */
            if (mObjGdwhLintdocd.docori != null && mObjGdwhLintdocd.docori != mCharNull) {
                switch (mStrTabori) {
                    // Propuestas de movimiento.  
                    case 'gmovproh':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gmovproh.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gmovproh' />
                                <where>
                                    gmovproh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Pedidos de Ventas.     
                    case 'PV':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gvenpedh.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gvenpedh' />
                                <where>
                                    gvenpedh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    // Expediciones de Ventas.   
                    case 'TV':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gvenmovh.fecmov,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gvenmovh' />
                                <where>
                                    gvenmovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    // Facturas de Ventas.   
                    case 'FV':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gvenfach.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gvenfach' />
                                <where>
                                    gvenfach.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Movimientos EAN.     
                    case 'EA':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>geanmovh.fecmov,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='geanmovh' />
                                <where>
                                    geanmovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Ordenes de produccion.    
                    case 'OP':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gpro_ordprodh.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gpro_ordprodh' />
                                <where>
                                    gpro_ordprodh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;                    
                
                    default:
                        throw new Ax.lang.Exception(`__local_gdwh_gen_gvenmovh: Tabla [${mStrTabori}] no contemplada.`);
                    break;
                }
                
            }

            /**
             *  Si no ha encontrado el documento origen lintdocd_fecori, 
             *  le asignamos el valor constante m_datenull.              
             */
            if (mObjGdwhLintdocd.fecori == null) {
                mObjGdwhLintdocd.fecori = mDatNull;
            }

            /**
             *  Inserción de las lineas.                                
             *  Atencion, este select intenta enlazar con el posible    
             *  gvenmovm relacionado (gvenmovm.linkit = gvenmovl.linid) 
             *  Por si lo que viniera en gvenmovl.codart fuera un KIT   
             *  y en gvenmovm tuvieramos el desglose del tal KIT        
             */
            var mArrGdwhLintdocd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN <nvl>gartfami2.secana,'${mCharNull}'</nvl>
                             ELSE <nvl>gartfami.secana,'${mCharNull}'</nvl>
                         END seccio,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN <nvl>garticul2.codfam,'${mCharNull}'</nvl>
                             ELSE <nvl>garticul.codfam,'${mCharNull}'</nvl>
                         END codfam,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.codart
                             ELSE gvenmovl.codart
                         END codart,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.varstk
                             ELSE gvenmovl.varstk
                         END varstk,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.udmven
                             ELSE gvenmovl.udmven
                         END coduni,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.numlot
                             ELSE gvenmovl.numlot
                         END numlot,
                        '${mCharNull}' codean,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.terdep
                             ELSE gvenmovl.terdep
                         END terdep,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.ubiori
                             ELSE gvenmovl.ubiori
                         END codubi,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.ubides
                             ELSE gvenmovl.ubides
                         END ubiaux,
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN gvenmovm.canmov
                             ELSE gvenmovl.canmov
                         END * -1 canmov,    <!-- Siempre se lee con signo inverso -->
                        CASE WHEN gvenmovm.linid IS NOT NULL
                             THEN (<nvl>gvenmovm.impcos, 0</nvl> * gartvarl2.unicon)
                             ELSE (<nvl>gvenmovl.impcos, 0</nvl> * gartvarl.unicon)
                         END impcos,    <!-- Se multiplica por cantidad más abajo -->
                        CASE WHEN garticul2.codfam IS NOT NULL
                             THEN garticul2.stock
                             ELSE garticul.stock
                         END stock
                    </columns>
                    <from table='gvenmovl'>
                        <join type='left' table='garticul'>
                            <on>gvenmovl.codart = garticul.codigo</on>
                            <join type='left' table='gartfami'>
                                <on>garticul.codfam = gartfami.codigo</on>
                            </join>
                        </join>
                        <join type='left' table='gartvarl'>
                            <on>gvenmovl.codart = gartvarl.codart</on>
                            <on>gvenmovl.varstk = gartvarl.varlog</on>
                        </join>
                        <join type='left' table='gvenmovm'>
                            <on>gvenmovl.linid = gvenmovm.linkit</on>
                            <join type='left' table='garticul' alias='garticul2'>
                                <on>gvenmovm.codart = garticul2.codigo</on>
                                <join type='left' table='gartfami' alias='gartfami2'>
                                    <on>garticul2.codfam = gartfami2.codigo</on>
                                </join>
                            </join>
                            <join type='left' table='gartvarl' alias='gartvarl2'>
                                <on>gvenmovm.codart = gartvarl2.codart</on>
                                <on>gvenmovm.varstk = gartvarl2.varlog</on>
                            </join>
                        </join>
                    </from>
                    <where>
                        gvenmovl.cabid = ?
                    </where>
                </select>   
            `, mObjGdwhLintdocd.cabid).toMemory();

            for (mObjGdwhLintdocd of mArrGdwhLintdocd) {
                mObjGdwhLintdocd.impcos = mObjGdwhLintdocd.impcos * mObjGdwhLintdocd.canmov;

                /**
                 *  Seteo y unseteo de variables no pertenecientes a la tabla pero qu 
                 *  se necesitan.                                                     
                 */
                var mStrStock = mObjGdwhLintdocd.stock;
                delete mObjGdwhLintdocd.stock;
                var mStrUbiori = mObjGdwhLintdocd.codubi;
                var mStrUbides = mObjGdwhLintdocd.ubiaux;

                //  OJO!. Si m_stock = 'N' no se graba el registro. 
                if (mStrStock == null || mStrStock == 'N') {
                    continue;
                }

                //  Realiza el/los insert/s  en gdwh_lintdocd. 
                let mRegexp = /(A|M)/;
                if (mRegexp.test(mStrGrabar)){
                    mRegexp = /(O|A)/;
                    if (!mRegexp.test(mStrTerstk)){
                        mObjGdwhLintdocd.terdep = mCharNull;
                    }

                    mObjGdwhLintdocd.consum = mStrOriConsum;

                    Ax.db.insert('gdwh_lintdocd', mObjGdwhLintdocd);
                }

                mRegexp = /(A|C)/;
                if (mRegexp.test(mStrGrabar)){
                    mRegexp = /(D|A)/;
                    if (!mRegexp.test(mStrTerstk)){
                        mObjGdwhLintdocd.terdep = mCharNull;
                    }

                    //  Almacenes
                    if (mStrTipmov == 'T') {    // Traspasos
                        mObjGdwhLintdocd.codalm = mStrAlmdes;
                        mObjGdwhLintdocd.almaux = mStrAlmori;
                    }

                    //  Cuentas
                    mObjGdwhLintdocd.cuenta = mStrCtades;
                    mObjGdwhLintdocd.cueaux = mStrCtaori;

                    //  Ubicaciones
                    mObjGdwhLintdocd.codubi = mStrUbides;
                    mObjGdwhLintdocd.ubiaux = mStrUbiori;

                    //  Cantidad-coste
                    mObjGdwhLintdocd.canmov = -mObjGdwhLintdocd.canmov;
                    mObjGdwhLintdocd.impcos = -mObjGdwhLintdocd.impcos;

                    mObjGdwhLintdocd.consum = mStrDesConsum;

                    Ax.db.insert('gdwh_lintdocd', mObjGdwhLintdocd)

                    /**
                     *  Restauramos los valores originales de las variables para el     
                     *  siguiente insert.                                               
                     */
                    mObjGdwhLintdocd.codalm = mStrAlmori;
                    mObjGdwhLintdocd.almaux = mStrAlmdes;
                    mObjGdwhLintdocd.cuenta = mStrCtaori;
                    mObjGdwhLintdocd.cueaux = mStrCtades;
                }

            }
            
        }

    }

    /**
     * ========================================================================
     * 
     *  FUNC: __local_gdwh_gen_gcommovh 
     * 
     *  Función que procesa los Suministros a generar.
     * 
     * ========================================================================
     */
    function __local_gdwh_gen_gcommovh(pIntCabid,pStrValida) {

        //  Inicialización de variables 
        var mCharNull = '-';                        // Campos char que no se informan  
        var mDatNull = new Ax.sql.Date(1900,1,1);   // Campos date que no se informan
        var mNumNull = 0;                           // Campos numericos que no se informan         
        var mObjGdwhLintdocd = {};                        
        mObjGdwhLintdocd.semmes = 'A';              // Indicativo de actualización de semanas/meses                       
        mObjGdwhLintdocd.agrega = 'N';              // Indicativo de agregación                                           
        mObjGdwhLintdocd.valida = pStrValida;       // Indicativo de validación
        
        /**
         *  Asigna valores a variables auxiliares no informadas.               
         *  Si se quisieran informar, se habrian de setear dentro del foreach  
         *  de los documentos para asignar el valor segun el documento que se  
         *  este procesando en cada momento.                                   
         */
        for (var index = 0; index <= 4; index++) {      // Alfanumericas 
            mObjGdwhLintdocd[`auxal${index}`] = mCharNull;
            mObjGdwhLintdocd[`auxnu${index}`] = mNumNull;            
        }

        //  Selección de datos de cabecera. 
        mObjGdwhLintdocd = Ax.db.executeQuery(`
            <select>
                <columns>
                    gcommovh.cabid,
                    'TC' tabori,
                    gcommovh.fecmov fecha,
                    gcommovh.empcode,
                    gcommovh.almori codalm,
                    CASE WHEN gcommovh.almdes IS NULL OR
                              <length>gcommovh.almdes</length> = 0
                         THEN '${mCharNull}'
                         ELSE gcommovh.almdes
                     END almaux,
                    gcommovh.delega,
                    gcommovh.depart,
                    gcommovh.tipdoc,
                    CASE WHEN gcommovh.clasif IS NULL OR
                              <length>gcommovh.clasif</length> = 0
                         THEN '${mCharNull}'
                         ELSE gcommovh.clasif
                     END cladoc,
                    gcommovh.docser,
                    CASE WHEN gcommovh.docori IS NULL OR
                              <length>gcommovh.docori</length> = 0
                         THEN '${mCharNull}'
                         ELSE gcommovh.docori
                     END docori,
                    CASE WHEN gcommovh.refter IS NULL OR
                              <length>gcommovh.refter</length> = 0
                         THEN '${mCharNull}'
                         ELSE gcommovh.refter
                     END refter,
                    ${mDatNull} fecori,
                    gcommovd.ctaori cuenta,
                    gcommovd.ctades cueaux,
                    gcommovd.tipmov,
                    gcommovd.tabori tabori2,
                    gcommovd.terstk,
                    gcommovd.consum
                </columns>
                <from table='gcommovh'>
                    <join table='gcommovd'>
                        <on>gcommovh.tipdoc = gcommovd.codigo</on>
                    </join>
                </from>
                <where>
                    gcommovh.cabid = ?
                </where>
            </select>
        `, pIntCabid).toOne()

        /**
         *  Seteo y unseteo de variables no pertenecientes a la tabla pero que 
         *  se necesitan.                                                      
         */
        var mStrTipmov = mObjGdwhLintdocd.tipmov;
        delete mObjGdwhLintdocd.tipmov;
        var mStrTabori = mObjGdwhLintdocd.tabori2;
        delete mObjGdwhLintdocd.tabori2; 
        var mStrTerstk = mObjGdwhLintdocd.terstk;
        delete mObjGdwhLintdocd.terstk;
        var mStrAlmori = mObjGdwhLintdocd.codalm;
        var mStrAlmdes = mObjGdwhLintdocd.almaux;
        var mStrCtaori = mObjGdwhLintdocd.cuenta;
        var mStrCtades = mObjGdwhLintdocd.cueaux;

        //  Comprobación de saldo de las cuentas intervienientes.
        var mStrGrabar = __local_check_grabar(mObjGdwhLintdocd.cuenta, mObjGdwhLintdocd.cueaux);

        /**
         *  Si es un consumo, geanmovd.consum = 'S' o geanmovd.consum = 'L',  
         *  se marca como consumo el movimiento del origen.                   
         *  Si es una devolución de consumo, geanmovd.consum = 'D' o          
         *  geanmovd.consum = 'E' se marca el destino como consumo.           
         */
        var mStrOriConsum = mObjGdwhLintdocd.consum == 'S' || mObjGdwhLintdocd.consum == 'L' ? 1 : 0;
        var mStrDesConsum = mObjGdwhLintdocd.consum == 'D' || mObjGdwhLintdocd.consum == 'E' ? 1 : 0;

        /**
         * Logica de montaje del contramovimiento                             
         *                                                         
         *  Al construir el contramovimiento tenemos que dar la vuelta a       
         *  ciertos valores-campos :                                           
         *                                                                  
         *  Cruzar codalm-almaux : Solo si el movimiento es de tipmov='T'      
         *  Cruzar cuenta-cueaux                                               
         *  Cruzar codubi-ubiaux                                               
         *  Cambiar el signo aritmetico a canmov-impcos                        
         *                                                                  
         *  Las variables de contramovimiento se asignan dentro del            
         *  FOREACH de lineas.                                                                                                       
         */

        // Se procede a grabar el documento si procede.
        if (mStrGrabar != 'N') {
            /**
             *  Asignacion de valores provenientes de los documentos origen.       
             *  Busca fecori en los posibles documentos origen.                    
             */
            if (mObjGdwhLintdocd.docori != null && mObjGdwhLintdocd.docori != mCharNull) {
                switch (mStrTabori) {
                    // Solicitudes de Consumos.    
                    case 'SC':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gcomsolh.fecsol,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gcommovh' />
                                <where>
                                    gcomsolh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Pedidos de Compras.    
                    case 'PC':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gcompedh.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gcompedh' />
                                <where>
                                    gcompedh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    // Suministros de Compras.    
                    case 'TC':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gcommovh.fecmov,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gcommovh' />
                                <where>
                                    gcommovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);

                    break;

                    // Propuestas de movimiento.    
                    case 'gmovproh':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gmovproh.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gmovproh' />
                                <where>
                                    gmovproh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Ordenes de Trabajo.     
                    case 'OT':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gman_ordetrah.fecpre,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gman_ordetrah' />
                                <where>
                                    gman_ordetrah.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Facturas de Compra.     
                    case 'FC':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gcomfach.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gcomfach' />
                                <where>
                                    gcomfach.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Acuerdos de Compra.      
                    case 'MC':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gcomacuh.fecacu,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gcomacuh' />
                                <where>
                                    gcomacuh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Expediciones de Ventas.       
                    case 'TV':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gvenmovh.fecmov,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gvenmovh' />
                                <where>
                                    gvenmovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Movimientos EAN.        
                    case 'EA':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>geanmovh.fecmov,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='geanmovh' />
                                <where>
                                    geanmovh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;

                    // Ordenes de produccion.         
                    case 'OP':
                        mObjGdwhLintdocd.fecori = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    <nvl>gpro_ordprodh.fecha,${mDatNull}</nvl> fecori
                                </columns>
                                <from table='gpro_ordprodh' />
                                <where>
                                    gpro_ordprodh.docser = ?
                                </where>
                            </select>
                        `, mObjGdwhLintdocd.docori);
                        
                    break;
                
                    default:
                        throw new Ax.lang.Exception(`__local_gdwh_gen_gcommovh: Tabla [${mStrTabori}] no contemplada.`);
                    break;
                }
                
            }

            /**
             *  Si no ha encontrado el documento origen lintdocd_fecori,  
             *  le asignamos el valor constante m_datenull.               
             */
            if (mObjGdwhLintdocd.fecori == null) {
                mObjGdwhLintdocd.fecori = mDatNull;
            }

            //  Inserción de las lineas. 
            var mArrGdwhLintdocd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        <nvl>gartfami.secana,'${mCharNull}'</nvl> seccio,
                        <nvl>garticul.codfam,'${mCharNull}'</nvl> codfam,
                        gcommovl.codart,
                        gcommovl.varlog varstk,
                        gcommovl.udmcom coduni,
                        gcommovl.numlot,
                        '${mCharNull}' codean,
                        gcommovl.terdep,
                        gcommovl.ubiori codubi,
                        gcommovl.ubides ubiaux,
                        -1 * gcommovl.canmov canmov,
                        <nvl>gcommovl.impcos, 0</nvl> *
                        gart_unidefs_get_canbase(1,
                                gcommovl.codart, gcommovl.varlog, gcommovl.udmcom,
                                gcommovl.udmalt, gcommovl.canmov, gcommovl.canalt) *
                        gartvarl.unicon * -1 impcos,
                        garticul.stock
                    </columns>
                    <from table='gcommovl'>
                        <join type='left' table='garticul'>
                            <on>gcommovl.codart = garticul.codigo</on>
                            <join type='left' table='gartfami'>
                                <on>garticul.codfam = gartfami.codigo</on>
                            </join>
                        </join>
                        <join type='left' table='gartvarl'>
                            <on>gcommovl.codart = gartvarl.codart</on>
                            <on>gcommovl.varlog = gartvarl.varlog</on>
                        </join>
                    </from>
                    <where>
                        gcommovl.cabid = ?
                    </where>
                </select>
            `, mObjGdwhLintdocd.cabid).toMemory();

            for (mObjGdwhLintdocd of mArrGdwhLintdocd) {
                /**
                 *  Seteo y unseteo de variables no pertenecientes a la tabla pero que 
                 *  se necesitan.                                                      
                 */
                var mStrStock = mObjGdwhLintdocd.stock;
                delete mObjGdwhLintdocd.stock;
                var mStrUbiori = mObjGdwhLintdocd.codubi;
                var mStrUbides = mObjGdwhLintdocd.ubiaux;

                //  OJO!. Si m_stock = 'N' no se graba el registro.  
                if (mStrStock == null || mStrStock == 'N') {
                    mStrGrabar = 'N';
                }

                // Realiza el/los insert/s  en gdwh_lintdocd.   
                var mRegexp = /(A|M)/;
                if (mRegexp.test(mStrGrabar)){
                    mRegexp = /(O|A)/;
                    if (!mRegexp.test(mStrGrabar)){
                        mObjGdwhLintdocd.terdep = mCharNull;
                    }

                    mObjGdwhLintdocd.consum = mStrOriConsum;

                    Ax.db.insert('gdwh_lintdocd', mObjGdwhLintdocd);
                }

                mRegexp = /(A|C)/;
                if (mRegexp.test(mStrGrabar)){
                    mRegexp = /(D|A)/;
                    if (!mRegexp.test(mStrTerstk)){
                        mObjGdwhLintdocd.terdep = mCharNull;
                    }

                    //  Almacenes
                    if (mStrTipmov == 'T') {    // Traspasos
                        mObjGdwhLintdocd.codalm = mStrAlmdes;
                        mObjGdwhLintdocd.almaux = mStrAlmori;
                    }

                    //  Cuentas
                    mObjGdwhLintdocd.cuenta = mStrCtades;
                    mObjGdwhLintdocd.cueaux = mStrCtaori;

                    //  Ubicaciones
                    mObjGdwhLintdocd.codubi = mStrUbides;
                    mObjGdwhLintdocd.ubiaux = mStrUbiori;

                    //  Cantidad-coste
                    mObjGdwhLintdocd.canmov = -mObjGdwhLintdocd.canmov;
                    mObjGdwhLintdocd.impcos = -mObjGdwhLintdocd.impcos;

                    mObjGdwhLintdocd.consum = mStrDesConsum;

                    Ax.db.insert('gdwh_lintdocd', mObjGdwhLintdocd)

                    /**
                     *  Restauramos los valores originales de las variables para el  
                     *  siguiente insert.                                            
                     */
                    mObjGdwhLintdocd.codalm = mStrAlmori;
                    mObjGdwhLintdocd.almaux = mStrAlmdes;
                    mObjGdwhLintdocd.cuenta = mStrCtaori;
                    mObjGdwhLintdocd.cueaux = mStrCtades;

                }

            }

        }

    }

    /**
     *  Control de errores                                                   
     *                                                                       
     *  Borrar los errores producidos en ejecuciones anteriores de facturas y
     *  sus descuentos.  
     *                                                     
     */
    var mStrProname = 'WLINDOC';        // Logistica Internos Documentos
    Ax.db.delete('gdwh_interr', 
        `
            proname = 'WLINDOC' AND
            delalm  ${pStrCodalm}   
        `
    );

    /**
     *  Procesa los registros existentes en la tabla de tracking para:          
     *                                                               
     *  Suministros     (gcommovh)                                              
     *  Expediciones    (gvenmovh)                                              
     *  Movimientos EAN (geanmovh)                                              
     *                                                                          
     *  El join con la tabla g???movh se hace porque es necesario procesar los  
     *  documentos ordenados cronológicamente (fecha), porque en los niveles    
     *  mensual y anual del DWH, por cada registro del periodo actual, se guarda
     *  el mismo dato del mismo periodo del año anterior. Esto es muy eficiente 
     *  cuando se realizan informes comparativos de un año frente al anterior.  
     *                                                                         
     */
    var mArrGdocTrasp = Ax.db.executeQuery(`
        <union type='all'>
            <!-- Suministros -->
            <select>
                <columns>
                    gdoc_traspaso.tabname, gcommovh.empcode, gcommovh.almori codalm, gcommovh.fecmov,
                    gcommovh.docser,       gdoc_traspaso.colval,
                    MAX(gdoc_traspaso.tipope) tipope
                </columns>
                <from table='gdoc_traspaso'>
                    <join table='gcommovh'>
                        <on>gdoc_traspaso.colval = gcommovh.cabid</on>
                    </join>
                    <join table='gcommovd'>
                        <on>gcommovh.tipdoc = gcommovd.codigo</on>
                    </join>
                </from>
                <where>
                    gdoc_traspaso.tabname = 'gcommovh' AND
                    gdoc_traspaso.colname = 'cabid'    AND
                    gdoc_traspaso.tippro  = 0          AND
                    gdoc_traspaso.tipope != 2          AND
                    gcommovh.fecmov       BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    gcommovd.tipmov       IN ('I','T','C') AND
                    gcommovh.empcode ${pStrEmpcode} AND
                    gcommovh.almori ${pStrCodalm}
                </where>
                <group>
                    tabname, empcode, almori, fecmov, docser, colval
                </group>
            </select>

            <select>
                <columns>
                    gdoc_traspaso.tabname, gdwh_lintdocd.empcode, gdwh_lintdocd.codalm, gdwh_lintdocd.fecha fecmov,
                    gdwh_lintdocd.docser,  gdoc_traspaso.colval,
                    MAX(gdoc_traspaso.tipope) tipope
                </columns>
                <from table='gdoc_traspaso'>
                    <join table='gdwh_lintdocd'>
                        <on>gdoc_traspaso.colval = gdwh_lintdocd.cabid</on>
                    </join>
                    <join table='gcommovd'>
                        <on>gdwh_lintdocd.tipdoc = gcommovd.codigo</on>
                    </join>
                </from>
                <where>
                    gdoc_traspaso.tabname = 'gcommovh' AND
                    gdoc_traspaso.colname = 'cabid'    AND
                    gdoc_traspaso.tippro  = 0          AND
                    gdoc_traspaso.tipope  = 2          AND
                    gdwh_lintdocd.tabori  = 'TC'       AND
                    gdwh_lintdocd.fecha   BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    gcommovd.tipmov       IN ('I','T','C') AND
                    gdwh_lintdocd.empcode ${pStrEmpcode} AND
                    gdwh_lintdocd.codalm  ${pStrCodalm}
                </where>
                <group>
                    tabname, empcode, codalm, fecha, docser, colval
                </group>
            </select>

            <!-- Expediciones -->
            <select>
                <columns>
                    gdoc_traspaso.tabname, gvenmovh.empcode, gvenmovh.almori codalm, gvenmovh.fecmov,
                    gvenmovh.docser,       gdoc_traspaso.colval,
                    MAX(gdoc_traspaso.tipope) tipope
                </columns>
                <from table='gdoc_traspaso'>
                    <join table='gvenmovh'>
                        <on>gdoc_traspaso.colval = gvenmovh.cabid</on>
                    </join>
                    <join table='gvenmovd'>
                        <on>gvenmovh.tipdoc = gvenmovd.codigo</on>
                    </join>
                </from>
                <where>
                    gdoc_traspaso.tabname = 'gvenmovh' AND
                    gdoc_traspaso.colname = 'cabid'    AND
                    gdoc_traspaso.tippro  = 0          AND
                    gdoc_traspaso.tipope != 2          AND
                    gvenmovh.fecmov       BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    gvenmovd.tipmov       IN ('I','T','P') AND
                    gvenmovh.empcode ${pStrEmpcode} AND
                    gvenmovh.almori ${pStrCodalm}
                </where>
                <group>
                    tabname, empcode, almori, fecmov, docser, colval
                </group>
            </select>

            <select>
                <columns>
                    gdoc_traspaso.tabname, gdwh_lintdocd.empcode, gdwh_lintdocd.codalm, gdwh_lintdocd.fecha fecmov,
                    gdwh_lintdocd.docser,  gdoc_traspaso.colval,
                    MAX(gdoc_traspaso.tipope) tipope
                </columns>
                <from table='gdoc_traspaso'>
                    <join table='gdwh_lintdocd'>
                        <on>gdoc_traspaso.colval = gdwh_lintdocd.cabid</on>
                    </join>
                    <join table='gvenmovd'>
                        <on>gdwh_lintdocd.tipdoc = gvenmovd.codigo</on>
                    </join>
                </from>
                <where>
                    gdoc_traspaso.tabname = 'gvenmovh' AND
                    gdoc_traspaso.colname = 'cabid'    AND
                    gdoc_traspaso.tippro  = 0          AND
                    gdoc_traspaso.tipope  = 2          AND
                    gdwh_lintdocd.tabori  = 'TV'       AND
                    gdwh_lintdocd.fecha   BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    gvenmovd.tipmov       IN ('I','T','C') AND
                    gdwh_lintdocd.empcode ${pStrEmpcode} AND
                    gdwh_lintdocd.codalm  ${pStrCodalm}
                </where>
                <group>
                    tabname, empcode, codalm, fecha, docser, colval
                </group>
            </select>

            <!-- Movimientos EAN -->
            <select>
                <columns>
                    gdoc_traspaso.tabname, geanmovh.empcode, geanmovh.almori codalm, geanmovh.fecmov,
                    geanmovh.docser,       gdoc_traspaso.colval,
                    MAX(gdoc_traspaso.tipope) tipope
                </columns>
                <from table='gdoc_traspaso'>
                    <join table='geanmovh'>
                        <on>gdoc_traspaso.colval = geanmovh.cabid</on>
                    </join>
                    <join table='geanmovd'>
                        <on>geanmovh.tipdoc = geanmovd.codigo</on>
                    </join>
                </from>
                <where>
                    gdoc_traspaso.tabname = 'geanmovh' AND
                    gdoc_traspaso.colname = 'cabid'    AND
                    gdoc_traspaso.tippro  = 0          AND
                    gdoc_traspaso.tipope != 2          AND
                    geanmovh.fecmov       BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    geanmovd.tipmov       IN ('I','T','A','B','N') AND
                    geanmovh.empcode ${pStrEmpcode} AND
                    geanmovh.almori ${pStrCodalm}
                </where>
                <group>
                    tabname, empcode, almori, fecmov, docser, colval
                </group>
            </select>

            <select>
                <columns>
                    gdoc_traspaso.tabname, gdwh_lintdocd.empcode, gdwh_lintdocd.codalm, gdwh_lintdocd.fecha fecmov,
                    gdwh_lintdocd.docser,  gdoc_traspaso.colval,
                    MAX(gdoc_traspaso.tipope) tipope
                </columns>
                <from table='gdoc_traspaso'>
                    <join table='gdwh_lintdocd'>
                        <on>gdoc_traspaso.colval = gdwh_lintdocd.cabid</on>
                    </join>
                    <join table='geanmovd'>
                        <on>gdwh_lintdocd.tipdoc = geanmovd.codigo</on>
                    </join>
                </from>
                <where>
                    gdoc_traspaso.tabname = 'geanmovh' AND
                    gdoc_traspaso.colname = 'cabid'    AND
                    gdoc_traspaso.tippro  = 0          AND
                    gdoc_traspaso.tipope  = 2          AND
                    gdwh_lintdocd.tabori  = 'EA'       AND
                    gdwh_lintdocd.fecha   BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    geanmovd.tipmov       IN ('I','T','C') AND
                    gdwh_lintdocd.empcode ${pStrEmpcode} AND
                    gdwh_lintdocd.codalm  ${pStrCodalm}
                </where>
                <group>
                    tabname, empcode, codalm, fecha, docser, colval
                </group>
                <order>
                    fecmov, colval
                </order>
            </select>
        </union>
    `).toMemory();

    for (var mRow of mArrGdocTrasp) {       
        //  Control de error y transacción por documento.
        try {
            //  Se abre transaccion por documento. 
            Ax.db.beginWork();

            //  Borrado del documento en caso de Delete (tipope = 2) y salir.
            if (mRow.tipope == 2) {
                Ax.db.delete('gdwh_lintdocd', 
                    {
                        cabid  : mRow.colval,   
                        docser : mRow.docser
                    }
                );

                //  Eliminamos el registro del tracking.
                Ax.db.delete('gdoc_traspaso', 
                    {
                        tabname : mRow.tabname,   
                        colname : 'cabid',
                        colval  : mRow.colval,
                        tippro  : 0,
                        tipope  : 2
                    }
                );

                //  Se cierra la transaccion. 
                Ax.db.commitWork(); 

                continue;
            }

            //  Borrado del documento en caso de Update (tipope = 1). 
            if (mRow.tipope == 1) {
                Ax.db.delete('gdwh_lintdocd', 
                    {
                        cabid  : mRow.colval,   
                        docser : mRow.docser
                    }
                );
            }

            //  Bifurcación del proceso en función de la tabla origen. 
            switch (mRow.tabname) {
                //  Suministros. 
                case 'gcommovh':
                    __local_gdwh_gen_gcommovh(mRow.colval, pStrValida)
                break;

                //  Expediciones.
                case 'gvenmovh':
                    __local_gdwh_gen_gvenmovh(mRow.colval, pStrValida)
                break;

                //  Movimientos EAN.
                case 'geanmovh':
                    __local_gdwh_gen_geanmovh(mRow.colval, pStrValida)
                break;
            
                default:
                    throw new Ax.lang.Exception(`gdwh_gen_lintdocd: Tabla [${mRow.tabname}] no contemplada.`);
                break;
            };

            //  Eliminamos el registro del tracking.  
            Ax.db.delete('gdoc_traspaso', 
                {
                    'tabname': mRow.tabname,
                    'colname': 'cabid',
                    'colval' : mRow.colval,
                    'tippro' : 0
                }
            )

            //  Marcamos el documento como traspasado.  
            Ax.db.update(mRow.tabname, 
                {
                    'movest': 1
                }, 
                {
                    'cabid': mRow.colval
                }
            )      
            
            //Se cierra la transaccion. 
            Ax.db.commitWork();

        } catch (error) {
            //  Se retrocede la transaccion.
            Ax.db.rollbackWork();

            Ax.db.insert('gdwh_interr', 
                {
                    'proname': mStrProname,      
                    'delalm' : mRow.codalm,      
                    'codigo' : mRow.docser,      
                    'fecinf' : mRow.fecmov,      
                    'fecerr' : new Ax.sql.Date(),      
                    'nsql'   : 0,   
                    'nisam'  : 0,   
                    'errmsg' : Ax.util.Error.getMessage(error)    
                }
            )
        }

        Ax.db.commitWork();    
    }

    /**
     *  Agregar el resto de piramides, o sea a partir de 'gdwh_lintdocd'   
     *  cargar 'gdwh_lmovartd', que a su vez cargará las restantes         
     *  pirámides llamando a gdwh_lintdocd_artd al ser el tercer parámetro 
     *  una 'S'.                                                            
     */
    if (pStrValida == 'N') {
        /**
         *  Logística Movimientos-Artículos-Día a partir de     
         *  Logística Movimientos-Documentos-Día.               
         */
        Ax.db.call('gdwh_lintdocd_artd', pStrEmpcode, pStrCodalm, pDatFecini, pDatFecfin, 'S', 'N');
    }
}