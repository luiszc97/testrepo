/**
 *  Js: gdwh_lsumdocd_vdel                                              
 *                                                                      
 *  Script que carga la tabla gdwh_vdelartd desde la tabla gdwh_lsumdocd  
 *  (Logística expediciones-documento) siempre  y cuando la informacion   
 *  hubiera sido cargada con el parametro p_valida = 'N' y los movimientos
 *  sean consumos por delegación                                          
 */
function gdwh_lsumdocd_vdel(pStrEmpcode, pStrCodalm, pDatFecha, pStrIndagr) {
    /**
     *  Control de errores                                      
     *  Borrar los errores producidos en ejecuciones anteriores.
     */
    var mStrProname = 'LSUMVDEL'        // Logística Suministros Ventas delegación 

    Ax.db.delete('gdwh_interr', {proname: mStrProname});

    /**
     *  Procesar registros de gdwh_lsumdocd.  
     */
    var mStrTabname, mIntCount;
    var mArrGdwhLsumdocd = Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT delega, depart, tabori, tipdoc
            </columns>
            <from table='gdwh_lsumdocd' />
            <where>
                fecha  = ${pDatFecha}       AND
                empcode = '${pStrEmpcode}'  AND
                codalm  = '${pStrCodalm}'   AND
                valida = 'N'
            </where>
            <order>
                delega, depart, tabori, tipdoc
            </order>
        </select>
    `);

    for (var mRow of mArrGdwhLsumdocd) {
        /**
         *  Solo se cargan los movimientos de consumo 
         */
        switch (mRow.tabori) {
            case 'EA':
                mStrTabname = 'geanmovd';
            break;

            case 'TV':
                mStrTabname = 'gvenmovd';
            break;

            case 'TC':
                mStrTabname = 'gcommovd';
            break;
        
            default:
            break;
        }

        mIntCount = Ax.db.executeGet(`
            <select>
                <columns>
                    COUNT(*)
                </columns>
                <from table='${mStrTabname}'/>
                <where>
                        codigo = '${mRow.tipdoc}'
                    AND consum NOT IN ('L', 'E')
                </where>
            </select>        
        `);

        if (mIntCount) {
            continue;
        }

        /**
         *  LOGÍSTICA MOVIMIENTOS-ARTÍCULOS-DIA.    
         */
        mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='gdwh_vdelartd' />
                <where>
                    empcode = ? AND
                    codalm = ? AND
                    delega = ? AND
                    depart = ? AND
                    tabori = ? AND
                    tipdoc = ? AND
                    fecha  = ${pDatFecha}
                </where>
            </select>
        `, pStrEmpcode, pStrCodalm, mRow.delega, mRow.depart, mRow.tabori, mRow.tipdoc);

        if (pStrIndagr == 'N' && !mIntCount) {
            var mArrGdwhLsumd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        fecha,  empcode, codalm, delega, depart, tabori, tipdoc, cladoc, seccio,
                        codfam, codart, varstk, coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                        SUM(canmov) canmov, SUM(0) impbru, SUM(0) impnet, SUM(0) impdto,
                        SUM(impcos) impcos, SUM(0) imprap,
                        SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                        SUM(auxnu4) auxnu4, SUM(0) auxnu5, SUM(0) auxnu6, SUM(0) auxnu7,
                        SUM(0) auxnu8, SUM(0) auxnu9,
                        semmes, agrega, valida
                    </columns>
                    <from table='gdwh_lsumdocd' />
                    <where>
                        empcode = ? AND
                        codalm  = ? AND
                        fecha   = ${pDatFecha}  AND
                        delega  = ?  AND
                        depart  = ?  AND
                        tabori  = ?  AND
                        tipdoc  = ?  AND
                        valida  = 'N'
                    </where>
                    <group>
                        fecha,  empcode,codalm, delega, depart, tabori, tipdoc, cladoc,
                        seccio, codfam, codart, varstk, coduni, auxal0, auxal1, auxal2,
                        auxal3, auxal4, semmes, agrega, valida
                    </group>
                </select>
            `, pStrEmpcode, pStrCodalm, mRow.delega, mRow.depart, mRow.tabori, mRow.tipdoc).toMemory();
            
            for (var mRow of mArrGdwhLsumd) {
                Ax.db.insert('gdwh_vdelartd', mRow)
            }
        } else {
            var mArrGdwhVdelartd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        fecha,  empcode,codalm, delega, depart, tabori,
                        tipdoc, cladoc, seccio, codfam, codart, varstk,
                        coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                        SUM(canmov) canmov, SUM(0) impbru, SUM(0) impnet,
                        SUM(0) impdto, SUM(impcos) impcos, SUM(0) imprap,
                        SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                        SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                        SUM(auxnu4) auxnu4, SUM(0) auxnu5,
                        SUM(0) auxnu6, SUM(0) auxnu7,
                        SUM(0) auxnu8, SUM(0) auxnu9,
                        semmes, agrega, valida
                    </columns>
                    <from table='gdwh_lsumdocd' />
                    <where>
                        empcode = ? AND
                        codalm  = ? AND
                        delega  = ? AND
                        depart  = ? AND
                        tabori  = ? AND
                        tipdoc  = ? AND
                        fecha   = ${pDatFecha} AND
                        valida  = 'N'
                    </where>
                    <group>
                        fecha,  empcode,codalm, delega, depart, tabori,
                        tipdoc, cladoc, seccio, codfam, codart, varstk,
                        coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                        semmes, agrega, valida
                    </group>
                </select>            
            `, pStrEmpcode, pStrCodalm, mRow.delega, mRow.depart, mRow.tabori, mRow.tipdoc).toMemory();

            for (var mObjGdwhVdelartd of mArrGdwhVdelartd) {
                for (var m_iter = 1; m_iter <= 11; m_iter++) {
                    /**
                     *  Control de que las iteraciones no sean más de 10. 
                     */
                    if (m_iter > 10) {
                        throw new Ax.lang.Exception(`gdwh_lsumdocd_vdel: Número de iteraciones superada. Máximo 10.`)
                    }

                    mIntCount = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='gdwh_vdelartd' />
                            <where>
                                fecha   = ${mObjGdwhVdelartd.fecha}  AND
                                empcode = ${mObjGdwhVdelartd.empcode} AND
                                codalm  = ${mObjGdwhVdelartd.codalm}  AND
                                delega  = ${mObjGdwhVdelartd.delega}  AND
                                depart  = ${mObjGdwhVdelartd.depart}  AND
                                tabori  = ${mObjGdwhVdelartd.tabori}  AND
                                tipdoc  = ${mObjGdwhVdelartd.tipdoc}  AND
                                cladoc  = ${mObjGdwhVdelartd.cladoc}  AND
                                seccio  = ${mObjGdwhVdelartd.seccio}  AND
                                codfam  = ${mObjGdwhVdelartd.codfam}  AND
                                codart  = ${mObjGdwhVdelartd.codart}  AND
                                varstk  = ${mObjGdwhVdelartd.varstk}  AND
                                coduni  = ${mObjGdwhVdelartd.coduni}  AND
                                auxal0  = ${mObjGdwhVdelartd.auxal0}  AND
                                auxal1  = ${mObjGdwhVdelartd.auxal1}  AND
                                auxal2  = ${mObjGdwhVdelartd.auxal2}  AND
                                auxal3  = ${mObjGdwhVdelartd.auxal3}  AND
                                auxal4  = ${mObjGdwhVdelartd.auxal4}  AND
                                semmes  = ${mObjGdwhVdelartd.semmes}
                            </where>
                        </select>
                    `);

                    Ax.db.execute(`
                        UPDATE gdwh_vdelartd
                           SET canmov = canmov + ${mObjGdwhVdelartd.canmov},
                               impcos = impcos + ${mObjGdwhVdelartd.impcos},
                               auxnu0 = auxnu0 + ${mObjGdwhVdelartd.auxnu0},
                               auxnu1 = auxnu1 + ${mObjGdwhVdelartd.auxnu1},
                               auxnu2 = auxnu2 + ${mObjGdwhVdelartd.auxnu2},
                               auxnu3 = auxnu3 + ${mObjGdwhVdelartd.auxnu3},
                               auxnu4 = auxnu4 + ${mObjGdwhVdelartd.auxnu4}
                            WHERE 
                               fecha   = ${mObjGdwhVdelartd.fecha}      AND
                               empcode = ${mObjGdwhVdelartd.empcode}    AND
                               codalm  = ${mObjGdwhVdelartd.codalm}     AND
                               delega  = ${mObjGdwhVdelartd.delega}     AND
                               depart  = ${mObjGdwhVdelartd.depart}     AND
                               tabori  = ${mObjGdwhVdelartd.tabori}     AND
                               tipdoc  = ${mObjGdwhVdelartd.tipdoc}     AND
                               cladoc  = ${mObjGdwhVdelartd.cladoc}     AND
                               seccio  = ${mObjGdwhVdelartd.seccio}     AND
                               codfam  = ${mObjGdwhVdelartd.codfam}     AND
                               codart  = ${mObjGdwhVdelartd.codart}     AND
                               varstk  = ${mObjGdwhVdelartd.varstk}     AND
                               coduni  = ${mObjGdwhVdelartd.coduni}     AND
                               auxal0  = ${mObjGdwhVdelartd.auxal0}     AND
                               auxal1  = ${mObjGdwhVdelartd.auxal1}     AND
                               auxal2  = ${mObjGdwhVdelartd.auxal2}     AND
                               auxal3  = ${mObjGdwhVdelartd.auxal3}     AND
                               auxal4  = ${mObjGdwhVdelartd.auxal4}     AND
                               semmes  = ${mObjGdwhVdelartd.semmes}
                    `);

                    if (mIntCount == 0) {
                        Ax.db.insert('gdwh_vdelartd', mObjGdwhVdelartd);
                    }

                    if (pStrIndagr == 'S') {
                        var mObjGdwhVdel = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    tipagr tipdoc, claagr cladoc
                                </columns>
                                <from table='gdwh_agrega' />
                                <where>
                                    tipdoc = ? AND
                                    cladoc = ?
                                </where>
                            </select>
                        `, mObjGdwhVdelartd.tipdoc, mObjGdwhVdelartd.cladoc).toOne();

                        mObjGdwhVdelartd.tipdoc = mObjGdwhVdel.tipdoc;
                        mObjGdwhVdelartd.cladoc = mObjGdwhVdel.cladoc;

                        if (mObjGdwhVdelartd.tipdoc == null) {
                            break;
                        } else {
                            break;
                        }
                    }
                }
            }
        }
    }
}
