/**
 *  Js: gdwh_vterdocd_artd                                               
 *                                                                         
 *  Script que carga la tabla gdwh_vterartd (Cliente - artículo diario)    
 *  desde la tabla gdwh_vterdocd (Cliente - documento), siempre y cuando la
 *  informacion hubiera sido cargada con el parametro p_valida = 'N'.      
 */
function gdwh_vterdocd_artd(
    pStrEmpcode,  pStrDelega,   pDatFecini,
    pDatFecfin,   pStrCargar,   pStrIndagr) {
    /**
     *  FUNC: __local_gdwh_vtersecd_totd                                    
     *                                                                  
     *  Función que carga la tabla gdwh_vtertotd (Cliente - total diario) 
     *  desde la tabla gdwh_vtersecd (Cliente - sección diario), siempre y
     *  cuando la informacion hubiera sido cargada con el parametro       
     *  p_valida = 'N'.                                                   
     */
    function __local_gdwh_vtersecd_totd(
        pStrEmpcode,  pStrDelega,   pDatFecini,
        pDatFecfin,   pStrIndagr) {
        /**
         *  Control de errores                                        
         *  Borrar los errores producidos en ejecuciones anteriores.  
         */
        var mStrProname = 'VTERSECT';       // Ventas Terceros Secciones-Totales
        Ax.db.delete('gdwh_interr', {proname: mStrProname});

        var mIntCount;
        /**
         *  Procesar registros de gdwh_vtersecd. 
         */
        var mArrGdelegac = Ax.db.executeQuery(`
            <select prefix='gdelegac_'>
                <columns>codigo</columns>
                <from table='gdelegac' />
                <where>
                    codigo ${pStrDelega}
                </where>
            </select>    
        `);

        for (var mObjGdelegac of mArrGdelegac) {
            var mArrGdwhVtersecd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        DISTINCT empcode, delega, fecha
                    </columns>
                    <from table='gdwh_vtersecd' />
                    <where>
                        fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                        empcode ${pStrEmpcode} AND
                        delega = ? AND
                        valida = 'N'
                    </where>
                    <order>
                        empcode, delega, fecha
                    </order>
                </select>        
            `, mObjGdelegac.codigo).toMemory();

            for (var mRow of mArrGdwhVtersecd) {
                /**
                 *  Control de error y transacción por delegación-día. 
                 */
                try {
                    /**
                     * Se abre transaccion por delegación-día.
                     */
                    Ax.db.beginWork();

                    /**
                     *  VENTAS TERCEROS-TOTALES-DIA. 
                     */
                    mIntCount = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='gdwh_vtertotd' />
                            <where>
                                empcode = ? AND
                                delega  = ? AND
                                fecha   = ${mRow.fecha}
                            </where>
                        </select>
                    `, mRow.empcode, mRow.delega);

                    if (pStrIndagr == 'N' && !mIntCount) {
                        var mArrGdwhVtertotd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, auxal0, auxal1, auxal2, auxal3, auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru, SUM(impnet) impnet,
                                    SUM(impdto) impdto, SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2,
                                    SUM(auxnu3) auxnu3, SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7, SUM(auxnu8) auxnu8,
                                    SUM(auxnu9) auxnu9, semmes,      'N' grpest
                                </columns>
                                <from table='gdwh_vtersecd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha}  AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, auxal0, auxal1, auxal2, auxal3, auxal4,
                                    semmes
                                </group>
                            </select>    
                        `).toMemory();

                        for (var mObjGdwhVtertotd of mArrGdwhVtertotd) {
                            Ax.db.insert('gdwh_vtertotd', mObjGdwhVtertotd);
                        }
                    } else {
                        var mArrVtertotd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart,
                                    tabori, tipdoc, cladoc, tercer, tipdir,
                                    terfac, tergrp, terfed, tercom, terenv,
                                    codnac, codpro, codzon, agente, auxal0,
                                    auxal1, auxal2, auxal3, auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru,
                                    SUM(impnet) impnet, SUM(impdto) impdto,
                                    SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                    SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                    SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7,
                                    SUM(auxnu8) auxnu8, SUM(auxnu9) auxnu9,
                                    semmes, 'N' grpest
                                </columns>
                                <from table='gdwh_vtersecd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha} AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart,
                                    tabori, tipdoc, cladoc, tercer, tipdir,
                                    terfac, tergrp, terfed, tercom, terenv,
                                    codnac, codpro, codzon, agente, auxal0,
                                    auxal1, auxal2, auxal3, auxal4, semmes
                                </group>
                            </select>  
                        `).toMemory();

                        for (var mObjVtertotd of mArrVtertotd) {
                            for (var mIntIter = 0; mIntIter < array.length; mIntIter++) {
                                /**
                                 *  Control de que las iteraciones no sean más de 10. 
                                 */
                                if (mIntIter > 10) {
                                    throw new Ax.lang.Exception(`local_gdwh_vtersecd_totd: Número de iteraciones superada. Máximo 10.`)
                                }

                                var mNumCount = Ax.db.executeGet(`
                                    <select>
                                        <columns>
                                            COUNT(*)
                                        </columns>
                                        <from table='gdwh_vtertotd' />
                                        <where>
                                            fecha  = ${mObjVtertotd.fecha}  AND
                                            empcode= '${mObjVtertotd.empcode}' AND
                                            codalm = '${mObjVtertotd.codalm}' AND
                                            delega = '${mObjVtertotd.delega}' AND
                                            depart = '${mObjVtertotd.depart}' AND
                                            tabori = '${mObjVtertotd.tabori}' AND
                                            tipdoc = '${mObjVtertotd.tipdoc}' AND
                                            cladoc = '${mObjVtertotd.cladoc}' AND
                                            tercer = '${mObjVtertotd.tercer}' AND
                                            tipdir = '${mObjVtertotd.tipdir}' AND
                                            terfac = '${mObjVtertotd.terfac}' AND
                                            tergrp = '${mObjVtertotd.tergrp}' AND
                                            terfed = '${mObjVtertotd.terfed}' AND
                                            tercom = '${mObjVtertotd.tercom}' AND
                                            terenv = '${mObjVtertotd.terenv}' AND
                                            codnac = '${mObjVtertotd.codnac}' AND
                                            codpro = '${mObjVtertotd.codpro}' AND
                                            codzon = '${mObjVtertotd.codzon}' AND
                                            agente = '${mObjVtertotd.agente}' AND
                                            auxal0 = '${mObjVtertotd.auxal0}' AND
                                            auxal1 = '${mObjVtertotd.auxal1}' AND
                                            auxal2 = '${mObjVtertotd.auxal2}' AND
                                            auxal3 = '${mObjVtertotd.auxal3}' AND
                                            auxal4 = '${mObjVtertotd.auxal4}' AND
                                            semmes = '${mObjVtertotd.semmes}'
                                        </where>
                                    </select> 
                                `);

                                Ax.db.execute(`
                                    --+INDEX(gdwh_vtertotd, "i_gdwh_vtertotd1")
                                    UPDATE gdwh_vtertotd
                                    SET canmov: canmov + ${mObjVtertotd.canmov},
                                        impbru: impbru + ${mObjVtertotd.impbru},
                                        impnet: impnet + ${mObjVtertotd.impnet},
                                        impdto: impdto + ${mObjVtertotd.impdto},
                                        impcos: impcos + ${mObjVtertotd.impcos},
                                        imprap: imprap + ${mObjVtertotd.imprap},
                                        auxnu0: auxnu0 + ${mObjVtertotd.auxnu0},
                                        auxnu1: auxnu1 + ${mObjVtertotd.auxnu1},
                                        auxnu2: auxnu2 + ${mObjVtertotd.auxnu2},
                                        auxnu3: auxnu3 + ${mObjVtertotd.auxnu3},
                                        auxnu4: auxnu4 + ${mObjVtertotd.auxnu4},
                                        auxnu5: auxnu5 + ${mObjVtertotd.auxnu5},
                                        auxnu6: auxnu6 + ${mObjVtertotd.auxnu6},
                                        auxnu7: auxnu7 + ${mObjVtertotd.auxnu7},
                                        auxnu8: auxnu8 + ${mObjVtertotd.auxnu8},
                                        auxnu9: auxnu9 + ${mObjVtertotd.auxnu9}
                                    WHERE 
                                        fecha  = ${mObjVtertotd.fecha}  AND
                                        empcode= '${mObjVtertotd.empcode}' AND
                                        codalm = '${mObjVtertotd.codalm}' AND
                                        delega = '${mObjVtertotd.delega}' AND
                                        depart = '${mObjVtertotd.depart}' AND
                                        tabori = '${mObjVtertotd.tabori}' AND
                                        tipdoc = '${mObjVtertotd.tipdoc}' AND
                                        cladoc = '${mObjVtertotd.cladoc}' AND
                                        tercer = '${mObjVtertotd.tercer}' AND
                                        tipdir = '${mObjVtertotd.tipdir}' AND
                                        terfac = '${mObjVtertotd.terfac}' AND
                                        tergrp = '${mObjVtertotd.tergrp}' AND
                                        terfed = '${mObjVtertotd.terfed}' AND
                                        tercom = '${mObjVtertotd.tercom}' AND
                                        terenv = '${mObjVtertotd.terenv}' AND
                                        codnac = '${mObjVtertotd.codnac}' AND
                                        codpro = '${mObjVtertotd.codpro}' AND
                                        codzon = '${mObjVtertotd.codzon}' AND
                                        agente = '${mObjVtertotd.agente}' AND
                                        auxal0 = '${mObjVtertotd.auxal0}' AND
                                        auxal1 = '${mObjVtertotd.auxal1}' AND
                                        auxal2 = '${mObjVtertotd.auxal2}' AND
                                        auxal3 = '${mObjVtertotd.auxal3}' AND
                                        auxal4 = '${mObjVtertotd.auxal4}' AND
                                        semmes = '${mObjVtertotd.semmes}'
                                `);

                                if (mNumCount == 0) {
                                    Ax.db.insert('gdwh_vtertotd', mObjVtertotd)
                                }

                                if (pStrIndagr == 'S') {
                                    var mObjAgrega = Ax.db.executeQuery(`
                                        <select>
                                            <columns>
                                                tipagr tipdoc, claagr cladoc
                                            </columns>
                                            <from table='gdwh_agrega' />
                                            <where>
                                                tipdoc = '${mObjVtertotd.tipdoc}' AND
                                                cladoc = '${mObjVtertotd.cladoc}'
                                            </where>
                                        </select>
                                    `).toOne();

                                    mObjVtertotd.tipdoc = mObjAgrega.tipdoc;
                                    mObjVtertotd.cladoc = mObjAgrega.cladoc;

                                    if (mObjVtertotd.tipdoc == null) {
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }

                    }

                    /**
                     *  Se marcan los registros procesados. 
                     */
                    Ax.db.update('gdwh_vtersecd', 
                        {
                            valida: 'S'
                        }, 
                        {
                            empcode:mRow.empcode,  
                            delega: mRow.delega, 
                            fecha: new Ax.sql.Date(mRow.fecha), 
                            valida: 'N'   
                        }
                    )

                    /**
                     *  Se cierra la transaccion. 
                     */

                    Ax.db.commitWork();
                    
                } catch (error) {
                    /**
                     *  Se retrocede la transaccion.  
                     */
                    Ax.db.rollbackWork();

                    Ax.db.insert('gdwh_interr', 
                        {
                            proname: mStrProname,
                            delalm :mRow.delega,
                            codigo :'',
                            fecinf : new Ax.sql.Date(mRow.fecha), 
                            fecerr : new Ax.sql.Date(),
                            nsql   : 0,
                            nisam  : 0,
                            errmsg : Ax.util.Error.getMessage(error)
                        }
                    );
                }
            }

            
            Ax.db.commitWork();
        }
    }

    /**
     *  FUNC: __local_gdwh_vterfamd_secd                                     
     *                                                                  
     *  Función que carga la tabla gdwh_vtersecd (Cliente - sección diario)
     *  desde la tabla gdwh_vterfamd (Cliente - familia diario), siempre y 
     *  cuando la informacion hubiera sido cargada con el parametro        
     *  p_valida = 'N'.                                                    
     */
    function __local_gdwh_vterfamd_secd(
        pStrEmpcode,  pStrDelega,   pDatFecini,
        pDatFecfin,   pStrCargar,   pStrIndagr) {
        /**
         *  Control de errores                                       
         *  Borrar los errores producidos en ejecuciones anteriores. 
         */
        var mStrProname = 'VTERFAMS';       // Ventas Terceros Familias-Secciones
        Ax.db.delete('gdwh_interr', {proname: mStrProname});
        
        var mIntCount;
        /**
         *  Procesar registros de gdwh_vterfamd. 
         */
        var mArrGdelegac = Ax.db.executeQuery(`
            <select>
                <columns>codigo</columns>
                <from table='gdelegac' />
                <where>
                    codigo ${pStrDelega}
                </where>
            </select>        
        `).toMemory(); 
        
        for (var mObjGdelegac of mArrGdelegac) {
            var mArrGdwhVterfamd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        DISTINCT empcode, delega, fecha
                    </columns>
                    <from table='gdwh_vterfamd' />
                    <where>
                        fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                        empcode ${pStrEmpcode} AND
                        delega = ? AND
                        valida = 'N'
                    </where>
                    <order>
                        empcode, delega, fecha
                    </order>
                </select>        
            `, mObjGdelegac.codigo).toMemory();

            for (var mRow of mArrGdwhVterfamd) {
                /**
                 *  Control de error y transacción por delegación-día. 
                 */
                try {
                    /**
                     *  Se abre transaccion por delegación-día.  
                     */
                    Ax.db.beginWork();

                    /**
                     *  VENTAS TERCEROS-SECCIONES-DIA. 
                     */
                    mIntCount = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='gdwh_vtersecd' />
                            <where>
                                empcode = ? AND
                                delega = ? AND
                                fecha  = ${mRow.fecha}
                            </where>
                        </select>
                    `, mRow.empcode, mRow.delega);

                    if (pStrIndagr == 'N' && !mIntCount) {
                        var mArrGdwhVtersecd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, seccio, auxal0, auxal1, auxal2, auxal3,
                                    auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru, SUM(impnet) impnet,
                                    SUM(impdto) impdto, SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2,
                                    SUM(auxnu3) auxnu3, SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7, SUM(auxnu8) auxnu8,
                                    SUM(auxnu9) auxnu9,
                                    semmes, valida
                                </columns>
                                <from table='gdwh_vterfamd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha}  AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, seccio, auxal0, auxal1, auxal2, auxal3,
                                    auxal4, semmes, valida
                                </group>
                            </select>
                        `, mRow.empcode, mRow.delega).toMemory();

                        for (var mObjGdwhVtersecd of mArrGdwhVtersecd) {
                            Ax.db.insert('gdwh_vtersecd', mObjGdwhVtersecd);
                        }
                    } else {
                        var mArrVtersecd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart,
                                    tabori, tipdoc, cladoc, tercer, tipdir,
                                    terfac, tergrp, terfed, tercom, terenv,
                                    codnac, codpro, codzon, agente, seccio,
                                    auxal0, auxal1, auxal2, auxal3, auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru,
                                    SUM(impnet) impnet, SUM(impdto) impdto,
                                    SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                    SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                    SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7,
                                    SUM(auxnu8) auxnu8, SUM(auxnu9) auxnu9,
                                    semmes, valida
                                </columns>
                                <from table='gdwh_vterfamd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha}  AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart,
                                    tabori, tipdoc, cladoc, tercer, tipdir,
                                    terfac, tergrp, terfed, tercom, terenv,
                                    codnac, codpro, codzon, agente, seccio,
                                    auxal0, auxal1, auxal2, auxal3, auxal4,
                                    semmes, valida
                                </group>
                            </select>
                        `, mRow.empcode, mRow.delega).toMemory();

                        for (var mObjVtersecd of mArrVtersecd) {
                            for (var mIntIter = 1; mIntIter <= 11; mIntIter++) {
                                /**
                                 *  Control de que las iteraciones no sean más de 10. 
                                 */
                                if (mIntIter > 10) {
                                    throw new Ax.lang.Exception(`__local_gdwh_vterfamd_secd: Número de iteraciones superada. Máximo 10.`)
                                }
                                
                                var mNumCount = Ax.db.executeGet(`
                                    <select>
                                        <columns>
                                            COUNT(*)
                                        </columns>
                                        <from table='gdwh_vtersecd' />
                                        <where>
                                            fecha  = ${mObjVtersecd.fecha}  AND
                                            empcode= '${mObjVtersecd.empcode}' AND
                                            codalm = '${mObjVtersecd.codalm}' AND
                                            delega = '${mObjVtersecd.delega}' AND
                                            depart = '${mObjVtersecd.depart}' AND
                                            tabori = '${mObjVtersecd.tabori}' AND
                                            tipdoc = '${mObjVtersecd.tipdoc}' AND
                                            cladoc = '${mObjVtersecd.cladoc}' AND
                                            tercer = '${mObjVtersecd.tercer}' AND
                                            tipdir = '${mObjVtersecd.tipdir}' AND
                                            terfac = '${mObjVtersecd.terfac}' AND
                                            tergrp = '${mObjVtersecd.tergrp}' AND
                                            terfed = '${mObjVtersecd.terfed}' AND
                                            tercom = '${mObjVtersecd.tercom}' AND
                                            terenv = '${mObjVtersecd.terenv}' AND
                                            codnac = '${mObjVtersecd.codnac}' AND
                                            codpro = '${mObjVtersecd.codpro}' AND
                                            codzon = '${mObjVtersecd.codzon}' AND
                                            agente = '${mObjVtersecd.agente}' AND
                                            seccio = '${mObjVtersecd.seccio}' AND
                                            auxal0 = '${mObjVtersecd.auxal0}' AND
                                            auxal1 = '${mObjVtersecd.auxal1}' AND
                                            auxal2 = '${mObjVtersecd.auxal2}' AND
                                            auxal3 = '${mObjVtersecd.auxal3}' AND
                                            auxal4 = '${mObjVtersecd.auxal4}' AND
                                            semmes = '${mObjVtersecd.semmes}'
                                        </where>
                                    </select> 
                                `);

                                Ax.db.execute(`
                                    --+INDEX(gdwh_vtersecd, "i_gdwh_vtersecd1")
                                    UPDATE gdwh_vtersecd
                                    SET canmov: canmov + ${mObjVtersecd.canmov},
                                        impbru: impbru + ${mObjVtersecd.impbru},
                                        impnet: impnet + ${mObjVtersecd.impnet},
                                        impdto: impdto + ${mObjVtersecd.impdto},
                                        impcos: impcos + ${mObjVtersecd.impcos},
                                        imprap: imprap + ${mObjVtersecd.imprap},
                                        auxnu0: auxnu0 + ${mObjVtersecd.auxnu0},
                                        auxnu1: auxnu1 + ${mObjVtersecd.auxnu1},
                                        auxnu2: auxnu2 + ${mObjVtersecd.auxnu2},
                                        auxnu3: auxnu3 + ${mObjVtersecd.auxnu3},
                                        auxnu4: auxnu4 + ${mObjVtersecd.auxnu4},
                                        auxnu5: auxnu5 + ${mObjVtersecd.auxnu5},
                                        auxnu6: auxnu6 + ${mObjVtersecd.auxnu6},
                                        auxnu7: auxnu7 + ${mObjVtersecd.auxnu7},
                                        auxnu8: auxnu8 + ${mObjVtersecd.auxnu8},
                                        auxnu9: auxnu9 + ${mObjVtersecd.auxnu9}
                                    WHERE 
                                        fecha  = ${mObjVtersecd.fecha}  AND
                                        empcode= '${mObjVtersecd.empcode}' AND
                                        codalm = '${mObjVtersecd.codalm}' AND
                                        delega = '${mObjVtersecd.delega}' AND
                                        depart = '${mObjVtersecd.depart}' AND
                                        tabori = '${mObjVtersecd.tabori}' AND
                                        tipdoc = '${mObjVtersecd.tipdoc}' AND
                                        cladoc = '${mObjVtersecd.cladoc}' AND
                                        tercer = '${mObjVtersecd.tercer}' AND
                                        tipdir = '${mObjVtersecd.tipdir}' AND
                                        terfac = '${mObjVtersecd.terfac}' AND
                                        tergrp = '${mObjVtersecd.tergrp}' AND
                                        terfed = '${mObjVtersecd.terfed}' AND
                                        tercom = '${mObjVtersecd.tercom}' AND
                                        terenv = '${mObjVtersecd.terenv}' AND
                                        codnac = '${mObjVtersecd.codnac}' AND
                                        codpro = '${mObjVtersecd.codpro}' AND
                                        codzon = '${mObjVtersecd.codzon}' AND
                                        agente = '${mObjVtersecd.agente}' AND
                                        seccio = '${mObjVtersecd.seccio}' AND
                                        auxal0 = '${mObjVtersecd.auxal0}' AND
                                        auxal1 = '${mObjVtersecd.auxal1}' AND
                                        auxal2 = '${mObjVtersecd.auxal2}' AND
                                        auxal3 = '${mObjVtersecd.auxal3}' AND
                                        auxal4 = '${mObjVtersecd.auxal4}' AND
                                        semmes = '${mObjVtersecd.semmes}'
                                `);

                                if (mNumCount == 0) {
                                    Ax.db.insert('gdwh_vtersecd', mObjVtersecd)
                                }

                                if (pStrIndagr == 'S') {
                                    var mObjAgrega = Ax.db.executeQuery(`
                                        <select>
                                            <columns>
                                                tipagr tipdoc, claagr cladoc
                                            </columns>
                                            <from table='gdwh_agrega' />
                                            <where>
                                                tipdoc = '${mObjVtersecd.tipdoc}' AND
                                                cladoc = '${mObjVtersecd.cladoc}'
                                            </where>
                                        </select>
                                    `).toOne();

                                    mObjVtersecd.tipdoc = mObjAgrega.tipdoc;
                                    mObjVtersecd.cladoc = mObjAgrega.cladoc;

                                    if (mObjVtersecd.tipdoc == null) {
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }

                    /**
                     *  Se marcan los registros procesados. 
                     */
                    Ax.db.update('', 
                        {
                            valida: 'S'
                        }, 
                        {
                            empcode: mRow.empcode,
                            delega: mRow.delega,
                            fecha: new Ax.sql.Date(mRow.fecha),
                            valida: 'N'
                        }
                    );

                    /**
                     *  Se cierra la transaccion.    
                     */
                    Ax.db.commitWork();   

                } catch (error) {
                    /**
                     *  Se retrocede la transaccion.  
                     */
                    Ax.db.rollbackWork(); 

                    Ax.db.insert('gdwh_interr', 
                        {
                            proname: mStrProname,
                            delalm: mRow.delega,
                            codigo: '',
                            fecinf: new Ax.sql.Date(mRow.fecha),
                            fecerr: new Ax.sql.Date(),
                            nsql: 0,
                            nisam: 0,
                            errmsg: Ax.util.Error.getMessage(error)
                        }
                    )
                }
            }

            Ax.db.commitWork();
        }

        /**
         *  Agregar el resto de piramides. 
         */
        if (pStrCargar == 'S') {
            /**
             *  Ventas Terceros-Totales-Día a partir de Terceros-Secciones-Día. 
             */
            __local_gdwh_vtersecd_totd(
                pStrEmpcode,
                pStrDelega,
                pDatFecini,
                pDatFecfin,
                'N'
            );
        }
    }

    /**
     *  FUNC: __local_gdwh_vterartd_artd                                       
     *                                                                      
     *  Fcunión que carga la tabla gdwh_vdelartd (Delegación-artículo diario)
     *  desde la tabla gdwh_vterartd (Cliente - artículo diario), siempre y  
     *  cuando la informacion hubiera sido cargada con el parametro          
     *  p_valida = 'N'.                                                      
     */
    function __local_gdwh_vterartd_artd(
        pStrEmpcode,  pStrDelega,   pDatFecini,
        pDatFecfin,   pStrCargar,   pStrIndagr) {
        /**
         *  Control de errores                                        
         *  Borrar los errores producidos en ejecuciones anteriores.  
         */
        var mStrProname = 'VTERARTA';       // Ventas Terceros Artículos-Ambos
                                            // (Delegaciones y Terceros)  
        Ax.db.delete('gdwh_interr', {proname: mStrProname});

        var mIntCount;
        /**
         *  Procesar registros de gdwh_vterartd. 
         */
        var mArrGdelegac = Ax.db.executeQuery(`
            <select>
                <columns>codigo</columns>
                <from table='gdelegac' />
                <where>
                    codigo ${pStrDelega}
                </where>
            </select>    
        `).toMemory();

        for (var mObjGdelegac of mArrGdelegac) {
            var mArrGdwhVterartd = Ax.db.executeQuery(`
                <select>
                    <columns>
                        DISTINCT empcode, delega, fecha
                    </columns>
                    <from table='gdwh_vterartd' />
                    <where>
                        fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                        empcode ${pStrEmpcode} AND
                        delega = ? AND
                        valida = 'N'
                    </where>
                    <order>
                        empcode, delega, fecha
                    </order>
                </select>    
            `, mObjGdelegac.codigo).toMemory();

            for (var mRow of mArrGdwhVterartd) {
                /**
                 *  Control de error y transacción por delegación-día. 
                 */
                try {
                    /**
                     *  Se abre transaccion por delegación-día. 
                     */
                    Ax.db.beginWork();

                    /**
                     *  VENTAS DELEGACIONES-ARTÍCULOS-DIA. 
                     */
                    mIntCount = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='gdwh_vdelartd' />
                            <where>
                                empcode = ? AND
                                delega = ? AND
                                fecha  = ${mRow.fecha}
                            </where>
                        </select>
                    `, mRow.empcode, mRow.delega);

                    if (pStrIndagr == 'N' && !mIntCount) {
                        var mArrGdwhVdelartd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, seccio, codfam, codart, varstk,
                                    coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru, SUM(impnet) impnet,
                                    SUM(impdto) impdto, SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2,
                                    SUM(auxnu3) auxnu3, SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7, SUM(auxnu8) auxnu8,
                                    SUM(auxnu9) auxnu9,
                                    semmes, agrega, valida
                                </columns>
                                <from table='gdwh_vterartd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha}  AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, seccio, codfam, codart, varstk,
                                    coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                                    semmes, agrega, valida
                                </group>
                            </select>        
                        `, mRow.empcode, mRow.delega).toMemory();

                        for (var mObjGdwhVdelartd of mArrGdwhVdelartd) {
                            Ax.db.insert('gdwh_vdelartd', mObjGdwhVdelartd)
                        }

                    } else {
                        var mArrVdelartd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart,
                                    tabori, tipdoc, cladoc, seccio, codfam,
                                    codart, varstk, coduni, auxal0, auxal1,
                                    auxal2, auxal3, auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru,
                                    SUM(impnet) impnet, SUM(impdto) impdto,
                                    SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                    SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                    SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7,
                                    SUM(auxnu8) auxnu8, SUM(auxnu9) auxnu9,
                                    semmes, agrega, valida
                                </columns>
                                <from table='gdwh_vterartd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha}  AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, seccio, codfam, codart, varstk,
                                    coduni, auxal0, auxal1, auxal2, auxal3, auxal4,
                                    semmes, agrega, valida
                                </group>
                            </select>
                        `, mRow.empcode, mRow.delega).toMemory();

                        for (var mObjVdelartd of mArrVdelartd) {
                            for (var mIntIter = 1; mIntIter <= 11; mIntIter++) {
                                if (mIntIter > 10) {
                                    throw new Ax.lang.Exception(`__local_gdwh_vterartd_artd: Número de iteraciones superada. Máximo 10.`);
                                }

                                var mNumCount = Ax.db.executeGet(`
                                    <select>
                                        <columns>
                                            COUNT(*)
                                        </columns>
                                        <from table='gdwh_vdelartd' />
                                        <where>
                                            fecha  = '${mObjVdelartd.fecha}  AND
                                            empcode= '${mObjVdelartd.empcode}' AND
                                            codalm = '${mObjVdelartd.codalm}' AND
                                            delega = '${mObjVdelartd.delega}' AND
                                            depart = '${mObjVdelartd.depart}' AND
                                            tabori = '${mObjVdelartd.tabori}' AND
                                            tipdoc = '${mObjVdelartd.tipdoc}' AND
                                            cladoc = '${mObjVdelartd.cladoc}' AND
                                            seccio = '${mObjVdelartd.seccio}' AND
                                            codfam = '${mObjVdelartd.codfam}' AND
                                            codart = '${mObjVdelartd.codart}' AND
                                            varstk = '${mObjVdelartd.varstk}' AND
                                            coduni = '${mObjVdelartd.coduni}' AND
                                            auxal0 = '${mObjVdelartd.auxal0}' AND
                                            auxal1 = '${mObjVdelartd.auxal1}' AND
                                            auxal2 = '${mObjVdelartd.auxal2}' AND
                                            auxal3 = '${mObjVdelartd.auxal3}' AND
                                            auxal4 = '${mObjVdelartd.auxal4}' AND
                                            semmes = '${mObjVdelartd.semmes}'
                                        </where>
                                    </select> 
                                `);

                                Ax.db.execute(`
                                    --+INDEX(gdwh_vdelartd, "i_gdwh_vdelartd1")
                                    UPDATE gdwh_vdelartd
                                    SET canmov: canmov + ${mObjVdelartd.canmov},
                                        impbru: impbru + ${mObjVdelartd.impbru},
                                        impnet: impnet + ${mObjVdelartd.impnet},
                                        impdto: impdto + ${mObjVdelartd.impdto},
                                        impcos: impcos + ${mObjVdelartd.impcos},
                                        imprap: imprap + ${mObjVdelartd.imprap},
                                        auxnu0: auxnu0 + ${mObjVdelartd.auxnu0},
                                        auxnu1: auxnu1 + ${mObjVdelartd.auxnu1},
                                        auxnu2: auxnu2 + ${mObjVdelartd.auxnu2},
                                        auxnu3: auxnu3 + ${mObjVdelartd.auxnu3},
                                        auxnu4: auxnu4 + ${mObjVdelartd.auxnu4},
                                        auxnu5: auxnu5 + ${mObjVdelartd.auxnu5},
                                        auxnu6: auxnu6 + ${mObjVdelartd.auxnu6},
                                        auxnu7: auxnu7 + ${mObjVdelartd.auxnu7},
                                        auxnu8: auxnu8 + ${mObjVdelartd.auxnu8},
                                        auxnu9: auxnu9 + ${mObjVdelartd.auxnu9}
                                    WHERE 
                                        fecha  = '${mObjVdelartd.fecha}  AND
                                        empcode= '${mObjVdelartd.empcode}' AND
                                        codalm = '${mObjVdelartd.codalm}' AND
                                        delega = '${mObjVdelartd.delega}' AND
                                        depart = '${mObjVdelartd.depart}' AND
                                        tabori = '${mObjVdelartd.tabori}' AND
                                        tipdoc = '${mObjVdelartd.tipdoc}' AND
                                        cladoc = '${mObjVdelartd.cladoc}' AND
                                        seccio = '${mObjVdelartd.seccio}' AND
                                        codfam = '${mObjVdelartd.codfam}' AND
                                        codart = '${mObjVdelartd.codart}' AND
                                        varstk = '${mObjVdelartd.varstk}' AND
                                        coduni = '${mObjVdelartd.coduni}' AND
                                        auxal0 = '${mObjVdelartd.auxal0}' AND
                                        auxal1 = '${mObjVdelartd.auxal1}' AND
                                        auxal2 = '${mObjVdelartd.auxal2}' AND
                                        auxal3 = '${mObjVdelartd.auxal3}' AND
                                        auxal4 = '${mObjVdelartd.auxal4}' AND
                                        semmes = '${mObjVdelartd.semmes}'
                                `);

                                if (mNumCount == 0) {
                                    Ax.db.insert('gdwh_vdelartd', mObjVdelartd)
                                }
                                    
                                if (pStrIndagr == 'S') {
                                    var mObjAgrega = Ax.db.executeQuery(`
                                        <select>
                                            <columns>
                                                tipagr tipdoc, claagr cladoc
                                            </columns>
                                            <from table='gdwh_agrega' />
                                            <where>
                                                tipdoc = '${mObjVdelartd.tipdoc}' AND
                                                cladoc = '${mObjVdelartd.cladoc}'
                                            </where>
                                        </select>
                                    `).toOne();

                                    mObjVdelartd.tipdoc = mObjAgrega.tipdoc;
                                    mObjVdelartd.cladoc = mObjAgrega.cladoc;

                                    if (mObjVdelartd.tipdoc == null) {
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }

                    /**
                     *  VENTAS TERCEROS-FAMILIAS-DIA. 
                     */
                    mIntCount = Ax.db.executeGet(`
                        <select>
                            <columns>COUNT(*)</columns>
                            <from table='gdwh_vterfamd' />
                            <where>
                                empcode = ? AND
                                delega = ? AND
                                fecha  = ${mRow.fecha}
                            </where>
                        </select>    
                    `, mRow.empcode, mRow.delega);

                    if (pStrIndagr == 'N' && !mIntCount) {
                        var mArrGdwhVterfamd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, seccio, codfam, auxal0, auxal1, auxal2,
                                    auxal3, auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru, SUM(impnet) impnet,
                                    SUM(impdto) impdto, SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2,
                                    SUM(auxnu3) auxnu3, SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7, SUM(auxnu8) auxnu8,
                                    SUM(auxnu9) auxnu9,
                                    semmes, valida
                                </columns>
                                <from table='gdwh_vterartd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha} AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, seccio, codfam, auxal0, auxal1, auxal2,
                                    auxal3, auxal4, semmes, valida
                                </group>
                            </select>
                        `, mRow.empcode, mRow.delega).toMemory();

                        for (var mObjGdwhVterfamd of mArrGdwhVterfamd) {
                            Ax.db.insert('gdwh_vterfamd', mObjGdwhVterfamd)
                        }
                    } else {
                        var mArrGdwhVterfamd = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, seccio, codfam, auxal0, auxal1, auxal2,
                                    auxal3, auxal4,
                                    SUM(canmov) canmov, SUM(impbru) impbru,
                                    SUM(impnet) impnet, SUM(impdto) impdto,
                                    SUM(impcos) impcos, SUM(imprap) imprap,
                                    SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                    SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                    SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                    SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7,
                                    SUM(auxnu8) auxnu8, SUM(auxnu9) auxnu9,
                                    semmes, valida
                                </columns>
                                <from table='gdwh_vterartd' />
                                <where>
                                    empcode = ? AND
                                    delega = ? AND
                                    fecha  = ${mRow.fecha} AND
                                    valida = 'N'
                                </where>
                                <group>
                                    fecha,  empcode,codalm, delega, depart, tabori,
                                    tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                    terfed, tercom, terenv, codnac, codpro, codzon,
                                    agente, seccio, codfam, auxal0, auxal1, auxal2,
                                    auxal3, auxal4, semmes, valida
                                </group>
                            </select>
                        `, mRow.empcode, mRow.delega);

                        for (var mObjGdwhVterfamd of mArrGdwhVterfamd) {
                            for (var mIntIter = 1; mIntIter <= 11; mIntIter++) {
                                /**
                                 *  Control de que las iteraciones no sean más de 10.  
                                 */
                                if (mIntIter > 10) {
                                    throw new Ax.lang.Exception(`__local_gdwh_vterartd_artd: Número de iteraciones superada. Máximo 10.`)
                                }

                                var mNumCount = Ax.db.executeGet(`
                                    <select>
                                        <columns>
                                            COUNT(*)
                                        </columns>
                                        <from table='gdwh_vterfamd' />
                                        <where>
                                            fecha  = ${mObjGdwhVterfamd.fecha}  AND
                                            empcode= '${mObjGdwhVterfamd.empcode}' AND
                                            codalm = '${mObjGdwhVterfamd.codalm}' AND
                                            delega = '${mObjGdwhVterfamd.delega}' AND
                                            depart = '${mObjGdwhVterfamd.depart}' AND
                                            tabori = '${mObjGdwhVterfamd.tabori}' AND
                                            tipdoc = '${mObjGdwhVterfamd.tipdoc}' AND
                                            cladoc = '${mObjGdwhVterfamd.cladoc}' AND
                                            tercer = '${mObjGdwhVterfamd.tercer}' AND
                                            tipdir = '${mObjGdwhVterfamd.tipdir}' AND
                                            terfac = '${mObjGdwhVterfamd.terfac}' AND
                                            tergrp = '${mObjGdwhVterfamd.tergrp}' AND
                                            terfed = '${mObjGdwhVterfamd.terfed}' AND
                                            tercom = '${mObjGdwhVterfamd.tercom}' AND
                                            terenv = '${mObjGdwhVterfamd.terenv}' AND
                                            codnac = '${mObjGdwhVterfamd.codnac}' AND
                                            codpro = '${mObjGdwhVterfamd.codpro}' AND
                                            codzon = '${mObjGdwhVterfamd.codzon}' AND
                                            agente = '${mObjGdwhVterfamd.agente}' AND
                                            seccio = '${mObjGdwhVterfamd.seccio}' AND
                                            codfam = '${mObjGdwhVterfamd.codfam}' AND
                                            auxal0 = '${mObjGdwhVterfamd.auxal0}' AND
                                            auxal1 = '${mObjGdwhVterfamd.auxal1}' AND
                                            auxal2 = '${mObjGdwhVterfamd.auxal2}' AND
                                            auxal3 = '${mObjGdwhVterfamd.auxal3}' AND
                                            auxal4 = '${mObjGdwhVterfamd.auxal4}' AND
                                            semmes = '${mObjGdwhVterfamd.semmes}'
                                        </where>
                                    </select> 
                                `);

                                Ax.db.execute(`
                                    --+INDEX(gdwh_vterfamd, "i_gdwh_vterfamd1")
                                    UPDATE gdwh_vterfamd
                                    SET canmov: canmov + ${mObjGdwhVterfamd.canmov},
                                        impbru: impbru + ${mObjGdwhVterfamd.impbru},
                                        impnet: impnet + ${mObjGdwhVterfamd.impnet},
                                        impdto: impdto + ${mObjGdwhVterfamd.impdto},
                                        impcos: impcos + ${mObjGdwhVterfamd.impcos},
                                        imprap: imprap + ${mObjGdwhVterfamd.imprap},
                                        auxnu0: auxnu0 + ${mObjGdwhVterfamd.auxnu0},
                                        auxnu1: auxnu1 + ${mObjGdwhVterfamd.auxnu1},
                                        auxnu2: auxnu2 + ${mObjGdwhVterfamd.auxnu2},
                                        auxnu3: auxnu3 + ${mObjGdwhVterfamd.auxnu3},
                                        auxnu4: auxnu4 + ${mObjGdwhVterfamd.auxnu4},
                                        auxnu5: auxnu5 + ${mObjGdwhVterfamd.auxnu5},
                                        auxnu6: auxnu6 + ${mObjGdwhVterfamd.auxnu6},
                                        auxnu7: auxnu7 + ${mObjGdwhVterfamd.auxnu7},
                                        auxnu8: auxnu8 + ${mObjGdwhVterfamd.auxnu8},
                                        auxnu9: auxnu9 + ${mObjGdwhVterfamd.auxnu9}
                                    WHERE 
                                        fecha  = ${mObjGdwhVterfamd.fecha}  AND
                                        empcode= '${mObjGdwhVterfamd.empcode}' AND
                                        codalm = '${mObjGdwhVterfamd.codalm}' AND
                                        delega = '${mObjGdwhVterfamd.delega}' AND
                                        depart = '${mObjGdwhVterfamd.depart}' AND
                                        tabori = '${mObjGdwhVterfamd.tabori}' AND
                                        tipdoc = '${mObjGdwhVterfamd.tipdoc}' AND
                                        cladoc = '${mObjGdwhVterfamd.cladoc}' AND
                                        tercer = '${mObjGdwhVterfamd.tercer}' AND
                                        tipdir = '${mObjGdwhVterfamd.tipdir}' AND
                                        terfac = '${mObjGdwhVterfamd.terfac}' AND
                                        tergrp = '${mObjGdwhVterfamd.tergrp}' AND
                                        terfed = '${mObjGdwhVterfamd.terfed}' AND
                                        tercom = '${mObjGdwhVterfamd.tercom}' AND
                                        terenv = '${mObjGdwhVterfamd.terenv}' AND
                                        codnac = '${mObjGdwhVterfamd.codnac}' AND
                                        codpro = '${mObjGdwhVterfamd.codpro}' AND
                                        codzon = '${mObjGdwhVterfamd.codzon}' AND
                                        agente = '${mObjGdwhVterfamd.agente}' AND
                                        seccio = '${mObjGdwhVterfamd.seccio}' AND
                                        codfam = '${mObjGdwhVterfamd.codfam}' AND
                                        auxal0 = '${mObjGdwhVterfamd.auxal0}' AND
                                        auxal1 = '${mObjGdwhVterfamd.auxal1}' AND
                                        auxal2 = '${mObjGdwhVterfamd.auxal2}' AND
                                        auxal3 = '${mObjGdwhVterfamd.auxal3}' AND
                                        auxal4 = '${mObjGdwhVterfamd.auxal4}' AND
                                        semmes = '${mObjGdwhVterfamd.semmes}'
                                `);

                                if (mNumCount == 0) {
                                    Ax.db.insert('gdwh_vterfamd', mObjGdwhVterfamd)
                                }
                                    
                                if (pStrIndagr == 'S') {
                                    var mObjAgrega = Ax.db.executeQuery(`
                                        <select>
                                            <columns>
                                                tipagr tipdoc, claagr cladoc
                                            </columns>
                                            <from table='gdwh_agrega' />
                                            <where>
                                                tipdoc = '${mObjGdwhVterfamd.tipdoc}' AND
                                                cladoc = '${mObjGdwhVterfamd.cladoc}'
                                            </where>
                                        </select>
                                    `).toOne();

                                    mObjGdwhVterfamd.tipdoc = mObjAgrega.tipdoc;
                                    mObjGdwhVterfamd.cladoc = mObjAgrega.cladoc;

                                    if (mObjGdwhVterfamd.tipdoc == null) {
                                        break;
                                    }
                                } else {
                                    break;
                                }
                                
                            }
                        }
                    }

                    /**
                     *  Se marcan los registros procesados.  
                     */
                    Ax.db.update('gdwh_vterartd', 
                        {
                            valida: 'S'
                        }, 
                        {
                            empcode: mRow.empcode,
                            delega : mRow.delega,
                            fecha  : new Ax.sql.Date(mRow.fecha),
                            valida : 'N'
                        }
                    )

                    /**
                     * Se cierra la transaccion.
                     */
                    Ax.db.commitWork();
                } catch (error) {
                    /**
                     * Se retrocede la transaccion. 
                     */
                    Ax.db.rollbackWork();

                    Ax.db.insert('gdwh_interr', 
                        {
                            proname: mStrProname,
                            delalm: mRow.delega,
                            codigo: '',
                            fecinf: new Ax.sql.Date(mRow.fecha),
                            fecerr: new Ax.sql.Date(),
                            nsql: 0,
                            nisam: 0,
                            errmsg: Ax.util.Error.getMessage(error)
                        }
                    )
                }

            }

            Ax.db.commitWork();
        }

        /**
         *  Agregar el resto de piramides. 
         */
        if (pStrCargar == 'S') {
            /**
             *  Ventas Delegaciones-Familias-Día a partir de 
             *  Delegaciones-Artículos-Día.                  
             */
            Ax.db.call('gdwh_vdelartd_famd', 
                pStrEmpcode,
                pStrDelega,
                pDatFecini,
                pDatFecfin,
                pStrCargar,
                'N'
            );

            /**
             *  Ventas Terceros-Secciones-Día a partir de Terceros-Familias-Día.  
             */
            __local_gdwh_vterfamd_secd(
                pStrEmpcode,
                pStrDelega,
                pDatFecini,
                pDatFecfin,
                pStrCargar,
                'N'
            );
        }
    }

    /**
     *  Control de errores                                       
     *  Borrar los errores producidos en ejecuciones anteriores. 
     */
    var mStrProname = 'VTERDOCA';       // Ventas Terceros Documento-Artículos
    Ax.db.delete('gdwh_interr', {proname: mStrProname});

    var mIntCount;

    /**
     *  Procesar registros de gdwh_vterdocd.    
     */
    var mArrGdelegac = Ax.db.executeQuery(`
        <select>
            <columns>codigo</columns>
            <from table='gdelegac' />
            <where>
                codigo ${pStrDelega}
            </where>
        </select>
    `).toMemory();

    for (var mObjGdelegac of mArrGdelegac) {
        var mArrGdwhVterdocd = Ax.db.executeQuery(`
            <select>
                <columns>
                    DISTINCT empcode, delega, fecha
                </columns>
                <from table='gdwh_vterdocd' />
                <where>
                    fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    empcode ${pStrEmpcode} AND
                    delega = ? AND
                    valida = 'N'
                </where>
                <order>
                    empcode, delega, fecha
                </order>
            </select>
        `, mObjGdelegac.codigo).toMemory();

        for (var mRow of mArrGdwhVterdocd) {
            /**
             *  Control de error y transacción por delegación-día.  
             */
            try {
                /**
                 *  Se abre transaccion por delegación-día.  
                 */
                Ax.db.beginWork();

                /**
                 *  VENTAS TERCEROS-ARTÍCULOS-DIA. 
                 */
                mIntCount = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gdwh_vterartd' />
                        <where>
                            empcode = ? AND
                            delega = ? AND
                            fecha  = ${mRow.fecha}
                        </where>
                    </select>
                `, mRow.empcode, mRow.delega);

                if (pStrIndagr == 'N' && !mIntCount) {
                    var mArrGdwhVterartd = Ax.db.executeQuery(`
                        <select>
                            <columns>
                                fecha,  empcode,codalm, delega, depart, tabori,
                                tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                terfed, tercom, terenv, codnac, codpro, codzon,
                                agente, seccio, codfam, codart, varstk, coduni,
                                auxal0, auxal1, auxal2, auxal3, auxal4,
                                SUM(canmov) canmov, SUM(impbru) impbru, SUM(impnet) impnet,
                                SUM(impdto) impdto, SUM(impcos) impcos, SUM(imprap) imprap,
                                SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2,
                                SUM(auxnu3) auxnu3, SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7, SUM(auxnu8) auxnu8,
                                SUM(auxnu9) auxnu9,
                                semmes, agrega, valida
                            </columns>
                            <from table='gdwh_vterdocd' />
                            <where>
                                empcode = ? AND
                                delega = ? AND
                                fecha  = ${mRow.fecha} AND
                                valida = 'N'
                            </where>
                            <group>
                                fecha,  empcode,codalm, delega, depart, tabori,
                                tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                terfed, tercom, terenv, codnac, codpro, codzon,
                                agente, seccio, codfam, codart, varstk, coduni,
                                auxal0, auxal1, auxal2, auxal3, auxal4, semmes,
                                agrega, valida
                            </group>
                        </select>
                    `, mRow.empcode, mRow.delega).toMemory();

                    for (var mObjGdwhVterartd of mArrGdwhVterartd) {
                        Ax.db.insert('gdwh_vterartd', mObjGdwhVterartd);
                    }
                } else {
                    var mArrVterartd = Ax.db.executeQuery(`
                        <select>
                            <columns>
                                fecha,  empcode,codalm, delega, depart, tabori,
                                tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                terfed, tercom, terenv, codnac, codpro, codzon,
                                agente, seccio, codfam, codart, varstk, coduni,
                                auxal0, auxal1, auxal2, auxal3, auxal4,
                                SUM(canmov) canmov, SUM(impbru) impbru,
                                SUM(impnet) impnet, SUM(impdto) impdto,
                                SUM(impcos) impcos, SUM(imprap) imprap,
                                SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7,
                                SUM(auxnu8) auxnu8, SUM(auxnu9) auxnu9,
                                semmes, agrega, valida
                            </columns>
                            <from table='gdwh_vterdocd' />
                            <where>
                                empcode = ? AND
                                delega = ? AND
                                fecha  = ${mRow.fecha} AND
                                valida = 'N'
                            </where>
                            <group>
                                fecha,  empcode,codalm, delega, depart, tabori,
                                tipdoc, cladoc, tercer, tipdir, terfac, tergrp,
                                terfed, tercom, terenv, codnac, codpro, codzon,
                                agente, seccio, codfam, codart, varstk, coduni,
                                auxal0, auxal1, auxal2, auxal3, auxal4, semmes,
                                agrega, valida
                            </group>
                        </select>    
                    `, mRow.empcode, mRow.delega).toMemory();

                    for (var mObjVterartd of mArrVterartd) {
                        for (var mIntIter = 1; mIntIter <= 11; mIntIter++) {
                            /**
                             *  Control de que las iteraciones no sean más de 10. 
                             */
                            if (mIntIter > 10) {
                                throw new Ax.lang.Exception(` gdwh_vterdocd_artd: Número de iteraciones superada. Máximo 10.`);
                            }

                            var mNumCount = Ax.db.executeGet(`
                                <select>
                                    <columns>
                                        COUNT(*)
                                    </columns>
                                    <from table='gdwh_vterartd' />
                                    <where>
                                        fecha  = ${mObjVterartd.fecha}  AND
                                        empcode= '${mObjVterartd.empcode}' AND
                                        codalm = '${mObjVterartd.codalm}' AND
                                        delega = '${mObjVterartd.delega}' AND
                                        depart = '${mObjVterartd.depart}' AND
                                        tabori = '${mObjVterartd.tabori}' AND
                                        tipdoc = '${mObjVterartd.tipdoc}' AND
                                        cladoc = '${mObjVterartd.cladoc}' AND
                                        tercer = '${mObjVterartd.tercer}' AND
                                        tipdir = '${mObjVterartd.tipdir}' AND
                                        terfac = '${mObjVterartd.terfac}' AND
                                        tergrp = '${mObjVterartd.tergrp}' AND
                                        terfed = '${mObjVterartd.terfed}' AND
                                        tercom = '${mObjVterartd.tercom}' AND
                                        terenv = '${mObjVterartd.terenv}' AND
                                        codnac = '${mObjVterartd.codnac}' AND
                                        codpro = '${mObjVterartd.codpro}' AND
                                        codzon = '${mObjVterartd.codzon}' AND
                                        agente = '${mObjVterartd.agente}' AND
                                        seccio = '${mObjVterartd.seccio}' AND
                                        codfam = '${mObjVterartd.codfam}' AND
                                        codart = '${mObjVterartd.codart}' AND
                                        varstk = '${mObjVterartd.varstk}' AND
                                        coduni = '${mObjVterartd.coduni}' AND
                                        auxal0 = '${mObjVterartd.auxal0}' AND
                                        auxal1 = '${mObjVterartd.auxal1}' AND
                                        auxal2 = '${mObjVterartd.auxal2}' AND
                                        auxal3 = '${mObjVterartd.auxal3}' AND
                                        auxal4 = '${mObjVterartd.auxal4}' AND
                                        semmes = '${mObjVterartd.semmes}'
                                    </where>
                                </select> 
                            `);

                            Ax.db.execute(`
                                --+INDEX(gdwh_vterartd, "i_gdwh_vterartd1")
                                UPDATE gdwh_vterartd
                                SET canmov: canmov + ${mObjVterartd.canmov},
                                    impbru: impbru + ${mObjVterartd.impbru},
                                    impnet: impnet + ${mObjVterartd.impnet},
                                    impdto: impdto + ${mObjVterartd.impdto},
                                    impcos: impcos + ${mObjVterartd.impcos},
                                    imprap: imprap + ${mObjVterartd.imprap},
                                    auxnu0: auxnu0 + ${mObjVterartd.auxnu0},
                                    auxnu1: auxnu1 + ${mObjVterartd.auxnu1},
                                    auxnu2: auxnu2 + ${mObjVterartd.auxnu2},
                                    auxnu3: auxnu3 + ${mObjVterartd.auxnu3},
                                    auxnu4: auxnu4 + ${mObjVterartd.auxnu4},
                                    auxnu5: auxnu5 + ${mObjVterartd.auxnu5},
                                    auxnu6: auxnu6 + ${mObjVterartd.auxnu6},
                                    auxnu7: auxnu7 + ${mObjVterartd.auxnu7},
                                    auxnu8: auxnu8 + ${mObjVterartd.auxnu8},
                                    auxnu9: auxnu9 + ${mObjVterartd.auxnu9}
                                WHERE 
                                    fecha  = ${mObjVterartd.fecha}  AND
                                    empcode= '${mObjVterartd.empcode}' AND
                                    codalm = '${mObjVterartd.codalm}' AND
                                    delega = '${mObjVterartd.delega}' AND
                                    depart = '${mObjVterartd.depart}' AND
                                    tabori = '${mObjVterartd.tabori}' AND
                                    tipdoc = '${mObjVterartd.tipdoc}' AND
                                    cladoc = '${mObjVterartd.cladoc}' AND
                                    tercer = '${mObjVterartd.tercer}' AND
                                    tipdir = '${mObjVterartd.tipdir}' AND
                                    terfac = '${mObjVterartd.terfac}' AND
                                    tergrp = '${mObjVterartd.tergrp}' AND
                                    terfed = '${mObjVterartd.terfed}' AND
                                    tercom = '${mObjVterartd.tercom}' AND
                                    terenv = '${mObjVterartd.terenv}' AND
                                    codnac = '${mObjVterartd.codnac}' AND
                                    codpro = '${mObjVterartd.codpro}' AND
                                    codzon = '${mObjVterartd.codzon}' AND
                                    agente = '${mObjVterartd.agente}' AND
                                    seccio = '${mObjVterartd.seccio}' AND
                                    codfam = '${mObjVterartd.codfam}' AND
                                    codart = '${mObjVterartd.codart}' AND
                                    varstk = '${mObjVterartd.varstk}' AND
                                    coduni = '${mObjVterartd.coduni}' AND
                                    auxal0 = '${mObjVterartd.auxal0}' AND
                                    auxal1 = '${mObjVterartd.auxal1}' AND
                                    auxal2 = '${mObjVterartd.auxal2}' AND
                                    auxal3 = '${mObjVterartd.auxal3}' AND
                                    auxal4 = '${mObjVterartd.auxal4}' AND
                                    semmes = '${mObjVterartd.semmes}'
                            `);

                            if (mNumCount == 0) {
                                Ax.db.insert('gdwh_vterartd', mObjVterartd)
                            }
                                
                            if (pStrIndagr == 'S') {
                                var mObjAgrega = Ax.db.executeQuery(`
                                    <select>
                                        <columns>
                                            tipagr tipdoc, claagr cladoc
                                        </columns>
                                        <from table='gdwh_agrega' />
                                        <where>
                                            tipdoc = '${mObjVterartd.tipdoc}' AND
                                            cladoc = '${mObjVterartd.cladoc}'
                                        </where>
                                    </select>
                                `).toOne();

                                mObjVterartd.tipdoc = mObjAgrega.tipdoc;
                                mObjVterartd.cladoc = mObjAgrega.cladoc;

                                if (mObjVterartd.tipdoc == null) {
                                    break;
                                }
                            } else {
                                break;
                            }

                        }
                    }
                }

                /**
                 *  Se marcan los registros procesados. 
                 */
                Ax.db.update('gdwh_vterdocd', 
                    {
                        valida: 'S' 
                    }, 
                    {
                        empcode: mRow.empcode,
                        delega : mRow.delega,
                        fecha  : new Ax.sql.Date(mRow.fecha),
                        valida : 'N'
                    }
                )

                /**
                 *  Se cierra la transaccion. 
                 */
                Ax.db.commitWork();
            } catch (error) {
                /**
                 *  Se retrocede la transaccion.    
                 */

                Ax.db.insert('gdwh_interr', 
                    {
                        proname: m_proname,
                        delalm: mRow.delega,
                        codigo: '',
                        fecinf: new Ax.sql.Date(mRow.fecha),
                        fecerr: new Ax.sql.Date(),
                        nsql: 0,
                        nisam: 0,
                        errmsg: Ax.util.Error.getMessage(error)
                    }
                )
            }
        }

        Ax.db.commitWork();
    }

    /**
     *  Agregar el resto de piramides.     
     */
    if (pStrCargar == 'S') {
        /**
         *  Ventas Delegaciones-Artículos-Día y Terceros-Familias-Día a partir 
         *  de Terceros-Artículos-Día.                                         
         */
        __local_gdwh_vterartd_artd(
            pStrEmpcode,
            pStrDelega,
            pDatFecini,
            pDatFecfin,
            pStrCargar,
            'N'
        )
    }
}