/**
 *  Js: gdwh_vdelsecm_tpv_comp                                                 
 *                                                                               
 *  Obtiene los datos para el canal de comparativo de ventas mensual.            
 *                                                                               
 *  El script es llamado indistintamente para ser ejecutado desde menú de objetos
 *  o desde canales.                                                             
 *                                                                               
 *  Llamada desde:                                                               
 *  ==============                                                               
 *     OBJETO   gdwh_vdelsecm_tpv_comp                                           
 *     CANAL    gdwh_vdelsecm_tpv_comp                                           
 */
function gdwh_vdelsecm_tpv_comp(
    pIntAnyAct,  pIntAnyCom, pIntTpv,
    pStrSqlcond, pStrSqlseca
) {
    var mStrSqlCond = pStrSqlcond || '1=1';
    var mStrSqlSeca = `gseccana.codigo ${pStrSqlseca || '=gseccana.codigo'}`;

    var mIntAnyAct = pIntAnyAct || new Ax.sql.Date().getFullYear();
    var mIntAnyCom = pIntAnyCom || (mIntAnyAct - 1);

    var mDatFecini = new Ax.sql.Date(mIntAnyCom,1,1);
    var mDatFecfin = new Ax.sql.Date(mIntAnyAct,12,31);

    /**
     *  Cuenta el número de tiquets por dia. 
     */
    var mBoolExistsTpv = false;

    if(Ax.db.existsTable('gtpv_ticketh')) {
        mBoolExistsTpv = true;
    }

    var mTmpGtpvTicketh = Ax.db.getTempTableName('tmp_gtpv_ticketh');

    if (pIntTpv == 0 || !mBoolExistsTpv) {
        Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGtpvTicketh}`);

        Ax.db.execute(`  
            CREATE TEMP TABLE ${mTmpGdelegac} (
                anymes INTEGER,
                fecha  DATE,
                delega CHAR(6), 
                secana CHAR(12),
                fecven DATE,
                numtic INTEGER
            )
            WITH NO LOG;
        `);  
    } else {
        Ax.db.execute(`
            <select intotemp='${mTmpGtpvTicketh}'>
                <columns>
                    <year>gtpv_ticketh.fecha</year>*100 + <month>gtpv_ticketh.fecha</month> anymes,
                    gtpv_ticketh.fecha,
                    gtpv_ticketh.delega,
                    <nvl>gartfami.secana, '-'</nvl> secana,
                    MAX(<eval-datetime>
                            <val unit='h'><hour>gtpv_ticketh.horfin</hour></val>
                            <val unit='min'><minute>gtpv_ticketh.horfin</minute></val>
                            <val unit='s'><second>gtpv_ticketh.horfin</second></val>
                            <val unit='datetime'><extend from='year' to='second'>gtpv_ticketh.fecha</extend></val>
                        </eval-datetime>) fecven,
                    COUNT(DISTINCT gtpv_ticketl.cabid) numtic
                </columns>
                <from table='gtpv_ticketh'>
                    <join table='gtpv_ticketd'>
                        <on>gtpv_ticketh.tipdoc = gtpv_ticketd.codigo</on>
                    </join>
                    <join table='gtpv_ticketl'>
                        <on>gtpv_ticketh.cabid = gtpv_ticketl.cabid</on>
                        <join table='garticul'>
                            <on>gtpv_ticketl.codart = garticul.codigo</on>
                            <join table='gartfami'>
                                <on>garticul.codfam = gartfami.codigo</on>
                            </join>
                        </join>
                    </join>
                </from>
                <where>
                    gtpv_ticketh.delega IN (SELECT gdelgrpl.delgrp
                                               FROM gdelgrph, gdelgrpl, gdelegac, cterdire
                                              WHERE ${mStrSqlCond}
                                                AND gdelgrpl.grpdel = gdelgrph.codigo
                                                AND gdelegac.codigo = gdelgrpl.delgrp
                                                AND cterdire.codigo = gdelegac.tercer
                                                AND cterdire.tipdir = gdelegac.dirdlg) AND
                    gtpv_ticketh.fecha BETWEEN ${mDatFecini} AND ${mDatFecfin} AND
                    gtpv_ticketd.indest != 0  AND
                    gtpv_ticketd.abono  = 0   AND
                    gtpv_ticketh.esttra = 0   AND
                    gtpv_ticketd.valdoc = 'S' AND
                    gartfami.secana IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlSeca})
                </where>
                <group>1, 2, 3, 4</group>
            </select>
        `)

        Ax.db.execute(`CREATE INDEX i_${mTmpGtpvTicketh} ON ${mTmpGtpvTicketh}(delega, secana)`)
    }    

    return Ax.db.executeQuery(`
        <select>
            <columns>
                <nvl>ctipozon.nomzon, '-'</nvl> nomzon,                                                                    <!-- 1  -->
                gdelegac.nomdlg,                                                                                                           <!-- 2  -->
                gseccana.nomsec,                                                                                                           <!-- 3  -->

                <!-- ============================================================ -->
                <!-- Facturación                                                  -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 1  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact1,  <!-- 4  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 2  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact2,  <!-- 5  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 3  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact3,  <!-- 6  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 4  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact4,  <!-- 7  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 5  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact5,  <!-- 8  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 6  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact6,  <!-- 9  -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 7  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact7,  <!-- 10 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 8  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact8,  <!-- 11 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 9  THEN gdwh_vdelsecm.impnet ELSE 0 END) facact9,  <!-- 12 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 10 THEN gdwh_vdelsecm.impnet ELSE 0 END) facact10, <!-- 13 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 11 THEN gdwh_vdelsecm.impnet ELSE 0 END) facact11, <!-- 14 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 12 THEN gdwh_vdelsecm.impnet ELSE 0 END) facact12, <!-- 15 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 1  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom1,  <!-- 16 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 2  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom2,  <!-- 17 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 3  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom3,  <!-- 18 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 4  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom4,  <!-- 19 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 5  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom5,  <!-- 20 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 6  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom6,  <!-- 21 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 7  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom7,  <!-- 22 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 8  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom8,  <!-- 23 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 9  THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom9,  <!-- 24 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 10 THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom10, <!-- 25 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 11 THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom11, <!-- 26 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 12 THEN gdwh_vdelsecm.impnet ELSE 0 END) faccom12, <!-- 27 -->

                <!-- ============================================================ -->
                <!-- Unidades                                                     -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 1  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact1,  <!-- 28 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 2  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact2,  <!-- 29 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 3  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact3,  <!-- 30 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 4  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact4,  <!-- 31 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 5  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact5,  <!-- 32 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 6  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact6,  <!-- 33 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 7  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact7,  <!-- 34 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 8  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact8,  <!-- 35 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 9  THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact9,  <!-- 36 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 10 THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact10, <!-- 37 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 11 THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact11, <!-- 38 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 12 THEN gdwh_vdelsecm.canmov ELSE 0 END) uniact12, <!-- 39 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 1  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom1,  <!-- 40 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 2  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom2,  <!-- 41 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 3  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom3,  <!-- 42 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 4  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom4,  <!-- 43 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 5  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom5,  <!-- 44 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 6  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom6,  <!-- 45 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 7  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom7,  <!-- 46 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 8  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom8,  <!-- 47 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 9  THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom9,  <!-- 48 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 10 THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom10, <!-- 49 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 11 THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom11, <!-- 50 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 12 THEN gdwh_vdelsecm.canmov ELSE 0 END) unicom12, <!-- 51 -->

                <!-- ============================================================ -->
                <!-- Clientes                                                     -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 1  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact1,  <!-- 52 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 2  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact2,  <!-- 53 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 3  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact3,  <!-- 54 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 4  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact4,  <!-- 55 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 5  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact5,  <!-- 56 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 6  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact6,  <!-- 57 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 7  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact7,  <!-- 58 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 8  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact8,  <!-- 59 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 9  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact9,  <!-- 60 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 10 THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact10, <!-- 61 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 11 THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact11, <!-- 62 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyAct}*100 + 12 THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact12, <!-- 63 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 1  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom1,  <!-- 64 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 2  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom2,  <!-- 65 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 3  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom3,  <!-- 66 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 4  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom4,  <!-- 67 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 5  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom5,  <!-- 68 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 6  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom6,  <!-- 69 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 7  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom7,  <!-- 70 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 8  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom8,  <!-- 71 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 9  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom9,  <!-- 72 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 10 THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom10, <!-- 73 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 11 THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom11, <!-- 74 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.anymes = ${mIntAnyCom}*100 + 12 THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom12, <!-- 75 -->

                <!-- ============================================================ -->
                <!-- Beneficios                                                   -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 1  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact1,  <!-- 76 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 2  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact2,  <!-- 77 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 3  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact3,  <!-- 78 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 4  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact4,  <!-- 79 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 5  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact5,  <!-- 80 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 6  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact6,  <!-- 81 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 7  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact7,  <!-- 82 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 8  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact8,  <!-- 83 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 9  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact9,  <!-- 84 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 10 THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact10, <!-- 85 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 11 THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact11, <!-- 86 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 12 THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) benact12, <!-- 87 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 1  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom1,   <!-- 88 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 2  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom2,   <!-- 89 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 3  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom3,   <!-- 90 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 4  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom4,   <!-- 91 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 5  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom5,   <!-- 92 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 6  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom6,   <!-- 93 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 7  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom7,   <!-- 94 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 8  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom8,   <!-- 95 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 9  THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom9,   <!-- 96 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 10 THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom10,  <!-- 97 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 11 THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom11,  <!-- 98 -->
                SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 12 THEN gdwh_vdelsecm.impnet - gdwh_vdelsecm.impcos ELSE 0 END) bencom12,  <!-- 99 -->

                <!-- ============================================================ -->
                <!-- Dias abiertos & datos                                        -->
                <!-- ============================================================ -->
                (SELECT COUNT(DISTINCT ${mTmpGtpvTicketh}.fecha)
                   FROM ${mTmpGtpvTicketh}
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecm.delega
                    AND ROUND(${mTmpGtpvTicketh}.anymes/100, 0) = ${mIntAnyAct}) openact,            <!-- 100 -->

                (SELECT COUNT(DISTINCT ${mTmpGtpvTicketh}.fecha)
                   FROM ${mTmpGtpvTicketh}
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecm.delega
                    AND ROUND(${mTmpGtpvTicketh}.anymes/100, 0) = ${mIntAnyCom}) opencom,            <!-- 101 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes BETWEEN ${mIntAnyCom}*100 + 1 AND ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes BETWEEN ${mIntAnyAct}*100 + 1 AND ${mIntAnyAct}*100 + 12 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes BETWEEN ${mIntAnyCom}*100 + 1 AND ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) datvar,                                                                   <!-- 102 -->

                <current /> datact,                                                                <!-- 103 -->

                (SELECT MAX(${mTmpGtpvTicketh}.fecven)
                   FROM ${mTmpGtpvTicketh}
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecm.delega) datult,                   <!-- 104 -->

                (SELECT COUNT(*)
                   FROM gtpv_emplepar
                  WHERE gtpv_emplepar.delega = gdwh_vdelsecm.delega
                    AND gtpv_emplepar.estado != 'B'
                    AND gtpv_emplepar.fecalt BETWEEN ${mDatFecini} AND ${mDatFecfin}
                    AND NOT(gtpv_emplepar.fecbaj BETWEEN ${mDatFecini} AND ${mDatFecfin})) numemp,   <!-- 105 -->

                <!-- ============================================================ -->
                <!-- Evolución ventas                                             -->
                <!-- ============================================================ -->
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 1 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 1 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 1 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven1,                                                                   <!-- 106 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 2 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 2 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 2 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven2,                                                                   <!-- 107 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 3 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 3 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 3 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven3,                                                                   <!-- 108 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 4 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 4 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 4 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven4,                                                                   <!-- 109 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 5 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 5 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 5 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven5,                                                                   <!-- 110 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 6 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 6 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 6 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven6,                                                                   <!-- 111 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 7 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 7 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 7 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven7,                                                                   <!-- 112 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 8 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 8 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 8 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven8,                                                                   <!-- 113 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 9 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 9 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 9 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven9,                                                                   <!-- 114 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 10 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 10 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 10 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven10,                                                                  <!-- 115 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 11 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 11 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 11 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven11,                                                                  <!-- 116 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyAct}*100 + 12 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecm.anymes = ${mIntAnyCom}*100 + 12 THEN <nvl>gdwh_vdelsecm.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven12,                                                                  <!-- 117 -->

                <!-- ============================================================ -->
                <!-- Semanas para el link a gdwh_vdelsec_tpv_comp_s               -->
                <!-- ============================================================ -->
                cterdire.codzon,                                                                     <!-- 118 -->
                gdelegac.codigo delega,                                                              <!-- 119 -->
                gseccana.codigo secana,                                                              <!-- 120 -->

                <!-- Mes actual -->
                gdwh_get_anysem(<mdy><m>1</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  semact1,
                gdwh_get_anysem(<mdy><m>2</m><d>28</d><y>${mIntAnyAct}</y></mdy>)  semact2,
                gdwh_get_anysem(<mdy><m>3</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  semact3,
                gdwh_get_anysem(<mdy><m>4</m><d>30</d><y>${mIntAnyAct}</y></mdy>)  semact4,
                gdwh_get_anysem(<mdy><m>5</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  semact5,
                gdwh_get_anysem(<mdy><m>6</m><d>30</d><y>${mIntAnyAct}</y></mdy>)  semact6,
                gdwh_get_anysem(<mdy><m>7</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  semact7,
                gdwh_get_anysem(<mdy><m>8</m><d>31</d><y>${mIntAnyAct}</y></mdy>)  semact8,
                gdwh_get_anysem(<mdy><m>9</m><d>30</d><y>${mIntAnyAct}</y></mdy>)  semact9,
                gdwh_get_anysem(<mdy><m>10</m><d>31</d><y>${mIntAnyAct}</y></mdy>) semact10,
                gdwh_get_anysem(<mdy><m>11</m><d>30</d><y>${mIntAnyAct}</y></mdy>) semact11,
                gdwh_get_anysem(<mdy><m>12</m><d>31</d><y>${mIntAnyAct}</y></mdy>) semact12,

                <!-- Mes comparativo -->
                gdwh_get_anysem(<mdy><m>1</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  semcom1,
                gdwh_get_anysem(<mdy><m>2</m><d>28</d><y>${mIntAnyCom}</y></mdy>)  semcom2,
                gdwh_get_anysem(<mdy><m>3</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  semcom3,
                gdwh_get_anysem(<mdy><m>4</m><d>30</d><y>${mIntAnyCom}</y></mdy>)  semcom4,
                gdwh_get_anysem(<mdy><m>5</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  semcom5,
                gdwh_get_anysem(<mdy><m>6</m><d>30</d><y>${mIntAnyCom}</y></mdy>)  semcom6,
                gdwh_get_anysem(<mdy><m>7</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  semcom7,
                gdwh_get_anysem(<mdy><m>8</m><d>31</d><y>${mIntAnyCom}</y></mdy>)  semcom8,
                gdwh_get_anysem(<mdy><m>9</m><d>30</d><y>${mIntAnyCom}</y></mdy>)  semcom9,
                gdwh_get_anysem(<mdy><m>10</m><d>31</d><y>${mIntAnyCom}</y></mdy>) semcom10,
                gdwh_get_anysem(<mdy><m>11</m><d>30</d><y>${mIntAnyCom}</y></mdy>) semcom11,
                gdwh_get_anysem(<mdy><m>12</m><d>31</d><y>${mIntAnyCom}</y></mdy>) semcom12

            </columns>
            <from table='gdwh_vdelsecm'>
                <join type='left' table='gdelegac'>
                    <on>gdelegac.codigo = gdwh_vdelsecm.delega</on>
                    <join table='cterdire'>
                        <on>gdelegac.tercer = cterdire.codigo</on>
                        <on>gdelegac.dirdlg = cterdire.tipdir</on>
                        <join type='left' table='ctipozon'>
                            <on>cterdire.codzon = ctipozon.codigo</on>
                        </join>
                    </join>
                </join>
                <join type='left' table='gseccana'>
                    <on>gseccana.codigo = gdwh_vdelsecm.seccio</on>
                </join>
                <join type='left' table='${mTmpGtpvTicketh}'>
                    <on>gdwh_vdelsecm.delega = ${mTmpGtpvTicketh}.delega</on>
                    <on>gdwh_vdelsecm.seccio = ${mTmpGtpvTicketh}.secana</on>
                    <on>gdwh_vdelsecm.anymes = ${mTmpGtpvTicketh}.anymes</on>
                </join>
            </from>
            <where>
                    gdwh_vdelsecm.delega IN (SELECT gdelgrpl.delgrp
                                               FROM gdelgrph, gdelgrpl, gdelegac, cterdire
                                              WHERE ${mStrSqlCond}
                                                AND gdelgrpl.grpdel = gdelgrph.codigo
                                                AND gdelegac.codigo = gdelgrpl.delgrp
                                                AND cterdire.codigo = gdelegac.tercer
                                                AND cterdire.tipdir = gdelegac.dirdlg)
                AND gdwh_vdelsecm.seccio IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlSeca})
                AND gdwh_vdelsecm.anymes BETWEEN ${mIntAnyCom}*100 + 1 AND ${mIntAnyAct}*100 + 12
            </where>
            <group>1, 2, 3, 100, 101, 103, 104, 105, 118, 119, 120</group>
            <order>1, 2, 3</order>
        </select>
    `);
}