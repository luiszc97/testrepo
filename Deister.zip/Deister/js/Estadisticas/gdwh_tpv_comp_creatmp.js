/**
 *  gdwh_tpv_comp_creatmp 
 */
function gdwh_tpv_comp_creatmp(pIntTpv, pStrSqlSecana, pStrSqlcond) {
    /**
     *  Elimna las tablas temporales con los valores a seleccionar.      
     */
    var mTmpGdelegac = Ax.db.getTempTableName('tmp_gdelegac');
    var mTmpGseccana = Ax.db.getTempTableName('tmp_gseccana');
    var mTmpGtpvTickethAct = Ax.db.getTempTableName('tmp_gtpv_ticketh_act');
    var mTmpgTpvTickethCom = Ax.db.getTempTableName('tmp_gtpv_ticketh_com');

    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGdelegac}`);
    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGseccana}`);
    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGtpvTickethAct}`);
    Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpgTpvTickethCom}`);

    var mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='@tmp_periodo' />
            <where>
                fecini IS NOT NULL AND
                fecfin IS NOT NULL
            </where>
        </select>    
    `)

    if (!mIntCount) {
        throw new Ax.lang.Exception(`No se han podido determinar las fechas segun las condiciones entradas.`)
    }

    /**
     *  DEFINICIÓN DE TEMPORALES.  
     */
    Ax.db.execute(`  
        CREATE TEMP TABLE ${mTmpGdelegac} (
            delega char(6),
            nomzon char(60),
            nomdlg varchar(50), 
            openact smallint,
            opencom smallint,
            numemp  smallint,
            datact  DATETIME year TO second,
            datult  DATETIME year TO second
        )
        WITH NO LOG;
    `);
    Ax.db.execute(`CREATE INDEX i_${mTmpGdelegac}1 ON ${mTmpGdelegac}(delega)`);

    Ax.db.execute(`  
        CREATE TEMP TABLE ${mTmpGseccana} (
            codigo char(12),
            nomsec varchar(40)
        )
        WITH NO LOG;
    `);
    Ax.db.execute(`CREATE INDEX i_${mTmpGseccana}1 ON ${mTmpGseccana}(codigo)`);

    Ax.db.execute(`  
        CREATE TEMP TABLE ${mTmpGtpvTickethAct} (
            fecha  date,
            fecven DATETIME year TO second,
            seccio char(12), 
            delega char(6),
            numtic integer
        )
        WITH NO LOG;
    `);
    Ax.db.execute(`CREATE INDEX i_${mTmpGtpvTickethAct} ON ${mTmpGtpvTickethAct}(fecha, seccio, delega)`);

    Ax.db.execute(`  
        CREATE TEMP TABLE ${mTmpgTpvTickethCom} (
            fecha  date,
            fecven DATETIME year TO second,
            seccio char(12), 
            delega char(6),
            numtic integer
        )
        WITH NO LOG;
    `);
    Ax.db.execute(`CREATE INDEX i_${mTmpgTpvTickethCom} ON ${mTmpgTpvTickethCom}(fecha, seccio, delega)`);

    /**
     *  Obtiene datos de las delegaciones seleccionadas en una temporal. 
     */
    var mArrGdelegac = Ax.db.executeQuery(`
        <select>
            <columns>
                gdelegac.codigo                 delega,
                <nvl>ctipozon.nomzon, '-'</nvl> nomzon,
                <trim>gdelegac.nomdlg</trim>    nomdlg,

                (SELECT COUNT(*) FROM gtpv_emplepar, @tmp_periodo
                  WHERE gtpv_emplepar.delega = gdelegac.codigo
                    AND gtpv_emplepar.estado != 'B'
                    AND @tmp_periodo.actcom = 'ACT'
                    AND @tmp_periodo.fecini BETWEEN <nvl>gtpv_emplepar.fecalt, @tmp_periodo.fecini</nvl> AND <nvl>gtpv_emplepar.fecbaj, @tmp_periodo.fecini</nvl>) numemp,

                <current /> datact
            </columns>
            <from table='gdelegac'>
                <join table='gret_delegac'>
                    <on>gdelegac.codigo = gret_delegac.codigo</on>
                </join>
                <join table='cterdire'>
                    <on>gdelegac.tercer = cterdire.codigo</on>
                    <on>gdelegac.dirdlg = cterdire.tipdir</on>
                    <join type='left' table='ctipozon'>
                        <on>cterdire.codzon = ctipozon.codigo</on>
                    </join>
                </join>
            </from>
            <where>
                ${pStrSqlcond}
            </where>
        </select>        
    `).toMemory();

    for (var mRow of mArrGdelegac) {
        Ax.db.insert(mTmpGdelegac, mRow);
    }

    /**
     *  TEMPORAL con las secciones analíticas a comprovar.  
     */
    var mArrGdataemp = Ax.db.executeQuery(`
        <select>
            <columns>
                '-' codigo, 'SECCIÓN ANALÍTICA SIN DEFINIR' nomsec
            </columns>
            <from table='gdataemp' />
            <where>
                '-' ${pStrSqlSecana}
            </where>
        </select>    
    `).toMemory();

    for (var mRow of mArrGdataemp) {
        Ax.db.insert(mTmpGseccana, mRow);
    }

    var mArrGSeccana = Ax.db.executeQuery(`
        <select>
            <columns>
                codigo, nomsec
            </columns>
            <from table='gseccana' />
            <where>
                codigo ${pStrSqlSecana}
            </where>
        </select>
    `).toMemory();

    for (var mRow of mArrGSeccana) {
        Ax.db.insert(mTmpGseccana, mRow);
    }

    /**
     *  TEMPORAL con los tickets de venta para la fecha ACTUAL, y para la fecha
     *  COMPARATIVA seleccionadas, y los últimos 7 días desde esta fecha.       
     */
    var mStrActcom, mStrTmpName;
    if (pIntTpv == 1) {
        for (var index = 1; index <= 2; index++) {
            if (index == 1) {
                mStrActcom = 'ACT';
                mStrTmpName = `${mTmpGtpvTickethAct}`;
            } else {
                mStrActcom = 'COM';
                mStrTmpName = `${mTmpgTpvTickethCom}`;
            }

            var mTmpGtpvTicketl= Ax.db.getTempTableName('tmp_gtpv_ticketl');
            Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGtpvTicketl}`);

            Ax.db.execute(`
                <select intotemp='@tmp_gtpv_ticketl'>
                    <columns>
                        gtpv_ticketh.fecha,
                        MAX(<eval-datetime>
                                <val unit='h'><hour>gtpv_ticketh.horfin</hour></val>
                                <val unit='min'><minute>gtpv_ticketh.horfin</minute></val>
                                <val unit='s'><second>gtpv_ticketh.horfin</second></val>
                                <val unit='datetime'><extend from='year' to='second'>gtpv_ticketh.fecha</extend></val>
                            </eval-datetime>) fecven,
                        <nvl>gartfami.secana, '-'</nvl> secana,
                        gtpv_ticketh.delega,
                        COUNT(DISTINCT gtpv_ticketl.cabid) numtiq
                    </columns>
                    <from table='gtpv_ticketh'>
                        <join table='gtpv_ticketd'>
                            <on>gtpv_ticketh.tipdoc = gtpv_ticketd.codigo</on>
                        </join>
                        <join table='@tmp_periodo'>
                            <on>gtpv_ticketh.fecha BETWEEN @tmp_periodo.fecini AND @tmp_periodo.fecfin</on>
                            <on>@tmp_periodo.actcom = '${mStrActcom}'</on>
                        </join>
                        <join table='gtpv_ticketl'>
                            <on>gtpv_ticketh.cabid = gtpv_ticketl.cabid</on>
                            <join table='garticul'>
                                <on>gtpv_ticketl.codart = garticul.codigo</on>
                                <join table='gartfami'>
                                    <on>garticul.codfam = gartfami.codigo</on>
                                </join>
                            </join>
                        </join>
                    </from>
                    <where>
                        gtpv_ticketh.delega IN (SELECT delega FROM ${mTmpGdelegac}) AND
                        gtpv_ticketd.indest != 0 AND
                        gtpv_ticketd.abono  = 0  AND
                        gtpv_ticketh.esttra = 0  AND
                        gtpv_ticketd.valdoc = 'S'
                    </where>
                    <group>1, 3, 4</group>
                </select>
            `);

            var mArrGdeleg =  Ax.db.executeQuery(`
                <select>
                    <columns>
                            @tmp_gtpv_ticketl.fecha,
                            @tmp_gtpv_ticketl.fecven,
                            @tmp_gseccana.codigo seccio,
                            @tmp_gdelegac.delega,
                            <nvl>@tmp_gtpv_ticketl.numtiq, 0</nvl> numtic
                    </columns>
                    <from table='@tmp_gdelegac'>
                         <join table='@tmp_gseccana' />
                         <join table='@tmp_gtpv_ticketl' type='left'>
                             <on>@tmp_gdelegac.delega = @tmp_gtpv_ticketl.delega</on>
                             <on>@tmp_gseccana.codigo = @tmp_gtpv_ticketl.secana</on>
                         </join>
                    </from>
                </select>
            `);

            for (var mRow of mArrGdeleg) {
                Ax.db.insert(mStrTmpName, mRow);
            }
        }

        /**
         *  Actualiza datos de la delegación, a partir de los tickets obtenidos.  
         */
        Ax.db.execute(`
            UPDATE gdwh_vdelartd
            SET openact = (SELECT COUNT(DISTINCT a.fecha) FROM ${mTmpGtpvTickethAct} a WHERE a.delega = ${mTmpGdelegac}.delega),
                opencom = (SELECT COUNT(DISTINCT a.fecha) FROM ${mTmpgTpvTickethCom} a WHERE a.delega = ${mTmpGdelegac}.delega),
                datult  = (SELECT MAX(a.fecven)           FROM ${mTmpGtpvTickethAct} a WHERE a.delega = ${mTmpGdelegac}.delega)
             WHERE 
                1=1
        `)
    }

}