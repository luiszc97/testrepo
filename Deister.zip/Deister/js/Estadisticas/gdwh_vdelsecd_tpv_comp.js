/**
 *  Js: gdwh_vdelsecd_tpv_comp                                       
 *                                                                  
 *  Obtiene los datos para el canal de comparativo de ventas diaria.   
 *                                                                  
 *  El script es llamado indistintamente para ser ejecutado desde menu 
 *  de objetos o desde canales.                                        
 *                                                                  
 *  Llamada desde:                                                     
 *  ==============                                                     
 *  OBJETO   gdwh_vdelsecd_tpv_comp                                 
 *  CANAL    gdwh_vdelsecd_tpv_comp                                 
 */
function gdwh_vdelsecd_tpv_comp(
    pDatFecAct,  pDatFecCom, pIntTpv,
    pStrSqlcond, pStrSqlseca
) {
    var mStrSqlCond = pStrSqlcond || '1=1';
    var mStrSqlSeca = `gseccana.codigo ${pStrSqlseca || '=gseccana.codigo'}`;

    var mDatFecAct = pDatFecAct || new Ax.sql.Date();
    //Obtener en dia actual menos un año 
    var mDatTodayAnt = new Ax.sql.Date(mDatFecAct.getFullYear() - 1, mDatFecAct.getMonth()+1, mDatFecAct.getDate());
    var mDatFecCom = pDatFecCom || mDatTodayAnt;

    /**
     *  Límites en los días a seleccionar. 
     */
    var mDatFeciniAct = new Ax.sql.Date(mDatFecAct.getFullYear(), mDatFecAct.getMonth()+1, mDatFecAct.getDate() - 6);
    var mDatFecfinAct = mDatFecAct;

    var mDatFeciniCom = new Ax.sql.Date(mDatFecCom.getFullYear(), mDatFecCom.getMonth()+1, mDatFecCom.getDate() - 6);
    var mDatFecfinCom = mDatFecCom;

    /**
     *  Cuenta el número de clientes por día.     
     */
    var mBoolExistsTpv = false;

    if (Ax.db.existsTable('gtpv_ticketh')) {
        mBoolExistsTpv = true;
    }

    var mTmpGtpvTicketh = Ax.db.getTempTableName('tmp_gtpv_ticketh');

    if (pIntTpv == 0 || !mBoolExistsTpv) {
        
        Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGtpvTicketh}`);

        Ax.db.execute(`  
            CREATE TEMP TABLE ${mTmpGdelegac} (
                anymes INTEGER,
                fecha  DATE,
                delega CHAR(6), 
                secana CHAR(12),
                fecven DATE,
                numtic INTEGER
            )
            WITH NO LOG;
        `);
    } else {
        Ax.db.execute(`
            <select intotemp='${mTmpGtpvTicketh}'>
                <columns>
                    gtpv_ticketh.fecha,
                    gtpv_ticketh.delega,
                    <nvl>gartfami.secana, '-'</nvl> secana,
                    MAX(<eval-datetime>
                            <val unit='h'><hour>gtpv_ticketh.horfin</hour></val>
                            <val unit='min'><minute>gtpv_ticketh.horfin</minute></val>
                            <val unit='s'><second>gtpv_ticketh.horfin</second></val>
                            <val unit='datetime'><extend from='year' to='second'>gtpv_ticketh.fecha</extend></val>
                        </eval-datetime>) fecven,
                    COUNT(DISTINCT gtpv_ticketl.cabid) numtic
                </columns>
                <from table='gtpv_ticketh'>
                    <join table='gtpv_ticketd'>
                        <on>gtpv_ticketh.tipdoc = gtpv_ticketd.codigo</on>
                    </join>
                    <join table='gtpv_ticketl'>
                        <on>gtpv_ticketh.cabid = gtpv_ticketl.cabid</on>
                        <join table='garticul'>
                            <on>gtpv_ticketl.codart = garticul.codigo</on>
                            <join table='gartfami'>
                                <on>garticul.codfam = gartfami.codigo</on>
                            </join>
                        </join>
                    </join>
                </from>
                <where>
                    gtpv_ticketh.delega IN (SELECT gdelgrpl.delgrp
                                              FROM gdelgrph, gdelgrpl, gdelegac, cterdire
                                             WHERE ${mStrSqlCond}
                                               AND gdelgrpl.grpdel = gdelgrph.codigo
                                               AND gdelegac.codigo = gdelgrpl.delgrp
                                               AND cterdire.codigo = gdelegac.tercer
                                               AND cterdire.tipdir = gdelegac.dirdlg) AND
                    (gtpv_ticketh.fecha BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct} OR
                     gtpv_ticketh.fecha BETWEEN ${mDatFeciniCom} AND ${mDatFecfinCom}) AND
                    gtpv_ticketd.indest != 0  AND
                    gtpv_ticketd.abono  = 0   AND
                    gtpv_ticketh.esttra = 0   AND
                    gtpv_ticketd.valdoc = 'S' AND
                    gartfami.secana IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlSeca})
                </where>
                <group>1, 2, 3</group>
            </select>
        `)

        Ax.db.execute(`CREATE INDEX i_${mTmpGtpvTicketh} ON ${mTmpGtpvTicketh}(delega, secana)`)
    }

    return Ax.db.executeQuery(`
        <select>
            <columns>
                <nvl>ctipozon.nomzon, '-'</nvl> nomzon,                                                                               <!-- 1  -->
                gdelegac.nomdlg,                                                                                                      <!-- 2  -->
                gseccana.nomsec,                                                                                                      <!-- 3  -->

                <!-- ============================================================ -->
                <!-- Facturación                                                  -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 6  THEN gdwh_vdelsecd.impnet ELSE 0 END) facact1,  <!-- 4  -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 5  THEN gdwh_vdelsecd.impnet ELSE 0 END) facact2,  <!-- 5  -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 4  THEN gdwh_vdelsecd.impnet ELSE 0 END) facact3,  <!-- 6  -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 3  THEN gdwh_vdelsecd.impnet ELSE 0 END) facact4,  <!-- 7  -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 2  THEN gdwh_vdelsecd.impnet ELSE 0 END) facact5,  <!-- 8  -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 1  THEN gdwh_vdelsecd.impnet ELSE 0 END) facact6,  <!-- 9  -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 0  THEN gdwh_vdelsecd.impnet ELSE 0 END) facact7,  <!-- 10 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 6  THEN gdwh_vdelsecd.impnet ELSE 0 END) faccom1,  <!-- 11 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 5  THEN gdwh_vdelsecd.impnet ELSE 0 END) faccom2,  <!-- 12 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 4  THEN gdwh_vdelsecd.impnet ELSE 0 END) faccom3,  <!-- 13 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 3  THEN gdwh_vdelsecd.impnet ELSE 0 END) faccom4,  <!-- 14 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 2  THEN gdwh_vdelsecd.impnet ELSE 0 END) faccom5,  <!-- 15 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 1  THEN gdwh_vdelsecd.impnet ELSE 0 END) faccom6,  <!-- 16 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 0  THEN gdwh_vdelsecd.impnet ELSE 0 END) faccom7,  <!-- 17 -->

                <!-- ============================================================ -->
                <!-- Unidades                                                     -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 6  THEN gdwh_vdelsecd.canmov ELSE 0 END) uniact1,  <!-- 18 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 5  THEN gdwh_vdelsecd.canmov ELSE 0 END) uniact2,  <!-- 19 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 4  THEN gdwh_vdelsecd.canmov ELSE 0 END) uniact3,  <!-- 20 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 3  THEN gdwh_vdelsecd.canmov ELSE 0 END) uniact4,  <!-- 21 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 2  THEN gdwh_vdelsecd.canmov ELSE 0 END) uniact5,  <!-- 22 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 1  THEN gdwh_vdelsecd.canmov ELSE 0 END) uniact6,  <!-- 23 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 0  THEN gdwh_vdelsecd.canmov ELSE 0 END) uniact7,  <!-- 24 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 6  THEN gdwh_vdelsecd.canmov ELSE 0 END) unicom1,  <!-- 25 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 5  THEN gdwh_vdelsecd.canmov ELSE 0 END) unicom2,  <!-- 26 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 4  THEN gdwh_vdelsecd.canmov ELSE 0 END) unicom3,  <!-- 27 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 3  THEN gdwh_vdelsecd.canmov ELSE 0 END) unicom4,  <!-- 28 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 2  THEN gdwh_vdelsecd.canmov ELSE 0 END) unicom5,  <!-- 29 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 1  THEN gdwh_vdelsecd.canmov ELSE 0 END) unicom6,  <!-- 30 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 0  THEN gdwh_vdelsecd.canmov ELSE 0 END) unicom7,  <!-- 31 -->

                <!-- ============================================================ -->
                <!-- Clientes                                                     -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecAct} - 6  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact1,  <!-- 32 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecAct} - 5  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact2,  <!-- 33 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecAct} - 4  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact3,  <!-- 34 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecAct} - 3  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact4,  <!-- 35 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecAct} - 2  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact5,  <!-- 36 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecAct} - 1  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact6,  <!-- 37 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecAct} - 0  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) cliact7,  <!-- 38 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecCom} - 6  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom1,  <!-- 39 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecCom} - 5  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom2,  <!-- 40 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecCom} - 4  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom3,  <!-- 41 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecCom} - 3  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom4,  <!-- 42 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecCom} - 2  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom5,  <!-- 43 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecCom} - 1  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom6,  <!-- 44 -->
                SUM(CASE WHEN ${mTmpGtpvTicketh}.fecha = ${mDatFecCom} - 0  THEN ${mTmpGtpvTicketh}.numtic ELSE 0 END) clicom7,  <!-- 45 -->

                <!-- ============================================================ -->
                <!-- Beneficios                                                   -->
                <!-- ============================================================ -->
                <!-- Semana actual -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 6  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) benact1,  <!-- 46 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 5  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) benact2,  <!-- 47 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 4  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) benact3,  <!-- 48 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 3  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) benact4,  <!-- 49 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 2  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) benact5,  <!-- 50 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 1  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) benact6,  <!-- 51 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 0  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) benact7,  <!-- 52 -->

                <!-- Semana comparativa -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 6  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) bencom1,  <!-- 53 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 5  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) bencom2,  <!-- 54 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 4  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) bencom3,  <!-- 55 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 3  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) bencom4,  <!-- 56 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 2  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) bencom5,  <!-- 57 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 1  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) bencom6,  <!-- 58 -->
                SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 0  THEN gdwh_vdelsecd.impnet - gdwh_vdelsecd.impcos ELSE 0 END) bencom7,  <!-- 59 -->

                <!-- ============================================================ -->
                <!-- Dias abiertos & datos                                        -->
                <!-- ============================================================ -->
                (SELECT COUNT(DISTINCT ${mTmpGtpvTicketh}.fecha)
                   FROM ${mTmpGtpvTicketh}
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecd.delega
                    AND ${mTmpGtpvTicketh}.fecha BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct}) openact,                   <!-- 60 -->

                (SELECT COUNT(DISTINCT ${mTmpGtpvTicketh}.fecha)
                   FROM ${mTmpGtpvTicketh}
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecd.delega
                    AND ${mTmpGtpvTicketh}.fecha BETWEEN ${mDatFeciniCom} AND ${mDatFecfinCom}) opencom,                  <!-- 61 -->

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha BETWEEN ${mDatFeciniCom} AND ${mDatFecfinCom} THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct} THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha BETWEEN ${mDatFeciniCom} AND ${mDatFecfinCom} THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) datvar,                                                                                        <!-- 62 -->

                <current /> datact,                                                                                     <!-- 63 -->

                (SELECT MAX(${mTmpGtpvTicketh}.fecven)
                   FROM ${mTmpGtpvTicketh}
                  WHERE ${mTmpGtpvTicketh}.delega = gdwh_vdelsecd.delega) datult,                                        <!-- 64 -->

                (SELECT COUNT(*)
                   FROM gtpv_emplepar
                  WHERE gtpv_emplepar.delega = gdwh_vdelsecd.delega
                    AND gtpv_emplepar.estado != 'B'
                    AND gtpv_emplepar.fecalt BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct}
                    AND NOT(gtpv_emplepar.fecbaj BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct})) numemp,                <!-- 65 -->

                <!-- ============================================================ -->
                <!-- Evolución ventas                                             -->
                <!-- ============================================================ -->
                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 6 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 6 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 6 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven1,

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 5 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 5 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 5 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven2,

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 4 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 4 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 4 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven3,

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 3 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 3 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 3 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven4,

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 2 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 2 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 2 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven5,

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 1 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 1 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 1 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven6,

                ROUND(
                CASE WHEN SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 0 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END) = 0 THEN 0
                     ELSE
                      (SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecAct} - 0 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)
                           /
                       SUM(CASE WHEN gdwh_vdelsecd.fecha = ${mDatFecCom} - 0 THEN <nvl>gdwh_vdelsecd.impnet, 0</nvl> ELSE 0 END)* 100)
                 END, 0) evoven7
            </columns>
            <from table='gdwh_vdelsecd'>
                <join type='left' table='gdelegac'>
                    <on>gdelegac.codigo = gdwh_vdelsecd.delega</on>
                    <join table='cterdire'>
                        <on>gdelegac.tercer = cterdire.codigo</on>
                        <on>gdelegac.dirdlg = cterdire.tipdir</on>
                        <join type='left' table='ctipozon'>
                            <on>cterdire.codzon = ctipozon.codigo</on>
                        </join>
                    </join>
                </join>
                <join type='left' table='gseccana'>
                    <on>gseccana.codigo = gdwh_vdelsecd.seccio</on>
                </join>
                <join type='left' table='${mTmpGtpvTicketh}'>
                    <on>gdwh_vdelsecd.delega = ${mTmpGtpvTicketh}.delega</on>
                    <on>gdwh_vdelsecd.seccio = ${mTmpGtpvTicketh}.secana</on>
                    <on>gdwh_vdelsecd.fecha  = ${mTmpGtpvTicketh}.fecha</on>
                </join>
            </from>
            <where>
                    gdwh_vdelsecd.delega IN (SELECT gdelgrpl.delgrp
                                               FROM gdelgrph, gdelgrpl, gdelegac, cterdire
                                              WHERE ${mStrSqlCond}
                                                AND gdelgrpl.grpdel = gdelgrph.codigo
                                                AND gdelegac.codigo = gdelgrpl.delgrp
                                                AND cterdire.codigo = gdelegac.tercer
                                                AND cterdire.tipdir = gdelegac.dirdlg)
                AND gdwh_vdelsecd.seccio IN (SELECT gseccana.codigo FROM gseccana WHERE ${mStrSqlSeca})
                AND (gdwh_vdelsecd.fecha BETWEEN ${mDatFeciniAct} AND ${mDatFecfinAct} OR
                     gdwh_vdelsecd.fecha BETWEEN ${mDatFeciniCom} AND ${mDatFecfinCom})
            </where>
            <group>1, 2, 3, 60, 61, 63, 64, 65</group>
            <order>1, 2, 3</order>
        </select>
    `);

}