/**
 *  Js: gdwh_vdelartd_famd                                               
 *                                                                      
 *  Script que carga la tabla gdwh_vdelfamtd (Delegación - familia diario) 
 *  desde la tabla gdwh_vdelartd (Delegación - artículo diario), siempre y 
 *  cuando la informacion hubiera sido cargada con el parametro            
 *  p_valida = 'N'.                                                        
 */
function gdwh_vdelartd_famd(
    pStrEmpcode, pStrDelega, pDatFecini,
    pDatFecfin, pStrCargar, pStrIndagr) {
    /**
     *  Control de errores                                       
     *  Borrar los errores producidos en ejecuciones anteriores. 
     */
    var mStrProname = 'VDELARTF';       // Ventas Delegaciones Artículos-Familias

    Ax.db.delete('gdwh_interr', {proname: mStrProname});

    var mIntCount;
    /**
     *  Procesar registros de gdwh_vdelartd.    
     */
    var mArrGdelegac = Ax.db.executeQuery(`
        <select>
            <columns>codigo</columns>
            <from table='gdelegac' />
            <where>
                codigo ${pStrDelega}
            </where>
        </select>        
    `).toMemory();

    for (var mObjGdelegac of mArrGdelegac) {
        var mArrGdwhVdelartd = Ax.db.executeQuery(`
            <select>
                <columns>
                    DISTINCT empcode, delega, fecha
                </columns>
                <from table='gdwh_vdelartd' />
                <where>
                    fecha BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                    empcode ${pStrEmpcode} AND
                    delega = ? AND
                    valida = 'N'
                </where>
                <order>
                    empcode, delega, fecha
                </order>
            </select>         
        `, mObjGdelegac.codigo).toMemory();

        for (var mRow of mArrGdwhVdelartd) {
            /**
             *  Control de error y transacción por delegación-día.   
             */
            try {
                /**
                 *  Se abre transaccion por delegación-día.  
                 */
                Ax.db.beginWork();

                /**
                 *  VENTAS DELEGACIONES-ARTÍCULOS-DIA. 
                 */
                mIntCount = Ax.db.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='gdwh_vdelfamd' />
                        <where>
                            empcode = ? AND
                            delega  = ? AND
                            fecha   = ?
                        </where>
                    </select>
                `, mRow.empcode, mRow.delega, mRow.fecha);

                if (pStrIndagr == 'N' && !mIntCount) {
                    var mArrGdwhVdelfamd = Ax.db.executeQuery(`
                        <select>
                           <columns>
                               fecha,  empcode,codalm, delega, depart, tabori,
                               tipdoc, cladoc, seccio, codfam, auxal0, auxal1,
                               auxal2, auxal3, auxal4,
                               SUM(canmov) canmov, SUM(impbru) impbru, SUM(impnet) impnet,
                               SUM(impdto) impdto, SUM(impcos) impcos, SUM(imprap) imprap,
                               SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1, SUM(auxnu2) auxnu2,
                               SUM(auxnu3) auxnu3, SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                               SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7, SUM(auxnu8) auxnu8,
                               SUM(auxnu9) auxnu9,
                               semmes, valida
                           </columns>
                           <from table='gdwh_vdelartd' />
                           <where>
                               delega = ? AND
                               fecha  = ${mRow.fecha} AND
                               valida = 'N'
                           </where>
                           <group>
                               fecha,  empcode,codalm, delega, depart, tabori, tipdoc,
                               cladoc, seccio, codfam, auxal0, auxal1, auxal2, auxal3,
                               auxal4, semmes, valida
                           </group>
                        </select>        
                    `, mRow.delega).toMemory();

                    for (var mObjGdwhVdelfamd of mArrGdwhVdelfamd) {
                        Ax.db.insert('gdwh_vdelfamd', mObjGdwhVdelfamd);
                    }        

                } else {
                    var mArrGdwhVdelfamd = Ax.db.executeQuery(`
                        <select>
                            <columns>
                                fecha,  empcode,codalm, delega, depart, tabori,
                                tipdoc, cladoc, seccio, codfam, auxal0, auxal1,
                                auxal2, auxal3, auxal4,
                                SUM(canmov) canmov, SUM(impbru) impbru,
                                SUM(impnet) impnet, SUM(impdto) impdto,
                                SUM(impcos) impcos, SUM(imprap) imprap,
                                SUM(auxnu0) auxnu0, SUM(auxnu1) auxnu1,
                                SUM(auxnu2) auxnu2, SUM(auxnu3) auxnu3,
                                SUM(auxnu4) auxnu4, SUM(auxnu5) auxnu5,
                                SUM(auxnu6) auxnu6, SUM(auxnu7) auxnu7,
                                SUM(auxnu8) auxnu8, SUM(auxnu9) auxnu9,
                                semmes, valida
                            </columns>
                            <from table='gdwh_vdelartd' />
                            <where>
                                delega = ? AND
                                fecha  = ${mRow.fecha} AND
                                valida = 'N'
                            </where>
                            <group>
                                fecha,  empcode,codalm, delega, depart, tabori,
                                tipdoc, cladoc, seccio, codfam, auxal0, auxal1,
                                auxal2, auxal3, auxal4, semmes, valida
                            </group>
                        </select>       
                    `, mRow.delega).toMemory();

                    for (var mObjGdwhVdelfamd of mArrGdwhVdelfamd) {
                        for (var mIntIter = 1; mIntIter <= 11; mIntIter++) {
                            /**
                             *  Control de que las iteraciones no sean más de 10.  
                             */
                            if (mIntIter > 10) {
                                throw new Ax.lang.Exception(`gdwh_vdelartd_famd: Número de iteraciones superada. Máximo 10.`)
                            }

                            var mNumCount = Ax.db.executeGet(`
                                <select>
                                    <columns>
                                        COUNT(*)
                                    </columns>
                                    <from table='gdwh_vdelfamd' />
                                    <where>
                                        fecha  = ${mObjGdwhVdelfamd.fecha}      AND
                                        empcode= '${mObjGdwhVdelfamd.empcode}'  AND
                                        codalm = '${mObjGdwhVdelfamd.codalm}'   AND
                                        delega = '${mObjGdwhVdelfamd.delega}'   AND
                                        depart = '${mObjGdwhVdelfamd.depart}'   AND
                                        tabori = '${mObjGdwhVdelfamd.tabori}'   AND
                                        tipdoc = '${mObjGdwhVdelfamd.tipdoc}'   AND
                                        cladoc = '${mObjGdwhVdelfamd.cladoc}'   AND
                                        seccio = '${mObjGdwhVdelfamd.seccio}'   AND
                                        codfam = '${mObjGdwhVdelfamd.codfam}'   AND
                                        auxal0 = '${mObjGdwhVdelfamd.auxal0}'   AND
                                        auxal1 = '${mObjGdwhVdelfamd.auxal1}'   AND
                                        auxal2 = '${mObjGdwhVdelfamd.auxal2}'   AND
                                        auxal3 = '${mObjGdwhVdelfamd.auxal3}'   AND
                                        auxal4 = '${mObjGdwhVdelfamd.auxal4}'   AND
                                        semmes = '${mObjGdwhVdelfamd.semmes}'
                                    </where>
                                </select> 
                            `);

                            Ax.db.execute(`
                                --+ INDEX(ventas idx_ventas_fecha)
                                UPDATE gdwh_vdelfamd
                                SET canmov = canmov + ${mObjGdwhVdelfamd.canmov},
                                    impbru = impbru + ${mObjGdwhVdelfamd.impbru},
                                    impnet = impnet + ${mObjGdwhVdelfamd.impnet},
                                    impdto = impdto + ${mObjGdwhVdelfamd.impdto},
                                    impcos = impcos + ${mObjGdwhVdelfamd.impcos},
                                    imprap = imprap + ${mObjGdwhVdelfamd.imprap},
                                    auxnu0 = auxnu0 + ${mObjGdwhVdelfamd.auxnu0},
                                    auxnu1 = auxnu1 + ${mObjGdwhVdelfamd.auxnu1},
                                    auxnu2 = auxnu2 + ${mObjGdwhVdelfamd.auxnu2},
                                    auxnu3 = auxnu3 + ${mObjGdwhVdelfamd.auxnu3},
                                    auxnu4 = auxnu4 + ${mObjGdwhVdelfamd.auxnu4},
                                    auxnu5 = auxnu5 + ${mObjGdwhVdelfamd.auxnu5},
                                    auxnu6 = auxnu6 + ${mObjGdwhVdelfamd.auxnu6},
                                    auxnu7 = auxnu7 + ${mObjGdwhVdelfamd.auxnu7},
                                    auxnu8 = auxnu8 + ${mObjGdwhVdelfamd.auxnu8},
                                    auxnu9 = auxnu9 + ${mObjGdwhVdelfamd.auxnu9}
                                WHERE 
                                    fecha  = ${mObjGdwhVdelfamd.fecha}      AND
                                    empcode= '${mObjGdwhVdelfamd.empcode}'  AND
                                    codalm = '${mObjGdwhVdelfamd.codalm}'   AND
                                    delega = '${mObjGdwhVdelfamd.delega}'   AND
                                    depart = '${mObjGdwhVdelfamd.depart}'   AND
                                    tabori = '${mObjGdwhVdelfamd.tabori}'   AND
                                    tipdoc = '${mObjGdwhVdelfamd.tipdoc}'   AND
                                    cladoc = '${mObjGdwhVdelfamd.cladoc}'   AND
                                    seccio = '${mObjGdwhVdelfamd.seccio}'   AND
                                    codfam = '${mObjGdwhVdelfamd.codfam}'   AND
                                    auxal0 = '${mObjGdwhVdelfamd.auxal0}'   AND
                                    auxal1 = '${mObjGdwhVdelfamd.auxal1}'   AND
                                    auxal2 = '${mObjGdwhVdelfamd.auxal2}'   AND
                                    auxal3 = '${mObjGdwhVdelfamd.auxal3}'   AND
                                    auxal4 = '${mObjGdwhVdelfamd.auxal4}'   AND
                                    semmes = '${mObjGdwhVdelfamd.semmes}'
                            `);

                            if (mNumCount == 0) {
                                Ax.db.insert('gdwh_vdelfamd', mObjGdwhVdelfamd)
                            }

                            if (pStrIndagr == 'S') {
                                mObjGdwhAgrega = Ax.db.executeQuery(`
                                    <select>
                                        <columns>
                                            tipagr tipdoc, claagr cladoc
                                        </columns>
                                        <from table='gdwh_agrega' />
                                        <where>
                                            tipdoc = '${mObjGdwhVdelfamd.tipdoc}' AND
                                            cladoc = '${mObjGdwhVdelfamd.cladoc}'
                                        </where>
                                    </select>
                                `).toOne();

                                mObjGdwhVdelfamd.tipdoc = mObjGdwhAgrega.tipdoc;
                                mObjGdwhVdelfamd.cladoc = mObjGdwhAgrega.cladoc;

                                if (mObjGdwhVdelfamd.tipdoc == null) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                    }
                }

                /**
                 *  Se marcan los registros procesados. 
                 */
                Ax.db.update('gdwh_vdelartd', 
                    {
                        valida: 'S'
                    }, 
                    {
                        empcode: mRow.empcode, 
                        delega : mRow.delega,
                        fecha  : mRow.fecha,
                        valida : 'N'
                    }
                )

                /**
                 *  Se cierra la transaccion.  
                 */
                Ax.db.commitWork();
                
            } catch (error) {
                /**
                 *  Se retrocede la transaccion.  
                 */
                Ax.db.rollbackWork();

                Ax.db.insert('gdwh_interr', 
                    {
                        proname: mStrProname, 
                        delalm : mRow.delega, 
                        codigo : '',   
                        fecinf : mRow.fecha,  
                        fecerr : new Ax.sql.Date(),
                        nsql   : 0,
                        nisam  : 0,
                        errmsg : Ax.util.Error.getMessage(error)
                    }
                )
            }

        }
        
        Ax.db.commitWork();
    }

    /**
     *  Agregar el resto de piramides.  
     */
    if (pStrCargar == 'S') {
        /**
         *  Ventas Delegaciones-Secciones-Día a partir de   
         *  Delegaciones-Familias-Día.                      
         */
        Ax.db.call('gdwh_vdelfamd_secd',
            pStrEmpcode,
            pStrDelega, 
            pDatFecini, 
            pDatFecfin, 
            pStrCargar,
            'N'
        )
    }

}