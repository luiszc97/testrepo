/* ============================================
//
// Enviar els geanmovh als armaris Omnicell.
//
// Cridat des de l´objecte mutGeanmovh2omn.
//
// ============================================*/
function mutGeanmovh2omn(pIntCabid) {
    //Inicializar el log. 
    Ax.db.beginWork();
    let mClogprohLogId = Ax.db.call('clogproh_ini', 'mutGeanmovh2omn', null, 0);

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    // IMPORTANT: El programa de farmacia no ha d'agafar línies sense capçaleres
    let mArrGeanmovl = Ax.db.executeQuery(`
        <select>
            <columns>
                geanmovh.fecmov, geanmovh.docser, gcomsolh.auxchr1, geanmovl.codart, geanmovl.canmov, geanmovl.cabid, geanmovl.linid, gcomsolh.tipdoc, geanmovh.date_created, gcomsolh.cabid gcomsolh_cabid
            </columns>
            <from table = 'geanmovl'>
                <join table='gcomsoll'>
                    <on>geanmovl.linori = gcomsoll.linid</on>
                </join>
                <join table='gcomsolh'>
                    <on>gcomsoll.cabid = gcomsolh.cabid</on>
                </join>
                <join table='geanmovh'>
                    <on>geanmovl.cabid = geanmovh.cabid</on>
                </join>
            </from>
            <where>
                geanmovl.cabid = ?
            and gcomsolh.tipdoc IN ('FMED')
            and geanmovl.canmov &gt; 0
            and NVL(gcomsolh.auxchr1,'') != ''
            and NOT EXISTS (SELECT * FROM mut_omn_geanmovh_his WHERE geanmovh.docser=omn_docori)
            and NOT EXISTS (SELECT * FROM mut_omn_geanmovh WHERE geanmovh.docser=omn_docori AND geanmovl.linid=omn_linean)
            </where>
            <order>geanmovl.cabid, geanmovl.linid</order>
        </select>
    `, pIntCabid);

    for (let mRow of mArrGeanmovl) {
        try {
            //Insertar la capçalera
            Ax.db.insert('mut_omn_geanmovh', 
                {
                    'omn_tipdoc': mRow.tipdoc,
                    'omn_fecha' : mRow.fecmov,
                    'omn_docori': mRow.docser,
                    'omn_codarmari': mRow.auxchr1,
                    'omn_codart': mRow.codart,
                    'omn_canmov': mRow.canmov,
                    'omn_cabean': mRow.cabid,
                    'omn_linean': mRow.linid
                }
            )

            Ax.db.call('clogprol_set', 
                mClogprohLogId,
                null,
                null,
                null,
                null,
                null,
                null,    
                mRow.cabid,
                null
            )

            //Marquem les sol.licituds com confirmades, no esperem a la reposició de l'armari
            Ax.db.execute(`
                UPDATE mut_omn_gcomsolh_his
                SET date_confirmed = ${mRow.date_created}, 
                    omn_linconfirm = ${mRow.linid}
                WHERE
                    date_confirmed IS NULL
                    AND omn_codart = ?
                    AND omn_cabsol = ${mRow.gcomsolh_cabid}
            `, mRow.codart);

        } catch (error) {
            Ax.db.rollbackWork();
            Ax.db.call('clogprol_set', 
                mClogprohLogId, 
                Ax.util.Error.getMessage(error),
                Ax.util.Error.getErrorCode(error),
                null,
                null,
                null,
                null,  
                mRow.cabid,
                null  
            );
        }
    }

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    //Cerrar el log de proceso.
    Ax.db.call('clogproh_fin', mClogprohLogId);

    return mClogprohLogId;

}
