/* 
// ================================================================================ 
//                                                                                  
//    Enviar els geanmovh amb codalm = '??FAR' i lineas no enviades i amb 'N' o 'E' 
//    a la BD lt_farma_mps@hp005so.                                                 
//                                                                                  
//    Cridat des de l´objecte mut_geanmovh2farma.                                   
//                                                                                  
// ================================================================================ 
*/
function mutGeanmovh2farma(pStrSqlcond) {
    //Inicializar el log.
    Ax.db.beginWork();
    let mClogprohLogId = Ax.db.call('clogproh_ini','mutGeanmovh2farma', null, 0);

    if (Ax.db.isOnTransaction()) {
        Ax.db.commitWork();
    }

    let mStrDbname = Ax.db.getCode();

    //  Primer insertar les línies. Així s'evita que el programa de farmàcia   
    //  agafi capçaleres sense línies.                                         
    //  IMPORTANT: El programa de farmàcia no ha d'agafar línies sense         
    //  capçaleres       
    
    let mArrGeanmovh = Ax.db.executeQuery(`
        <select>
            <columns>
            geanmovh.cabid,
            geanmovh.tipdoc,
            geanmovh.empcode,
            CASE WHEN geanmovh.delega[1,2] = "14" THEN "N" || TRIM(substr(geanmovh.delega,3,length(geanmovh.delega)-2)) ELSE geanmovh.delega END delega,
            substr(gdelgrpl.grpdel,2,length(gdelgrpl.grpdel)-1) depart,
            geanmovh.fecmov fecsol,
            geanmovh.docser,
            geanmovh.user_updated username,
            date(geanmovh.date_updated) fecmod,
            <m_dbname /> dbsname,
            'N' estado,
            geanmovh.date_updated date_updated,
            geanmovl.linid,
            TRIM(replace(geanmovl.codart,'.','')) codart,
            geanmovl.varstk varlog,
            geanmovl.desvar,
            geanmovl.canmov cansol,
            geanmovl.precio,
            TRIM(replace(<nvl>garticul.auxchr2,geanmovl.codart</nvl>,'.','')) errmsg
            </columns>
            <from table='geanmovh'>
                <join table='geanmovl'>
                    <on>geanmovl.cabid = geanmovh.cabid</on>
                    <join type='left' table='garticul'>
                        <on>garticul.codigo = geanmovl.codart</on>
                    </join>
                </join>
                <join type='left' table='gdelgrpl'>
                    <on>gdelgrpl.delgrp = geanmovh.delega</on>
                    <on>gdelgrpl.estado = 'A'</on>
                </join>
            </from>
            <where>
            geanmovh.tipdoc IN ('COCF','DEVA')              AND
            geanmovh.almori MATCHES '??FAR'                 AND
            geanmovh.fecmov &gt;= '01-12-2012'                 AND
            geanmovl.estlin = 'V'                           AND
            (gdelgrpl.grpdel MATCHES "F[A-R,T-Z,0-9]*" OR gdelgrpl.grpdel in ('FSM05','FSM06','FSS08')) AND
            ${pStrSqlcond}
            </where>
            <order>cabid,linid</order>
        </select>
    `);

    let mBoolErrorLine;

    mArrGeanmovh.cursor()
        .group("cabid")
            .before(mRow => {
                Ax.db.beginWork();
                mBoolErrorLine = false;
            })
            .after(mRow => {
                if (!mBoolErrorLine) {
                    try {
                        // Primer es modifica la possible capçalera.
                        let dbName = Ax.db.of('lt_farma_mps');
                        dbName.execute(`
                            DELETE FROM mps_gcomsolh_erp 
                                WHERE cabid = ${mRow.cabid} 
                                  AND dbsname = '${mRow.dbsname}'
                                  AND estado IN ('N', 'E')
                        `);

                        // Insertar la capçalera
                        dbName.insert('mps_gcomsolh_erp', 
                            {
                                'cabid'  : mRow.cabid,
                                'tipdoc' : mRow.tipdoc,
                                'empcode': mRow.empcode,
                                'delega' : mRow.delega,
                                'depart' : mRow.depart,
                                'fecsol' : mRow.fecsol,
                                'docser' : mRow.docser,
                                'username': mRow.username,
                                'fecmod' : mRow.fecmod,
                                'dbsname': mRow.dbsname,
                                'estado' : mRow.estado,
                                'date_updated': mRow.date_updated,
                                'errno' : null,
                                'isamno': null,
                                'errmsg': null
                            }
                        )

                        Ax.db.call('clogprol_set', 
                            mClogprohLogId,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            mRow.cabid,
                            null
                        );

                    } catch (error) {
                        Ax.db.rollbackWork();

                        Ax.db.call('clogprol_set', 
                            mClogprohLogId,
                            Ax.util.Error.getMessage(error),
                            Ax.util.Error.getErrorCode(error),
                            null,
                            null,
                            null,
                            null,
                            mRow.cabid,
                            null
                        );

                    }
                }

                if (Ax.db.isOnTransaction()) {
                    Ax.db.commitWork();
                }
        })
        .forEach(mRow => {
            let dbName = Ax.db.of('lt_farma_mps');
            let mIntCount = dbName.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mps_gcomsoll_erp'>
                        <join table='mps_gcomsolh_erp'>
                            <on>mps_gcomsoll_erp.cabid = mps_gcomsolh_erp.cabid</on>
                        </join>
                    </from>
                    <where>
                        mps_gcomsoll_erp.linid   = ?   AND
                        mps_gcomsoll_erp.estado IN ('S','P','Z') AND
                        mps_gcomsolh_erp.dbsname = ?
                    </where>
                </select>
            `, mRow.linid, mRow.dbsname);

            if (mIntCount) {
                return;
            }

            try {
                //Error en línies no processar-les fins a nou cabid.
                if (mBoolErrorLine) {
                    return;
                }

                let dbName2 = Ax.db.of('lt_farma_mps');
                dbName2.execute(`
                 DELETE FROM mps_gcomsoll_erp 
                  WHERE linid = ${mRow.linid} 
                    AND dbsname = '${mRow.dbsname}'
                    AND estado IN ('E','N')
                `)

                let mStrSwap = mRow.codart;
                mRow.codart  = mRow.errmsg;
                mRow.errmsg  = mStrSwap;
                mRow.desvar  = `${mRow.desvar} (${mRow.errmsg})`;

                dbName2.insert('mps_gcomsoll_erp', 
                    {
                        'linid':   mRow.linid,
                        'cabid':   mRow.cabid,
                        'codart':  mRow.codart,
                        'varlog':  mRow.varlog,
                        'desvar':  mRow.desvar,
                        'cansol':  mRow.cansol,
                        'precio':  mRow.precio,
                        'dbsname': mRow.dbsname,
                        'estado':  mRow.estado,
                        'date_updated': mRow.date_updated,
                        'errno': null,
                        'isamno': null,
                        'errmsg': null
                    }
                )

            } catch (error) {
                mBoolErrorLine = true;
                Ax.db.rollbackWork();

                Ax.db.call('clogprol_set', 
                    mClogprohLogId,
                    Ax.util.Error.getMessage(error),
                    Ax.util.Error.getErrorCode(error),
                    null,
                    null,
                    null,
                    null,
                    mRow.cabid,
                    mRow.linid
                )
            }

        }
    );

    //Cerrar el log de proceso.
    Ax.db.call('clogproh_fin', mClogprohLogId);

    return mClogprohLogId;

}