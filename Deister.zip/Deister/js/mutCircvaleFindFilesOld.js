function mutCircvaleFindFilesOld() {
    let mRsResult = new Ax.rs.Reader().memory(options => {
		options.setColumnNames(['cabid','status','codusr','fecha','filept']);
		options.setColumnTypes([Ax.sql.Types.INTEGER,Ax.sql.Types.VARCHAR,Ax.sql.Types.VARCHAR,Ax.sql.Types.TIMESTAMP, Ax.sql.Types.VARCHAR]);
	});

    let mArrCircvale = Ax.db.executeQuery(`
        <select>
            <columns>cabid, user_created, date_created</columns>
            <from table='mut_circvale' />
            <where>
                tabname = 'gcomfach' AND
                indpdf  = 0
            </where>
            <order>date_created</order>
        </select>
    `);

    for (const mRow of mArrCircvale) {
        let mStrText = new Ax.lang.String(mRow.cabid);
        let mStrCabchr = mStrText.lpad('0', 7);
        let mStrRootpt = `/mnt/factures/dirOut/`;
        let mStrResult1 = mStrCabchr.slice(0, 3);
        let mStrResult2 = mStrCabchr.slice(3, 5);
        let mStrHashpt = `${mStrResult1}/${mStrResult2}/`;

        let mIntDigcon;
        switch (mRow.cabid) {
            case '299999':
                mIntDigcon = 9;
            break;
            default:
                let mIntV1 = Number(mStrCabchr.slice(0, 1)) * 3;
                let mIntV2 = Number(mStrCabchr.slice(1, 2)) * 1;
                let mIntV3 = Number(mStrCabchr.slice(2, 3)) * 3;
                let mIntV4 = Number(mStrCabchr.slice(3, 4)) * 1;
                let mIntV5 = Number(mStrCabchr.slice(4, 5)) * 3;
                let mIntV6 = Number(mStrCabchr.slice(5, 6)) * 1;
                let mIntV7 = Number(mStrCabchr.slice(6, 7)) * 3;

                let mIntSuma = mIntV1+mIntV2+mIntV3+mIntV4+mIntV5+mIntV6+mIntV7;
                let mIntRe = Math.abs(100 - mIntSuma);
                mIntDigcon = mIntRe % 10;

            break;
        }

        let mStrNamefl = `${mStrCabchr}${mIntDigcon}.pdf`;
        let mStrFilept = `${mStrRootpt}${mStrHashpt}${mStrNamefl}`;
        let mStrStatus = 'FOUND';

        let folder = new Ax.io.File(mStrFilept);

        if (folder.canRead()) {
            Ax.db.call('mut_circvale_accion', 
                'gcomfach',
                mRow.cabid,
                'V',
                null,
                null,
                null,
                null
            );

        } else {
            mStrStatus = 'NOT FOUND';
        }

        mRsResult.rows().add([row.cabid, mStrStatus, row.user_created, row.date_created,  mStrFilept]);
    }

    return mRsResult;
    
}