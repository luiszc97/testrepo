function mut_nfc_get_mailconf(pStrTercer, pStrState){

    let mStrEmail;
    switch (pStrState) {
        case '0':
            mStrEmail = Ax.db.executeGet(`
                <select>
                    <columns>
                        recexp emails
                    </columns>
                    <from table='mut_nfc_mailconf'/>
                    <where>
                        tercer = ?
                    </where>
                </select>
            `, pStrTercer);            
            break;

        case '1':
            mStrEmail = Ax.db.executeGet(`
                <select>
                    <columns>
                        recfin emails
                    </columns>
                    <from table='mut_nfc_mailconf'/>
                    <where>
                        tercer = ?
                    </where>
                </select>
            `, pStrTercer);            
            break;

        case '2':
            mStrEmail = Ax.db.executeGet(`
                <select>
                    <columns>
                        recpen emails
                    </columns>
                    <from table='mut_nfc_mailconf'/>
                    <where>
                        tercer = ?
                    </where>
                </select>
            `, pStrTercer);            
            break;
        
        case '3':
            mStrEmail = Ax.db.executeGet(`
                <select>
                    <columns>
                        recirr emails
                    </columns>
                    <from table='mut_nfc_mailconf'/>
                    <where>
                        tercer = ?
                    </where>
                </select>
            `, pStrTercer);            
            break;

        case '4':
            mStrEmail = Ax.db.executeGet(`
                <select>
                    <columns>
                        recpenmat emails
                    </columns>
                    <from table='mut_nfc_mailconf'/>
                    <where>
                        tercer = ?
                    </where>
                </select>
            `, pStrTercer);            
            break;

        case '5':
            mStrEmail = Ax.db.executeGet(`
                <select>
                    <columns>
                        reccord emails
                    </columns>
                    <from table='mut_nfc_mailconf'/>
                    <where>
                        tercer = ?
                    </where>
                </select>
            `, pStrTercer);            
            break;
        
        case '6':
            mStrEmail = Ax.db.executeGet(`
                <select>
                    <columns>
                        recservext emails
                    </columns>
                    <from table='mut_nfc_mailconf'/>
                    <where>
                        tercer = ?
                    </where>
                </select>
            `, pStrTercer);            
            break;
    
        default:
            mStrEmail = null;
            break;
    }

    return mStrEmail;
    
}