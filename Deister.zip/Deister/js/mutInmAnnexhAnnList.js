function mutInmAnnexhAnnList() {
    return Ax.db.executeQuery(`
        <select>
            <columns>
                ann_code, TRIM(ann_code) || ' - ' || TRIM(ann_title) ann_title
            </columns>
            <from table='mut_inm_annexh' />
            <order>1</order>
        </select>
    `);
}