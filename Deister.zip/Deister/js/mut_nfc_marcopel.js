function mut_nfc_marcopel(pStrEvent, pIntRowid){
    
    //Obté els components d'una data o timestamp.
    function __local_date_comp(pDatefecha){
        let mObjDate = Ax.db.executeQuery(`
            <select>
                <columns>
                    YEAR(${pDatefecha})  year,
                    MONTH(${pDatefecha}) month,
                    DAY(${pDatefecha})   day
                </columns>
                <from table='wic_dual' />
            </select>`).toOne();

        return mObjDate;

    }

    //Registrar error de línia i capçalera.
    function __local_set_error(pIntRegid, pStrErrmsg){
        Ax.db.update('mut_nfc_marcopel', 
            {
                'estado': 'E',
                'errmsg': pStrErrmsg
            }, 
            {
                'regid': pIntRegid
            }
        );

        let mObjtMarcopel = Ax.db.executeQuery(`
            <select>
                <columns>
                    fecmar, 
                    tercer
                </columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    regid = ?
                </where>
            </select>
        `, pIntRegid).toOne();

        Ax.db.update('mut_nfc_marcopeh', 
            {
                'estado': 'E'
            }, 
            {
                'fecmar': mObjtMarcopel.fecmar,
                'tercer': mObjtMarcopel.tercer,
                'estado': 'V'
            }
        );       

    }

    //Sortir si event és Esborrat. 
    if (pStrEvent == 'D') {
        return;
    }

    //Selecció de dades.
    let mObjMarcopel = Ax.db.executeQuery(`
        <select>
            <columns>
                *
            </columns>
            <from table='mut_nfc_marcopel' />
            <where>
                rowid = ?
            </where>
        </select>
    `, pIntRowid)
        .toOne()
        .setRequired('Registre no seleccionat.');

    //Sortir si registre ja està Processat.
    if (mObjMarcopel.estado == 'P') {
        return;
    }

    //Comprovacions bàsiques.
    if (mObjMarcopel.cifusr == null) {
        __local_set_error(mObjMarcopel.regid, 'CIF no informat.');
        return;

    }

    if (mObjMarcopel.codusr == null) {
        mObjMarcopel.codusr = Ax.db.executeGet(`
            <select>
                <columns>
                    first 1 codigo codusr
                </columns>
                <from table='cper_empleado' />
                <where>
                    cif = ? AND 
                    <today /> &gt;= fecini AND
                    fecfin IS NULL
                </where>
                <order>codigo</order>
            </select>
        `, mObjMarcopel.cifusr);

        Ax.db.update('mut_nfc_marcopel',
            {
                'codusr': mObjMarcopel.codusr
            },
            {
                'regid': mObjMarcopel.regid
            }
        )
    }

    if (mObjMarcopel.codusr == null) {
        __local_set_error(mObjMarcopel.regid, 'Operari no informat.');
        return;
    }

    if (mObjMarcopel.numhor == null) {
        __local_set_error(mObjMarcopel.regid, 'Hora no informada.');
        return;
    }

    if (mObjMarcopel.numhor < 0 || mObjMarcopel.numhor > 23) {
        __local_set_error(mObjMarcopel.regid, 'Hora fora de rang.');
        return;
    }

    if (mObjMarcopel.nummin < 0 || mObjMarcopel.nummin > 60) {
        __local_set_error(mObjMarcopel.regid, 'Minut fora de rang.');
        return;
    }

    if (mObjMarcopel.accion == null) {
        __local_set_error(mObjMarcopel.regid, 'Acció no informada.');
        return;
    }

    if (mObjMarcopel.accion < 1 || mObjMarcopel.accion > 2) {
        __local_set_error(mObjMarcopel.regid, 'Acció desconeguda.');
        return;
    }

    //Primera acció Sortida.
    if (mObjMarcopel.accion == 2) {
        let mIntCount1 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    fecmar = ? AND
                    tercer = ? AND
                    codusr = ? AND
                    regid != ?  AND
                    orddia &lt; ?
                </where>
            </select>
        `,mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia);

        let mIntCount2 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    fecmar  = ? AND
                    tercer  = ? AND
                    codusr  = ? AND
                    regid  != ? AND
                    orddia  = ? AND
                    accion != ?
                </where>
            </select>
        `,mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia, mObjMarcopel.accion);

        let mIntCount3 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    fecmar  = ? AND
                    tercer  = ? AND
                    codusr  = ? AND
                    regid  != ? AND
                    fecrea &lt; ? AND
                    accion != ?
                </where>
            </select>
        `,mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.fecmar, mObjMarcopel.accion);

        if (!mIntCount1 && !mIntCount2 && !mIntCount3) {
            __local_set_error(mObjMarcopel.regid, 'Primera acció Sortida');
            return;
        }
    }

    //Ultima acció Entrada.
    if (mObjMarcopel.accion == 1) {
        let mIntCount1 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    fecmar = ? AND
                    tercer = ? AND
                    codusr = ? AND
                    regid != ? AND
                    orddia &gt; ?
                </where>
            </select>
        `,mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia);

        let mIntCount2 = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    fecmar  = ? AND
                    tercer  = ? AND
                    codusr  = ? AND
                    regid  != ? AND
                    orddia  = ? AND
                    accion != ?
                </where>
            </select>
        `,mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia, mObjMarcopel.accion);

        if (!mIntCount1 && !mIntCount2) {
            __local_set_error(mObjMarcopel.regid, 'Última acció Entrada');
            return;
        }

    }

    //Sortida sense Entrada.
    if (mObjMarcopel.accion == 1) {
        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    fecmar = ? AND
                    tercer = ? AND
                    codusr = ? AND
                    regid != ? AND
                    orddia &gt; ? AND
                    accion = 2
                </where>
            </select>
        `,mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia);

        if (!mIntCount) {
            __local_set_error(mObjMarcopel.regid, 'Entrada sense Sortida');
            return;
        }
    }

    //Entrada sense Sortida.
    if (mObjMarcopel.accion == 2) {
        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_marcopel' />
                <where>
                    fecmar = ? AND
                    tercer = ? AND
                    codusr = ? AND
                    regid != ? AND
                    orddia &lt; ? AND
                    accion = 1
                </where>
            </select>
        `, mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia);

        if (!mIntCount) {
            __local_set_error(mObjMarcopel.regid, 'Sortida sense Entrada');
            return;
        }
    }

    //Comprovació d'acció repetida.
    let mArrAccion = Ax.db.executeQuery(`
        <select>
            <columns>accion</columns>
            <from table='mut_nfc_marcopel' />
            <where>
                fecmar = ? AND
                tercer = ? AND
                codusr = ? AND
                regid != ? AND
                orddia &lt;= ?
            </where>
            <order>orddia DESC</order>
        </select>
    `, mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia).toJSONArray();

    for(let mRowAccion of mArrAccion){
        if (mRowAccion.accion == mObjMarcopel.accion) {
            __local_set_error(mObjMarcopel.regid, 'Acció repetida');
            return;
        }
    }

    //Comprovació d'OTs fora de període de marcatge.
    let mObjFecha = __local_date_comp(mObjMarcopel.fecmar);

    let mIntIniany = mObjFecha.year;
    let mIntInimes = mObjFecha.month;
    let mIntInidia = mObjFecha.day;

    let mDateFecact = new Ax.util.Date(mIntIniany, mIntInimes, mIntInidia, mObjMarcopel.numhor, mObjMarcopel.nummin);
    
    switch (mObjMarcopel.accion) {
        case 1:
            let mIntCount = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_nfc_marcopel' />
                    <where>
                        fecmar = ? AND
                        tercer = ? AND
                        codusr = ? AND
                        regid != ? AND
                        orddia &lt; ?
                    </where>
                </select>
            `, mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia);

            if (!mIntCount) {
                //Revisar OTs iniciades abans del primer marcatge d'Entrada. 
                let mArrOrdetrah = Ax.db.executeQuery(`
                    <select>
                        <columns>
                            docser, ini_datcon
                        </columns>
                        <from table='mut_nfc_ordetrah' />
                        <where>
                            ? = ? AND
                            assign_user      = ? AND
                            DATE(ini_datcon) = ? AND
                            ini_datcon &lt; ?
                        </where>
                        <order>ini_datcon</order>
                    </select>
                `, mObjMarcopel.fecmar, mObjMarcopel.fecrea, mObjMarcopel.codusr, mObjMarcopel.fecmar, mDateFecact).toJSONArray();

                for(let mRowOrdetrah of mArrOrdetrah){
                    let mHour = new Ax.util.Date(mRowOrdetrah.ini_datcon);

                    if (mHour.getHours() >= 6) {
                        __local_set_error(mObjMarcopel.regid, `OT [${mRowOrdetrah.docser}, ${mRowOrdetrah.ini_datcon}] iniciada abans de primera Entrada.`);
                        return;
                    }
                }

                //Revisar OTs finalitzades abans del primer marcatge d'Entrada.
                let mArrOrdetrah2 = Ax.db.executeQuery(`
                    <select>
                        <columns>docser, fin_datcon</columns>
                        <from table='mut_nfc_ordetrah' />
                        <where>
                            ? = ? AND
                            assign_user      = ? AND
                            DATE(ini_datcon) = ? AND
                            fin_datcon &lt; ?
                        </where>
                        <order>fin_datcon</order>
                    </select>
                `, mObjMarcopel.fecmar, mObjMarcopel.fecrea, mObjMarcopel.codusr, mObjMarcopel.fecmar, mDateFecact).toJSONArray();

                for(let mRowOrdetrah of mArrOrdetrah2){
                    let mHour = new Ax.util.Date(mRowOrdetrah.fin_datcon);
                    if (mHour.getHours() >= 6) {
                        __local_set_error(mObjMarcopel.regid, `OT [${mRowOrdetrah.docser}, ${mRowOrdetrah.fin_datcon}] finalitzada abans de primera Entrada.`);
                        return;
                    }
                }

            }
            
            break;
        
        case 2:
            let mIntCount2 = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_nfc_marcopel' />
                    <where>
                        fecmar = ? AND
                        tercer = ? AND
                        codusr = ? AND
                        regid != ? AND
                        orddia &gt; ?
                    </where>
                </select>                
            `, mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia);

            if (!mIntCount2) {
                //Revisar OTs iniciades després de l'últim marcatge Sortida.
                let mArrOrdetrah = Ax.db.executeQuery(`
                    <select>
                        <columns>docser, ini_datcon</columns>
                        <from table='mut_nfc_ordetrah' />
                        <where>
                            ? = ? AND
                            assign_user      = ? AND
                            DATE(ini_datcon) = ? AND
                            ini_datcon &gt; ?
                        </where>
                        <order>ini_datcon</order>
                    </select>
                `, mObjMarcopel.fecmar, mObjMarcopel.fecrea, mObjMarcopel.codusr, mObjMarcopel.fecmar, mDateFecact).toJSONArray();

                for(let mRow of mArrOrdetrah){
                    let mHour = new Ax.util.Date(mRow.ini_datcon);

                    if (mHour.getHours() < 19 || (mHour.getHours() == 19 && mHour.getMinutes() < 30)) {
                        __local_set_error(mObjMarcopel.regid, `OT [${mRow.docser}, ${mRow.ini_datcon}] iniciada després d'última Sortida.`);
                        return;
                    }
                }

                // Revisar OTs finalitzades després de l'últim marcatge Sortida.
                let mArrOrdetrah2 = Ax.db.executeQuery(`
                    <select>
                        <columns>docser, fin_datcon</columns>
                        <from table='mut_nfc_ordetrah' />
                        <where>
                            ? = ? AND
                            assign_user      = ? AND
                            DATE(fin_datcon) = ? AND
                            fin_datcon &gt; ?
                        </where>
                        <order>fin_datcon</order>
                    </select>                    
                `, mObjMarcopel.fecmar, mObjMarcopel.fecrea, mObjMarcopel.codusr, mObjMarcopel.fecmar, mDateFecact).toJSONArray();

                for(let mRow of mArrOrdetrah2){
                    let mHour = new Ax.util.Date(mRow.fin_datcon);

                    if (mHour.getHours() < 22) {
                        __local_set_error(mObjMarcopel.regid, `OT [${mRow.docser}, ${mRow.fin_datcon}] finalitzada després d'última Sortida.`);
                        return;
                    }
                }

            }

            //Revisar OTs iniciades o finalitzades entre períodes de marcatge.
            let mArrMarcopel = Ax.db.executeQuery(`
                <select>
                    <columns>numhor, nummin</columns>
                    <from table='mut_nfc_marcopel' />
                    <where>
                        fecmar = ? AND
                        tercer = ? AND
                        codusr = ? AND
                        regid != ? AND
                        orddia &gt; ? AND
                        accion = 1
                    </where>
                    <order>1,2</order>
                </select>
            `, mObjMarcopel.fecmar, mObjMarcopel.tercer, mObjMarcopel.codusr, mObjMarcopel.regid, mObjMarcopel.orddia).toJSONArray();

            for (let mRow of mArrMarcopel) {
                if (mRow.numhor != null) {
                    let mDateFecNxt = new Ax.util.Date(mIntIniany, mIntInimes, mIntInidia, mRow.numhor, mRow.nummin);

                    let mArrOrdetrah = Ax.db.executeQuery(`
                        <select>
                            <columns>docser, ini_datcon</columns>
                            <from table='mut_nfc_ordetrah' />
                            <where>
                                assign_user      = ? AND
                                DATE(ini_datcon) = ? AND
                                ini_datcon BETWEEN ? AND ?
                            </where>
                            <order>ini_datcon</order>
                        </select>
                    `, mObjMarcopel.codusr, mObjMarcopel.fecmar, mDateFecact, mDateFecNxt);

                    for(let mRowOrder of mArrOrdetrah){
                        __local_set_error(mObjMarcopel.regid, `OT [${mRowOrder.docser}, ${mRowOrder.ini_datcon}] iniciada entre Sortida i Entrada.`);
                        return;
                    }

                    let mArrOrdetrah2 = Ax.db.executeQuery(`
                        <select>
                            <columns>docser, fin_datcon</columns>
                            <from table='mut_nfc_ordetrah' />
                            <where>
                                assign_user      = ? AND
                                DATE(fin_datcon) = ? AND
                                fin_datcon BETWEEN ? AND ?
                            </where>
                            <order>fin_datcon</order>
                        </select>
                    `, mObjMarcopel.codusr, mObjMarcopel.fecmar, mDateFecact, mDateFecNxt);

                    for(let mRowOrder2 of mArrOrdetrah2){
                        __local_set_error(mObjMarcopel.regid, `OT [${mRowOrder2.docser}, ${mRowOrder2.fin_datcon}] finalitzada entre Sortida i Entrada.`);
                        return;
                    }

                }
                break;
            }

            //Sortides en les que hi ha una tasca iniciada previament i finalitzada posteriorment.
            let mObjData = __local_date_comp(mObjMarcopel.fecmar);

            mIntIniany = mObjData.year;
            mIntInimes = mObjData.month;
            mIntInidia = mObjData.day;

            mDateFecact = new Ax.util.Date(mIntIniany, mIntInimes, mIntInidia, mObjMarcopel.numhor, mObjMarcopel.nummin);

            let mArrOrdetrah = Ax.db.executeQuery(`
                <select>
                    <columns>docser, ini_datcon, fin_datcon</columns>
                    <from table='mut_nfc_ordetrah' />
                    <where>
                        ? = ? AND
                        assign_user      = ? AND
                        DATE(ini_datcon) = ? AND
                        ini_datcon &lt; ? AND
                        fin_datcon &gt; ?
                    </where>
                    <order>ini_datcon</order>
                </select>
            `, mObjMarcopel.fecmar, mObjMarcopel.fecrea, mObjMarcopel.codusr, mObjMarcopel.fecmar, mDateFecact, mDateFecact).toJSONArray();

            for (let mRow of mArrOrdetrah) {
                __local_set_error(mObjMarcopel.regid, `OT [${mRow.docser}] iniciada dins de període però finalitzada posteriorment.`);
                return;
            }

        break;
    }

    //La línia queda Validada si ha superat totes les comprovacions.
    Ax.db.update('mut_nfc_marcopel', 
        {
            'estado': 'V',
            'errmsg': null,
            'date_updated': new Ax.sql.Date(),
            'user_updated': Ax.db.getUser()
        }, 
        {
            'regid': mObjMarcopel.regid
        }
    );

    //Marcar capçalera en Error per a forçar revalidació global.
    Ax.db.update('mut_nfc_marcopeh', 
        {
            'estado': 'E',
            'date_updated': new Ax.sql.Date(),
            'user_updated': Ax.db.getUser()
        }, 
        {
            'fecmar': mObjMarcopel.fecmar,
            'tercer': mObjMarcopel.tercer
        }
    );
}