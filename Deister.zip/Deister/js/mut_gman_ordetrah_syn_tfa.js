function mutGmanOrdetrahSynTfa(pIntSeqno, pStrType) {
    let mObjNfcOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='mut_nfc_ordetrah' />
            <where>
                seqno = ?
            </where>
        </select>   
    `, pIntSeqno).toOne()
        .setRequired(`Acció ${pIntSeqno} inexistent.`);

    //Selecció de dades de la OT.
    let mObjGmanOrdetrah = Ax.db.executeQuery(`
        <select>
            <columns>
                o.tipdoc,
                o.delega, gdelegac.nomdlg,
                o.depart, gdeparta.nomdep,
                o.fecpre, o.docser,
                o.codins, gman_equinsta.nomins,
                o.codmaq, o.codope, o.docori,
                o.estcab, o.errcab, o.wkfcab, o.preini,
                o.operac, o.horpre,
                gman_equidefs.nommaq, gman_equidefs.codloc locmaq
            </columns>
            <from table='gman_ordetrah' alias='o'>
                <join table='gdelegac'>
                    <on>o.delega = gdelegac.codigo</on>
                </join>
                <join table='gdeparta'>
                    <on>o.delega = gdeparta.delega</on>
                    <on>o.depart = gdeparta.depart</on>
                </join>
                <join table='gman_equinsta'>
                    <on>o.codins = gman_equinsta.codins</on>
                </join>
                <join type='left' table='gman_equidefs'>
                    <on>o.codmaq = gman_equidefs.codmaq</on>
                </join>
            </from>
            <where>
                cabid = ?
            </where>
        </select>
    `, mObjNfcOrdetrah.cabid).toOne();

    let mStrMobdbs = 'mutua_mobile';

    if (Ax.db.getCode() != 'mutua') {
        mStrMobdbs = 'mutua_mobile_test';
    }

    //Si el departament no està en cap grup de departaments, no sincronitzar.
    let mStrCodgru = null;

    mStrCodgru = Ax.db.executeGet(`
        <select>
            <columns>codgru</columns>
            <from table='gdepgrpl' />
            <where>
                delega = ? AND
                depart = ? AND
                estado = 'A'
            </where>
            <order>codgru</order>
        </select>
    `, mObjGmanOrdetrah.delega, mObjGmanOrdetrah.depart);

    if (mStrCodgru == null) {
        return;
    }

    //Definir tipus d'assignació.
    let mStrTaskCode
    switch (mObjGmanOrdetrah.tipdoc) {
        case 'OT':
        case 'CP':
        case 'RU':
            mStrTaskCode = `CO${pStrType}`;
            break;
        case 'OP':
            mStrTaskCode = `PR${pStrType}`;
            break;
        case 'OA':
            mStrTaskCode = `PA${pStrType}`;
            break;
        case 'TR':
            mStrTaskCode = `TR${pStrType}`;
            break;
    
        default:
            throw new Ax.lang.Exception(`Tipus de document [${mObjGmanOrdetrah.tipdoc}] no contemplat.`);
            break;
    }

    //Obtenir tags permesos per l'OT.
    let mObjGmanEquidefs = {'tag_code1': null, 'reads_counter': null};

    if (mObjGmanOrdetrah.codmaq != null) {
        mObjGmanEquidefs = Ax.db.executeQuery(`
            <select>
                <columns>codmaq tag_code1, auxnum2 reads_counter</columns>
                <from table='gman_equidefs' />
                <where>
                    codmaq  = ? AND
                    auxnum1 = 1
                </where>
            </select>
        `, mObjGmanOrdetrah.codmaq).toOne();
    }

    if (mObjGmanEquidefs.tag_code1 == null) {
        mObjGmanEquidefs.tag_code1 =  mStrCodgru;
    }

    let mStrTagCode2 = 'TSACETLELE';
    let mStrTagCode3 = 'TSACETLELM';
    let mStrTagCode4 = 'TSACETLMEC';
    let mStrTagCode5 = null;

    if (mObjGmanEquidefs.reads_counter == 0) {
        mStrTagCode5 = mStrCodgru;
    }

    //Verificacions. 
    let mObjAppsSysUsers = Ax.db.executeQuery(`
        <select>
            <columns>user_code</columns>
            <from table='apps_sys_users' />
            <where>
                user_code  = ? AND
                user_state = 'A'
            </where>
        </select>
    `, mObjGmanOrdetrah.codope).toOne()
        .setRequired(`Usuari inexistent [${mObjGmanOrdetrah.codope}]`);;

    let mObjAppsCustomers = Ax.db.executeQuery(`
        <select>
            <columns>
                customer_code, customer_phone1,
                'POINT(' || REPLACE(gps_lon,',','.') || ' ' || REPLACE(gps_lat, ',','.') || ')' gps_point,
                gps_lon, gps_lat
            </columns>
            <from table='apps_customers' />
            <where>
                customer_code  = ? AND
                event_sync     = 'A'
            </where>
        </select>
    `, mStrCodgru).toOne();

    //Obtenir número d'assignació de l'usuari.
    let mIntAssignNumber = Ax.db.executeFunction('apps_sfa_task_assign_get_nxt_n', mObjAppsSysUsers.user_code).toValue();

    //Definir data de sincronització.
    let mDateToSync = mObjNfcOrdetrah.datprg;

    //Header
    let mStrAssignDesc = mObjGmanOrdetrah.docser;

    if (mObjGmanOrdetrah.codmaq != null) {
        mStrAssignDesc = `${mObjGmanOrdetrah.docser} (${mObjGmanOrdetrah.codmaq} ${mObjGmanOrdetrah.nommaq || ''})`;
    }

    let mIntAssignTime = 0;

    if (mObjGmanOrdetrah.horpre != null) {
        let mTimeHour   = parseInt(mObjGmanOrdetrah.horpre.slice(0, 2));
        let mTimeMinute = parseInt(mObjGmanOrdetrah.horpre.slice(3, 5));
        mIntAssignTime = (mTimeHour * 60) + mTimeMinute;
    }

    if (mObjNfcOrdetrah.indurg) {
        //Informar Urgent o Pendent. 
        let mIntIndpen = 0;

        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='mut_nfc_ordetrah' />
                <where>
                    cabid  = ? AND
                    seqno != ?
                </where>
            </select>
        `, mObjNfcOrdetrah.cabid, pIntSeqno);

        if (mIntCount) {
            let mIntLstSeq = null;

            mIntLstSeq = Ax.db.executeGet(`
                <select>
                    <columns>MAX(seqno) lstseq</columns>
                    <from table='mut_nfc_ordetrah' />
                    <where>
                        cabid  = ? AND
                        seqno != ?
                    </where>
                </select>
            `, mObjNfcOrdetrah.cabid, pIntSeqno);

            let mIntCant = Ax.db.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='mut_nfc_ordetrah' />
                    <where>
                        seqno = ? AND
                        fin_estado = 2
                    </where>
                </select>
            `, mIntLstSeq);

            if (mIntCant) {
                mIntIndpen = 1;
            }

        }

        if (!mIntIndpen) {
            mObjGmanOrdetrah.operac = `***URGENT*** ${mObjGmanOrdetrah.operac}`;
        } else {
            mObjGmanOrdetrah.operac = `***PENDENT*** ${mObjGmanOrdetrah.operac}`;
        }

    }

    let mIntAssignHide = 0;

    if (pStrType == 'F') {
        mIntAssignHide = 1;
    }

    Ax.db.insert("apps_sfa_task_assign", 
        {
            'assign_user'    : mObjAppsSysUsers.user_code,
            'assign_type'    : 1,
            'assign_number'  : mIntAssignNumber,
            'assign_desc'    : mStrAssignDesc,
            'assign_customer': mObjAppsCustomers.customer_code,
            'task_code'      : mStrTaskCode,
            'assign_date'    : mDateToSync,
            'assign_time'    : mIntAssignTime,
            'assign_state'   : 0,
            'assign_notify'  : 10,
            'assign_progress': 0,
            'assign_coment'  : mObjGmanOrdetrah.operac,
            'gps_lon'        : mObjAppsCustomers.gps_lon,
            'gps_lat'        : mObjAppsCustomers.gps_lat,
            'assign_tabori'  : 'gman_ordetrah',
            'assign_docori'  : mObjGmanOrdetrah.docser,
            'assign_hide'    : mIntAssignHide,
            'date_to_sync'   : mDateToSync
        }
    );

    //Atributs
    Ax.db.insert("apps_sfa_task_assign_attr", 
        {
            'assign_user'   : mObjAppsSysUsers.user_code,
            'assign_type'   : 1,
            'assign_number' : mIntAssignNumber,
            'group_code'    : 'OT_ATTR',
            'attr_order'    : 2,
            'attr_label'    : 'OT',
            'attr_value'    : mObjGmanOrdetrah.docser,
            'attr_print'    : 1
        }
    );

    Ax.db.insert("apps_sfa_task_assign_attr", 
        {
            'assign_user'   : mObjAppsSysUsers.user_code,
            'assign_type'   : 1,
            'assign_number' : mIntAssignNumber,
            'group_code'    : 'OT_ATTR',
            'attr_order'    : 4,
            'attr_label'    : 'Instal·lació',
            'attr_value'    : mObjGmanOrdetrah.nomins,
            'attr_print'    : 1
        }
    );

    if (mObjGmanOrdetrah.codmaq != null) {
        Ax.db.insert("apps_sfa_task_assign_attr", 
            {
                'assign_user'   : mObjAppsSysUsers.user_code,
                'assign_type'   : 1,
                'assign_number' : mIntAssignNumber,
                'group_code'    : 'OT_ATTR',
                'attr_order'    : 6,
                'attr_label'    : 'Equip',
                'attr_value'    : `${mObjGmanOrdetrah.codmaq} ${mObjGmanOrdetrah.nommaq}`,
                'attr_print'    : 1
            }

        );

    } else {
        if (mObjGmanOrdetrah.tipdoc == 'OA') {
            let mStrEqplst = '';

            let mArrOrdetrah = Ax.db.executeQuery(`
                <select>
                    <columns>gman_ordetrah.codmaq</columns>
                    <from table='mut_nfc_ordetrah'>
                        <join table='gman_ordetrah'>
                            <on>mut_nfc_ordetrah.cabid = gman_ordetrah.cabid</on>
                        </join>
                    </from>
                    <where>
                        mut_nfc_ordetrah.seqori = ?
                    </where>
                </select>
            `, pIntSeqno).toJSONArray();

            for (let mRow of mArrOrdetrah) {
                mStrEqplst = mRow.codmaq;
            }

            if (mStrEqplst.length > 0) {
                mStrEqplst = mStrEqplst.slice(0, mStrEqplst.length - 1);

                Ax.db.insert("apps_sfa_task_assign_attr", 
                    {
                        'assign_user'   : mObjAppsSysUsers.user_code,
                        'assign_type'   : 1,
                        'assign_number' : mIntAssignNumber,
                        'group_code'    : 'OT_ATTR',
                        'attr_order'    : 6,
                        'attr_label'    : `Llista d'equips`,
                        'attr_value'    : mStrEqplst,
                        'attr_print'    : 1
                    }
        
                );    

            }

        }

    }

    let mObjSolitrah = {'codloc': null};

    if (mObjGmanOrdetrah.docori != null) {
        let mObjSolitrah = Ax.db.executeQuery(`
            <select>
                <columns>TRIM('[' || TRIM(docser) || '] ' || NVL(nomsol, '')) nomsol, codloc</columns>
                <from table='gman_solitrah' />
                <where>
                    docser = ?
                </where>
            </select>    
        `, mObjGmanOrdetrah.docori).toOne();

        Ax.db.insert("apps_sfa_task_assign_attr", 
            {
                'assign_user'   : mObjAppsSysUsers.user_code,
                'assign_type'   : 1,
                'assign_number' : mIntAssignNumber,
                'group_code'    : 'OT_ATTR',
                'attr_order'    : 8,
                'attr_label'    : 'Sol·licitant',
                'attr_value'    : mObjSolitrah.nomsol,
                'attr_print'    : 1
            }
        ); 

        if (mObjSolitrah.codloc.length == 0) {
            if (mObjGmanOrdetrah.locmaq != null) {
                mObjSolitrah.codloc  = mObjGmanOrdetrah.locmaq;
            }

        } else {
            if (mObjGmanOrdetrah.locmaq != null) {
                mObjSolitrah.codloc = `${mObjGmanOrdetrah.locmaq} / ${mObjSolitrah.codloc}`
            }
        }

    } else {
        if (mObjGmanOrdetrah.locmaq.length != 0) {
            mObjSolitrah.codloc = mObjGmanOrdetrah.locmaq;
        }
    }

    if (mObjSolitrah.codloc.length == 0) {
        mObjSolitrah.codloc = '???'
    }

    Ax.db.insert("apps_sfa_task_assign_attr", 
        {
            'assign_user'   : mObjAppsSysUsers.user_code,
            'assign_type'   : 1,
            'assign_number' : mIntAssignNumber,
            'group_code'    : 'OT_ATTR',
            'attr_order'    : 10,
            'attr_label'    : 'Localització',
            'attr_value'    : mObjSolitrah.codloc,
            'attr_print'    : 1
        }

    );     
    
    for (let i = 1; i <= 5; i++) {
        Ax.db.insert("mut_apps_sfa_task_assign_vals", 
            {
                'assign_user'   : mObjAppsSysUsers.user_code,
                'assign_type'   : 1,
                'assign_number' : mIntAssignNumber,
                'ask_code'      : `TAG${i}`,
                'defs_text'     : `m_tag_code${i}`,
                'date_to_sync'  : mDateToSync
            }

        );
        
    }

    Ax.db.update('apps_sfa_task_assign', 
        {
            'assign_state': 1
        },
        {
            'assign_user': mObjAppsSysUsers.user_code,
            'assign_type'   : 1,
            'assign_number' : mIntAssignNumber,
        }
    )

    if (pStrType == 'I') {
        Ax.db.update('apps_sfa_task_assign', 
            {
                'assign_user': mObjAppsSysUsers.user_code,
                'assign_type': 1,
                'ini_number' : mIntAssignNumber
            },
            {
                'seqno': pIntSeqno
            }
        )

        if (mObjGmanOrdetrah.tipdoc == 'OA') {
            let mArrLisOrde = Ax.db.executeQuery(`
                <select>
                    <columns>mut_nfc_ordetrah.seqno</columns>
                    <from table='mut_nfc_ordetrah' />
                    <where>
                        mut_nfc_ordetrah.seqori = ?
                    </where>
                </select>
            `, pIntSeqno).toJSONArray();

            for (let mRow of mArrLisOrde) {
                Ax.db.update('mut_nfc_ordetrah', 
                    {
                        'assign_user': mObjAppsSysUsers.user_code,
                        'assign_type': 1,
                        'ini_number' : mIntAssignNumber
                    },
                    {
                        'seqno': mRow.seqno
                    }
                )
            }
        }

    }

    if (pStrType == 'F') {
        Ax.db.update('mut_nfc_ordetrah', 
            {
                'fin_number': mIntAssignNumber,
                'datprg'    : mDateToSync
            },
            {
                'seqno': pIntSeqno
            }
        )  
    }

    //Subtasques associades a una OT agrupada.
    if (mObjGmanOrdetrah.tipdoc == 'OA' && pStrType == 'F') {
        mObjGmanOrdetrah.docori = mObjGmanOrdetrah.docser;

        let mArrNfcOrder = Ax.db.executeQuery(`
            <select>
                <columns>
                    mut_nfc_ordetrah.seqno seqdes,
                    gman_ordetrah.cabid cabdes, mut_nfc_ordetrah.docser docdes,
                    gman_ordetrah.codmaq, gman_equidefs.nommaq,
                    gman_ordetrah.horpre
                </columns>
                <from table='mut_nfc_ordetrah'>
                    <join table='gman_ordetrah'>
                        <on>mut_nfc_ordetrah.cabid = gman_ordetrah.cabid</on>
                        <join type='left' table='gman_equidefs'>
                            <on>gman_ordetrah.codmaq = gman_equidefs.codmaq</on>
                        </join>
                    </join>
                </from>
                <where>
                    mut_nfc_ordetrah.seqori = ? AND
                    mut_nfc_ordetrah.estado = 10
                </where>
                <order>mut_nfc_ordetrah.seqno</order>
            </select>
        `, pIntSeqno).toJSONArray();

        for (let mRow of mArrNfcOrder) {
            //Obtenir número d'assignació de l'usuari.
            mIntAssignNumber = Ax.db.executeFunction('apps_sfa_task_assign_get_nxt_n', mObjAppsSysUsers.user_code).toValue();

            mIntAssignTime = 0;

            if (mRow.horpre != null) {
                let mTimeHour  = parseInt(mRow.horpre.slice(0, 2));
                let mTimeMinu  = parseInt(mRow.horpre.slice(3, 5));
                mIntAssignTime = (mTimeHour * 60)/mTimeMinu;
            }

            Ax.db.insert("apps_sfa_task_assign", 
                {
                    'assign_user'    : mObjAppsSysUsers.user_code,
                    'assign_type'    : 1,
                    'assign_number'  : mIntAssignNumber,
                    'assign_desc'    : `${mRow.docdes} (${mRow.codmaq} ${mRow.nommaq})`,
                    'assign_customer': mObjAppsCustomers.customer_code,
                    'task_code'      : 'SU',
                    'assign_date'    : mDateToSync,
                    'assign_time'    : mIntAssignTime,
                    'assign_state'   : 0,
                    'assign_notify'  : 10,
                    'assign_progress': 0,
                    'assign_coment'  : mObjGmanOrdetrah.operac,
                    'gps_lon'        : mObjAppsCustomers.gps_lon,
                    'gps_lat'        : mObjAppsCustomers.gps_lat,
                    'assign_tabori'  : 'gman_ordetrah',
                    'assign_docori'  : mRow.docdes,
                    'assign_hide'    : mIntAssignHide,
                    'date_to_sync'   : mDateToSync
                }
            );

            Ax.db.insert("apps_sfa_task_assign_attr", 
                {
                    'assign_user'   : mObjAppsSysUsers.user_code,
                    'assign_type'   : 1,
                    'assign_number' : mIntAssignNumber,
                    'group_code'    : 'OT_ATTR',
                    'attr_order'    : 2,
                    'attr_label'    : 'OT',
                    'attr_value'    : mRow.docdes,
                    'attr_print'    : 1
                }
        
            );   

            Ax.db.insert("apps_sfa_task_assign_attr", 
                {
                    'assign_user'   : mObjAppsSysUsers.user_code,
                    'assign_type'   : 1,
                    'assign_number' : mIntAssignNumber,
                    'group_code'    : 'OT_ATTR',
                    'attr_order'    : 4,
                    'attr_label'    : 'Instal·lació',
                    'attr_value'    : mObjGmanOrdetrah.nomins,
                    'attr_print'    : 1
                }
        
            ); 

            mRow.nommaq = Ax.db.executeGet(`
                <select>
                    <columns>nommaq</columns>
                    <from table='gman_equidefs' />
                    <where>
                        codmaq = ?
                    </where>
                </select>            
            `, mRow.codmaq);

            Ax.db.insert("apps_sfa_task_assign_attr", 
                {
                    'assign_user'   : mObjAppsSysUsers.user_code,
                    'assign_type'   : 1,
                    'assign_number' : mIntAssignNumber,
                    'group_code'    : 'OT_ATTR',
                    'attr_order'    : 6,
                    'attr_label'    : 'Equip',
                    'attr_value'    : `${mRow.codmaq} ${mRow.nommaq}`,
                    'attr_print'    : 1
                }
        
            );        
            
            Ax.db.insert("apps_sfa_task_assign_attr", 
                {
                    'assign_user'   : mObjAppsSysUsers.user_code,
                    'assign_type'   : 1,
                    'assign_number' : mIntAssignNumber,
                    'group_code'    : 'OT_ATTR',
                    'attr_order'    : 8,
                    'attr_label'    : 'OT Agrupació',
                    'attr_value'    : mObjGmanOrdetrah.docori,
                    'attr_print'    : 1
                }
        
            );
            
            Ax.db.update('mut_nfc_ordetrah', 
                {
                    'assign_user': mObjAppsSysUsers.user_code,
                    'assign_type': 1,
                    'fin_number' : mIntAssignNumber
                }, 
                {
                    'seqno': mRow.seqdes
                }
            );

            Ax.db.update('apps_sfa_task_assign', 
                {
                    'assign_state': 1
                }, 
                {
                    'assign_user'  : mObjAppsSysUsers.user_code,
                    'assign_type'  : 1,
                    'assign_number': mIntAssignNumber
                }
            );       
            
            Ax.db.update('mut_nfc_ordetrah', 
                {
                    'fin_number': mIntAssignNumber,
                    'datprg'    : mDateToSync,
                }, 
                {
                    'seqno'  : mRow.seqdes
                }
            ); 

        }

    }

}