function mut_tesis_import() {
    function __local_send_errmail(pStrMessage) {
        let mObjMailSel = Ax.db.call('mut_sys_mail_select', 'mut_tesis_import', 'general');

        let mStrMailfrom = mObjMailSel.mail_from; 
        let mStrMailto   = mObjMailSel.mail_to;
        let mStrMailcc   = mObjMailSel.mail_cc; 
        let mStrMailbcc  = mObjMailSel.mail_bcc;

        let mMail = new Ax.mail.MailerMessage();
        mMail.from(mStrMailfrom);
        mMail.to(mStrMailto);
        mMail.cc(mStrMailcc)
        mMail.bcc(mStrMailbcc)
        mMail.subject('Tesis Load Error');
        mMail.setText(pStrMessage);

        //Se hace el envío del email
        let mMailer = new Ax.mail.Mailer();
        mMailer.setSMTPServer("localhost", 25);
        mMailer.send(mMail);      
    }

    Ax.db.beginWork();
    let mStrPathname = '/erpsync/tesis/';
    let mStrPathback = '/erpsync/tesis/bak/';

    let mStrFilter = '.*\.csv|.*\.CSV|.*\.txt|.*\.TXT';

    //Control de fitxers PRJ #71656
    let mIntNumfitxers = 0;

    let mFilesl = new Ax.io.File(mStrPathname);

    try {
        for (let mRow of mFilesl) {

            let regex = new RegExp(".*\\." + mStrFilter + "$", "gi");
    
            if (mRow.getName().match(regex) == null) {
                continue;
            }
    
            //Control de fitxers PRJ #71656
            mIntNumfitxers = mIntNumfitxers + 1;
    
            //Lectura del fitxer.
            let mStrContent = mRow.readString().split(/\r\n|\n/);

            let mObjTesisGvenfac = {};
            mObjTesisGvenfac.filename = mRow.getName();
            mObjTesisGvenfac.errno = -1;
            mObjTesisGvenfac.errmsg = 'TRASPASSANT FITXER';
            mObjTesisGvenfac.empcode = 14;
    
            for(let mStrLine of mStrContent) {
                //S'afegeix un espai al inici i al final del registre per a que l'array tingui sempre 41 columnes
                //encare que les últimes columnes no estiguin informades
                mStrLine = ` ${mStrLine} `;
    
                let mStrALine = mStrLine.split(';');
    
                //Per evitar registres en blanc al final del document, el count
                //del array ha de ser 41
    
                if (mStrALine.length == 41) {
                    for (let i = 0; i < mStrALine.length; i++) {
                        let mStrElem = mStrALine[i].trim();
                        
                        switch (i) {
                            case 2:
                                mObjTesisGvenfac.nombre = mStrElem;
                                break;
                            case 3: 
                                mObjTesisGvenfac.cif = mStrElem;
                                break;
                            case 4: 
                                mObjTesisGvenfac.direcc = mStrElem;
                                break;
                            case 5: 
                                mObjTesisGvenfac.poblac = mStrElem;
                                break;
                            case 6: 
                                mObjTesisGvenfac.provin = mStrElem;
                                break;
                            case 7: 
                                mObjTesisGvenfac.telef1 = mStrElem;
                                break;
                            case 8: 
                                mObjTesisGvenfac.telef2 = mStrElem;
                                break;
                            case 9: 
                                mObjTesisGvenfac.codpos = mStrElem;
                                break;
                            case 10: 
                                mObjTesisGvenfac.garant = mStrElem;
                                break;
                            case 11: 
                                mObjTesisGvenfac.concepte = mStrElem;
                                break;
                            case 12: 
                                mObjTesisGvenfac.concepte_des = mStrElem;
                                break;
                            case 13: 
                                mObjTesisGvenfac.agrupador = mStrElem;
                                break;
                            case 14: 
                                mObjTesisGvenfac.agrupador_des = mStrElem;
                                break;
                            case 15: 
                                mObjTesisGvenfac.empresa = mStrElem;
                                break;
                            case 16: 
                                mObjTesisGvenfac.fecfac = mStrElem.format('yyyyMMdd');
                                break;
                            case 17: 
                                mObjTesisGvenfac.tipfac = mStrElem;
                                break;
                            case 18: 
                                mObjTesisGvenfac.docser = mStrElem;
                                break;
                            case 19: 
                                mObjTesisGvenfac.particular = mStrElem;
                                break;
                            case 20: 
                                mObjTesisGvenfac.nom_particular = mStrElem;
                                break;
                            case 21: 
                                mObjTesisGvenfac.cif_particular = mStrElem;
                                break;
                            case 22: 
                                mObjTesisGvenfac.quantitat = Number(mStrElem);
                                break;
                            case 23: 
                                mObjTesisGvenfac.base = Number(mStrElem);
                                break;
                            case 24: 
                                mObjTesisGvenfac.iva = Number(mStrElem);
                                break;
                            case 25: 
                                mObjTesisGvenfac.servei = mStrElem;
                                break;
                            case 26: 
                                mObjTesisGvenfac.centre = mStrElem;
                                break;
                            case 27: 
                                mObjTesisGvenfac.numhist = mStrElem;
                                break;
                            case 28: 
                                mObjTesisGvenfac.numllit = mStrElem;
                                break;
                            case 29: 
                                mObjTesisGvenfac.tipiva = mStrElem;
                                break;
                            case 30: 
                                mObjTesisGvenfac.categoria = mStrElem;
                                break;
                            case 31: 
                                mObjTesisGvenfac.docserabonament = mStrElem;
                                break;
                            case 32: 
                                mObjTesisGvenfac.scs = mStrElem;
                                break;
                            case 33: 
                                mObjTesisGvenfac.scs_des = mStrElem;
                                break;
                            case 34: 
                                mObjTesisGvenfac.sala = mStrElem;
                                break;
                            case 35: 
                                mObjTesisGvenfac.sii_tipus = mStrElem;
                                break;
                            case 36: 
                                mObjTesisGvenfac.sii_base = mStrElem;
                                break;
                            case 37: 
                                mObjTesisGvenfac.sii_quota = mStrElem;
                                break;
                            case 38: 
                                mObjTesisGvenfac.sii_dt_ope = mStrElem;
                                break;
                            case 39: 
                                mObjTesisGvenfac.sii_tipus_id = `${mStrElem}`;
                                break;
                            case 40: 
                                mObjTesisGvenfac.pais = `${mStrElem}`;
                                break;
                            default:
                                break;
                        }
                    }

                    if (mObjTesisGvenfac.sii_base != '' && mObjTesisGvenfac.sii_base != null) {
                        mObjTesisGvenfac.sii_base = Number(mObjTesisGvenfac.sii_base);
                    }

                    if (mObjTesisGvenfac.sii_quota != '' && mObjTesisGvenfac.sii_quota != null) {
                        mObjTesisGvenfac.sii_quota = Number(mObjTesisGvenfac.sii_quota);
                    }

                    if (mObjTesisGvenfac.quantitat > 0) {
                        mObjTesisGvenfac.base = mObjTesisGvenfac.base/mObjTesisGvenfac.quantitat;
                    }

                    if (mObjTesisGvenfac.empresa == '5') {
                        mObjTesisGvenfac.empcode = '21';
                    }

                    if (mObjTesisGvenfac.errno == -1 && mObjTesisGvenfac.pais == '') {
                        mObjTesisGvenfac.pais = '724';
                    }

                    if (mObjTesisGvenfac.errno == -1) {
                        mObjTesisGvenfac.errno = 100;
                        mObjTesisGvenfac.errmsg = 'PENDENT PROCESSAR';
                    }

                    Ax.db.insert('mut_tesis_gvenfac', mObjTesisGvenfac);

                }    
            }

            mRow.renameTo(mStrPathback + mRow.getName());
    
        }

    } catch (error) {
        let mError = Ax.util.Error.getMessage(error);

        __local_send_errmail(`No s'ha processat el fitxer degut a [${mError}].`);
    }

    //Control de fitxers PRJ #71656
    if (mIntNumfitxers == 0) {
        __local_send_errmail(`No s'han rebut fitxers de TESIS.`)
    }

    Ax.db.commitWork();
   
}