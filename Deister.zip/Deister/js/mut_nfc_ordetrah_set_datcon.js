function mut_nfc_ordetrah_set_datcon(pStrDocser, pStrHorini, pStrhorfin) {
    let mObjParteser = Ax.db.executeQuery(`
        <select>
            <columns>
                rowid, fecini
            </columns>
            <from table='gman_parteser' />
            <where>
                docser = ?
            </where>
        </select>
    `, pStrDocser).toOne();

    let mRegexp = `\d{2}:\d{2}`;
    if (!mRegexp.test(pStrHorini)){
        throw new Ax.ext.Exception(`Format d'hora d'inici incorrecte [${pStrHorini}].`);
    }

    if (!mRegexp.test(pStrhorfin)) {
        throw new Ax.ext.Exception(`Format d'hora d'inici incorrecte [${pStrhorfin}].`);
    }

    let mIntInihor = parseInt(pStrHorini.slice(0, 2));
    let mIntInimin = parseInt(pStrHorini.slice(3, 5));
    let mIntFinhor = parseInt(pStrhorfin.slice(0, 2));
    let mIntFinmin = parseInt(pStrhorfin.slice(3, 5));

    if (mIntInihor > 23 || mIntInimin > 59) {
        throw new Ax.ext.Exception(`Format d'hora d'inici incorrecte [${pStrHorini}].`);
    }

    if (mIntFinhor > 23 || mIntFinmin > 59) {
        throw new Ax.ext.Exception(`Format d'hora de finalització incorrecte [${pStrhorfin}].`)
    }

    if (pStrHorini >= pStrhorfin) {
        throw new Ax.ext.Exception(`Hora d'inici igual o posterior a hora de finalització.`)
    }

    let mIntIniany =  mObjParteser.fecini.getFullYear();
    let mIntInimes =  mObjParteser.fecini.getMonth()+1;
    let mIntInidia =  mObjParteser.fecini.getDate();

    let mStrIniDatcon = new Ax.util.Date(mIntIniany, mIntInimes, mIntInidia, mIntInihor, mIntInimin);

    let mStrFinDatcon = new Ax.util.Date(mIntIniany, mIntInimes, mIntInidia, mIntFinhor, mIntFinmin);

    Ax.db.update('mut_nfc_ordetrah', 
        {
            'ini_datcon': mStrIniDatcon,
            'fin_datcon': mStrFinDatcon
        }, 
        {
            'doccom': pStrDocser
        }
    );

    Ax.db.update('gman_parteser', 
        {
            'tiphor': null,
            'hortot': null,
            'precio': 0
        }, 
        {
            'doccom': pStrDocser
        }
    );

    Ax.db.call('gman_parteser', 'V', mObjParteser.rowid);

}