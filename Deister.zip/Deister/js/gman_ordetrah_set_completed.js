//Completar la orden de trabajo guardando como fecha real de finalización la
//del último parte de servicio entrado.
function gman_ordetrah_set_completed(pStrDocord) {
    //Include al inicio del xsql. 
    let mDateFecfinOrd = null;

    let mObjParteser = Ax.db.executeQuery(`
        <select>
            <columns>
                FIRST 1
                <nvl>fecfin, fecini</nvl> fecfin, horfin,
                fecini, horini, hortot
            </columns>
            <from table='gman_parteser' />
            <where>
                docord = ?
            </where>
            <order>1 DESC, 2 DESC</order>
        </select>
    `, pStrDocord).toOne();

    if (mObjParteser.fecfin != null && mObjParteser.horfin != null) {
        let mDate = new Ax.sql.Date(mObjParteser.fecfin);

        let mIntIniany = mDate.getFullYear();
        let mIntInimes = mDate.getMonth()+1;
        let mIntInidia = mDate.getDate();  
        let mIntInihor = mDate.getHours();
        let mIntInimin = mDate.getMinutes();

        mDateFecfinOrd = new Ax.util.Date(mIntIniany, mIntInimes, mIntInidia, mIntInihor, mIntInimin);
    }

    if (mObjParteser.fecfin != null && mObjParteser.horfin == null) {
        let mDate = new Ax.sql.Date(mObjParteser.fecfin);

        let mIntIniany = mDate.getFullYear();
        let mIntInimes = mDate.getMonth()+1;
        let mIntInidia = mDate.getDate();  

        mDateFecfinOrd = new Ax.util.Date(mIntIniany, mIntInimes, mIntInidia,0,0);
    }

    mDateFecfinOrd = mDateFecfinOrd == null ? new Ax.sql.Date() : mDateFecfinOrd;

    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='gman_ordetrah' />
            <where>
                docser = ? AND
                fecini &gt; ?
            </where>
        </select>
    `, pStrDocord, mDateFecfinOrd);

    if (mIntCount) {
        Ax.db.update('gman_ordetrah', 
            {
                'fecini': mDateFecfinOrd
            },
            {
                'docser': pStrDocord
            }
        )
    }

    Ax.db.update('gman_ordetrah', 
        {
            'estcab': 'C',
            'fecfin': mDateFecfinOrd,
            'user_updated': Ax.db.getUser(),
            'date_updated': new Ax.sql.Date()

        },
        {
            'docser': pStrDocord
        }
    ) 

    //Liberar las reservas no consumidas.
    Ax.db.delete('greserva', 
        {
            'tabres': 'gman_ordetrah',
            'docres': pStrDocord,
            'canser': 0
        }
    );

    Ax.db.execute(`
        UPDATE greserva
        SET canres = canser
        WHERE tabres = 'gman_ordetrah' 
          AND docres = ? 
          AND canser > 0 
          AND canres > canser
    `, pStrDocord);


}