function mutPpvInvoiceDeassign(pIntRowid) {
    //Selecció de dades. 
    let mObjPpvInvoice = Ax.db.executeQuery(`
        <select>
            <columns>cif, cabfac, refter, estado</columns>
            <from table='mut_ppv_invoice' />
            <where>
                rowid = ?
            </where>
        </select>
    `, pIntRowid).toOne();

    //Control d'errors.
    if (mObjPpvInvoice.cif == null) {
        throw new Ax.lang.Exception(`Registre [${pIntRowid}] no trobat.`);
    }

    if (mObjPpvInvoice.estado != 'A') {
        throw new Ax.lang.Exception(`Factura [${mObjPpvInvoice.cif} - ${mObjPpvInvoice.refter}] no assignada.`);
    }

    //Retornar el fitxer al camp BLOB de la taula d'entrada de factures.
    let mPathname = Ax.db.executeGet(`
        <select>
            <columns>pathname</columns>
            <from table='mut_filelnk' />
            <where>
                tabname = 'gcomfach' AND
                cabid   = ?
            </where>
        </select>
    `, mObjPpvInvoice.cabfac);

    if (mPathname == null) {
        throw new Ax.lang.Exception('La factura no es troba en el Repositori de Factures. Contactar amb Aplicacions Corporatives.');
    }

    let mFile = new Ax.io.File(mPathname);

    ///file.bytes.read
    Ax.db.update('mut_ppv_invoice', 
        {
            'file_data': mFile.asBytes()
        }, 
        {
            'rowid': pIntRowid
        }
    )

    //Esborrat del fitxer 
    mFile.delete();

    //Esborrat del la taula de d'enllaços. 
    Ax.db.delete('mut_filelnk', 
        {
            'tabname': 'gcomfach',
            'cabid':   mObjPpvInvoice.cabfac
        }
    )

    //Restabliment a la taula d'entrada de factures. 
    Ax.db.update('mut_ppv_invoice', 
        {
            'cabfac': null,
            'estado': 'P',
            'user_updated': Ax.db.getUser(),
            'date_updated': new Ax.sql.Date(),
            'user_assign': null,
            'date_assign': null
        }, 
        {
            'rowid': pIntRowid
        }
    )

}