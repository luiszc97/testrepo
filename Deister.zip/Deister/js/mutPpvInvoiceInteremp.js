function mutPpvInvoiceInteremp(pIntCabid) {
    //Selecció de dades. 
    let mStrEmpcode = Ax.db.executeGet(`
        <select>
            <columns>
                cempresa.empcode
            </columns>
            <from table='gvenfach'>
                <join table='ctercero'>
                    <on>gvenfach.terfac = ctercero.codigo</on>
                    <join table='cempresa'>
                        <on>ctercero.terhol = cempresa.tercer</on>
                    </join>
                </join>
            </from>
            <where>
                gvenfach.cabid = ?
            </where>
        </select>
    `, pIntCabid);

    let mObjGvenfach = Ax.db.executeQuery(`
        <select>
            <columns>
                gvenfach.docser, ctercero.cif
            </columns>
            <from table='gvenfach'>
                <join table='cempresa'>
                    <on>gvenfach.empcode = cempresa.empcode</on>
                    <join table='ctercero'>
                        <on>cempresa.tercer = ctercero.codigo</on>
                    </join>
                </join>
            </from>
            <where>
                gvenfach.cabid = ?
            </where>
        </select>
    `, pIntCabid).toOne();

    //Controls.
    if (mStrEmpcode == null) {
        throw new Ax.lang.Exception(`Factura [${mObjGvenfach.docser}] no és interempresa. Contactar amb Aplicacions Corporatives.`);
    }

    let mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='mut_ppv_invoice' />
            <where>
                cif    = ? AND
                refter = ?
            </where>
        </select>
    `, mObjGvenfach.cif, mObjGvenfach.docser);

    if (mIntCount) {
        throw new Ax.lang.Exception(`Factura [${mObjGvenfach.docser}] ja registrada.`);
    }

    mIntCount = Ax.db.executeGet(`
        <select>
            <columns>COUNT(*)</columns>
            <from table='mut_ppv_invoice' />
            <where>
                cabfac = ?
            </where>
        </select>
    `, pIntCabid);

    if (mIntCount) {
        throw new Ax.lang.Exception(`Factura [${mObjGvenfach.docser}] ja assignada.`);
    }

    // Generació del PDF.  
    ///fop.form
    let mFile = Ax.ext.webapp.fopForm('gvenfach_print_mut' ,options => {
        options.setType('pdf');                                                        
        options.setCond(`gvenfach.docser = '${mObjGvenfach.docser}'`);
        options.setDatabase(Ax.ext.db.getDatabase());
    }); 

    //Inserció.  
    Ax.db.insert('mut_ppv_invoice', 
        {
            'cif': mObjGvenfach.cif,
            'refter': mObjGvenfach.docser,
            'codemp': mStrEmpcode,
            'file_name': `${mObjGvenfach.docser}.pdf`,
            'file_type': mFile.getContentType(),
            'file_size': mFile.length(),
            'file_data': mFile.toBlob().getBytes(),
            'origen': 'INT',
            'cabint': pIntCabid,
            'estado': 'P',
            'refori': mObjGvenfach.docser,
            'empori': mStrEmpcode,
            'user_created': Ax.db.getUser(),
            'date_created': new Ax.sql.Date(),
            'user_updated': Ax.db.getUser(),
            'date_updated': new Ax.sql.Date()
        }
    )

}