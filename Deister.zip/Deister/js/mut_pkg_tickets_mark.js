function mut_pkg_tickets_mark(pStrTercer, pData) {
    Ax.db.beginWork();

    let mArrTofile = [];

    if (Array.isArray(pData)) {
        pData.forEach(row => {
            // For multy selector row
            mArrTofile.push({'numseq': row.numseq});
        });
    } else {
        // For single selector row
        mArrTofile.push({'numseq': pData.numseq});
    }

    for (let mRow of mArrTofile) {
        let mObjPkgTickets = {'status': null};
        mObjPkgTickets = Ax.db.executeQuery(`
            <select>
                <columns>numtiq, status</columns>
                <from table='mut_pkg_tickets' />
                <where>
                    numseq = ?
                </where>
            </select>    
        `, mRow.numseq).toOne();

        if (mObjPkgTickets.numtiq == null) {
            throw new Ax.lang.Exception(`Tiquet amb identificador [${mRow.numseq}] no trobat.`);
        }

        if (mObjPkgTickets.status != 'S') {
            throw new Ax.lang.Exception(`Tiquet [${mObjPkgTickets.numtiq}] no existeix com a factura simplicada.`);
        }

        Ax.db.insert('mut_pkg_tickcli', 
            {
                'numseq': mRow.numseq,
                'tercer': pStrTercer,
                'user_created': Ax.db.getUser(),
                'date_created': new Ax.sql.Date(),
                'user_updated': Ax.db.getUser(),
                'date_updated': new Ax.sql.Date()
            }
        );

        Ax.db.update('mut_pkg_tickets', 
            {
                'status': 'R'
            }, 
            {
                'numseq': mRow.numseq
            }
        )

    }

    Ax.db.commitWork();
}