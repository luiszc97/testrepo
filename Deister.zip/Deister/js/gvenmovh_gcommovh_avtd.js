function gvenmovh_gcommovh_avtd(pIntCabori) {
    //===========================================================================
    // Seleccion de datos del movimiento original                                 
    //===========================================================================
    let mObjGvenmovh = Ax.db.executeQuery(`
        <select>
            <columns>
                gvenmovh.cabid,  gvenmovh.empcode, gvenmovh.delega,
                gvenmovh.fecmov, gvenmovh.fecent,  gvenmovh.docser,
                gvenmovh.docori, gvenmovh.almori,  gvenmovh.tercer,
                gvenmovh.tipdir, gvenmovh.terfac,  gvenmovh.dirfac,
                gdelegac.tercer terdlg,            gdelegac.dirdlg,
                gvenmovd.empalb, gvenmovd.tabori,  gvenmovd.dtoesp,
                gdeparta.terdep, gdeparta.dirdep
            </columns>
            <from table='gvenmovh'>
                <join table='gdelegac'>
                    <on>gvenmovh.delega = gdelegac.codigo</on>
                </join>
                <join table='gdeparta'>
                    <on>gvenmovh.delega = gdeparta.delega</on>
                    <on>gvenmovh.depart = gdeparta.depart</on>
                </join>
                <join table='gvenmovd'>
                    <on>gvenmovh.tipdoc = gvenmovd.codigo</on>
                </join>
            </from>
            <where>
                gvenmovh.cabid  = ?
            </where>
        </select>
    `, pIntCabori).toOne();

    // ===========================================================================
    //  Si no es facturacion interempresa -> Salir                                 
    // ===========================================================================
    let interemp = Ax.db.executeFunction('icon_get_interempresa', mObjGvenmovh.empcode, mObjGvenmovh.tercer).toValue();

    if (interemp == null || mObjGvenmovh.empalb == null || mObjGvenmovh.empalb.length == 0) {
        return;
    }

    // ========================================================================
    //  srf: Obtenir empcode, delega,depart,tercer,tipdir.                      
    // ========================================================================    
    let mObjGcommovh = Ax.db.executeQuery(`
        <select>
            <columns>
                gdelegac.empcode, gdeparta.delega, gdeparta.depart
            </columns>
            <from table='gdeparta'>
                <join table='gdelegac'>
                    <on>gdeparta.delega = gdelegac.codigo</on>
                </join>
            </from>
            <where>
                gdeparta.terdep = ? AND
                gdeparta.dirdep = ?
            </where>
        </select>        
    `, mObjGvenmovh.tercer, mObjGvenmovh.tipdir)
        .toOne()
        .setRequired('Conversió departament interempresa inexistent.');

    if (mObjGvenmovh.dirdep != null) {
        mObjGcommovh.tercer = mObjGvenmovh.terdep;
        mObjGcommovh.tipdir = mObjGvenmovh.dirdep;
    } else {
        mObjGcommovh.tercer = mObjGvenmovh.terdlg;
        mObjGcommovh.tipdir = mObjGvenmovh.dirdlg;
    }

    if (mObjGcommovh.tercer == null || mObjGcommovh.tipdir == null) {
        throw new Ax.lang.Exception(`Tercer/Direcció no definits per departament [${mObjGcommovh.delega},${mObjGcommovh.depart}].`);
    }

    // =========================================================================== 
    //  Tipo de documento a generar es el albarán interempresa definido             
    //  en 'gvenmovd' para el tipo de albarán de ventas.                            
    // =========================================================================== 
    mObjGcommovh.tipdoc = mObjGvenmovh.empalb;

    // ===========================================================================
    //  Almacen del albaran de compras.                                            
    //  Si no existe un almacen según tercero y direccion del albaran de ventas    
    //  se toma el almacen por defecto de la delegación ya propuesta.              
    // ===========================================================================    
    mObjGcommovh.almori = Ax.db.executeFunction('galmdele_get_almacen', `TC`, 0, 
        mObjGcommovh.delega, mObjGcommovh.depart, null, null,
        null, mObjGcommovh.tipdoc).toValue();

    if (mObjGcommovh.almori == null) {
        // ===================================================================
        //  Se hace un foreach con un exit para coger sólo el primer registro  
        //  que retorna el select ya que en teoría sólo debería haber uno      
        // =================================================================== 
        mObjGcommovh.almori = Ax.db.executeGet(`
            <select>
                <columns> 
                    first 1 codigo almori
                </columns>
                <from table='galmacen' />
                <where>
                    EXISTS(SELECT <rowid table='gdelegac' />
                             FROM gdelegac
                            WHERE gdelegac.codigo = ?
                              AND gdelegac.tercer = galmacen.tercer
                              AND gdelegac.dirdlg = galmacen.tipdir)
                </where>
            </select>            
        `, mObjGcommovh.delega);

        if (mObjGcommovh.almori == null) {
            throw new Ax.lang.Exception(`gvenmovh_gcommovh_avtd: No se ha podido determinar el almacen del albarán de compras.`);
        }

        // ===========================================================================
        //  Serie por defecto del albaran a generar.                                   
        // ===========================================================================    
        let mObjGcommovd = Ax.db.executeQuery(`
            <select>
                <columns>
                    dtoesp, ctades, indsal, proubi
                </columns>
                <from table='gcommovd'>
                    <join table='galmctas' type='left'>
                        <on>gcommovd.ctades = galmctas.codigo</on>
                    </join>
                </from>
                <where>
                    gcommovd.codigo = ?
                </where>
            </select>        
        `, mObjGcommovh.tipdoc).toOne();

        let mObjGalmctas = {};
        mObjGalmctas.indsal = mObjGcommovd.indsal;
        delete mObjGcommovd.indsal;

        if (mObjGcommovd.dtoesp == null) {
            throw new Ax.lang.Exception(`gvenmovh_gcommovh_avtd: Tipo de albaran de compras: [${mObjGcommovh.tipdoc}] no existente.`);
        }

        // ===========================================================================
        //  No puede ser que los dos albaranes interempresa tengan diferente           
        //  tratamiento de descuentos.                                                 
        // ===========================================================================    
        if (mObjGcommovd.dtoesp != mObjGvenmovh.dtoesp) {
            throw new Ax.lang.Exception(`gvenmovh_gcommovh_avtd: No puede ser, tipos albaranes interempresa con indicativo 'dtoesp' diferente.`);
        }

        // ===========================================================================
        //  Inicializar el campo refter (factura proveedor) con el valor del           
        //  docser de la factura de venta o con el docser del mismo albaran de         
        //  venta                                                                      
        // ===========================================================================
        mObjGcommovh.refter = mObjGvenmovh.docser;

        // =========================================================================== 
        //  Insercion cabecera albaran                                                  
        // ===========================================================================         
        //<call name='gcommovh_init' into='v_gcommovh' />

        // ===========================================================================
        //  Si no existe el tercero en el maestro de proveedores, aviso                
        // ===========================================================================
        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*) count</columns>
                <from table='gproveed' />
                <where>
                    codigo = ?
                </where>
            </select>            
        `, mObjGcommovh.tercer);

        if (mIntCount == 0) {
            throw new Ax.lang.Exception(`gvenmovh_gcommovh_avtd: Falta definir [${mObjGcommovh.tercer}] en 'gproveed'.`);
        }

        let mObjGcommovh = Ax.db.executeQuery(`
            <select>
                <columns>
                    gvenmovh.divisa,  gvenmovh.cambio,  gvenmovh.coment,
                    gvenmovh.tipefe,  gvenmovh.frmpag,  gvenmovh.terenv,
                    gvenmovh.direnv,  gvenmovh.nommos,  gvenmovh.direcc,
                    gvenmovh.codnac,  gvenmovh.nomnac,  gvenmovh.codpos,
                    gvenmovh.poblac,  gvenmovh.codprv,  gvenmovh.nomprv,
                    gvenmovh.telef1,  gvenmovh.telef2,  gvenmovh.fax,
                    gvenmovh.email,   gvenmovh.codpre,  gvenmovh.codpar,

                    gvenmovh.auxchr1, gvenmovh.auxchr2, gvenmovh.auxchr3,
                    gvenmovh.auxchr4, gvenmovh.auxchr5, gvenmovh.auxnum1,
                    gvenmovh.auxnum2, gvenmovh.auxnum3, gvenmovh.auxnum4,
                    gvenmovh.auxnum5,

                    <nvl>gvenmovh.refter, <gcommovh_refter /></nvl> refter,
                    gvenmovh.docser docori,             gvenmovh.docser oriaux,
                    gvenmovh.clasif,  gvenmovh.dtogen,  gvenmovh.dtopp,
                    CASE WHEN gvenmovh.portes = 'P'
                        THEN 'D'
                        ELSE 'P'
                    END portes
                </columns>
                <from table='gvenmovh'>
                </from>
                <where>
                    gvenmovh.cabid = ?
                </where>
            </select>            
        `, pIntCabori).toOne();

        mObjGcommovh.refter = null;
        mObjGcommovh.docori = null;

        // ===========================================================================
        //  Insertar cabecera de albarán.                                              
        // ===========================================================================
        mObjGcommovh.cabid = Ax.db.call('gcommovh_insert', 'INTEREMP', mObjGcommovh);

        // ===========================================================================
        //  Traspaso de descuentos de cabecera                                         
        // ===========================================================================
        if (mObjGcommovd.dtoesp == 'S') {
            Ax.db.call('gcomdtcl_InsGvendtcl', 'gcommovh', mObjGcommovh.cabid, 'gvenmovh', pIntCabori);
        }

        // ===========================================================================
        //  Insert de las lineas del albaran de compras previo paso por tabla          
        //  temporal y procedure de usuario                                            
        // ===========================================================================
        let mArrGcommovl = Ax.db.executeQuery(`
            <select>
                <columns>
                    gvenmovl.linid linmov,  ${mObjGcommovh.cabid} cabid, gvenmovl.orden,
                    gvenmovl.codart,        gvenmovl.varstk varlog,      gvenmovl.desvar,
                    gvenmovl.numlot,        gvenmovl.canmov,             gvenmovl.udmven,
                    gvenmovl.canalt,        gvenmovl.udmalt,             'E' estlin,
                    0 errlin,               gvenmovl.terdep terdep,      '0' ubiori,
                    gvenmovl.precio,        gvenmovl.pretar,             'S' indmod,
                    gvenmovl.dtotar,        0 impnet,                    gvenmovl.desamp
                </columns>
                <from table='gvenmovl' />
                <where>
                    gvenmovl.cabid   = ?
                </where>
            </select>            
        `, pIntCabori).toMemory();

        for (let mRow of mArrGcommovl) {
            // ===================================================================
            // Obtiene unidades para el suministro.                               
            // ===================================================================    
            let mObjMeasure = Ax.db.executeProcedure("gart_unidefs_get_flowqtys", columnIndex => {
                switch  (columnIndex) {
                    case 1:  return 'udmcom';
                    case 2:  return 'canped';
                    case 3:  return 'udmalt';
                    case 4:  return 'canalt';
                    case 5:  return 'udmpre';
                    case 6:  return 'canpre';
                    case 7:  return 'udmrec';
                    default: return "undefined";
                    }
                },
               'CL',
               0,
               mRow.udmven,
               mRow.canmov,
               mRow.udmalt,
               mRow.canalt,
               null,
               null,
               mRow.codart,
               mRow.varlog,
               mObjGcommovh.delega,
               mObjGcommovh.almori,
               mObjGcommovh.tercer,
               mObjGcommovh.tipdir,
               'gcommovh',
               mObjGcommovh.tipdoc,
               new Ax.sql.Date()
            ).toOne();   
            
            mRow.udmcom = mObjMeasure.udmcom;
            mRow.canmov = mObjMeasure.canmov;
            mRow.udmalt = mObjMeasure.udmalt;
            mRow.canalt = mObjMeasure.canalt;
            mRow.udmpre = mObjMeasure.udmpre;
            mRow.canpre = mObjMeasure.canpre;

            mRow.linid = mRow.linmov;

            delete mRow.udmven;
            delete mRow.linmov;

            mRow.canrec = 0;
            mRow.canabo = 0;
            mRow.regalo = 'N';

            mObjGartprov = {};
            mObjGartprov.refpro = null;

            mObjGartprov.refpro = Ax.db.executeGet(`
                <select>
                    <columns>refpro</columns>
                    <from table='gartprov' />
                    <where>
                        codart = ? AND
                        grpemp IN ('DIEM','DIST')
                    </where>
                </select>            
            `, mRow.codart);

            if (mObjGartprov.refpro == null) {
                throw new Ax.lang.Exception(`gvenmovh_gcommovh_avtd: Article [${mRow.codart}] sense conversió interempresa.`);
            }

            mRow.codart = mObjGartprov.refpro;

            mRow.udmcom = Ax.db.executeGet(`
                <select>
                    <columns>udmbas udmcom</columns>
                    <from table='garticul' />
                    <where>
                        codigo = ?
                    </where>
                </select>                
            `, mRow.codart);

            mRow.ubides = Ax.db.executeFunction("gcommovh_get_ubides",
                mObjGcommovh.cabid,
                mObjGcommovh.almori,
                null,
                mObjGcommovd.ctades,
                mRow.codart,
                mRow.varlog,
                mRow.numlot,
                mObjGalmctas.indsal
            ).toValue();

            // Inserción
            let mIntSerial = Ax.db.insert('gcommovl', mRow).getSerial();

            mRow.linid = mIntSerial;
        }

        // ===========================================================================
        // Validacion del albaran de compras generado                                 
        // ===========================================================================        
        Ax.db.call('gcommovh_Valida', mObjGcommovh.cabid);

        // ===========================================================================
        // Marcar el albaran de ventas origen como no modificable                     
        // ===========================================================================        
        Ax.db.update('gvenmovh', 
            {
                'indmod': 'N',
                'user_updated': Ax.db.getUser(),
                'date_updated': Ax.sql.Date()
            }, 
            {
                'cabid': pIntCabori
            }
        )

    }

}