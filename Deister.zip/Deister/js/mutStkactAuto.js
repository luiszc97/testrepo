function mutStkactAuto() {
    let mDate = new Ax.sql.Date();
    mDate = mDate.format('yyyyMMdd');

    //let mStrFilenameGalmstku = `/erpsync/mut_galmstku_${mDate}.xlsx`;
    //let mStrFilenameSiglasFoto = `/erpsync/mut_siglas_foto_${mDate}.xlsx`;

    let mObjMail = Ax.db.call('mutSysMailSelect', 'mutStkactAuto', 'general');
    let mStrSubject = 'Informe Valorat + Foto Estoc';

    let mStrCodobj = 'mut_stkact';
    let mStrCodobjFoto = 'sig_articulo_infest';
    let mStrCond = `garticul.estado = 'A' AND garticul.codtip = 'FAR' AND galmstku.codalm = '14FAR'`;

    try {
        let mMail = new Ax.mail.MailerMessage();
        mMail.from(mObjMail.mail_from);
        mMail.to(mObjMail.mail_to);
        mMail.cc(mObjMail.mail_cc);
        mMail.bcc(mObjMail.mail_bcc);
        mMail.subject(mStrSubject);
        mMail.setText("Correu electrònic amb fitxer adjunt enviat des de WebStudio.");


        let mOut = Ax.ext.webapp.fopForm(mStrCodobj ,options => {
            options.setType('xlsx');                                                        
            options.setCond(mStrCond);
            options.setDatabase(Ax.ext.db.getDatabase());
        }); 

        let mOut2 = Ax.ext.webapp.fopForm(mStrCodobjFoto ,options => {
            options.setType('xlsx');                                                        
            options.setDatabase(Ax.ext.db.getDatabase());
        });

        mMail.addAttachment(mOut.getBytes());
        mMail.addAttachment(mOut2.getBytes());
    
        //Se hace el envío del email
        let mMailer = new Ax.mail.Mailer();
        mMailer.setSMTPServer("localhost", 25);
        mMailer.send(mMail);  


    } catch (error) {
        let mMail = new Ax.mail.MailerMessage();
        mMail.from(mObjMail.mail_from);
        mMail.to(mObjMail.mail_to);
        mMail.cc(mObjMail.mail_cc);
        mMail.bcc(mObjMail.mail_bcc);
        mMail.subject(mStrSubject);
        mMail.setText(Ax.util.Error.getMessage(error));

        //Se hace el envío del email
        let mMailer = new Ax.mail.Mailer();
        mMailer.setSMTPServer("localhost", 25);
        mMailer.send(mMail);  
    }

}