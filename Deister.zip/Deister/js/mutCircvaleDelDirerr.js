function mutCircvaleDelDirerr() {
    let mStrPathName = `/factures/Factures/dirErr/`;

    let mFolder = new Ax.io.File(mStrPathName);

    for (let mFile of mFolder.listFiles()) {
        if (!mFile.isFile()) {
            continue;
        }

        mFile.delete();
    }

}