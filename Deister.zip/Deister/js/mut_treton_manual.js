function mut_treton_manual(pIntSeqno){

    let mDateToday = new Ax.sql.Date().format('yyyyMMdd');
    
    let mStrFileName = `/erpsync/mut_treton_manual_${mDateToday}.pdf`;
    
    let mStrMailFrom = 'noreply@mutuaterrassa.cat';
    let mStrMailto   = Ax.ext.user.getMail();
    let mStrSubject  = 'Traspàs Manual de Factures treton';

    let mStrCodobj   = 'mut_treton_gvenfac_mail';
    let mStrTtipefe  = 'TR';
    let mIntCount    = 0;
    let mStrFrmpag   = '085';

    try {

        //INCORPORACIÓ DE FITXERS
        Ax.db.call('mut_treton_import');
        Ax.db.beginWork();

        //GENERACIÓ DE FACTURES
        Ax.db.call('mut_treton_gvenfac', mStrTtipefe, mStrFrmpag);
        
        //TANQUEM PROCESSOS PENDENTS
        let mObjtClogproh = Ax.db.executeQuery(`
            <select>
                <columns>
                    FIRST 1 log_id, log_procname, log_user, log_date_ini
                </columns>
                <from table='clogproh'>
                </from>
                <where>
                        log_procname = 'gvenfach_contabn'
                    AND log_date_end IS NULL
                </where>
            </select>        
        `).toOne();

       //mObjtClogproh.log_id = mObjtClogproh.log_id == null ? 0 : mObjtClogproh.log_id; 
       
       if (mObjtClogproh.log_id != 0) {
            Ax.db.update("clogproh",
                {
                    "log_date_end": new Ax.sql.Date()
                },
                {
                    "log_id" : mObjtClogproh.log_id
                }
            )            
       }

       mIntCount = Ax.db.call(mut_treton_gvenfac_mail_count);

       if (mIntCount > 0) {        
            let mMail = new Ax.mail.MailerMessage();
            mMail.from(mStrMailFrom);
            mMail.to(mStrMailto);
            mMail.subject(mStrSubject);
            mMail.setText("Correu electrònic amb fitxer adjunt enviat des de WebStudio.");

            let mOut = Ax.ext.webapp.fopForm(mStrCodobj ,options => {
                options.setType('pdf');                                                        
                //options.setCond('condicionSQL');
                options.setDatabase(Ax.ext.db.getDatabase());
            }); 

            mMail.addAttachment(mOut.getBytes());

            //Se hace el envío del email
            let mMailer = new Ax.mail.Mailer();
            mMailer.setSMTPServer("localhost", 25);
            mMailer.send(mMail);      
       }

       Ax.db.commitWork();
        
    } catch (error) {

        Ax.db.rollbackWork();

        Ax.db.beginWork();

        Ax.db.update("mut_treton_file",
            {
                "estat": 5,
                "errmsg": Ax.util.Error.getMessage(error)
            },
            {
                "seqno" : pIntSeqno
            }
        ) 

        Ax.db.commitWork();
        
    }
}