/**
 *  <call name='mut_mail_docser_error'>
 *      <string>geanmovh</string>
 *      ${pIntCabid}
 *  </call>
 */

/**
 * ===============================================================================
 *  Marcar el moviment intern com a "especial Covid-19".                           
 * ===============================================================================
 */
let mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='geanmovh'>
            <join table='geanmovd'>
                <on>geanmovh.tipdoc = geanmovd.codigo</on>
            </join>
        </from>
        <where>
            geanmovh.cabid = ? AND
            geanmovh.refter <matches>'*/COV'</matches> AND
            <nvl>geanmovh.auxnum4, 0</nvl> != 1
        </where>
    </select>
`, pIntCabid);

if (mIntCount) {
    Ax.db.update('geanmovh', 
        {
            'auxnum4': 1
        }, 
        {
            'cabid': pIntCabid
        }
    )
}

mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='geanmovh'>
            <join table='geanmovd'>
                <on>geanmovh.tipdoc = geanmovd.codigo</on>
            </join>
            <join table='gvenmovh'>
                <on>geanmovh.refter = gvenmovh.docser</on>
            </join>
        </from>
        <where>
            geanmovh.cabid  = ? AND
            geanmovd.tabori = 'gcomsolh'  AND
            gvenmovh.refter <matches>'*/COV'</matches> AND
            <nvl>geanmovh.auxnum4, 0</nvl> != 1
        </where>
    </select>
`, pIntCabid)

if (mIntCount) {
    Ax.db.update('geanmovh', 
        {
            'auxnum4': 1
        }, 
        {
            'cabid': pIntCabid
        }
    )
}

/** 
 * ================================================================================
 *  Un cop validat el moviment, processem possibles enviaments d'entrades als       
 *  armaris Omnicell:                                                               
 *  1) Creació de registres a la taula mut_omn_geanmovh                             
 *  2) Creació de fitxers amb les dades de la taula mut_omn_geanmovh                
 * ================================================================================
 */
Ax.db.call('mut_geanmovh_ToOmnGeanmovh', pIntCabid)

mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='geanmovh'>
        </from>
        <where>
            geanmovh.cabid  = ${pIntCabid}
            AND geanmovh.estcab = 'V'
            AND EXISTS (SELECT * FROM geanmovl WHERE geanmovl.cabid = ${pIntCabid} AND estlin='V')
            AND NOT EXISTS (SELECT * FROM mut_omn_geanmovh_his WHERE omn_cabean = ${pIntCabid})
        </where>
    </select>
`);

let mStrDocser = Ax.db.executeGet(`
    <select>
        <columns>docser</columns>
        <from table='geanmovh'>
        </from>
        <where>
            geanmovh.cabid  = ${pIntCabid}
        </where>
    </select>
`)

if (mIntCount) {
    Ax.db.call('mut_omn_geanmovh_Export', pIntCabid, mStrDocser)
}