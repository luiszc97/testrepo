let mObjGvenmovh = Ax.db.executeQuery(`
    <select>
        <columns>
            docser
        </columns>
        <from table='gvenmovh ' />
        <where>
            cabid  = ? 
        </where>
    </select>
`, pIntCabid).toOne();

let mIntCount1 = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='gvenmovh' />
        <where>
            cabid  = ? AND
            estcab = 'V'         AND
            tipdoc IN ('NVID','RVID')
        </where>
    </select>
`, pIntCabid);

let mIntCount2 = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='gcommovh' />
        <where>
            tipdoc IN ('NCID','RCID') AND
            oriaux = ?
        </where>
    </select>
`, mObjGvenmovh.docser);

if (mIntCount1 && !mIntCount2) {
    Ax.db.call('disGvenmovhInteremp', pIntCabid);
}

mIntCount1 = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='gvenmovh' />
        <where>
            cabid  = ?   AND
            estcab = 'V' AND
            tipdoc IN ('NEID','REID')
        </where>
    </select>
`, pIntCabid);

mIntCount2 = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='gcommovh' />
        <where>
            tipdoc IN ('NOID','ROID') AND
            oriaux = ?
        </where>
    </select>
`, mObjGvenmovh.docser);

if (mIntCount1 && !mIntCount2) {
    Ax.db.call('disGvenmovhInterempDevo', pIntCabid);
}

mIntCount1 = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='gvenmovh' />
        <where>
            cabid   = ? AND
            tipdoc  = 'AVTD' AND
            empcode = '14' AND
            estcab  = 'V'
        </where>
    </select>
`, pIntCabid);

mIntCount2 = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='gcommovh' />
        <where>
            tipdoc  = 'ACTD' AND
            oriaux  = ?
        </where>
    </select>
`, mObjGvenmovh.docser);

if (mIntCount1 && !mIntCount2) {
    // funcion gvenmovh_gcommovh_avtd Not found
    //Ax.db.call('gvenmovh_gcommovh_avtd', pIntCabid);
}

//Se comento la funcion mut_mail_docser_error
//Ax.db.call('mutMailDocserError', 'gvenmovh', pIntCabid);

/*
 * ===============================================================================
 *  Marcar l'albarà com a "especial Covid-19".                                     
 * ===============================================================================
 */
let mIntCount = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*)</columns>
        <from table='gvenmovh' />
        <where>
            cabid = ? AND
            refter <matches>'*/COV'</matches> AND
            <nvl>auxnum4, 0</nvl> != 1
        </where>
    </select>
`, pIntCabid);

if (mIntCount) {
    Ax.db.update('gvenmovh', 
        {
            'auxnum4': 1
        }, 
        {
            'cabid': pIntCabid
        }
    )
}