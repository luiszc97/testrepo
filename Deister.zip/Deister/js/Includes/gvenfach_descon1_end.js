/* 
 * Registrar a la taula mut_fac_conhist les dades bàsiques 
 * de l'última situació de la factura (a modificar)  
 */
let mArrGvenfach = Ax.db.executeQuery(`
    <select>
        <columns>
            0 orden,
            'V' naturaleza,
            gvenfach.cabid,
            'D' accio,
            gvenfach.empcode,
            ctercero.cif idemisor,
            gvenfach.docser,
            gvenfach.fecha,
            gvenfach.fecope,
            gvenfach.docser refter,
            gvenfach.tercer,
            gvenfach.imptot,
            gvenfach.imptot impfac,
            essii_facturas.erp_estado,
            essii_facturas.tipocomunicacion,
            essii_facturas.sii_estado,
            essii_facturas.user_updated sii_user_updated,
            essii_facturas.date_updated sii_date_updated,
            '${Ax.db.getUser()}' user_created,
            current date_created,
            max(NVL(essii_factuhis.orden,0)) sii_orden
        </columns>
        <from table='gvenfach'>
            <join table='cempresa'>
                <on>gvenfach.empcode = cempresa.empcode</on>
                <join table='ctercero'>
                    <on>cempresa.tercer = ctercero.codigo</on>
                </join>
            </join>
            <join table='essii_facturas' type='left'>
                <on>gvenfach.empcode = essii_facturas.empcode</on>
                <on>ctercero.cif     = essii_facturas.idemisor</on>
                <on>gvenfach.docser  = essii_facturas.numfactura</on>
                <on>gvenfach.fecha   = essii_facturas.fechafactura</on>
                <join table='essii_factuhis'>
                    <on>essii_facturas.empcode      = essii_factuhis.empcode</on>
                    <on>essii_facturas.idemisor     = essii_factuhis.idemisor</on>
                    <on>essii_facturas.numfactura   = essii_factuhis.numfactura</on>
                    <on>essii_facturas.fechafactura = essii_factuhis.fechafactura</on>
                </join>
            </join>
        </from>
        <where>
            gvenfach.cabid = ?
        </where>
        <group>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20</group>
    </select>
`, pIntCabid);

for (let mRow of mArrGvenfach) {
    Ax.db.insert('mut_fac_conhist', mRow)

    break;
}