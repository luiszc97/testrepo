let mIntNumreg = Ax.db.executeGet(`
    <select>
        <columns>COUNT(*) numreg</columns>
        <from table='geanmovh'>
            <join table='geanmovd'>
                <on>geanmovh.tipdoc = geanmovd.codigo</on>
            </join>
        </from>
        <where>
            ${pStrSqlcond} AND
            geanmovd.tipast IS NOT NULL AND
            EXISTS (SELECT geanmovl.linid
                    FROM geanmovl
                    WHERE geanmovh.cabid = geanmovl.cabid
                    AND geanmovl.impcos IS NULL)
        </where>
    </select>
`);

if (mIntNumreg) {
    throw new Ax.lang.Exception(`Pel criteri seleccionat, existeixen ${mIntNumreg} moviment/s sense valorar.`)
}