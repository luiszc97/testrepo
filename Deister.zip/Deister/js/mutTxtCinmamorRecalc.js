function mutTxtCinmamorRecalc(
    pStrEmpcode,
    pStrCodinm,
    pStrCodele,
    pStrCodcom,
    pIntNumhis,
    pStrSistem
) {
    Ax.db.beginWork();

    let mIntMaxhis = Ax.db.executeGet(`
        <select>
            <columns>MAX(numhis) maxhis</columns>
            <from table='cinmcval' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                sistem  = ? AND
                estado  = 'A'
            </where>
        </select>
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, pStrSistem);

    if (mIntMaxhis != (pIntNumhis+1)) {
        throw new Ax.lang.Exception('No es el penúltim element.')
    }

    let mArrCinmamor = Ax.db.executeQuery(`
        <select>
            <columns>
                cinmamor.empcode, cinmamor.codinm, cinmamor.codele,
                cinmamor.codcom,  cinmamor.numhis, cinmamor.sistem,
                cinmamor.fecini,  cinmamor.fecfin,
                mut_txt_cinmamor.import
            </columns>
            <from table='cinmamor'>
                <join table='mut_txt_cinmamor'>
                    <on>cinmamor.empcode = mut_txt_cinmamor.empcode</on>
                    <on>cinmamor.codinm  = mut_txt_cinmamor.codinm</on>
                    <on>cinmamor.codele  = mut_txt_cinmamor.codele</on>
                    <on>cinmamor.codcom  = mut_txt_cinmamor.codcom</on>
                    <on>cinmamor.numhis  = mut_txt_cinmamor.numhis</on>
                    <on>cinmamor.sistem  = mut_txt_cinmamor.sistem</on>
                    <on>cinmamor.fecini  = mut_txt_cinmamor.fecini</on>
                </join>
            </from>
            <where>
                cinmamor.empcode = ? AND
                cinmamor.codinm  = ? AND
                cinmamor.codele  = ? AND
                cinmamor.codcom  = ? AND
                cinmamor.numhis  = ${mIntMaxhis}  AND
                cinmamor.sistem  = ?  AND
                mut_txt_cinmamor.hisori = ${pIntNumhis}
            </where>
            <order>cinmamor.fecini</order>
        </select>
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, pStrSistem);

    for (let mRow of mArrCinmamor) {
        let mDecImpdif = Ax.db.executeGet(`
            <select>
                <columns>
                    SUM(cinmamor.import - mut_txt_cinmamor.import) impdif
                </columns>
                <from table='cinmamor'>
                    <join table='mut_txt_cinmamor'>
                        <on>cinmamor.empcode = mut_txt_cinmamor.empcode</on>
                        <on>cinmamor.codinm  = mut_txt_cinmamor.codinm</on>
                        <on>cinmamor.codele  = mut_txt_cinmamor.codele</on>
                        <on>cinmamor.codcom  = mut_txt_cinmamor.codcom</on>
                        <on>cinmamor.numhis  = mut_txt_cinmamor.numhis</on>
                        <on>cinmamor.sistem  = mut_txt_cinmamor.sistem</on>
                        <on>cinmamor.fecini  = mut_txt_cinmamor.fecini</on>
                    </join>
                </from>
                <where>
                    cinmamor.empcode = ? AND
                    cinmamor.codinm  = ? AND
                    cinmamor.codele  = ? AND
                    cinmamor.codcom  = ? AND
                    cinmamor.numhis  = ${pIntNumhis}  AND
                    cinmamor.sistem  = ? AND
                    mut_txt_cinmamor.hisori = ${pIntNumhis} AND
                    (cinmamor.fecini = ${mRow.fecini} OR cinmamor.fecfin = ${mRow.fecfin})
                </where>
            </select>
        `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, pStrSistem);

        Ax.db.update('cinmamor', 
            {
                'import': mRow.import - mDecImpdif
            }, 
            {
                'empcode': pStrEmpcode, 
                'codinm': pStrCodinm, 
                'codele': pStrCodele, 
                'codcom': pStrCodcom, 
                'numhis': mIntMaxhis, 
                'sistem': pStrSistem, 
                'fecfin': mRow.fecfin 

            }
        )

    }

    let mDecBakori = Ax.db.executeGet(`
        <select>
            <columns>SUM(import) bakori</columns>
            <from table='mut_txt_cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
                sistem  = ?
            </where>
        </select>
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, pIntNumhis, pStrSistem);

    let mDecTotori = Ax.db.executeGet(`
        <select>
            <columns>SUM(import) totori</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
                sistem  = ?
            </where>
        </select>
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, pIntNumhis, pStrSistem);

    let mDecAmoori = Ax.db.executeGet(`
        <select>
            <columns><nvl>SUM(import), 0</nvl> amoori</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
                sistem  = ? AND
                estado  = 'C'
            </where>
        </select>
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, pIntNumhis, pStrSistem);

    let mDecBakdes = Ax.db.executeGet(`
        <select>
            <columns>SUM(import) bakdes</columns>
            <from table='mut_txt_cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
                sistem  = ?
            </where>
        </select>
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, mIntMaxhis, pStrSistem);

    let mDecTotdes = Ax.db.executeGet(`
        <select>
            <columns>SUM(import) totdes</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
                sistem  = ?
            </where>
        </select>    
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, mIntMaxhis, pStrSistem);

    if (mDecBakori != mDecTotori) {
        throw new Ax.lang.Exception(`Sumatori d'import inicial [${mDecBakori}] i final [${mDecTotori}] no coincideixen.`)
    }

    let mDecAmodes = Ax.db.executeGet(`
        <select>
            <columns><nvl>SUM(import), 0</nvl> amodes</columns>
            <from table='cinmamor' />
            <where>
                empcode = ? AND
                codinm  = ? AND
                codele  = ? AND
                codcom  = ? AND
                numhis  = ? AND
                sistem  = ? AND
                estado  = 'C'
            </where>
        </select>    
    `, pStrEmpcode, pStrCodinm, pStrCodele, pStrCodcom, mIntMaxhis, pStrSistem);

    Ax.db.update('cinmcval', 
        {
            'acucom': mDecAmoori,
            'netcom': mDecTotori - mDecAmoori
        }, 
        {
            'empcode': pStrEmpcode,
            'codinm': pStrCodinm,
            'codele': pStrCodele,
            'codcom': pStrCodcom,
            'numhis': pIntNumhis,
            'sistem': pStrSistem
        }
    )

    Ax.db.update('cinmcval', 
        {
            'acucom': mDecAmodes,
            'netcom': mDecTotdes - mDecAmodes
        }, 
        {
            'empcode': pStrEmpcode,
            'codinm': pStrCodinm,
            'codele': pStrCodele,
            'codcom': pStrCodcom,
            'numhis': mIntMaxhis,
            'sistem': pStrSistem
        }
    )

    Ax.db.commitWork();

}