function mut_sendmail_ctg(
    pIntCtgidx,  
    pStrIdioma,  
    pStrTabname, 
    pStrMailfrom,
    pStrMailto,  
    pStrMailcc,  
    pStrMailbcc, 
    pStrSubject
){
    var mStrTextCode = `${pStrTabname}_mail`;
    var mStrTextData = Ax.db.executeGet(`
        <select>
            <columns>
                text_data
            </columns>
            <from table='cdoctext' />
            <where>
                tabname   = ? AND
                text_code = ? AND
                idioma    = ?
            </where>
        </select>
    `, pStrTabname, mStrTextCode, pStrIdioma);

    var mStrContent;

    if (mStrTextData != null) {
        mStrContent = `<p style="font-family: verdana, font-size: 8pt;">${m_text_data}</p>`;
    }

    var mStrContentType = 'text/html';
    var mBoolAddReadReceiptHeader = false;

    // Ajustar el missatge de l´email.  
    var mObjCtergest = Ax.db.executeQuery(`
        <select prepare='false'>
            <columns>
                ctergest.ctg_tabname,
                ctergest.ctg_cabid,
                cdoctext.text_data,
                cdoctext.text_code, 
                ctergest.ctg_tipges,                          
                ctipoges.nomges,
                cempresa.empname,
                cdoctext.text_desc
            </columns>
            <from table='ctergest'>
                <join table='ctipoges'>
                    <on>ctipoges.codigo = ctergest.ctg_tipges</on>
                </join>
                <join type='left' table='cdoctext'>
                    <on>cdoctext.text_code = <trim>ctergest.ctg_tipges</trim> || '_email'</on>
                </join>
                <join type='left' table='cempresa'>
                    <on>cempresa.empcode = ctergest.ctg_empcode</on>
                </join>
            </from>
            <where>
                    ctergest.ctg_seqno = ?
                AND cdoctext.tabname   = 'ctergest'
                AND cdoctext.idioma    = ?
            </where>
        </select>
    `, pIntCtgidx, pStrIdioma).toOne();

    if (mStrTextCode == null) {
        throw new Ax.ext.Exception(`Falta informar en la taula cdoctext el codi: ${mObjCtergest.ctg_tipges}_email`);
    }

    /**
     *  Realitza una segona passada per si amb el resultat per la tipologia
     *  P o V , s'afegeix alguna variable que es vulgui substituir         
     *  aquesta substitucio nomes afecta al cos del email no als documents  
     *  adjunts                                                            
     */ 
    if (mStrTextData != null) {
        mStrTextData = Ax.db.call('mut_text_data_var', 
            mStrTextData, 
            'ctergest', 
            pIntCtgidx, 
            mObjCtergest.ctg_tipges
        )
    }

    if (
        mStrTextData.indexOf("<br") > 0 ||
        mStrTextData.indexOf("<BR") > 0 ||
        mStrTextData.indexOf("<tt") > 0 ||
        mStrTextData.indexOf("<TT") > 0 ||
        mStrTextData.indexOf("<pre") > 0 ||
        mStrTextData.indexOf("<PRE") > 0
    ) {
        mStrContentType = "text/html";
    } else {
        mStrContentType = "text/plain";
    }

    var mStrDocser = null;

    if (mObjCtergest.ctg_tipges != 'cefectos') {
        mStrDocser = Ax.db.executeGet(`
            <select>
                <columns>docser</columns>
                <from table='${mObjCtergest.ctg_tabname}'/>
                <where>
                    cabid = ?
                </where>
            </select>
        `, mObjCtergest.ctg_cabid);
    }

    mBoolAddReadReceiptHeader = true;
    pStrSubject = `${mObjCtergest.text_desc || mObjCtergest.nomges} \ ${mStrDocser} \ ${mObjCtergest.empname}`;
    mStrContent = `\n${mStrTextData}\n\n${mObjCtergest.empname}`.trim();

    /**
     *  Toma el valor que se le esta dando por parametro en caso de ser nulo este parametro 
     *  tomaria el valor del campo email_pri del registro que coincidiera con el tipo de    
     *  de gestion indicado por p_tipges si existe                                          
     */
    if (pStrMailfrom == null || pStrMailfrom.length == 0) {
        pStrMailfrom = Ax.db.executeGet(`
            <select>
                <columns>
                    <trim>email_pri</trim> mailfrom
                </columns>
                <from table='mut_ctipoges' />
                <where>
                    codigo  = ?
                </where>
            </select>        
        `, mObjCtergest.ctg_tipges);
    }

    /**
     *  Preparar ficheros a adjuntar. 
     */
    var mArrAttach = [];
    var mNumAttach = 0;

    var mArrCtergestDocs = Ax.db.executeQuery(`
        <select>
            <columns>
                file_type, REPLACE(file_name, "/", "_") file_name, file_data
            </columns>
            <from table='ctergest_docs' />
            <where>
                ctg_seqno = ? AND
                device = 1
            </where>
        </select>
    `, pIntCtgidx).toMemory();

    var mFile;

    for (var mRow of mArrCtergestDocs) {
        mFile = new Ax.io.File(mRow.file_name);
        mFile.write(mRow.file_data, 'ISO-8859-1');
        mArrAttach.push(mFile);         
        mNumAttach = 1
    }

    /**
     *  Enviar email. 
     */
    let mMail = new Ax.mail.MailerMessage();
    mMail.from(pStrMailfrom);
    mMail.to(pStrMailto);
    mMail.cc(pStrMailcc)
    mMail.bcc(pStrMailbcc)
    mMail.subject(pStrSubject);
    mMail.addHeader(mBoolAddReadReceiptHeader);
    mMail.addHeader("Disposition-Notification-To", mBoolAddReadReceiptHeader); // Confirmación de lectura

    mMail.setBody(mStrContent, mStrContentType);

    mArrAttach.forEach(file => {
        mMail.addAttachment(file);
    });

   /** 
    * Borrar tots els documents de la gestio que continguin el substring ô-    
    * aquets arxius s'han definit com a no persistents actualment son el tipus 
    * ô-0 i ô-1  
    */   
    mArrCtergestDocs = Ax.db.executeQuery(`
        <select>
            <columns>
                *
            </columns>
            <from table='ctergest_docs' />
            <where>
                ctergest_docs.ctg_seqno = ${pIntCtgidx}
                AND '${pStrTabname}' = 'ctergest'  
            </where>
        </select>
    `).toMemory();
    
    for (var mRow of mArrCtergestDocs) {
        if (mRow.file_memo.indexOf("ô-") > 0) {
            Ax.db.delete('ctergest_docs', {seqno: mRow.seqno});
        }
    }
    
    /**
     *  Guardar email enviado. 
     */
    var mStrCtgTercer = Ax.db.executeGet(`
        <select>
            <columns>
                ctg_tercer
            </columns>
            <from table='ctergest' />
            <where>
                ctg_seqno = ?
            </where>
        </select>
    `, pIntCtgidx);

    Ax.db.insert('ctermail', 
        {
            tercer: mStrCtgTercer,
            tabori: pStrTabname,
            tabid:  pIntCtgidx,
            mail_io: 0,
            mail_server: Ax.ext.system.getRequest().getRemoteHost(),
            mail_user: Ax.db.getUser(),
            mail_uid: Ax.db.getUser(),
            mail_from: Ax.db.getUser(),
            mail_to: pStrMailto,
            mail_replyto: pStrMailbcc,
            mail_sentdate: new Ax.util.Date(),
            mail_subject: pStrSubject,
            mail_xmailer: 'DEISTER WebMail',
            flag_attach: mNumAttach,
            mail_message: mMail
        }
    )   

}