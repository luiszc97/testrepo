function mut_text_data_var(
    pStrText,   
    pStrTabname,
    pIntSeqno,  
    pStrTabori
) {
    // Tipus que començan amb #
    var mArrName = [];

    // Tipus que començan amb ^
    var mArrDocName    = [];
    var mArrDocNameVar = [];

    // Tipus que començan amb ¨
    var mArrFunName    = [];
    var mArrFunNameVar = []; 
    
    // Obtenir les variables per substituir del camp text
    var mBoolVariable = false;
    var mStrTokens = [" ","#", "\n", "\r", ",", ";", ":", "-", "+", "!", ")", "'", '"', "^", "¨", "â", "ê", "î", "ô", "û", "ä", "ë", "ï", "ö", "ü", "{", "}", "&"];
    
    var escapedTokens = mStrTokens.map(token => token.replaceAll(/[.*+?^=!:${}()|\[\]\/\\]/g, "\\$&"));
    
    // Convertimos el array de tokens en una expresión regular
    var regex = new RegExp(`(${escapedTokens.join('|')})`, 'g');
    var mArr = pStrText.split(regex);
    var mArrsize = mArr.length - 1;

    for (var idx = 0; idx <= mArrsize; idx++) {
        if (mArr[idx] === '#') {
            mBoolVariable = true;
            continue;
        }
    
        if (mBoolVariable) {
            mArrName.push(mArr[idx]); 
        }
    
        mBoolVariable = false; 
    }
    var mArrDocs;

    if (pStrTabname == 'ctergest') {
        // Obtenir els documents per afegir a les gestions   
        mBoolVariable = false;
        mStrTokens = ["\n", "\r", "^"]; // Definimos los delimitadores
		escapedTokens = mStrTokens.map(token => token.replaceAll(/[.*+?^=!:${}()|\[\]\/\\]/g, "\\$&"));
        regex = new RegExp(`(${escapedTokens.join('|')})`, 'g');
        mArrDocs = pStrText.split(regex);
        mArrsize = mArrDocs.length - 1;

        // Recorremos el arreglo arr_docs con un bucle for
        for (var idx = 0; idx <= mArrsize; idx++) {
            if (mArrDocs[idx] === '^') {
                mBoolVariable = true;
                continue; // Salta a la siguiente iteración del bucle
            }

            if (mBoolVariable) {
                mArrDocName.push(mArrDocs[idx]);
            }

            mBoolVariable = false;
        }

        // Obtenir les funcions per executar a les gestions
        mBoolVariable = false;
        mStrTokens = ["\n", "\r", "¨"];
        escapedTokens = mStrTokens.map(token => token.replaceAll(/[.*+?^=!:${}()|\[\]\/\\]/g, "\\$&"));
        regex = new RegExp(`(${escapedTokens.join('|')})`, 'g');
        var mArrFunc = pStrText.split(regex);
        mArrsize = mArrFunc.length - 1;

        for (let idx = 0; idx <= mArrsize; idx++) {
            if (mArrFunc[idx] === '¨') {
                mBoolVariable = true;
                continue; // Salta a la siguiente iteración del bucle
            }

            if (mBoolVariable) {
                mArrFunName.push(mArrFunc[idx]);
            }

            mBoolVariable = false;
        }

    }

    var mColori;
    // Obtenir i substituir el valor de les variables  
    switch (pStrTabori) {
        case 'cefectos': 
            mColori = 'cefectos.numero';
            break;
    
        default:
            mColori = `${pStrTabori}.cabid`;
            break;
    }

    mArrsize = mArrName.length - 1;
    var mStrColumn;
    var mIntCount;
    var mValue;

    for (var idx = 0; idx <= mArrsize; idx++) {
        mStrColumn = mArrName[idx];

        if (mStrColumn.length == 0) {
            throw new Ax.ext.Exception(`Column es Nul [${mStrColumn}]. Variable [${mArrName[idx]}].`);
        }
        
        switch (pStrTabname) {
            case 'ctergest':
                switch (pStrTabori) {
                    case 'gman_ordetrah':
                        /**
                         *  Controls previs.  
                         */
                        mIntCount = Ax.db.executeGet(`
                            <select>
                                <columns>COUNT(*)</columns>
                                <from table='ctergest'>
                                    <join table='ctercero'>
                                        <on>ctercero.codigo = ctergest.ctg_tercer</on>
                                    </join>
                                </from>
                                <where>
                                    ctergest.ctg_seqno = ? AND
                                    ctercero.cif IS NOT NULL         AND
                                    ctercero.cif != '0'
                                </where>
                            </select>
                        `, pIntSeqno);

                        if (!mIntCount) {
                            throw new Ax.ext.Exception(`Tercer sense CIF informat.`);
                        }

                        mIntCount = Ax.db.executeGet(`
                            <select>
								<columns>COUNT(*)</columns>
								<from table='ctergest'>
									<join table='ctercero'>
										<on>ctercero.codigo = ctergest.ctg_tercer</on>
									</join>
									<join table='cterpago'>
										<on>ctergest.ctg_tercer = cterpago.codigo</on>
									</join>
								</from>
								<where>
									ctergest.ctg_seqno = ?
								</where>
							</select>
                        `, pIntSeqno);

                        if (!mIntCount) {
                            throw new Ax.ext.Exception(`Tercer sense condicions de pagament.`);
                        }

                        /**
                         *  Valor de la variable 
                         */
                        mValue = Ax.db.executeGet(`
                            <select prepare='false'>
                                <columns>
                                    unique ${mStrColumn} value
                                </columns>
                                <from table='ctergest'>
                                    <join table='ctercero'>
                                        <on>ctercero.codigo = ctergest.ctg_tercer</on>
                                    </join>
                                    <join table='cterdire'>
                                        <on>ctergest.ctg_tercer = cterdire.codigo</on>
                                        <on>ctergest.ctg_tipdir = cterdire.tipdir</on>
                                    </join>
                                    <join type='left' table='cprovinc'>
                                        <on>cprovinc.codnac  = cterdire.codnac</on>
                                        <on>cprovinc.codigo  = cterdire.codprv</on>
                                    </join>
                                    <join type='left' table='cuserids'>
                                        <on>ctergest.ctg_user = cuserids.usercode</on>
                                    </join>
                                    <join type='left' table='${pStrTabori}'>
                                        <on>${mColori} = ctergest.ctg_cabid</on>
                                    </join>
                                    <join type='left' table='cterpago' alias='cterpago_ctercero_gman_ordetrah'>
                                         <on>${pStrTabori}.tercer = cterpago_ctercero_gman_ordetrah.codigo</on>
                                         <on>
                                             cterpago_ctercero_gman_ordetrah.grpemp = (case when
                                             (
                                              select count(*)
                                                from choldinl e1
                                               where e1.empcode = ${pStrTabori}.empcode
                                                 and e1.holcode = cterpago_ctercero_gman_ordetrah.grpemp
                                                 and e1.holcode = ${pStrTabori}.empcode
                                             ) &gt; 0
                                              then
                                             (
                                              select e1.holcode
                                                from choldinl e1
                                               where e1.empcode = ${pStrTabori}.empcode
                                                 and e1.holcode = cterpago_ctercero_gman_ordetrah.grpemp
                                                 and e1.holcode = ${pStrTabori}.empcode
                                             )
                                             else
                                            (
                                              select e2.holcode
                                                from choldinl e2
                                               where e2.empcode = ${pStrTabori}.empcode
                                                 and e2.holcode = cterpago_ctercero_gman_ordetrah.grpemp
                                                 and e2.holcode = "ALL"
                                             )
                                            end
                                            )
                                        </on>
                                    </join>
                                    <join table='ctipopag' alias='ctipopag_cterpago_ctercero_gman_ordetrah'>
                                        <on>cterpago_ctercero_gman_ordetrah.tippag = ctipopag_cterpago_ctercero_gman_ordetrah.codigo</on>
                                    </join>                                    
                                    <join type='left' table='gman_ordetrad'>
                                        <on>gman_ordetrad.codigo = ${pStrTabori}.tipdoc</on>
                                    </join>
                                    <join table='cempresa'>
                                        <on>${pStrTabori}.empcode = cempresa.empcode</on>
                                    </join>
                                    <join type='left' table='ctercero' alias='ctercero_cempresa_gman_ordetrah'>
                                        <on>cempresa.tercer = ctercero_cempresa_gman_ordetrah.codigo</on>
                                    </join>
                                    <join type='left' table='cterdire' alias='cterdire_cempresa_gman_ordetrah'>
                                        <on>cempresa.tercer = cterdire_cempresa_gman_ordetrah.codigo</on>
                                        <on>cempresa.tipdir = cterdire_cempresa_gman_ordetrah.tipdir</on>
                                    </join>
                                    <join type='left' table='cprovinc' alias='cprovinc_cterdire_cempresa_gman_ordetrah'>
                                        <on>cterdire_cempresa_gman_ordetrah.codnac = cprovinc_cterdire_cempresa_gman_ordetrah.codnac</on>
                                        <on>cterdire_cempresa_gman_ordetrah.codprv = cprovinc_cterdire_cempresa_gman_ordetrah.codigo</on>
                                    </join>
                                    <join type='left' table='ctercero' alias='ctercero_gman_ordetrah'>
                                        <on>ctercero_gman_ordetrah.codigo = gman_ordetrah.tercer</on>
                                    </join>
                                    <join type='left' table='cterdire' alias='cterdire_gman_ordetrah'>
                                        <on>cterdire_gman_ordetrah.codigo = gman_ordetrah.tercer</on>
                                        <on>cterdire_gman_ordetrah.tipdir = gman_ordetrah.tipdir</on>
                                    </join>
                                    <join type='left' table='gman_equidefs'>
                                        <on>gman_equidefs.codmaq = gman_ordetrah.codmaq</on>
                                    </join>
                                    <join type='left' table='mut_repdocl'>
                                        <on>mut_repdocl.tabid  = 'gman_equidefs'</on>
                                        <on>mut_repdocl.codigo = gman_equidefs.codmaq</on>
                                    </join>
                                    <join type='left' table='mut_repdoch'>
                                        <on>mut_repdoch.cabid = mut_repdocl.cabid</on>
                                    </join>
                                    <join type='left' table='gman_equinsta'>
                                        <on>gman_equinsta.codins = gman_ordetrah.codins</on>
                                    </join>
                                    <join type='left' table='gdelegac'>
                                        <on>gdelegac.codigo = gman_ordetrah.delega</on>
                                    </join>
                                    <join type='left' table='gdeparta'>
                                        <on>gdeparta.delega = gman_ordetrah.delega</on>
                                        <on>gdeparta.depart = gman_ordetrah.depart</on>
                                    </join>
                                    <join type='left' table='gman_equicomp'>
                                        <on>gman_equicomp.codmaq = gman_ordetrah.codmaq</on>
                                        <on>gman_equicomp.codcom = gman_ordetrah.codcom</on>
                                    </join>
                                    <join type='left' table='gman_gamadefs'>
                                        <on>gman_gamadefs.codgam = gman_ordetrah.codgam</on>
                                    </join>
                                    <join type='left' table='gman_gamadefs_docs'>
                                        <on>gman_gamadefs_docs.codgam = gman_gamadefs.codgam</on>
                                    </join>
                                    <join type='left' table='gman_contrath'>
                                        <on>gman_contrath.docser = gman_ordetrah.codcon</on>
                                    </join>
                                    <join type='left' table='gman_contratl'>
                                        <on>gman_contratl.cabid = gman_contrath.cabid</on>
                                        <on>gman_contratl.codmaq = gman_ordetrah.codmaq</on>
                                        <on>gman_contratl.codins = gman_ordetrah.codins</on>
                                    </join>
                                    <join type='left' table='cper_empleado' alias='gman_ordetrah_codope_cper_empleado'>
                                        <on>gman_ordetrah_codope_cper_empleado.codigo = ${pStrTabori}.codope</on>
                                    </join>
                                    <join type='left' table='cper_empleado' alias='gman_ordetrah_codper_cper_empleado'>
                                        <on>gman_ordetrah_codper_cper_empleado.codigo = ${pStrTabori}.codper</on>
                                    </join>
                                    <join type='left' table='gman_tiposerv'>
                                        <on>gman_tiposerv.codigo = ${pStrTabori}.codser</on>
                                    </join>
                                    <join type='left' table='gman_solitrah'>
                                        <on>gman_solitrah.docser = ${pStrTabori}.docori</on>
                                    </join>
                                    <join type='left' table='gman_planprel'>
                                        <on>gman_planprel.linid = ${pStrTabori}.plaori</on>
                                    </join>
                                    <join table='gman_planpreh'>
                                        <on>gman_planpreh.cabid = gman_planprel.cabid</on>
                                    </join>                                   
                                </from>
                                <where>
                                    ctergest.ctg_seqno = ?
                                </where>
                            </select>
                        `, pIntSeqno);

                    break;
                
                    default:
                        // Valor de la variable
                        mValue = Ax.db.executeGet(`
                            <select prepare='false'>
                                <columns>
                                    unique ${mStrColumn} value
                                </columns>
                                <from table='ctergest'>
                                    <join table='ctercero'>
                                        <on>ctercero.codigo = ctergest.ctg_tercer</on>
                                    </join>
                                    <join table='cterdire'>
                                        <on>cterdire.codigo = ctergest.ctg_tercer</on>
                                        <on>cterdire.tipdir = ctergest.ctg_tipdir</on>
                                    </join>
                                    <join table='cempresa'>
                                        <on>cempresa.empcode = ctergest.ctg_empcode</on>
                                    </join>
                                    <join type='left' table='cprovinc'>
                                        <on>cprovinc.codnac  = cterdire.codnac</on>
                                        <on>cprovinc.codigo  = cterdire.codprv</on>
                                    </join>
                                    <join type='left' table='cuserids'>
                                        <on>ctergest.ctg_user = cuserids.usercode</on>
                                    </join>
                                    <join type='left' table='${pStrTabori}'>
                                        <on>${mColori} = ctergest.ctg_cabid</on>
                                    </join>
                                </from>
                                <where>
                                    ctergest.ctg_seqno = ?
                                </where>
                            </select>                        
                        `, pIntSeqno);

                    break;
                }
            break;

            case 'gman_ordetrah':
                //  Valor de la variable
                mValue = Ax.db.executeGet(`
                    <select prepare='false'>
                        <columns>
                            unique ${mStrColumn} value
                        </columns>
                        <from table='gman_ordetrah'>
                            <join table='ctercero'>
                                <on>ctercero.codigo = gman_ordetrah.tercer</on>
                            </join>
                            <join table='cterdire'>
                                <on>cterdire.codigo = gman_ordetrah.tercer</on>
                                <on>cterdire.tipdir = gman_ordetrah.tipdir</on>
                            </join>
                            <join type='left' table='cprovinc'>
                                <on>cprovinc.codnac  = cterdire.codnac</on>
                                <on>cprovinc.codigo  = cterdire.codprv</on>
                            </join>
                            <!-- Afegit de la selecte de ctergest INICI -->

                            <join type='left' table='cterpago' alias='cterpago_ctercero_gman_ordetrah'>
                                  <on>${pStrTabname}.tercer = cterpago_ctercero_gman_ordetrah.codigo</on>
                                  <on>
                                      cterpago_ctercero_gman_ordetrah.grpemp = (case when
                                      (
                                       select count(*)
                                         from choldinl e1
                                        where e1.empcode = ${pStrTabname}.empcode
                                          and e1.holcode = cterpago_ctercero_gman_ordetrah.grpemp
                                          and e1.holcode = ${pStrTabname}.empcode
                                      ) > 0
                                       then
                                      (
                                       select e1.holcode
                                         from choldinl e1
                                        where e1.empcode = ${pStrTabname}.empcode
                                          and e1.holcode = cterpago_ctercero_gman_ordetrah.grpemp
                                          and e1.holcode = ${pStrTabname}.empcode
                                      )
                                      else
                                     (
                                       select e2.holcode
                                         from choldinl e2
                                        where e2.empcode = ${pStrTabname}.empcode
                                          and e2.holcode = cterpago_ctercero_gman_ordetrah.grpemp
                                          and e2.holcode = "ALL"
                                      )
                                     end
                                     )
                                 </on>
                            </join>
	                        <join table='ctipopag' alias='ctipopag_cterpago_ctercero_gman_ordetrah'>
	                            <on>cterpago_ctercero_gman_ordetrah.tippag = ctipopag_cterpago_ctercero_gman_ordetrah.codigo</on>
	                        </join>
                            <join type='left' table='gman_ordetrad'>
                                <on>gman_ordetrad.codigo = ${pStrTabname}.tipdoc</on>
                            </join>
                            <join table='cempresa'>
                                <on>${pStrTabname}.empcode = cempresa.empcode</on>
                            </join>
                            <join type='left' table='ctercero' alias='ctercero_cempresa_gman_ordetrah'>
                                <on>cempresa.tercer = ctercero_cempresa_gman_ordetrah.codigo</on>
                            </join>
                            <join type='left' table='cterdire' alias='cterdire_cempresa_gman_ordetrah'>
                                <on>cempresa.tercer = cterdire_cempresa_gman_ordetrah.codigo</on>
                                <on>cempresa.tipdir = cterdire_cempresa_gman_ordetrah.tipdir</on>
                            </join>
                            <join type='left' table='cprovinc' alias='cprovinc_cterdire_cempresa_gman_ordetrah'>
                                <on>cterdire_cempresa_gman_ordetrah.codnac = cprovinc_cterdire_cempresa_gman_ordetrah.codnac</on>
                                <on>cterdire_cempresa_gman_ordetrah.codprv = cprovinc_cterdire_cempresa_gman_ordetrah.codigo</on>
                            </join>
                            <join type='left' table='ctercero' alias='ctercero_gman_ordetrah'>
                                <on>ctercero_gman_ordetrah.codigo = gman_ordetrah.tercer</on>
                            </join>
                            <join type='left' table='cterdire' alias='cterdire_gman_ordetrah'>
                                <on>cterdire_gman_ordetrah.codigo = gman_ordetrah.tercer</on>
                                <on>cterdire_gman_ordetrah.tipdir = gman_ordetrah.tipdir</on>
                            </join>
                            <join type='left' table='gman_equidefs'>
                                <on>gman_equidefs.codmaq = gman_ordetrah.codmaq</on>
                            </join>
                            <join type='left' table='mut_repdocl'>
                                <on>mut_repdocl.tabid  = 'gman_equidefs'</on>
                                <on>mut_repdocl.codigo = gman_equidefs.codmaq</on>
                            </join>
                            <join type='left' table='mut_repdoch'>
                                <on>mut_repdoch.cabid = mut_repdocl.cabid</on>
                            </join>
                            <join type='left' table='gman_equinsta'>
                                <on>gman_equinsta.codins = gman_ordetrah.codins</on>
                            </join>
                            <join type='left' table='gdelegac'>
                                <on>gdelegac.codigo = gman_ordetrah.delega</on>
                            </join>
                             <join type='left' table='gdeparta'>
                                 <on>gdeparta.delega = gman_ordetrah.delega</on>
                                 <on>gdeparta.depart = gman_ordetrah.depart</on>
                             </join>
                            <join type='left' table='gman_equicomp'>
                                <on>gman_equicomp.codmaq = gman_ordetrah.codmaq</on>
                                <on>gman_equicomp.codcom = gman_ordetrah.codcom</on>
                            </join>
                            <join type='left' table='gman_gamadefs'>
                                <on>gman_gamadefs.codgam = gman_ordetrah.codgam</on>
                            </join>
                            <join type='left' table='gman_gamadefs_docs'>
                                <on>gman_gamadefs_docs.codgam = gman_gamadefs.codgam</on>
                            </join>
                            <join type='left' table='gman_contrath'>
                                <on>gman_contrath.docser = gman_ordetrah.codcon</on>
                            </join>
                            <join type='left' table='gman_contratl'>
                                <on>gman_contratl.cabid = gman_contrath.cabid</on>
                                <on>gman_contratl.codmaq = gman_ordetrah.codmaq</on>
                                <on>gman_contratl.codins = gman_ordetrah.codins</on>
                            </join>
                            <join type='left' table='cper_empleado' alias='gman_ordetrah_codope_cper_empleado'>
                                <on>gman_ordetrah_codope_cper_empleado.codigo = ${pStrTabname}.codope</on>
                            </join>
                            <join type='left' table='cper_empleado' alias='gman_ordetrah_codper_cper_empleado'>
                                <on>gman_ordetrah_codper_cper_empleado.codigo = ${pStrTabname}.codper</on>
                            </join>
                            <join type='left' table='gman_tiposerv'>
                                <on>gman_tiposerv.codigo = ${pStrTabname}.codser</on>
                            </join>
                            <join type='left' table='gman_solitrah'>
                                <on>gman_solitrah.docser = ${pStrTabname}.docori</on>
                            </join>
                            <join type='left' table='gman_planprel'>
                                <on>gman_planprel.linid = ${pStrTabname}.plaori</on>
                            </join>
                            <join table='gman_planpreh'>
                                <on>gman_planpreh.cabid = gman_planprel.cabid</on>
                            </join>
                            <!-- Afegit de la selecte de ctergest  FINAL -->
                        </from>
                        <where>
                            gman_ordetrah.cabid = ?
                        </where>
                    </select>
                `, pIntSeqno);

            break;

            case 'gcompedh':
                //  Valor de la variable 
                mValue = Ax.db.executeGet(`
                                        <select prepare='false'>
                        <columns>
                            unique ${mStrColumn} value
                        </columns>
                        <from table='gcompedh'>
                            <join table='ctercero'>
                                <on>ctercero.codigo = gcompedh.tercer</on>
                            </join>
                            <join table='cterdire'>
                                <on>cterdire.codigo = gcompedh.tercer</on>
                                <on>cterdire.tipdir = gcompedh.tipdir</on>
                            </join>
                            <join table='gdelegac'>
                                <on>gdelegac.codigo = gcompedh.delega</on>
                            </join>
                            <join type='left' table='cterdire' alias='cterdire2'>
                                <on>cterdire2.codigo = gdelegac.tercer</on>
                                <on>cterdire2.tipdir = gdelegac.dirdlg</on>
                            </join>
                            <join table='cempresa'>
                                <on>cempresa.empcode = gcompedh.empcode</on>
                            </join>
                            <join type='left' table='cprovinc'>
                                <on>cprovinc.codnac  = cterdire.codnac</on>
                                <on>cprovinc.codigo  = cterdire.codprv</on>
                            </join>
                        </from>
                        <where>
                            gcompedh.cabid = ?
                        </where>
                    </select>
                `, pIntSeqno); 

            break;
        }

        //  Substituir en el text
        try {
            mValue = mValue.format('dd-MM-yyyy');
        } catch (error) {
            
        }

        // Si el contingut del text es rtf substitueix els sals de linea per \line 
        if (pStrText.indexOf("{\\rtf1\\") >= 0) {
            mValue = mValue.replaceAll(/\r\n/g, " \\line ")
                             .replaceAll(/\r/g, " \\line ")
                             .replaceAll(/\n/g, " \\line ");
        }

        pStrText = pStrText.replaceAll(`#${mStrColumn}`, mValue || " ");

        if (pStrTabname == 'ctergest') {
            // Substituir variables a l'array dels documents per afegir a les gestions
            mArrDocNameVar = [];

            for (var mVar of mArrDocName) {
                mVar = mVar.replaceAll(`#${mStrColumn}`, mValue || " ");
                mArrDocNameVar.push(mVar);
            }

            mArrDocName = [...mArrDocNameVar];

            // Substituir variables a l'array de les funcions per afegir a les gestions     
            mArrFunNameVar = [];

            // Iterar sobre cada elemento en var_fun_name
            for (var mVar of mArrFunName) {
                mVar = mVar.replaceAll(`#${mStrColumn}`, mValue ?? " ");

                // Agregar el valor modificado al nuevo arreglo
                mArrFunNameVar.push(mVar);
            }

            mArrFunName = [...mArrFunNameVar];

        }
    }    
      

    pStrText = pStrText.replaceAll(/\r\n/g, "\n");

    if (pStrTabname == 'ctergest') {
        // Crea Documents a la gestio i Esborra les lineas de Documents
        mArrsizeDoc = mArrDocName.length;
        mStrColumn = null;


        for (var idx = 0; idx < mArrsizeDoc; idx++) {
            mStrColumn = mArrDocName[idx];

            //  Crea Documents a la gestio
            var mBoolA = false;
            var mBoolE = false;
            var mBoolI = false;
            var mBoolO = false;
            var mBoolU = false;
            var dBoolA = false;
            var dBoolE = false;
            var dBoolO = false;
            var mAV = null;
            var mEV = null;
            var mIV = null;
            var mOV = null;
            var mUV = null;
            var dAV = null;
            var dEV = null;
            var dOV = null;

            var mVarResp = '';

            // Definir los tokens de separación
            mStrTokens = ['\n','â', 'ê', 'î', 'ô', 'û', 'ä', 'ë', 'ö'];
            escapedTokens = mStrTokens.map(token => token.replaceAll(/[.*+?^=!:${}()|\[\]\/\\]/g, "\\$&"));
            regex = new RegExp(`(${escapedTokens.join('|')})`, 'g');
            var mArrAei = mStrColumn.split(regex);
            mArrsizeAei = mArrAei.length - 1;

            for (var idx1 = 0; idx1 <= mArrsizeAei; idx1++) {
                if (mArrAei[idx1] == 'â') {
                    mBoolA = true;
                    continue;
                }
                if (mArrAei[idx1] == 'ê') {
                    mBoolE = true;
                    continue;
                }
                if (mArrAei[idx1] == 'î') {
                    mBoolI = true;
                    continue;
                }
                if (mArrAei[idx1] == 'ô') {
                    mBoolO = true;
                    continue;
                }
                if (mArrAei[idx1] == 'û') {
                    mBoolU = true;
                    continue;
                }
                if (mArrAei[idx1] == 'ä') {
                    dBoolA = true;
                    continue;
                }
                if (mArrAei[idx1] == 'ë') {
                    dBoolE = true;
                    continue;
                }
                if (mArrAei[idx1] == 'ö') {
                    dBoolO = true;
                    continue;
                }
                if (mBoolA) {
                    mAV = mArrAei[idx1]
                }
                if (mBoolE) {
                    mEV = mArrAei[idx1]
                }
                if (mBoolI) {
                    mIV = mArrAei[idx1]
                }
                if (mBoolO) {
                    mOV = mArrAei[idx1]
                }
                if (mBoolU) {
                    mUV = mArrAei[idx1]
                }
                if (dBoolA) {
                    dAV = mArrAei[idx1]
                }
                if (dBoolE) {
                    dEV = mArrAei[idx1]
                }
                if (dBoolO) {
                    dOV = mArrAei[idx1]
                }

                mBoolA = false;
                mBoolE = false;
                mBoolI = false;
                mBoolO = false;
                mBoolU = false;
                dBoolA = false;
                dBoolE = false;
                dBoolO = false;
            }

            // Tractament tipus Objecte
            if (mAV == 'F' || mAV == 'L' || mAV == 'V' || mAV == 'P') {

                // Valors per defecte, segons cada cas
                switch (mAV) {
                    case 'F':
                        mOV = mOV || '-1';
                        mUV = mUV || 'pdf';
                    break;

                    case 'L':
                        mOV = mOV || '-1';
                        mUV = mUV || 'pdf';
                    break;

                    case 'V':
                        mOV = mOV || '-0';
                        mUV = mUV || 'asc';
                    break;

                    case 'P':
                        mOV = mOV || '-0';
                        mUV = mUV || 'asc';
                    break;
                
                    default:
                        mOV = mOV || '-2';
                        mUV = mUV || 'asc';
                    break;
                }

                var mFopForm;
                var vFopForm;

                // Per tal de realitzar procesos, que tenen informacio de retorn
                if (mAV == 'P') {
                    vFopForm =  Ax.db.call(mEV, mIV);

                    // Realitza una passada per si el text porta variables del 
                    // tipus # per tal de poder afegir al cos del email i/o als
                    // documents adjunts                                       

                    vFopForm = Ax.db.call('mut_text_data_var', 
                        vFopForm,
                        pStrTabname,
                        pIntSeqno,
                        pStrTabori
                    );

                    mFopForm = Ax.io.File.createTempFile("fop_form"); 

                    mFopForm.write(vFopForm.trim());
                    
                    mFopForm.close;
                    
                }

                if (mAV == 'F') {
                    mFopForm = Ax.db.call(mEV, mIV)
                }

                if (mAV == 'V' || mAV == 'V') {
                    mFopForm = Ax.db.call(mEV, mIV)
                }

                mAV = mUV.replaceAll('asc','txt');

                /**
                 *  Per tal d identificar la procedencia dels fitxers el nom es formara amb 
                 *  el seqno de la gestio que el genera,                                    
                 *  l'extensio segons el tipus de fitxer demanat amb el parametre û         
                 */

                /**
                 *  Crear noms o alterar els noms per defecte dels documents                  
                 *  Analitza si existeix les clausules ä , ë , ö                              
                 *  ä = <I>nici | <F>inal | Solo <D>efecto | Solo <P>articularizado           
                 *      Indica la posicion que tomara los valores por defecto o si tomara solo
                 *      solo los valores por defecto o solo valores particularizados          
                 *      No es obligatori i el valor per defecte en aquet cas es Solo <D>efecto
                 *  ë = Textes | Camps amb el format # | Barreja texte i Camps amb forma #    
                 *      No es obligatori i agafa per defecte <string></string>                
                 *  ö = Valors per separar les parts del nom del fitxer, per defecte _        
                 *      Tambe caracter per substituir l espai , el punt si cal                
                 *      Si possem == el separador sera cap <string></string>                  
                 */

                dAV = dAV || 'D';
                dEV = dEV || '';
                dOV = dOV || '_';

                if (dOV == '==') {
                    dOV = '';
                }

                var mFileNameDef = `${pIntSeqno}`;
                var mFileName;

                switch (dAV) {
                    case 'I':
                        mFileName = `${mFileNameDef}${dOV}${dEV}`;
                    break;
                        
                    case 'F':
                        mFileName = `${dEV}${dOV}${mFileNameDef}`;
                    break;

                    case 'P':
                        mFileName = `${dEV}`;
                    break;
                
                    default:
                        mFileName = `${mFileNameDef}`;
                    break;
                }

                var mFileName1;

                mFileName1 = mFileName.replaceAll(' ', `${dOV}`);
                mFileName1 = mFileName1.replaceAll('\r\n', '');
                mFileName1 = mFileName1.replaceAll('\n', '');
                mFileName1 = mFileName1.replaceAll('\r', '');
                mFileName1 = mFileName1.replaceAll('\.', `${dOV}`);

                var mObjCtergest = {};
                mObjCtergest.sn_ctergest = Ax.db.executeGet(`
                    <select>
                        <columns>
                            count(*) sn_ctergest
                        </columns>
                        <from table='ctergest_docs' />
                        <where>
                            ctg_seqno   = ? and
                            file_name   = ?  and
                            file_memo   = ?
                        </where>
                    </select>
                `, pIntSeqno, `${mFileName1}.${mUV}`, mStrColumn);

                mUV = mUV.replaceAll('asc', 'txt');

                var mTFopForm;
                var mFFopForm;
                var mArrAeiFo = [];
                var mArrsizeFo;

                // Per a detectar el tipus MIME que correspon i modifica m_u_v asc a txt si cal
                switch (mUV) {
                    case 'txt':
                        mFFopForm = 'text/plain';
                    break;

                    case 'htm':
                        mFFopForm = 'text/html';
                    break;

                    case 'pdf':
                        mFFopForm = 'application/pdf';
                    break;

                    case 'csv':
                        mFFopForm = 'application/vnd.ms-excel';
                    break;

                    case 'xls':
                        mFFopForm = 'application/vnd.ms-excel';
                    break;

                    case 'xlsx':
                        mFFopForm = 'application/vnd.openxmlformats-officedoc';
                    break;

                    case 'dbf':
                        mFFopForm = 'application/octet-stream';
                    break;

                    case 'xml':
                        mFFopForm = 'text/xml';
                    break;

                    case 'rtf':
                        mFFopForm = 'application/msword';
                    break;
                
                    default:
                        mTFopForm = `${mFopForm}`;
                        var tokens = ["/"]; // Definimos los delimitadores
                        var escapedTokens = tokens.map(token => token.replaceAll(/[.*+?^=!:${}()|\[\]\/\\]/g, "\\$&"));
                        regex = new RegExp(`(${escapedTokens.join('|')})`, 'g');

                        mArrAeiFo = mTFopForm.split(regex);
                        mArrsizeFo = mArrAeiFo.length - 1;
                        mFFopForm = mArrAeiFo[mArrsizeFo];

                        mFFopForm = mFopForm.getContentType();
                    break;
                } 

                var mOVf;

                if (mObjCtergest.sn_ctergest == 0) {
                    if (mFopForm.length() != 0) {

                        mOVf = Math.abs(Number(mOV));
                        if (mOVf > 1) {
                            mOVf = mOVf - 2;
                        }

                        var mIns = Ax.db.insert('ctergest_docs', 
                            {
                                seqno     : 0,
                                ctg_seqno : pIntSeqno,
                                file_name : `${mFileName1}.${mUV}`,
                                file_date : new Ax.util.Date(),
                                file_memo : mStrColumn,
                                file_type : mFFopForm,
                                file_size : mFopForm.length(),
                                file_data : mFopForm.readBytes(),
                                device    : Number(mOVf)
                            }
                        );
                    }
                }

                var mObjDocs = Ax.db.executeQuery(`
                    <select>
                        <columns>
                            file_data,ctg_seqno,seqno
                        </columns>
                        <from table='ctergest_docs' />
                        <where>
                            ctg_seqno   = ? and
                            file_name   = ?  and
                            file_memo   = ?
                        </where>
                    </select>  
                `, pIntSeqno, `${mFileName1}.${mUV}`, mStrColumn).toOne();

                mObjCtergest.seqno      = mObjDocs.seqno;
                mObjCtergest.ctg_seqno  = mObjDocs.ctg_seqno;
                mObjCtergest.file_data  = mObjDocs.file_data;

                /**
                 *  Si es te que borrar el fitxer i es del tipus P o V , igualara ctergest_file_data 
                 *  al contingut de m_fop_form, per tal que possi la informacio calculada al cos     
                 *  del email, aixo es per procediments i variables no persistents, que no es        
                 *  passin com fitxers tambe (persistent o no). Seria variable ô igual a -0          
                 */
                if (mOV == '-0' || mOV == '-2') {
                    Ax.db.delete('ctergest_docs', {seqno: mObjCtergest.seqno})
                }


                if (mOV == '0' || mOV == '3' || mOV == '-0' || mOV == '-3') {
					var mBlob = new Ax.sql.Blob(mObjCtergest.file_data);
                    mVarResp = `${mBlob.getText()}`;
                }
            }

            if (mAV == 'D') {
                if (mEV != null) {
                    if (mIV != null) {
                        //  Valors per defecte, segons cada cas
                        switch (mAV) {
                            case 'D':
                                mOV = mOV || '-1';
                            break;
                        
                            default:
                                mOV = mOV || '-2';
                            break;
                        }

                        var mArrMEV = Ax.db.executeQuery(`
                            <select>
                                <columns>
                                    rowid,*
                                </columns>
                                <from table='${mEV}' />
                                <where>
                                    ${mIV}
                                </where>
                            </select>        
                        `).toMemory();
                        
                        var tokens1;
                        var regex1;
                        var mArrAei1 = [];
                        var mArrsize1;
                        var mStrExtensio;

                        for (var mRow of mArrMEV) {
                            tokens1 = ["/"]; // Definimos los delimitadores
                            var escapedTokens = tokens1.map(token => token.replaceAll(/[.*+?^=!:${}()|\[\]\/\\]/g, "\\$&"));
                            regex1 = new RegExp(`(${escapedTokens.join('|')})`, 'g');
                            mArrAei1 = mRow.file_type.split(regex1);
                            mArrsize1 = mArrAei1.length - 1;
                            mStrExtensio = `.${mArrAei1[mArrsize1]}`;

                            /**
                             *  Per tal d identificar la procedencia dels fitxers el nom es formara amb 
                             *  el rowid del registre de la taula que conte el document origen,         
                             *  el seqno de la gestio que el genera,                                    
                             *  el nom del fitxer del registre a la taula que conte el document origen, 
                             *  l'extensio segons el file type del document origen                      
                             */

                            /**
                             *  Crear noms o alterar els noms per defecte dels documents                   
                             *  Analitza si existeix les clausules ä , ë , ö                               
                             *  ä = <I>nici | <F>inal | Solo <D>efecto | Solo <P>articularizado            
                             *      Indica la posicion que tomara los valores por defecto o si tomara solo 
                             *      solo los valores por defecto o solo valores particularizados           
                             *      No es obligatori i el valor per defecte en aquet cas es Solo <D>efecto 
                             *  ë = Textes | Camps amb el format # | Barreja texte i Camps amb forma #     
                             *      No es obligatori i agafa per defecte <string></string>                 
                             *  ö = Valors per separar les parts del nom del fitxer, per defecte _         
                             *      Tambe caracter per substituir l espai , el punt si cal                 
                             *      Si possem == el separador sera cap <string></string>                   
                             */
                            dAV = dAV || 'D';
                            dEV = dEV || '';
                            dOV = dOV || '_';

                            if (dOV == '==') {
                                dOV = '';
                            }

                            mFileName1 = mFileName.replaceAll(' ', `${dOV}`)

                            //  Tractament dels casos que extensions i file_type no coincideixen
                            switch (mStrExtensio) {
                                case '.msword':
                                    mStrExtensio = '.docx';
                                    mFileName1 = mFileName1.replaceAll(mStrExtensio, '');
                                    mStrExtensio = '.rtf';
                                    mFileName1 = mFileName1.replaceAll(mStrExtensio, '');
                                    mStrExtensio = '.doc';
                                    mFileName1 = mFileName1.replaceAll(mStrExtensio, '');
                                break;
                            
                                default:
                                    mFileName1 = mFileName1.replaceAll(mStrExtensio, '');
                                break;
                            } 

                            mFileName1 = mFileName1.replaceAll('\.', `${dOV}`);

                            mFileNameDef = `${mRow.rowid}${dOV}${pIntSeqno}${dOV}${mFileName1}`;

                            switch (dAV) {
                                case 'I':
                                    mFileName = `${mFileNameDef}${dOV}${dEV}`;
                                break;

                                case 'F':
                                    mFileName = `${dEV}${dOV}${mFileNameDef}`;
                                break;

                                case 'P':
                                    mFileName = `${dEV}`;
                                break;
                            
                                default:
                                    mFileName = `${mFileNameDef}`;
                                break;
                            }

                            mFileName1 = mFileName.replaceAll(' ', `${dOV}`);
                            mFileName1 = mFileName1.replaceAll('\n', '');
                            mFileName1 = mFileName1.replaceAll('\r', '');
                            mFileName1 = mFileName1.replaceAll('\.', `${dOV}`);
                            mFileName1 = mFileName1.replaceAll(mStrExtensio, `${dOV}`);

                            mObjCtergest.sn_ctergest = Ax.db.executeGet(`
                                <select>
                                    <columns>
                                        count(*) sn_ctergest
                                    </columns>
                                    <from table='ctergest_docs' />
                                    <where>
                                        ctg_seqno   = ? and
                                        file_name   = ? and
                                        file_memo   = ?
                                    </where>
                                </select>
                            `, pIntSeqno, mFileName1, mStrColumn);

                            if (mObjCtergest.sn_ctergest == 0) {
                                mOVf = Math.abs(Number(mOV));

                                if (mOVf > 1) {
                                    mOVf = mOVf - 2;
                                }
                                
                                /**
                                 *  Realitza una segona passada per si el document porta variables del 
                                 *  tipus # per tal de poder afegir al cos del email i/o als documents 
                                 *  adjunts                                                            
                                 */
                                if (mStrExtensio == '.txt'  || mStrExtensio == '.asc' || mStrExtensio == '.htm'  || 
                                    mStrExtensio == '.html' || mStrExtensio == '.csv' || mStrExtensio == '.rtf'  || 
                                    mStrExtensio == '.doc'  || mStrExtensio == '.docx'){
                                    var mFileOutData = '';
                                    mFileOutData = `${mRow.file_data}`; 
                                    
                                    mFileOutData = Ax.db.call('mut_text_data_var', 
                                        mFileOutData,
                                        pStrTabname,
                                        pIntSeqno,
                                        pStrTabori
                                    );

                                    mRow.file_data = Ax.io.File.createTempFile("fop_form"); 
                                    mRow.file_data.write(mFileOutData.trim());
                                    mRow.file_data.close;

                                    mRow.file_size = mRow.file_data.length;
                                } 

                                Ax.db.insert('ctergest_docs', 
                                    {
                                        seqno: 0,
                                        ctg_seqno: pIntSeqno,
                                        file_name: mFileName1,
                                        file_date: new Ax.util.Date(),
                                        file_memo: mStrColumn,
                                        file_type: mRow.file_type,
                                        file_size: mRow.file_size,
                                        file_data: mRow.file_data,
                                        device: Number(mOVf),
                                        coment: mRow.coment
                                    }
                                )
                                
                            }

                            var mObjDocs1 = Ax.db.executeQuery(`
                                <select>
                                    <columns>
                                        file_data,ctg_seqno,seqno
                                    </columns>
                                    <from table='ctergest_docs' />
                                    <where>
                                        ctg_seqno   = ? and
                                        file_name   = ? and
                                        file_memo   = ?
                                    </where>
                                </select>
                            `, pIntSeqno, mFileName1, mStrColumn).toOne();

                            mObjCtergest.file_data = mObjDocs1.file_data;
                            mObjCtergest.ctg_seqno = mObjDocs1.ctg_seqno;
                            mObjCtergest.seqno = mObjDocs1.seqno;

                            if (mOV == '-0' || mOV == '-2') {
                                Ax.db.delete('ctergest_docs', {seqno: mObjCtergest.seqno})
                            }

                            if (mOV == '0' || mOV == '3' || mOV == '-0' || mOV == '-3') {
								var mBlob = new Ax.sql.Blob(mObjCtergest.file_data);
                    			mVarResp = `${mBlob.getText()}`;
                            }
                        }
                    }
                }
            }

            pStrText = pStrText.replaceAll(`^${mStrColumn}`,`${mVarResp}`)

        }

        //  Esborra les lineas de Funcions
        mArrsize = mArrFunName.length - 1;

        mStrColumn = null;

        for (var idx = 0; idx < mArrsize; idx++) {
            mStrColumn = mArrFunName[idx];

            pStrText = pStrText.replaceAll('¨', mStrColumn);           
        }
    }

    return pStrText;
}