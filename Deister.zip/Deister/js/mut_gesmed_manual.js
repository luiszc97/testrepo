//Resultat de la generació manual de factures de GESMED.
function mut_gesmed_manual(pIntSeqno){
    let mDateToday = new Ax.sql.Date().format('yyyyMMdd');
    let mStrFilename = `/erpsync/mut_gesmed_manual_${mDateToday}.pdf`;
    let mStrMailFrom = 'noreply@mutuaterrassa.cat';
    let mStrMailto   = Ax.ext.user.getMail();
    let mStrSubject  = '>Traspàs Manual de Factures GESMED';

    let mStrCodobj   = 'mut_gesmed_gvenfac_mail';
    let mStrTtipefe  = 'TR';
    let mIntCount    = 0;
    let mStrFrmpag   = '085';
    let mStrCond     = `gvenfach.tipdoc MATCHES 'N?VH' AND gvenfach.delega MATCHES '*VENT' AND gvenfach.docser MATCHES '*/22' AND gvenfach.empcode IN ('21') AND gvenfach.estcab!='C' AND gvenfach.fecha BETWEEN DATE(CURRENT)-3 AND DATE(CURRENT)`;

    try {
        Ax.db.beginWork();

        //INCORPORACIÓ DE FITXERS
        Ax.db.call('mut_gesmed_import');

        //GENERACIÓ DE FACTURES
        Ax.db.call('mut_gesmed_gvenfac', mStrTtipefe, mStrFrmpag);

        //TANQUEM PROCESSOS PENDENTS
        let mObjClogproh = Ax.db.executeQeury(`
            <select>
                <columns>
                    FIRST 1 log_id, log_procname, log_user, log_date_ini
                </columns>
                <from table='clogproh'>
                </from>
                <where>
                        log_procname = 'gvenfach_contabn'
                    AND log_date_end IS NULL
                </where>
            </select>
        `).toOne();

        if (mObjClogproh.log_id != 0) {
            Ax.db.update('',
                {
                    'log_date_end': new Ax.sql.Date()
                },
                {
                    'log_id': mObjClogproh.log_id
                }
           )
        }

        //COMPTABILITZACIÓ DE FACTURES (INCLOURE'L EN L'SCRIPT mut_gesmed_gvenfac)
        let clogproh_log_id = Ax.db.call('gvenfach_contabn', mStrCond, new Ax.sql.Date());

        //COMPTADOR DE INCIDÈNCIES
        mIntCount = Ax.db.call('mut_gesmed_gvenfac_mail_count');

        if (mIntCount > 0) {
            let mMail = new Ax.mail.MailerMessage();
            mMail.from(mStrMailFrom);
            mMail.to(mStrMailto);
            mMail.subject(mStrSubject);
            mMail.setText("Correu electrònic amb fitxer adjunt enviat des de WebStudio.");

            let mOut = Ax.ext.webapp.fopForm(mStrCodobj ,options => {
                options.setType('pdf');                                                        
                //options.setCond('condicionSQL');
                options.setDatabase(Ax.ext.db.getDatabase());
            }); 

            mMail.addAttachment(mOut.getBytes());

            //Se hace el envío del email
            let mMailer = new Ax.mail.Mailer();
            mMailer.setSMTPServer("localhost", 25);
            mMailer.send(mMail);      
        }

        Ax.db.commitWork();

    } catch (error) {
        Ax.db.rollbackWork();

        Ax.db.beginWork();

        Ax.db.update("mut_gesmed_file",
            {
                "estat": 5,
                "errmsg": Ax.util.Error.getMessage(error)
            },
            {
                "seqno" : pIntSeqno
            }
        ) 

        Ax.db.commitWork();
    }


}