function mut_gesmed_auto(){

    let mDateToday = new Ax.sql.Date().format('yyyyMMdd');
    let mStrFilename = `/erpsync/mut_gesmed_auto_${mDateToday}.pdf`;

    let mStrMailfrom, mStrMailto, mStrMailcc, mStrMailbcc;
    let mObjtList = Ax.db.call('mut_sys_mail_select','mut_gesmed_auto','general');
    mStrMailfrom = mObjtList.mai_from;
    mStrMailto   = mObjtList.mai_to; 
    mStrMailcc   = mObjtList.mai_cc;  
    mStrMailbcc  = mObjtList.mai_bcc; 

    let mStrSubject = 'Traspàs automàtic de Factures GESMED';
    let mStrCodobj = 'mut_gesmed_gvenfac_mail';
    let mStrTipefe = 'TR';
    let mIntCount  = 0;
    let mStrFrmpag = '085';
    let mStrCond   = `gvenfach.tipdoc MATCHES 'N?VH' AND gvenfach.delega MATCHES '*VENT' AND gvenfach.docser MATCHES '*/22' AND gvenfach.empcode IN ('21') AND gvenfach.estcab!='C' AND gvenfach.fecha BETWEEN DATE(CURRENT)-3 AND DATE(CURRENT)`;

    try {
        //INCORPORACIÓ DE FITXERS
        Ax.db.call('mut_gesmed_import')

        //GENERACIÓ DE FACTURES
        Ax.db.call('mut_gesmed_import', mStrTipefe, mStrFrmpag)

        //TANQUEM PROCESSOS PENDENTS
        let mObjtClogproh = Ax.db.executeQuery(`
            <select>
                <columns>
                    FIRST 1 log_id, log_procname, log_user, log_date_ini
                </columns>
                <from table='clogproh'>
                </from>
                <where>
                        log_procname = 'gvenfach_contabn'
                    AND log_date_end IS NULL
                </where>
            </select>
        `).toOne();

        if (mObjtClogproh.log_id != 0) {
            Ax.db.update('clogproh',
                {
                    'log_date_end': new Ax.sql.Date()
                },
                {
                    'log_id': mObjtClogproh.log_id
                }
            )
        }

        // COMPTABILITZACIÓ DE FACTURES (INCLOURE'L EN L'SCRIPT mut_gesmed_gvenfac)
        let clogproh_log_id = Ax.db.call('gvenfach_contabn', mStrCond, new Ax.sql.Date());

        //COMPTADOR DE INCIDÈNCIES
        mIntCount = Ax.db.call('mut_gesmed_gvenfac_mail_count');

        if (mIntCount > 0) {
            let mMail = new Ax.mail.MailerMessage();
            mMail.from(mStrMailfrom);
            mMail.to(mStrMailto);
            mMail.cc(mStrMailcc)
            mMail.bcc(mStrMailbcc)
            mMail.subject(mStrSubject);
            mMail.setText("Correu electrònic amb fitxer adjunt enviat des de WebStudio.");

            let mOut = Ax.ext.webapp.fopForm(mStrCodobj ,options => {
                options.setType('pdf');                                                        
                //options.setCond('condicionSQL');
                options.setDatabase(Ax.ext.db.getDatabase());
            }); 

            mMail.addAttachment(mOut.getBytes());

            //Se hace el envío del email
            let mMailer = new Ax.mail.Mailer();
            mMailer.setSMTPServer("localhost", 25);
            mMailer.send(mMail);      

        }
        
    } catch (error) {
        let mMail = new Ax.mail.MailerMessage();
        mMail.from(mStrMailfrom);
        mMail.to(mStrMailto);
        mMail.cc(mStrMailcc)
        mMail.bcc(mStrMailbcc)
        mMail.subject(mStrSubject);     
        mMail.setText(Ax.util.Error.getMessage(error)); 

        //Se hace el envío del email
        let mMailer = new Ax.mail.Mailer();
        mMailer.setSMTPServer("localhost", 25);
        mMailer.send(mMail);   
        
    }

}