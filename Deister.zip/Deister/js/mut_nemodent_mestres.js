// Cargar tablas maestras de la facturación del hospital                      -->
// LLAMADAS DESDE: OBJ:   mut_nemodent_traspas                                 -->
function mut_nemodent_mestres(pStrTipefe, pStrFrmpag) {
    //ACTUALITZEM MESTRE D'ARTICLES
    let mArrMutNemodentGvenfac = Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT t.concepte codart, 
                t.concepte_des nomart, 
                garticul.codigo codart2, 
                t.tipiva
            </columns>
            <from table='mut_nemodent_gvenfac' alias='t'>
                <join type='left' table='garticul'>
                    <on>t.concepte = garticul.codigo</on>
                </join>
            </from>
            <where>
                errno=100
            </where>
        </select>
    `);

    
    for (let mRow of mArrMutNemodentGvenfac) {
        let mStrCimart;

        if (mRow.codart2 == null) {
            //Transformem el Tipus d'IVA.
            switch (mRow.tipiva) {
                case 1:
                    mStrCimart = 'BSR'
                    break;

                case 2:
                    mStrCimart = 'BRE'
                    break;

                case 3:
                    mStrCimart = 'BOR'
                    break;

                case 4:
                    mStrCimart = 'BEX'
                    break;

                case 0:
                    mStrCimart = 'BEX'
                    break;
            
                default:
                    break;
            }

            //INSERTEM L'ARTICLE
            Ax.db.insert('garticul', 
                {
                    'artid' : 0,
                    'codigo': mRow.codart,
                    'nomart': mRow.nomart,
                    'cimart': mStrCimart,
                    'estado': 'A',
                    'udmbas': 'UNI',
                    'desvar': 'V',
                    'lotes' : 'N',
                    'stock' : 'N',
                    'codfam': 'FVEN',
                    'codtip': 'VEN',
                    'sermin': 0,
                    'sermax': 0,
                    'fecalt': new Ax.sql.Date(),
                    'user_created': Ax.db.getUser(),
                    'user_updated': Ax.db.getUser()
                }
            )

        } else {
            //ACTUALITZEM DADES DE L'ARTICLE
            Ax.db.update('garticul', 
                {
                    'nomart': mRow.nomart,
                    'codfam': 'FVEN',
                    'user_updated': Ax.db.getUser()
                }, 
                {
                    'codigo': mRow.codart
                }
            )
        }
    }

}