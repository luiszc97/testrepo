function mutPlanconePrpeProcess(pIntFileSeqno) {
    let mObjPlanconePrpe = Ax.db.executeQuery(`
        <select>
            <columns>cabid, concep, estado, file_data, file_size, file_type</columns>
            <from table='mut_plancone_prpe' />
            <where>
                file_seqno = ?
            </where>
        </select>    
    `, pIntFileSeqno).toOne();

    if (mObjPlanconePrpe.estado == 'P') {
        throw new Ax.lang.Exception(`Fitxer [${pIntFileSeqno}] ja processat.`);
    }

    if (!(mObjPlanconePrpe.file_type == 'application/vnd.ms-excel' || 
        mObjPlanconePrpe.file_type == 'text/csv')) {
        Ax.db.update('mut_plancone_prpe', 
            {
                'estado': 'E',
                'errmsg': 'Format de fitxer incorrecte.'
            }, 
            {
                'file_seqno': pIntFileSeqno
            }
        )
    }

    let wb = Ax.ms.Excel.load(mObjPlanconePrpe.file_data);

    mObjPlanconePrpe.sheets = wb.getNumberOfSheets();
    let mArrHoja =  wb.getSheet(0);

    //Comprovacions prèvies.
    let mIntNumlin = 0;
    let mIntLincom = 0;

    let mDecImport;

    for (let item of mArrHoja) {
        mIntNumlin = mIntNumlin + 1;
        let mArrLine = item.split(';');
        
        if (!mArrLine.length) {
            continue;
        }

        mIntLincom = mIntLincom + 1;

        if (mArrLine != 3) {
            Ax.db.update('mut_plancone_prpe', 
                {
                    'estado': 'E',
                    'errmsg': `Línia ${mIntNumlin}: No conté 3 columnes.`
                }, 
                {
                    'file_seqno': pIntFileSeqno
                }
            )

            return;
        }

        let mStrSeccio = mArrLine[0];

        let mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='cseccion' />
                <where>
                    codigo = ?
                </where>
            </select>    
        `, mStrSeccio);

        if (!mIntCount) {
            Ax.db.update('mut_plancone_prpe', 
                {
                    'estado': 'E',
                    'errmsg': `Línia ${mIntNumlin}: Secció [${mStrSeccio}] inexistent.`
                }, 
                {
                    'file_seqno': pIntFileSeqno
                }
            );

            return;
        }

        let mStrCencos = mArrLine[1];

        mIntCount = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*)</columns>
                <from table='ccosdesc' />
                <where>
                    codigo = ?
                </where>
            </select>    
        `, mStrCencos);

        if (!mIntCount) {
            Ax.db.update('mut_plancone_prpe', 
                {
                    'estado': 'E',
                    'errmsg': `Línia ${mIntNumlin}: Centre de Cost [${mStrSeccio}] inexistent.`
                }, 
                {
                    'file_seqno': pIntFileSeqno
                }
            );

            return;
        }

        try {
            let mStrVa1 = mArrLine[2].replace(".", "");
            let mStrVa2 = mStrVa1.replace(",", ".");
            mDecImport = Number(mStrVa2.replace(" ", ""));

        } catch (error) {
            Ax.db.update('mut_plancone_prpe', 
                {
                    'estado': 'E',
                    'errmsg': `Línia ${mIntNumlin}: Format d'import incorrecte.`
                }, 
                {
                    'file_seqno': pIntFileSeqno
                }
            );

            return;

        }
        

    }

    if (mObjPlanconePrpe.file_size == 0 || mIntLincom == 0) {
        Ax.db.update('mut_plancone_prpe',
            {
                'estado': 'E',
                'errmsg': 'Fiter buit.'
            },
            {
                'file_seqno': pIntFileSeqno
            }
        )
    }

    //Actualització/Inserció de registres.
    Ax.db.beginWork();
    mIntNumlin = 0;

    for (let item of mArrHoja) {
        mIntNumlin = mIntNumlin + 1;
        let mArrLine = item.split(';');

        if (!mArrLine.length) {
            continue;
        }

        let mStrSeccio = mArrLine[0];
        let mStrCencos = mArrLine[1];

        let mStrVa1 = mArrLine[2].replace(".", "");
        let mStrVa2 = mStrVa1.replace(",", ".");
        mDecImport = Number(mStrVa2.replace(" ", ""));

        mDecImport = mDecImport.toFixed(2);

        let mIntNumreg = Ax.db.executeGet(`
            <select>
                <columns>COUNT(*) numreg</columns>
                <from table='mut_planconl_prpe' />
                <where>
                    cabid  = ? AND
                    seccio = ? AND
                    cencos = ?
                </where>
            </select>
        `, mObjPlanconePrpe.cabid, mStrSeccio, mStrCencos);

        if (mIntNumreg) {
            Ax.db.execute(`
                UPDATE mut_planconl_prpe
                SET ${mObjPlanconePrpe.concep} = ${mDecImport},
                    user_updated = '${Ax.db.getUser()}',
                    date_updated = ${new Ax.sql.Date()}
                WHERE cabid = ?
                AND seccio = ? 
                AND cencos = ? 
            `, mObjPlanconePrpe.cabid, mStrSeccio, mStrCencos);

        } else {
            Ax.db.execute(`
                INSERT INTO mut_honoraris_xlsval_his 
                (linid, cabid, seccio, cencos, ${mObjPlanconePrpe.concep}, user_created, date_created, user_updated, date_updated)
                VALUES (0, ${mObjPlanconePrpe.cabid}, ?, ?, ${mDecImport}, 
                '${Ax.db.getUser()}', ${new Ax.sql.Date()},
                '${Ax.db.getUser()}', ${new Ax.sql.Date()});
            `, mStrSeccio, mStrCencos)
        }

    }

    Ax.db.update('mut_plancone_prpe', 
        {
            'estado': 'P',
            'errmsg': null
        }, 
        {
            'file_seqno': pIntFileSeqno
        }
    )

    Ax.db.commitWork();

}