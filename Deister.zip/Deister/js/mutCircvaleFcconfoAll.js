function mutCircvaleFcconfoAll() {
    let mArrCircvale = Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT gcomfach.cabid
            </columns>
            <from table='mut_circvale'>
                <join table='mut_gcomfach_s' alias='gcomfach'>
                    <on>gcomfach.cabid = mut_circvale.cabid</on>
                </join>
            </from>
            <where>
                DATE(mut_circvale.date_created) &gt;= '01-12-2021' AND
                mut_circvale.tabname = 'gcomfach' AND
                mut_circvale.estado  = 'V' AND
                EXISTS (SELECT capuntes.loteid
                        FROM capuntes
                        WHERE capuntes.loteid IN (SELECT cenllote.loteid
                                                    FROM cenllote, cenlsubs
                                                    WHERE cenllote.loteid = cenlsubs.loteid
                                                    AND cenllote.tabname = 'gcomfach'
                                                    AND cenllote.modcon = 1
                                                    AND cenlsubs.procid = gcomfach.cabid)
                        AND EXISTS (SELECT cefectos.apteid
                                        FROM cefectos
                                        WHERE capuntes.apteid = cefectos.apteid
                                        AND cefectos.estado = 'PC')) AND
                mut_circvale.indcom = 0
            </where>
        </select>    
    `);

    for (let mRow of mArrCircvale) {
        let mArrCefectos = Ax.db.executeQuery(`
            <select>
                <columns>
                    cefectos.numero, cefectos.empcode, cefectos.moneda,
                    cefectos.tipefe, cefectos.fecven,  cremesas.fecrem,
                    cefectos.clase,  cefectos.impdiv,  cefectos.estado,
                    cefectos.import, cefectos.remesa,  cefectos.fecaux,
                    cefectos.ctafin, cefectos.codper,  cefectos.numban,
                    cefectos.refban, cefectos.cambio,  cefectos.tipdoc,
                    cefectos.coment
                </columns>
                <from table='cefectos'>
                    <join type='left' table='cremesas'>
                        <on>cefectos.remesa = cremesas.numrem</on>
                    </join>
                </from>
                <where>
                    cefectos.estado = 'PC' AND
                    cefectos.apteid IN (SELECT capuntes.apteid
                                        FROM capuntes
                                        WHERE capuntes.loteid IN (SELECT cenllote.loteid
                                                                    FROM cenllote, cenlsubs
                                                                    WHERE cenllote.loteid = cenlsubs.loteid
                                                                    AND cenllote.tabname = 'gcomfach'
                                                                    AND cenllote.modcon = 1
                                                                    AND cenlsubs.procid = ?))
                </where>
            </select>
        `, mRow.cabid);

        for (let mItem of mArrCefectos) {
            let mObjCefeacti = Ax.db.executeQuery(`
                <select>
                    <columns>
                        cefeacti.clase  clase_ac,
                        cefeacti.codigo,
                        cefeacti.nomact,
                        cefeacti.fecven fecven_ac,
                        cefeacti.tipefe tipefe_ac,
                        cefeacti.ctafin ctafin_ac,
                        cefeacti.domban,
                        cefeacti.tipdoc tipdoc_ac,
                        cefeacti.import import_ac,
                        cefeacti.gastos gastos_ac,
                        cefeacti.difcam difcam_ac,
                        cefeacti.coment coment_ac,
                        <nvl>cefeacti.efefin, '${mItem.tipefe}'</nvl> tipefe,
                        cefeplah.feccon feccon_ac,
                        CASE WHEN cefeplah.feccon = 'V' THEN ${mItem.fecven}
                            WHEN cefeplah.feccon = 'R' THEN ${mItem.fecrem}
                            ELSE TODAY
                        END feccon,
                        CASE WHEN cefeacti.clase = '${mItem.clase}' THEN ${mItem.impdiv}
                            ELSE ${mItem.impdiv} * -1.0
                        END impdiv_sigeco
                    </columns>
                    <from table='cefeacti'>
                        <join table='cefeacti_est'>
                            <on>cefeacti.clase = cefeacti_est.clase</on>
                            <on>cefeacti.codigo = cefeacti_est.codigo</on>
                        </join>
                        <join type='left' table='cefeplah'>
                            <on>cefeacti.clase = cefeplah.clase</on>
                            <on>cefeacti.codast = cefeplah.codigo</on>
                        </join>
                    </from>
                    <where>
                        cefeacti.clase  = '${mItem.clase}' AND
                        cefeacti.codigo = 'CFRA'
                    </where>
                    <order>
                        1, 2
                    </order>
                </select>
            `).toOne();

            Ax.db.call('cefectos_estado_ava',
                mItem.numero,
                mItem.empcode,
                mItem.moneda,
                mItem.clase,
                mObjCefeacti.clase_ac,
                mObjCefeacti.codigo,
                mObjCefeacti.feccon,
                mItem.fecven,
                mItem.fecaux,
                mObjCefeacti.tipefe,
                mItem.ctafin,
                mItem.codper,
                mItem.numban,
                mItem.refban,
                mItem.tipdoc,
                mItem.coment,
                mItem.cambio,
                mObjCefeacti.impdiv_sigeco,
                null,
                null,
                null
            )
        }
    }
}