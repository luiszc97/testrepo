function mutInmAnnexhGetCursor(
    pIntEjerci, 
    pIntPerini, 
    pIntPerfin, 
    pStrEmpcode,
    pStrAnnCode
) {
    let mStrPlacon = 'ES';

    if (pStrEmpcode == '13') {
        mStrPlacon = pStrEmpcode;
    }

    return Ax.db.executeQuery(`
        <select>
            <columns>
                DISTINCT mut_inm_annexh.ann_code,
                mut_inm_annexh.ann_title,
                ${pIntEjerci}  ejerci,
                ${pIntPerini}  perini,
                ${pIntPerfin}  perfin,
                mut_inm_annexe.ann_empcode empcode,
                cempresa.empname,
                mut_inm_annexh.flg_initial,
                mut_inm_annexh.flg_in,
                mut_inm_annexh.flg_gain,
                mut_inm_annexh.flg_out,
                mut_inm_annexh.flg_rescue,
                mut_inm_annexh.flg_adjust,
                mut_inm_annexh.flg_transfer,
                mut_inm_annexh.flg_implicit,
                mut_inm_annexh.flg_final
            </columns>
            <from table='mut_inm_annexh'>
                <join table='mut_inm_annexl'>
                    <on>mut_inm_annexh.ann_code = mut_inm_annexl.ann_code</on>
                    <join table='mut_inm_annexc'>
                        <on>mut_inm_annexl.ele_id = mut_inm_annexc.ele_id</on>
                        <join type='left' table='csaldos'>
                            <on>csaldos.placon = <m_placon /></on>
                            <on>mut_inm_annexc.acc_code = csaldos.cuenta</on>
                        </join>
                    </join>
                </join>
                <join table='mut_inm_annexe'>
                    <on>mut_inm_annexh.ann_code = mut_inm_annexe.ann_code</on>
                    <on>mut_inm_annexe.ann_empcode = '${pStrEmpcode}'</on>
                    <join type='left' table='cempresa'>
                        <on>mut_inm_annexe.ann_empcode = cempresa.empcode</on>
                    </join>
                </join>
            </from>
            <where>
                csaldos.ejerci = ${pIntEjerci} AND
                csaldos.period BETWEEN 0 AND ${pIntPerfin} AND
                csaldos.empcode = '${pStrEmpcode}' AND
                mut_inm_annexh.ann_code ${pStrAnnCode}
            </where>
        </select>
    `);
}