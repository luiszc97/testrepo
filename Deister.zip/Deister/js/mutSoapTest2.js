function mutSoapTest2(pStrCodfam) {
    return Ax.db.executeQuery(`
        <select>
            <columns>
                codigo, nomart, tipcon, estado, errnum, wkfnum, codfam, codtip, fecalt, fecbaj
            </columns> 
            <from table='garticul' />
            <where>
                garticul.codfam = ?
            </where>
        </select>
    `, pStrCodfam)
}