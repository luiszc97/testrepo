function mutInmAnnexhGetTotals(
    pIntEjerci,  
    pIntPerini,  
    pIntPerfin,  
    pStrAnnCode
) {
    Ax.db.execute(`DROP TABLE IF EXISTS @tmp_output`);

    Ax.db.execute(`  
        <select intotemp='@tmp_output'>
            <columns>
                empcode,
                empname,
                0::DECIMAL(14,2) vncant,
                0::DECIMAL(14,2) vncact,
                0::DECIMAL(14,2) impalt,
                0::DECIMAL(14,2) impamo
            </columns>
            <from table='cempresa' />
            <where>
                empcode MATCHES '??'
            </where>
            <order>1</order>
        </select>
    `);

    let mArrTmp = Ax.db.executeQuery(`
        <select>
            <columns>empcode, empname</columns>
            <from table='@tmp_output' />
            <order>1</order>
        </select>
    `);

    for (let mRow of mArrTmp) {
        let mStrPlacon = 'ES';

        if (mRow.empcode == '13') {
            mStrPlacon = mRow.empcode;
        }

        Ax.db.execute(`DROP TABLE IF EXISTS @tmp_input`);

        Ax.db.execute(`  
            <select intotemp='@tmp_input'>
                <columns>
                    mut_inm_annexh.ann_code,
                    mut_inm_annexh.ann_title,
                    mut_inm_annexl.ele_position,
                    mut_inm_annexl.ele_concept,
                    mut_inm_annexl.ele_chapter,
                    mut_inm_annexl.ele_name,
                (SELECT SUM(a.debe-a.haber)
                    FROM mut_inm_annexh h, mut_inm_annexl l, mut_inm_annexc c, capuntes a
                    WHERE h.ann_code = l.ann_code
                    AND l.ele_id = c.ele_id
                    AND a.placon = '${mStrPlacon}'
                    AND c.acc_gain = a.cuenta
                    AND mut_inm_annexh.ann_code = h.ann_code
                    AND mut_inm_annexl.ele_position = l.ele_position
                    AND csaldos.empcode = a.empcode
                    AND YEAR(a.fecha) = ${pIntEjerci}
                    AND MONTH(a.fecha) BETWEEN 0 AND ${pIntPerfin}
                    AND h.flg_gain = 1
                    AND c.acc_gain IS NOT NULL) <alias name='gain' />,
                    SUM(CASE WHEN csaldos.period = 0
                            THEN csaldos.debe - csaldos.haber
                            ELSE 0
                        END) <alias name='salape' />,
                    SUM(CASE WHEN csaldos.period BETWEEN 0 AND (CASE WHEN ${pIntPerini} = 0
                                                                    THEN 0
                                                                    ELSE ${pIntPerini} - 1
                                                                END)
                            THEN csaldos.debe - csaldos.haber
                            ELSE 0
                        END) <alias name='salant' />,
                    SUM(CASE WHEN csaldos.period BETWEEN ${pIntPerini} AND ${pIntPerfin}
                            THEN CASE WHEN mut_inm_annexc.acc_invert = 0
                                    THEN csaldos.debe
                                    ELSE -csaldos.haber
                                END
                            ELSE 0
                        END) <alias name='perdeb' />,
                    SUM(CASE WHEN csaldos.period BETWEEN ${pIntPerini} AND ${pIntPerfin}
                            THEN CASE WHEN mut_inm_annexc.acc_invert = 0
                                    THEN -csaldos.haber
                                    ELSE csaldos.debe
                                END
                            ELSE 0
                        END) <alias name='perhab' />,
                    0::DECIMAL(14,2) transf,
                    0::DECIMAL(14,2) adjust,
                    0::DECIMAL(14,2) implicit,
                    SUM(csaldos.debe - csaldos.haber) <alias name='saldo' />
                </columns>
                <from table='mut_inm_annexh'>
                    <join table='mut_inm_annexl'>
                        <on>mut_inm_annexh.ann_code = mut_inm_annexl.ann_code</on>
                        <join table='mut_inm_annexc'>
                            <on>mut_inm_annexl.ele_id = mut_inm_annexc.ele_id</on>
                            <join type='left' table='csaldos'>
                                <on>csaldos.placon = '${mStrPlacon}'</on>
                                <on>mut_inm_annexc.acc_code = csaldos.cuenta</on>
                            </join>
                        </join>
                    </join>
                    <join table='mut_inm_annexe'>
                        <on>mut_inm_annexh.ann_code = mut_inm_annexe.ann_code</on>
                        <on>mut_inm_annexe.ann_empcode = '${mRow.empcode}'</on>
                    </join>
                </from>
                <where>
                    mut_inm_annexh.ann_code = '${pStrAnnCode}' AND
                    csaldos.ejerci = ${pIntEjerci} AND
                    csaldos.period BETWEEN 0 AND ${pIntPerfin} AND
                    csaldos.empcode = '${mRow.empcode}'
                </where>
                <group>1,2,3,4,5,6,7</group>
                <order>1,3</order>
            </select>
        `);

        let mArrTmpInput = Ax.db.executeQuery(`
            <select>
                <columns>*</columns>
                <from table='@tmp_input' />
                <where>
                    ele_concept IN ('Cost','Valor Net','Instruments','Préstecs')
                </where>
                <order>1,3</order>
            </select>
        `);

        for (let idx of mArrTmpInput) {
            idx.transf = Ax.db.executeGet(`
                <select>
                    <columns>SUM(capuntes.debe-capuntes.haber) transf</columns>
                    <from table='mut_inm_annexh'>
                        <join table='mut_inm_annexl'>
                            <on>mut_inm_annexh.ann_code = mut_inm_annexl.ann_code</on>
                            <join table='mut_inm_annexc'>
                                <on>mut_inm_annexl.ele_id = mut_inm_annexc.ele_id</on>
                                <join table='capuntes'>
                                    <on>capuntes.placon = '${mStrPlacon}'</on>
                                    <on>mut_inm_annexc.acc_code = capuntes.cuenta</on>
                                </join>
                            </join>
                        </join>
                    </from>
                    <where>
                        mut_inm_annexh.ann_code = ? AND
                        mut_inm_annexl.ele_position = ? AND
                        capuntes.empcode = '${mRow.empcode}' AND
                        YEAR(capuntes.fecha) = ${pIntEjerci} AND
                        MONTH(capuntes.fecha) BETWEEN ${pIntPerini} AND ${pIntPerfin} AND
                        capuntes.jusser <matches>'??TRAS*'</matches>
                    </where>
                </select>
            `, idx.ann_code, idx.ele_position);

            idx.adjust = Ax.db.executeGet(`
                <select>
                    <columns>SUM(capuntes.debe-capuntes.haber) adjust</columns>
                    <from table='mut_inm_annexh'>
                        <join table='mut_inm_annexl'>
                            <on>mut_inm_annexh.ann_code = mut_inm_annexl.ann_code</on>
                            <join table='mut_inm_annexc'>
                                <on>mut_inm_annexl.ele_id = mut_inm_annexc.ele_id</on>
                                <join table='capuntes'>
                                    <on>capuntes.placon = '${mStrPlacon}'</on>
                                    <on>mut_inm_annexc.acc_code = capuntes.cuenta</on>
                                </join>
                            </join>
                        </join>
                    </from>
                    <where>
                        mut_inm_annexh.ann_code = ? AND
                        mut_inm_annexl.ele_position = ? AND
                        capuntes.empcode = '${mRow.empcode}' AND
                        YEAR(capuntes.fecha) = ${pIntEjerci} AND
                        MONTH(capuntes.fecha) BETWEEN ${pIntPerini} AND ${pIntPerfin} AND
                        capuntes.jusser <matches>'??ACVA*'</matches>
                    </where>
                </select>
            `, idx.ann_code, idx.ele_position);

            idx.implicit = Ax.db.executeGet(`
                <select>
                    <columns>SUM(capuntes.debe-capuntes.haber) implicit</columns>
                    <from table='mut_inm_annexh'>
                        <join table='mut_inm_annexl'>
                            <on>mut_inm_annexh.ann_code = mut_inm_annexl.ann_code</on>
                            <join table='mut_inm_annexc'>
                                <on>mut_inm_annexl.ele_id = mut_inm_annexc.ele_id</on>
                                <join table='capuntes'>
                                    <on>capuntes.placon = '${mStrPlacon}'</on>
                                    <on>mut_inm_annexc.acc_code = capuntes.cuenta</on>
                                </join>
                            </join>
                        </join>
                    </from>
                    <where>
                        mut_inm_annexh.ann_code = ? AND
                        mut_inm_annexl.ele_position = ? AND
                        capuntes.empcode = '${mRow.empcode}' AND
                        YEAR(capuntes.fecha) = ${pIntEjerci} AND
                        MONTH(capuntes.fecha) BETWEEN ${pIntPerini} AND ${pIntPerfin} AND
                        capuntes.jusser <matches>'??IMPL*'</matches>
                    </where>
                </select>
            `, idx.ann_code, idx.ele_position);

            if (idx.transf > 0) {
                Ax.db.update('@tmp_input', 
                    {
                        'perdeb': idx.perdeb - idx.transf,
                        'transf': idx.transf
                    }, 
                    {
                        'ann_code': idx.ann_code,
                        'ele_position': idx.ele_position
                    }
                )
            }

            if (idx.transf < 0) {
                Ax.db.update('@tmp_input', 
                    {
                        'perhab': idx.perhab - idx.transf,
                        'transf': idx.transf
                    }, 
                    {
                        'ann_code': idx.ann_code,
                        'ele_position': idx.ele_position
                    }
                )
            }

        }

        let mObjInput = Ax.db.executeQuery(`
            <select>
                <columns>SUM(salape) vncant, SUM(saldo) vncact</columns>
                <from table='@tmp_input' />
                <where>
                    ele_concept = 'Valor Net'
                </where>
            </select>
        `).toOne();

        let mDecImpalt = Ax.db.executeGet(`
            <select>
                <columns>SUM(perdeb) impalt</columns>
                <from table='@tmp_input' />
                <where>
                    ele_concept = 'Cost'
                </where>
            </select>
        `)

        let mDecImpamo = Ax.db.executeGet(`
            <select>
                <columns>-SUM(perdeb) impamo</columns>
                <from table='@tmp_input' />
                <where>
                    ele_concept = 'Amortització Acumulada'
                </where>
            </select>
        `)

        Ax.db.update('@tmp_output', 
            {
                'vncant': mObjInput.vncant || 0,
                'vncact': mObjInput.vncact || 0,
                'impalt': mDecImpalt || 0,
                'impamo': mDecImpamo || 0
            }, 
            {
                'empcode': mRow.empcode
            }
        )

    }

    Ax.db.execute(`
        DELETE FROM @tmp_output
        WHERE vncant + vncact + impalt + impamo = 0
    `);

    return Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='@tmp_output' />
            <order>empname</order>
        </select>
    `);

}