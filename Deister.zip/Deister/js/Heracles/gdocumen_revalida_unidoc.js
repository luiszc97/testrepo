// =========================================================================== 
//                                                                             
//    XSQL: gdocumen_revalida_unidoc (Antes se llamaba iges_doc_valdocum)      
//                                                                             
//    Llamado desde los objetos:                                               
//                                                                             
//                                                                             
//    gvenalbh  - Botón Revalorar                                             -
//                                                                             
// =========================================================================== 
function gdocumen_revalida_unidoc(pStrIdalbaran, pStrTabname, pIntRevalo) {

    /**
     * FUNC: Borrado de descuentos
     */ 
    function __local_del_dtos(pStrTabname, pIntCabid, pStrSqlalb) {
        // ====================================================================
        //  Descartamos las tablas que no procedan
        // ====================================================================

        if (pStrTabname == 'gcomforh'       || pStrTabname == 'gvenforh' || pStrTabname == 'gmovproh'       || 
            pStrTabname == 'glog_movplanh'  || pStrTabname == 'ganticih' || pStrTabname == 'gvenofeh_ing'   || 
            pStrTabname == 'gcomconh'
        ) {
            return;
        }

        // ====================================================================
        //  Definimos un mapa para asignar la tabla de descuentos de cabecera
        // ====================================================================
        let mMapTabdtcl = Ax.util.Map.of(

            // COMPRAS
            'gcomofeh', 'gcomofel',
            'gcomsolh', 'gcomsoll',
            'gcomacuh', 'gcomacul',
            'gcompedh', 'gcompedl', 
            'gcomfach', 'gcomfacl',
            'gcommovh', 'gcommovl',
            'gcomalbh', 'gcomalbl',

            // VENTAS
            'gvenofeh', 'gvenofel',
            'gvenpedh', 'gvenpedl',
            'gvenacuh', 'gvenacul',
            'gvenalbh', 'gvenalbl',
            'gvenfach', 'gvenfacl',
            'gvenmovh', 'gvenmovl'

        );

        let mStrTabdtcl = mMapTabdtcl.get(pStrTabname);

        // ====================================================================
        //  Definimos un mapa para asignar la tabla de descuentos de líneas 
        // ====================================================================
        let mMapTabdtlh = Ax.util.Map.of(

            // COMPRAS
            'gcomofeh', 'gcomofel_dtlh',
            'gcomsolh', 'gcomsoll_dtlh',
            'gcomacuh', 'gcomacul_dtlh',
            'gcompedh', 'gcompedl_dtlh', 
            'gcommovh', 'gcommovl_dtlh',
            'gcomalbh', 'gcommovl_dtlh',
            'gcomfach', 'gcomfacl_dtlh',

            // VENTAS
            'gvenofeh', 'gvenofel_dtlh',
            'gvenacuh', 'gvenacul_dtlh',
            'gvenpedh', 'gvenpedl_dtlh',
            'gvenmovh', 'gvenmovl_dtlh',
            'gvenalbh', 'gvenmovl_dtlh',
            'gvenfach', 'gvenfacl_dtlh'

        );

        let mStrTabdtch = mMapTabdtlh.get(pStrTabname);

        Ax.db.delete(mStrTabdtcl,
            `
                cabid IN (SELECT cabid FROM ${pStrTabname}
                                    WHERE cabid  = ${pIntCabid}
                                        AND indmod IN ('S', 'B')
                                        AND estcab IN ('V','E')
                                        AND ${pStrSqlalb})
            `
        );

        Ax.db.delete(mStrTabdtch,
            `
                cabid IN (SELECT cabid FROM ${pStrTabname}
                           WHERE cabid  = ${pIntCabid}
                             AND indmod IN ('S', 'B')
                             AND estcab IN ('V','E')
                             AND ${pStrSqlalb})
            `
        );

    }

    /**
     * FUNC: Borrado de lineas regalo y otros
     */ 
    function __local_del_varios(pStrTabname, pIntCabid, pStrSqlalb) {

        // ============================================================================
        //  El campo "regalo" sólo existe en pedidos, acuerdos, albaranes y facturas
        // ============================================================================
        var mRegExpC = /(gcompedh|gcomacuh|gcommovh|gcomalbh|gcomfach)/;
        var mRegExpV = /(gvenpedh|gvenacuh|gvenmovh|gvenalbh|gvenfach)/;

        if (mRegExpC.test(pStrTabname) || mRegExpV.test(pStrTabname)){
            
            //  Definimos un mapa para asignar la tabla de lineas 
            let mMapTablin = Ax.util.Map.of(

                // COMPRAS
                'gcompedh', 'gcompedl',
                'gcomacuh', 'gcomacul',
                'gcommovh', 'gcommovl',
                'gcomalbh', 'gcomalbl', 
                'gcomfach', 'gcomfacl',

                // VENTAS
                'gvenpedh', 'gvenpedl',
                'gvenacuh', 'gvenacul',
                'gvenmovh', 'gvenmovl',
                'gvenalbh', 'gvenalbl',
                'gvenfach', 'gvenfacl'

            );

            let mStrTabname = mMapTablin.get(pStrTabname);

            Ax.db.delete(mStrTabname,
                `
                    cabid IN (SELECT cabid FROM ${pStrTabname}
                                  WHERE cabid  = ${pIntCabid}
                                    AND indmod IN ('S', 'B')
                                    AND estcab IN ('E', 'V')
                                    AND ${pStrSqlalb}) AND
                    regalo = 'S'
                `
            );
        } 

        // ============================================================================
        //  Órdenes de producción. Se borran los costes, ya sean planificados
        //  como reales                                                      
        // ============================================================================
        if (pStrTabname == 'gpro_ordprodh') {
            Ax.db.delete('gpro_ordcostp',
                `
                    ordpro IN (SELECT docser
                                 FROM gpro_ordprodh
                                WHERE cabid  = ${pIntCabid}
                                 AND estcab  = 'L') AND
                    manual = 0
                `
            );

            Ax.db.delete('gpro_ordcostr',
                `
                    ordpro IN (SELECT docser
                                 FROM gpro_ordprodh
                                WHERE cabid  = ${pIntCabid}
                                  AND estcab = 'C') AND
                    manual = 0
                `
            );
        }
    }

    /**
     * FUNC: Modificación de líneas
     */ 
    function __local_upd_lineas(pStrTabname, pIntCabid, pStrSqlalb) {
        // ============================================================================
        //  Definimos un mapa para asignar la tabla de lineas
        // ============================================================================
        let mMapTablin = Ax.util.Map.of(

            // COMPRAS
            'gcomofeh', 'gcomofel',
            'gcomsolh', 'gcomsoll',
            'gcomacuh', 'gcomacul',
            'gcompedh', 'gcompedl', 
            'gcomfach', 'gcomfacl',
            'gcommovh', 'gcommovl', 
            'gcomalbh', 'gcomalbl',

            // VENTAS
            'gvenofeh', 'gvenofel',
            'gvenpedh', 'gvenpedl',
            'gvenacuh', 'gvenacul',
            'gvenalbh', 'gvenalbl',
            'gvenfach', 'gvenfacl',
            'gvenmovh', 'gvenmovl'

        );

        // ============================================================================
        //  Leer el mapa. Si la tabla no está en el mapa, salir de la función
        // ============================================================================
        let mStrTabname = mMapTablin.get(pStrTabname);

        if (mStrTabname == null) {
            return;
        }

        // En caso de solicitudes, los campos no son los mismos. 
        if (mStrTabname == 'gcomsoll') {

            Ax.db.update(mStrTabname,
                {
                    //estlin: 'E',                  //comentado columna no existe
                    precio: '0'
                },        
                `
                    --estlin IN ('V','E') AND       --comentado columna no existe
                    cabid IN (SELECT cabid FROM ${pStrTabname}
                               WHERE cabid   = ${pIntCabid}
                                 AND indmod  IN ('S', 'B')
                                 AND estcab  IN ('E', 'V'))
                `        
            )
        }
        // En caso de acuerdos, el where no es igual.  

        else if (mStrTabname == 'gcomacul' || mStrTabname == 'gvenacul') {

            Ax.db.update(mStrTabname,
                {
                    //estlin, pretar, dtotar columnas no existen

                    //estlin: 'E',
                    precio: 0//,
                    //pretar: null,
                    //dtotar: null
                },
                `
                    -- estlin IN ('V','E') AND      --comentado columna no existe
                    (canacu = 0 AND impacu = 0) AND
                    cabid IN (SELECT cabid FROM ${pStrTabname}
                               WHERE cabid   = ${pIntCabid}
                                 AND indmod  IN ('S', 'B')
                                 AND estcab  IN ('E', 'V'))
                `

            )

        } else {

            Ax.db.update(mStrTabname,
                {
                    //estlin, pretar, dtotar columnas no existen

                    //estlin: 'E',
                    precio: 0//,
                    //pretar: null,
                    //dtotar: null
                },
                `
                    --estlin IN ('V','E') AND --comentado columna no existe
                    cabid IN (SELECT cabid FROM ${pStrTabname}
                               WHERE cabid   = ${pIntCabid}
                                 AND indmod  IN ('S', 'B')
                                 AND estcab  IN ('E', 'V')
                                 AND ${pStrSqlalb})
                `

            )

        }

    }

    /**
     * FUNC: Validación de los documentos   
     */
    function __local_val_docum(pStrTabname, pIntCabid) {
        // ============================================================================
        //  Obtención del rowid 
        // ============================================================================
        let mIntRowId = Ax.db.executeGet(`
            <select>
                <columns>rowid</columns>
                <from table='${pStrTabname}' />
                <where>
                    cabid = ${pIntCabid}
                </where>
            </select>
        `);

        //Ax.db.call(pStrTabname, 'U', mIntRowId)
        Ax.db.call(`${pStrTabname}_Valida`,  pIntCabid);
    
    }

    /**
     * Inicio de proceso 
     */
    let mObjGVenmovh = Ax.db.executeQuery(`
        <select>
             <columns>
                 cabid, docser
             </columns>
             <from table='gvenmovh' />
             <where>
             	    cabid = ?
             </where>
         </select>
    `, pStrIdalbaran).toOne();

    /**
     *  Validación y revalorización del documento.                          
     *  Si lo que esta dentro del try - body, va bien y no hay              
     *  ninguna excepcion, entonces se valida y revalora el documento.      
     *  Si diese alguna excepcion entonces pasaria a ejecutarse lo que haya 
     *  dentro del catch, es decir, mostrar el mensaje con el documento que 
     *  haya dado lugar a la excepcion.                                     
     */

    // Caso en que se revalore. 
    if (pIntRevalo == 1) {
        /**
         * Determinamos el string a añadir si es albarán de ventas o    
         * compras.No se permite borrar descentos de albaranes si están 
         * contabilizados                                               
         */
        let mStrSqlalb = '1=1';

        if (pStrTabname == 'gcomalbh' || pStrTabname == 'gcommovh' ||
            pStrTabname == 'gvenalbh' || pStrTabname == 'gvenmovh'
        ) {
            mStrSqlalb = 'fconta IS NULL AND fcontm IS NULL'
        }

        // Eliminación de descuentos para su regeneración.
        __local_del_dtos(pStrTabname, mObjGVenmovh.cabid, mStrSqlalb);

        // Eliminación de lineas de regalo y otros.     
        __local_del_varios(pStrTabname, mObjGVenmovh.cabid, mStrSqlalb);

        // Modificación de líneas para su recálculo.
        __local_upd_lineas(pStrTabname, mObjGVenmovh.cabid, mStrSqlalb)

    }

    //  Validación del documento.  
    __local_val_docum(pStrTabname, mObjGVenmovh.cabid);

}