function mutCopArtFar(
    pStrCodori,
    pStrCodnew,

    pStrNomart,
    pStrCodfam,
    pStrCodatc,
    pStrFetiq1,
    pStrFetiq2,
    pStrFetiq3,
    pStrFetiqco,

    pStrGuiaStock,
    pStrCarat,
    pStrEstupe,
    pStrUbicacio
) {
    //Tablas relacionadas con el articulo.
    let mArrGarticul = 
    [
        'gartvarl         codart  codigo',
        'gart_unidefs     codart  codigo',         
        'gart_uniconv     codart  codigo',
        'ggrpstkn         codart  codigo',
        'galmstkn         codart  codigo',
        'gartprov         codart  codigo',
        'gartclie         codart  codigo',
        'gartalma         codart  codigo',
        'garticul_cart    cabid   artid<',
        'gartidio         codart  codigo',
        'gcomprad         codart  codigo',
        'gproforh         codart  codigo',
        'gproforl         codcom  codigo',
        'gartalte         codart  codigo',
        'gart_catalogo    codart  codigo',
        'gcomtarl         codart  codigo',
        'gventarl         codart  codigo',
        'gartcali         codart  codigo',
        'gartcalh         codart  codigo',
        'glog_articulo    codart  codigo',
        'gret_pvparti     codart  codigo',
        'gret_pvplind     codart  codigo',
        'gret_artingr     codart  codigo'
    ];

    Ax.db.beginWork();

    //GARTICUL

    let mObjGarticul = {};

    mObjGarticul = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='garticul' />
            <where>
                codigo = ?
            </where>
        </select>
    `, pStrCodori).toOne()
        .setRequired(`Article inexistent [${pStrCodori}]'`);

    mObjGarticul.artid = 0;
    mObjGarticul.auxchr2 = mObjGarticul.codigo;
    mObjGarticul.codigo = pStrCodnew;

    if (pStrNomart != '') {
        mObjGarticul.nomart = pStrNomart;
    }

    if (pStrCodfam != '') {
        mObjGarticul.codfam = pStrCodfam;
        mObjGarticul.intfam = pStrCodfam;
    }

    mObjGarticul.estado = 'B';

    let mIntArtid = Ax.db.insert('garticul', mObjGarticul).getSerial();

    //GARTVARL
    Ax.db.delete('gartvarl', 
        {
            'codart': pStrCodnew
        }
    )

    let mArrGartvarl = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='gartvarl' />
            <where>
                codart = ?
            </where>
            <order>varlog</order>
        </select>
    `, pStrCodori);

    for (let mRow of mObjGartvarl) {
        mRow.varid = 0;
        mRow.codart = pStrCodnew;
        mRow.user_created = 'far_auto';
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto';
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('gartvarl', mRow)
    }

    //GART_UNIDEFS  
    Ax.db.delete('gart_unidefs', 
        {
            'codart': pStrCodnew
        }
    );

    let mArrGartUnidefs = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='gart_unidefs' />
            <where>
                codart = ?
            </where>
        </select> 
    `, pStrCodori);

    for (let mRow of mArrGartUnidefs) {
        mRow.seqno = 0;
        mRow.codart = pStrCodnew;
        mRow.user_created = 'far_auto';
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto';
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('gart_unidefs', mRow)
    }

    //GART_UNICONV
    Ax.db.delete('gart_uniconv', 
        {
            'codart': pStrCodnew
        }
    );

    let mArrGartUniconv = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='gart_uniconv' />
            <where>
                codart = ?
            </where>
        </select> 
    `, pStrCodori);

    for (let mRow of mArrGartUniconv) {
        mRow.codart = pStrCodnew;

        Ax.db.insert('gart_uniconv', mRow)
    }

    //GARTICUL_CART
    Ax.db.execute(`
        DELETE FROM garticul_cart
        WHERE cabid = ${mIntArtid}
        and garticul_cart.carcode not in ('FETIQ1','FETIQ2','FETIQ3','FETIQCO','FFCODATC')
        and garticul_cart.carcode not matches "FC*"
        and garticul_cart.carcode not matches "FF*"
    `);

    let mArrGarticulCart = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='garticul_cart' />
            <where>
                    cabid IN (SELECT artid FROM garticul WHERE codigo = ?)
                and garticul_cart.carcode not in ('FETIQ1','FETIQ2','FETIQ3','FETIQCO','FFCODATC')
                and garticul_cart.carcode not matches "FC*"
                and garticul_cart.carcode not matches "FF*"
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGarticulCart) {
        mRow.cabid = mIntArtid;
        mRow.user_created = 'far_auto';
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto';
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('garticul_cart', mRow)
    }

    if (pStrFetiq1 != null) {
        if (pStrFetiq2 == null || pStrFetiq3 == null) {
            Ax.db.execute(`
                UPDATE garticul_cart
                   SET user_created = 'far_auto',
                       date_created = ${new Ax.sql.Date()},
                       user_updated = 'far_auto',
                       date_updated = ${new Ax.sql.Date()},
                       cardata      = ?,
                       cartext      = ''
                 WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                 and garticul_cart.carcode = 'FETIQ2'
            `, pStrFetiq1, pStrCodnew);

        } else {
            Ax.db.execute(`
                UPDATE garticul_cart
                   SET user_created = 'far_auto',
                       date_created = ${new Ax.sql.Date()},
                       user_updated = 'far_auto',
                       date_updated = ${new Ax.sql.Date()},
                       cardata      = ?,
                       cartext      = ''
                 WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FETIQ1'
            `, pStrFetiq1, pStrCodnew);
        }
    }

    if (pStrFetiq2 != null) {
        if (pStrFetiq1 != null || pStrFetiq3 == null) {
            Ax.db.execute(`
                UPDATE garticul_cart
                   SET user_created = 'far_auto',
                       date_created = ${new Ax.sql.Date()},
                       user_updated = 'far_auto',
                       date_updated = ${new Ax.sql.Date()},
                       cardata      = ?,
                       cartext      = ''
                 WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                 and garticul_cart.carcode = 'FETIQ3'
            `, pStrFetiq2, pStrCodnew);
        } else {
            Ax.db.execute(`
                UPDATE garticul_cart
                   SET user_created = 'far_auto',
                       date_created = ${new Ax.sql.Date()},
                       user_updated = 'far_auto',
                       date_updated = ${new Ax.sql.Date()},
                       cardata      = ?,
                       cartext      = ''
                 WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                 and garticul_cart.carcode = 'FETIQ2'
            `, pStrFetiq2, pStrCodnew);
        }
    }

    if (pStrFetiq3 != null) {
        Ax.db.execute(`
            UPDATE garticul_cart
               SET user_created = 'far_auto',
                   date_created = ${new Ax.sql.Date()},
                   user_updated = 'far_auto',
                   date_updated = ${new Ax.sql.Date()},
                   cardata      = ?,
                   cartext      = ''
             WHERE 
                cabid IN (SELECT artid 
                            FROM garticul 
                           WHERE codigo = ?)
             and garticul_cart.carcode = 'FETIQ3'
        `, pStrFetiq3, pStrCodnew);
    }

    Ax.db.execute(`
        UPDATE garticul_cart
           SET user_created = 'far_auto',
               date_created = ${new Ax.sql.Date()},
               user_updated = 'far_auto',
               date_updated = ${new Ax.sql.Date()},
               cardata      = ?,
               cartext      = ''
         WHERE 
            cabid IN (SELECT artid 
                        FROM garticul 
                       WHERE codigo = ?)
         and garticul_cart.carcode = 'FETIQCO'
    `, pStrFetiqco, pStrCodnew);

    Ax.db.execute(`
        UPDATE garticul_cart
           SET user_created = 'far_auto',
               date_created = ${new Ax.sql.Date()},
               user_updated = 'far_auto',
               date_updated = ${new Ax.sql.Date()},
               cardata      = ?,
               cartext      = ''
         WHERE 
            cabid IN (SELECT artid 
                        FROM garticul
                       WHERE codigo = ?)
            and garticul_cart.carcode = 'FFCODATC'
    `, pStrCodatc.trim(), pStrCodnew);

    switch (pStrGuiaStock) {
        case 'GUIA': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFGUIAPE'
            `, pStrCodnew);

            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFSTOCK'
            `, pStrCodnew);
        break;

        case 'NO GUIA/ESTOC': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'N',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFGUIAPE'
            `, pStrCodnew);

            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFSTOCK'
            `, pStrCodnew);
        break;

        case 'NO GUIA/ESTOC': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'N',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFGUIAPE'
            `, pStrCodnew);

            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFSTOCK'
            `, pStrCodnew);
        break;
    
        default:        
        break;
    }

    switch (pStrCarat) {
        case 'ALTRES': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFALTRES'
            `, pStrCodnew);            
        break;

        case 'DIETA': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFDIETA'
            `, pStrCodnew);            
        break;

        case 'DUP': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFDUP'
            `, pStrCodnew);            
        break;

        case 'FM': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFFM'
            `, pStrCodnew);            
        break;

        case 'FMC': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFFMC'
            `, pStrCodnew);            
        break;

        case 'MATERIAL': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFMATERIAL'
            `, pStrCodnew);            
        break;

        case 'ME': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFME'
            `, pStrCodnew);            
        break;

        case 'MPI': 
            Ax.db.execute(`
                UPDATE garticul_cart
                SET user_created = 'far_auto',
                    date_created = ${new Ax.sql.Date()},
                    user_updated = 'far_auto',
                    date_updated = ${new Ax.sql.Date()},
                    cardata      = 'S',
                    cartext      = ''
                WHERE 
                    cabid IN (SELECT artid 
                                FROM garticul 
                               WHERE codigo = ?)
                    and garticul_cart.carcode = 'FFMPI'
            `, pStrCodnew);            
        break;
    
        default:
            break;
    }

    if (pStrEstupe == 'E') {
        Ax.db.execute(`
            UPDATE garticul_cart
            SET user_created = 'far_auto',
                date_created = ${new Ax.sql.Date()},
                user_updated = 'far_auto',
                date_updated = ${new Ax.sql.Date()},
                cardata      = 'S',
                cartext      = ''
            WHERE 
                cabid IN (SELECT artid 
                            FROM garticul 
                           WHERE codigo = ?)
                and garticul_cart.carcode = 'FFESTUPE'
        `, pStrCodnew); 
    }

    mArrGarticulCart = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='garticul_cart' />
            <where>
                    cabid IN (SELECT artid FROM garticul WHERE codigo = ?)
                and garticul_cart.carcode matches "FC*"
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGarticulCart) {
        Ax.db.execute(`
            UPDATE garticul_cart
            SET user_created = 'far_auto',
                date_created = ${new Ax.sql.Date()},
                user_updated = 'far_auto',
                date_updated = ${new Ax.sql.Date()},
                cardata      = '${mRow.cardata}',
                cartext      = '${mRow.cartext}'
            WHERE 
                cabid IN (SELECT artid FROM garticul WHERE codigo = ?)
                and garticul_cart.carcode = ?
        `, pStrCodnew, mRow.carcode); 
    }

    //NEVERA
    let mStrUbipic = Ax.db.executeGet(`
        <select>
            <columns>glog_articulo.ubipic</columns>
            <from table='glog_articulo' />
            <where>
                    glog_articulo.codart = ?
                and glog_articulo.varlog = '0'
                and (glog_articulo.ubipic matches "5N*"
                    or
                    glog_articulo.ubipic matches "5CF*")  
            </where>
        </select> 
    `, pStrCodori);

    if (mStrUbipic != null) {
        Ax.db.execute(`
            UPDATE garticul_cart
            SET user_created = 'far_auto',
                date_created = ${new Ax.sql.Date()},
                user_updated = 'far_auto',
                date_updated = ${new Ax.sql.Date()},
                cardata      = 'S',
                cartext      = ''
            WHERE 
                cabid IN (SELECT artid FROM garticul WHERE codigo = ?)
                and garticul_cart.carcode = 'FFNEVERA'
        `, pStrCodnew);     
    }

    //GARTPROV
    Ax.db.delete('gartprov', 
        {
            'codart': pStrCodnew
        }
    )

    let mArrGartprov = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='gartprov' />
            <where>
                codart = ?
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGartprov) {
        mRow.codart       = pStrCodnew;
        mRow.user_created = 'far_auto';
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto';
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('gartprov', mRow)
    }

    //GARTPROV_DOCS 
    let mArrGartprovDocs = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='gartprov_docs' />
            <where>
                codart = ?
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGartprovDocs) {
        mRow.seqno        = 0;
        mRow.codart       = pStrCodnew;    
        mRow.user_created = 'far_auto'; 
        mRow.date_created = new Ax.sql.Date(); 
        mRow.user_updated = 'far_auto'; 
        mRow.date_updated = new Ax.sql.Date(); 

        Ax.db.insert('gartprov_docs', mRow)
    }

    //GALMSTKN
    Ax.db.delete('galmstkn', 
        {
            'codart': pStrCodnew
        }
    )

    let mArrGalmstkn = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='galmstkn' />
            <where>
                codart = ?
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGalmstkn) {
        mRow.codart = pStrCodnew;
        mRow.auxnum1 = 0;
        mRow.user_created = 'far_auto'; 
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto'; 
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('galmstkn', mRow)
    }

    //GLOG_ARTICULO
    Ax.db.delete('glog_articulo', 
        {
            'codart': pStrCodnew
        }
    )

    let mArrGlogArticulo = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='glog_articulo' />
            <where>
                codart = ?
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGlogArticulo) {
        mRow.seqno  = 0;
        mRow.codart = pStrCodnew;
        mRow.user_created = 'far_auto'; 
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto'; 
        mRow.date_updated = new Ax.sql.Date();
        mRow.ubipic = pStrUbicacio;

        Ax.db.insert('glog_articulo', mRow)
    }

    //GCOMTARL
    let mArrGcomtarl = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='gcomtarl' />
            <where>
                codart = ?
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGcomtarl) {
        mRow.linid  = 0;
        mRow.codart = pStrCodnew;
        mRow.user_created = 'far_auto'; 
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto'; 
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('glog_articulo', mRow)
    }

    //GARTICUL_NOTE
    Ax.db.delete('garticul_note', 
        {
            artid: mIntArtid
        }
    );

    let mArrGarticulNote = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='garticul_note' />
            <where>
                artid IN (SELECT artid FROM garticul WHERE codigo = ?)
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrGarticulNote) {
        mRow.artid        = mIntArtid;
        mRow.user_created = 'far_auto'; 
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto'; 
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('garticul_note', mRow);
    }

    //SGA_CODBAR  
    Ax.db.delete('sga_codbar', 
        {
            codart: pStrCodnew
        }
    );

    let mArrSgaCodbar = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='sga_codbar' />
            <where>
                codart = ?
            </where>
        </select>
    `, pStrCodori);

    for (let mRow of mArrSgaCodbar) {
        mRow.codart       = pStrCodnew
        mRow.user_created = 'far_auto'; 
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto'; 
        mRow.date_updated = new Ax.sql.Date();

        Ax.db.insert('garticul_note', mRow);
    }

    //GARTICUL_DOCS
    Ax.db.delete('garticul_docs', 
        {
            'codart': pStrCodnew
        }
    );

    let mArrGarticulDocs = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='garticul_docs' />
            <where>
                codart = ?
            </where>
        </select>    
    `, pStrCodori)

    for (let mRow of mArrGarticulDocs) {
        mRow.codart       = pStrCodnew;
        mRow.user_created = 'far_auto'; 
        mRow.date_created = new Ax.sql.Date();
        mRow.user_updated = 'far_auto'; 
        mRow.date_updated = new Ax.sql.Date();   
        
        Ax.db.insert('garticul_docs', mRow);
    }

    Ax.db.commitWork();

}