/*====================================================================
//Script que genera sol.licituds dels registres de mut_axi_gcomsolh
//                -->
//circuit AXIMAT (AXOR/AXRE/FAXI/RAXI) 
//====================================================================*/
function mutAxiGcomsolhGenera(pStrSqlcond) {
    //FUNCTION local_gcomsolh_insert
    //Genera un registre a gcomsolh.
    function __local_gcomsolh_insert(
        pStrDocori, 
        pStrDelega, 
        pStrDepart, 
        pDatFecsol, 
        pStrTipdoc, 
        pStrEmpcode,
        pStrClasif
    ) {
        let mObjGcomsolh = {};
        mObjGcomsolh.docori = pStrDocori;
        mObjGcomsolh.tipdoc = pStrTipdoc;
        mObjGcomsolh.empcode = pStrEmpcode;
        mObjGcomsolh.delega = pStrDelega;
        mObjGcomsolh.depart = pStrDepart;
        mObjGcomsolh.fecsol = pDatFecsol;
        mObjGcomsolh.fecini = mObjGcomsolh.fecsol;
        mObjGcomsolh.fecfin = mObjGcomsolh.fecini;
        mObjGcomsolh.clasif = pStrClasif;
        mObjGcomsolh.docser = null;

        //Seleccionem el magatzem.   
        if (mObjGcomsolh.delega == null || mObjGcomsolh.delega.length == 0) {
            mObjGcomsolh.codalm = `${pStrEmpcode}CEN`;
            mObjGcomsolh.delega = Ax.db.executeGet(`
                <select>
                    <columns>delega</columns>
                    <from table='galmacen' />
                    <where>
                        codigo = ?
                    </where>
                </select>
            `, mObjGcomsolh.codalm);
            mObjGcomsolh.depart = 0;

        } else {
            mObjGcomsolh.codalm = Ax.db.executeFunction('galmdele_get_almacen', 
                null,
                null,
                mObjGcomsolh.delega,
                mObjGcomsolh.depart,
                null,
                null,
                null,
                null 
            )
        }

        // En últim cas el codi de magatzem és el CEN 
        if (mObjGcomsolh.codalm == null) {
            mObjGcomsolh.codalm = `${pStrEmpcode}CEN`;
        }

        if (mObjGcomsolh.tipdoc == null) {
            throw new Ax.lang.Exception('Tipus de document indeterminat');
        }

        //Valores por defecto fijos 
        mObjGcomsolh.imptot = 0;
        mObjGcomsolh.cambio = 1;
        mObjGcomsolh.estcab = 'E';
        mObjGcomsolh.errcab = 0;
        mObjGcomsolh.impres = 'N';
        mObjGcomsolh.movest = 0;
        mObjGcomsolh.indmod = 'S';
        mObjGcomsolh.divisa =  Ax.db.executeFunction('icon_get_moneda', pStrEmpcode);

        //Serie según máscara
        if (mObjGcomsolh.docser == null) {
            let mStrCodser = Ax.db.executeGet(`
                <select>
                    <columns>codser</columns>
                    <from table='gcomsold' />
                    <where>
                        codigo = ?
                    </where>
                </select>    
            `, mObjGcomsolh.tipdoc);

            if (mStrCodser == null) {
                throw new Ax.lang.Exception(`Tipus de solicitud [${mObjGcomsolh.tipdoc}] no trobada`);
            }

            mObjGcomsolh.docser = Ax.db.call('gsermask_get_docser', 
                'SC',
                pStrTipdoc,
                pStrEmpcode,
                pStrDelega,
                pStrDepart,
                null,
                null,
                pDatFecsol,
                mStrCodser   
            );

            mObjGcomsolh.docser = mObjGcomsolh.docser;

        }

        //Insertar en 'gcomsolh'
        let mInsert = Ax.db.insert('gcomsolh', mObjGcomsolh);
        
        let mObjRetur = {};
        mObjRetur.serial = mInsert.getSerial();
        mObjRetur.rowid  = mInsert.getRowId();
        mObjRetur.codalm = mObjGcomsolh.codalm;

        return mObjRetur;

    }

    // PRJ #10702	
    // No subministrar articles que tenen línies pendents en documents AXIM
    Ax.db.execute(`
        UPDATE mut_axi_gcomsolh
           SET axi_estado = 9,
               nerrno = 100,
               msgerr = 'NO subministrat per sol.licitud pendent'
         WHERE 
               axi_estado = '1' AND 1 = (SELECT (CASE 
					WHEN mut_axi_gcomsolh.axi_tipuscalaix='DOBLE CALAIX' AND COUNT(*)>=2 THEN 1
					WHEN mut_axi_gcomsolh.axi_tipuscalaix='CALAIX UNIC' AND COUNT(*)>=1 THEN 1
				ELSE 0 END)
					FROM gcomsoll l, gcomsolh h
					WHERE l.cabid = h.cabid 
					   AND l.estlin IN ('V','P','X','R')
					   AND h.tipdoc IN ('AXIM')
					   AND mut_axi_gcomsolh.axi_codart = l.codart
					   AND mut_axi_gcomsolh.axi_delega = h.delega
					   AND mut_axi_gcomsolh.axi_depart = h.depart) 
    `);

    //Processar els registres de mut_axi_gcomsolh pendents
    let mRsAxiGcomsolh = Ax.db.executeQuery(`
        <select>
            <columns>
                (CASE WHEN mut_axi_gcomsolh.axi_docori IN ('FAXI','RAXI') THEN mut_axi_gcomsolh.axi_docori ELSE 'AXIM' END) ||
                mut_axi_gcomsolh.axi_docori || mut_axi_gcomsolh.axi_delega || mut_axi_gcomsolh.axi_depart ||
                DATE(mut_axi_gcomsolh.date_created) group,
                (CASE WHEN mut_axi_gcomsolh.axi_docori IN ('FAXI','RAXI') THEN mut_axi_gcomsolh.axi_docori ELSE 'AXIM' END) tipdoc,
                mut_axi_gcomsolh.axi_docori,
                mut_axi_gcomsolh.axi_delega,
                mut_axi_gcomsolh.axi_depart,
                mut_axi_gcomsolh.axi_empcode,
                DATE(mut_axi_gcomsolh.date_created) fecsol,
                mut_axi_gcomsolh.axiid,
                mut_axi_gcomsolh.axi_codart,
                mut_axi_gcomsolh.axi_varlog,
                ABS(mut_axi_gcomsolh.axi_cansol) cansol,
                <nvl>mut_axi_gcomsolh.axi_varlog, 0</nvl> varstk,
                gartvarl.udmcom udmcom,
                CASE WHEN (gart_uniconv.relori IS NULL OR gart_uniconv.relori = 0) THEN 1 ELSE gart_uniconv.relori END cancom,
                CASE WHEN (gart_uniconv.reldes IS NULL OR gart_uniconv.reldes = 0) THEN 1 ELSE gart_uniconv.reldes END canuni,
                CASE WHEN (gart_unidefs.faccar IS NULL OR gart_unidefs.faccar = 0) THEN 1 ELSE gart_unidefs.faccar END canmul,
                mut_axi_gcomsolh.axi_clasif
            </columns>
            <from table='mut_axi_gcomsolh'>
                <join table='gartvarl'>
                    <on>gartvarl.codart = mut_axi_gcomsolh.axi_codart</on>
                    <on>gartvarl.varlog = '0'</on>
                </join>
                <join type='left' table='glog_articulo'>
                    <on>glog_articulo.codart = mut_axi_gcomsolh.axi_codart</on>
                    <on>glog_articulo.varlog = '0'</on>
                </join>
                <join type='left' table='gart_uniconv'>
                    <on>gart_uniconv.codart = gartvarl.codart</on>
                    <on>gart_uniconv.varlog IS NULL</on>
                    <on>gart_uniconv.udmori = gartvarl.udmcom</on>
                </join>
                <join type='left' table='gart_unidefs'>
                    <on>gartvarl.codart = gart_unidefs.codart</on>
                    <on>gart_unidefs.varlog IS NULL</on>
                    <on>gartvarl.udmcom = gart_unidefs.coduni</on>
                </join>
            </from>
            <where>
                    mut_axi_gcomsolh.axi_estado = '1'
                AND galmdele_get_almacen(NULL, NULL, mut_axi_gcomsolh.axi_delega,
                                    mut_axi_gcomsolh.axi_depart, NULL, NULL,
                                    NULL, NULL) = glog_articulo.codalm
                AND ${pStrSqlcond}
            </where>
            <order>
                group
            </order>
        </select>
    `);

    let mObjRs = {};
    let mIntOrden, mIntRowid, mStrCodalm, mIntCabid;

    //Nova capçalera de sol.licitud 
    mRsAxiGcomsolh.cursor()
    .group("group")
        .before(mRow => {
            //Inici de transacció. Per evitar deixar en cas d´error capçaleres sense línies.
            Ax.db.beginWork();
            mIntRowid = null;
            if (mRow.tipdoc != null) {
                mObjRs = __local_gcomsolh_insert(
                    mRow.axi_docori,
                    mRow.axi_delega,
                    mRow.axi_depart,
                    mRow.fecsol,
                    mRow.tipdoc,
                    mRow.axi_empcode,
                    mRow.axi_clasif
                );
                mIntCabid = mObjRs.cabid;
                mIntRowid = mObjRs.rowid;
                mStrCodalm = mObjRs.codalm;
            }
            mIntOrden = 0;

        })
        .after(mRow => {
            //Validar la sol.licitud.
            Ax.db.call('gcomsolh', 'I', mIntRowid);

    })
    .forEach(mRow => {
        try {
            // Transacció per row.  
            if (!Ax.db.isOnTransaction()) {
                Ax.db.beginWork();
            }
            //Línia sense capçalera sense poderla relacionar amb una
            //capçalera. S´intenta crear una nova capçalera.
            if (mIntCabid == null) {
                mObjRs = __local_gcomsolh_insert(
                    mRow.axi_docori,
                    mRow.axi_delega,
                    mRow.axi_depart,
                    mRow.fecsol,
                    mRow.tipdoc,
                    mRow.axi_empcode,
                    mRow.axi_clasif 
                );
                mIntCabid = mObjRs.cabid;
                mIntRowid = mObjRs.rowid;
                mStrCodalm = mObjRs.codalm;
            }

            if (mRow.canuni == 0) {
                throw new Ax.lang.Exception(`Art:[${mRow.axi_codart}] té la relació amb la VLS igual a 0`)
            }

            //Incialitzar les  variables per els dos circuits:
            //Per pròtesis s´ha de determinar el preu de compra
            let mStrEstado = '9';

            //Insertar línia de sol.licitud 
            mIntOrden = mIntOrden + 5;
            let mObjGcomsoll = {};
            mObjGcomsoll.linid = 0;
            mObjGcomsoll.cabid = mIntCabid;
            mObjGcomsoll.orden = mIntOrden;
            mObjGcomsoll.codart = mRow.axi_codart;
            mObjGcomsoll.varlog = 0;
            mObjGcomsoll.udmsol = mRow.udmcom;
            mObjGcomsoll.udmpre = mRow.udmcom;
            mObjGcomsoll.cansol = mRow.cansol;
            mObjGcomsoll.canpre = mRow.cansol;
            mObjGcomsoll.precio = 0;
            mObjGcomsoll.canped = 0;
            mObjGcomsoll.canser = 0;
            mObjGcomsoll.canadj = 0;
            mObjGcomsoll.canext = 0;
            mObjGcomsoll.estlin = 'E';
            mObjGcomsoll.errlin = 0;
            mObjGcomsoll.indmod = 'S';

            mObjGcomsoll.linid = Ax.db.insert('gcomsoll', mObjGcomsoll).getSerial();

            //Marcar la línia de mut_axi_gcomsolh com a processada.
            Ax.db.update('mut_axi_gcomsolh', 
                {
                    'nerrno': null,
                    'msgerr': null,
                    'axi_estado': mStrEstado,
                    'axi_linsol': mObjGcomsoll.linid
                }, 
                {
                    'axiid': mRow.axiid
                }
            );

            Ax.db.commitWork();
        
        } catch (error) {
            Ax.db.rollbackWork();
            Ax.db.update('mut_axi_gcomsolh', 
                {
                    'nerrno': 999,
                    'msgerr': Ax.util.Error.getMessage(error)
                }, 
                {
                    'axiid': mRow.axiid
                }
            )
            mIntCabid = null;
        }
    });


    let mArrGcomsolh = Ax.db.executeQuery(`
        <select>
            <columns>
                rowid
            </columns>
            <from table='gcomsolh'>
            </from>
            <where>
                    gcomsolh.tipdoc IN ('AXIM','FAXI','RAXI') AND  gcomsolh.estcab = 'E' AND  gcomsolh.errcab = 0
            </where>
        </select>
    `);

    for (let mRow of mArrGcomsolh) {
        //Validar la sol.licitud. 
        Ax.db.call('gcomsolh', 'I', mRow.rowid);
    }

}