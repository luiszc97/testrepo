function sga_ajustes_stock_Print(pStrCond){
    /** Local function __getLabel()
     * 
     *  Return label for field or box.
     * 
     *  PARAMETERS: 
     *  =============
     *      
     *      @param      {string}       pStrLBL              label.
     *      @param      {string}       pStrLang             Lang
     */
    function __getLabel (pStrLBL, pStrLang) {
        return Ax.ext.webapp.getLabel(pStrLBL, pStrLang);
    }

    /** Local function __getColumnLabel()
     * 
     *  Column label of a table that returns a field or box.
     * 
     *  PARAMETERS: 
     *  =============
     *      
     *      @param      {string}       pStrTable            Table name
     *      @param      {string}       pStrColumn           Column name
     *      @param      {string}       pStrLang             Lang
     */

    function __getColumnLabel (pStrTable, pStrColumn, pStrLang) {
        return Ax.ext.webapp.getColumn(pStrTable,  pStrColumn, pStrLang).getColMemo();
    }

    var mArrGeanmovh = Ax.db.executeQuery(`
        <select>
            <columns>
                geanmovh.fecmov, geanmovh.almori, geanmovh.tipdoc, geanmovd.ctaori,
                geanmovd.ctades, geanmovl.codart, geanmovl.terdep, geanmovl.ubiori,
                geanmovl.ubides, geanmovl.canmov
            </columns>
            <from table='geanmovh'>
                <join table='geanmovl'>
                    <on>geanmovh.cabid = geanmovl.cabid</on>
                </join>
                <join table='geanmovd'>
                    <on>geanmovh.tipdoc = geanmovd.codigo</on>
                </join>
            </from>
            <where>
                geanmovh.tipdoc IN ('DIFP', 'DIFN')
                AND ${pStrCond}
            </where>
        </select>
    `).toJSONArray();

    // =========================================================================
    // STYLE VARIABLES
    // =========================================================================
    const BACKCOLOR1  = "#FFDD90";
    const BACKCOLOR2  = "#D6DEE7";
    const FONT_SIZE   = 8;
    const BORDERCOLOR = '#000000';
	//Se recupera el idioma del cliente, en caso venga informado; si no se toma el idioma del usuario.
    const LOCALE      = Ax.ext.user.getLang() || 'ca';
    const DATE_FORMAT  = (LOCALE == "es" || LOCALE == "ca") ? "dd/MM/yyyy" : "MM/dd/yyyy";
    const DATE_FORMAT2 = (LOCALE == "es" || LOCALE == "ca") ? "dd/MM/yyyy hh:mm:ss" : "MM/dd/yyyy hh:mm:ss";
    const FONT_NAME   =  "Noto Sans";
    const BORDERWIDTH = 0.5;
    const FONT_S_TEX = 8;
    const PADDING     ='2pt';
    const NumFormat = new Ax.text.NumberFormat(LOCALE);
	const DB_NAME = 'Grup Mútua Terrassa (Consulta)';

    /**
     * Se inicializa el espacio para el inicio, que se va a ampliar cuando exista comentario del documento.
     */
    var mSpaceBefore = 4;

    //Se inicializa el espacio para el bloque final.
    var mSpaceAfter = 1.5;

    /********************************************/
	/**             Inicio del fop.           **/
	/********************************************/	
    var template = new Ax.fop.SinglePageTemplate("A4");

    template.setRoot(root => {
        //root.setDebug("*");
        // Default Page layout    
        root.getSimplePageMaster().getRegionBefore().setExtent(mSpaceBefore);
        root.getSimplePageMaster().getRegionAfter().setExtent(1.0);
        root.getSimplePageMaster().getRegionStart().setExtent(1.0);
        root.getSimplePageMaster().getRegionEnd().setExtent(1.0);
        //root.getSimplePageMaster().setMargins(0, 0, 0, 0);
        
        // Get the FOPSimplePageMaster now (we only have one)
        // after adding the first .. we can not call again
        // cause we have two ... and dont know witch one ..
        var spm       = root.getSimplePageMaster();
        var pageOnly  = root.addSimplePageMaster("PageOnly").apply(spm);
        var pageFirst = root.addSimplePageMaster("PageFirst").apply(spm);
        var pageRest  = root.addSimplePageMaster("PageRest").apply(spm);
        var pageLast  = root.addSimplePageMaster("PageLast").apply(spm);
        
        // In last page we need to acommodate Tax and Notes table. So we requie more space
        pageFirst.setMargins(0, 0, 1.0, 0); //TODO AJUSTAR TOTALES SOLO A LA ÚLTIMA PAGINA
        pageFirst.getRegionAfter().setExtent(2);
        pageRest.setMargins(0, 0, 1.0, 0);
        pageRest.getRegionAfter().setExtent(2);
        pageLast.setMargins(0, 0, 1.0, 0);
        pageLast.getRegionAfter().setExtent(mSpaceAfter);
        pageOnly.setMargins(0, 0, 1.0, 0);
        pageOnly.getRegionAfter().setExtent(mSpaceAfter);
        
        // Create a pagesequence master
        var master = root.createPageSequenceMaster("master");    
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageOnly"),  "only");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageFirst"), "first");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageRest"),  "rest");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageLast"),  "last");
        root.addPageSequenceMaster(master);
        root.getPageSequence().setMasterReferenceName("master");

    });

    // =======================================================================
    // CONFIGURE START
    // =======================================================================
    template.setStart(start => {

    });

    // =======================================================================
    // CONFIGURE END
    // =======================================================================
    template.setEnd(end => {

    });  

    // =======================================================================
    // CONFIGURE BEFORE
    // =======================================================================
    template.setBefore(before => {
        var mDatFecha = new Ax.util.Date();
        var mStrUser  = Ax.db.getUser();
        
    	before.addBlockContainer()
            .setPosition("absolute")
            .addBlock(mDatFecha.format("EEEE, d MMMM yyyy HH:mm:ss z",LOCALE)  + ' ('+mStrUser+')').setFontSize(FONT_SIZE).setMarginLeft(0.1)
            .addBlock(DB_NAME).setFontSize(FONT_SIZE).setFontWeight("bold")
            .addBlock("MOVIMENTS D'AJUSTAMENT GENERATS PER FOTO D'ESTOC SGA").setFontSize(FONT_SIZE).setFontWeight("bold");
        
        var mTableComent = before.addTable();
            mTableComent.setSpaceBefore("1.25cm");
            mTableComent.setFontSize(FONT_SIZE);
            mTableComent.addColumn().setColumnWidth(5);  
            mTableComent.addColumn().setColumnWidth(14);  
            mTableComent.setFontFamily(FONT_NAME);  
			
        var mRowComentL = mTableComent.getBody().addRow(); 
        var mcellEtiq = mRowComentL.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);          
        var mcellParam = mRowComentL.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);

        if (pStrCond.toString() !='1=1') {
            pStrCond = pStrCond.toString().split('AND');

            for (const index in pStrCond){
                pStrCond[index] = pStrCond[index].replaceAll(" ","");

                if(pStrCond[index].substr(0, 15) == 'geanmovh.fecmov') {
                    mcellEtiq.addBlock(__getColumnLabel('geanmovh','fecmov',  LOCALE)).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                    mcellParam.addBlock(pStrCond[index].substr(16).replaceAll("'","") || '').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                } 
                else if (pStrCond[index].substr(0, 15) == 'geanmovh.almori') {
                    mcellEtiq.addBlock(__getColumnLabel('geanmovh','almori',  LOCALE)).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                    mcellParam.addBlock(pStrCond[index].substr(16).replaceAll("'","") || '').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                } 
                else if (pStrCond[index].substr(0, 15) == 'geanmovl.codart') {
                    mcellEtiq.addBlock(__getColumnLabel('geanmovl','codart',  LOCALE)).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                    mcellParam.addBlock(pStrCond[index].substr(16).replaceAll("'","") || '').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                }
                else if (pStrCond[index].substr(0, 15) == 'geanmovl.ubiori') {
                    mcellEtiq.addBlock(__getColumnLabel('geanmovl','ubiori',  LOCALE)).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                    mcellParam.addBlock(pStrCond[index].substr(16).replaceAll("'","") || '').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                }
                else if (pStrCond[index].substr(0, 15) == 'geanmovl.ubides') {
                    mcellEtiq.addBlock(__getColumnLabel('geanmovl','ubides',  LOCALE)).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                    mcellParam.addBlock(pStrCond[index].substr(16).replaceAll("'","") || '').setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
                }
            }
        } else {
            mcellEtiq.addBlock(__getColumnLabel('virtualmut','consulta',  LOCALE)).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);
            mcellParam.addBlock(pStrCond).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1); 
        }

                   
    });

    // =======================================================================
    // CONFIGURE BODY
    // =======================================================================
    template.setBody(body => {  
        var mTable = body.addTable();
        mTable.setSpaceBefore("0.3cm");
        mTable.setFontSize(FONT_SIZE);
        mTable.setFontFamily(FONT_NAME);
        mTable.addColumn();

        var mRowL = mTable.getBody().addRow(); 
        
        var mCellPedPorL = mRowL.addCell().setBackgroundColor(BACKCOLOR1).setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
        
        mCellPedPorL.addBlock(__getLabel('HDR_MOV_AJUS_GENE_FOT_STOCK_SGA', LOCALE)).setPaddingBottom("1pt").setPaddingTop("4pt").setMarginLeft(0.1);

		const ColSetWith = {
            total_width : 19,
            total_width_ref : 0,
            columns : {},
            setColumnSizeRef (column, sizeRef) {
                this.columns[column] = sizeRef;
                this.total_width_ref += this.columns[column];
            },
            getColumnSize (column) {
                return (this.total_width_ref ? this.columns[column] / this.total_width_ref * this.total_width : 0)
            }
        };

        ColSetWith.setColumnSizeRef("fecmov", 1.9); //fecmov
        ColSetWith.setColumnSizeRef("almori", 1.9); //almori
        ColSetWith.setColumnSizeRef("tipdoc", 1.9); //tipdoc
        ColSetWith.setColumnSizeRef("ctaori", 1.9); //ctaori
        ColSetWith.setColumnSizeRef("ctades", 1.9); //ctades
        ColSetWith.setColumnSizeRef("codart", 1.9); //codart
        ColSetWith.setColumnSizeRef("terdep", 1.9); //terdep
        ColSetWith.setColumnSizeRef("ubiori", 1.9); //ubiori
        ColSetWith.setColumnSizeRef("ubides", 1.9); //ubides
        ColSetWith.setColumnSizeRef("canmov", 1.9); //canmov


        var mTableLineas = body.addTable();
        mTableLineas.setProperty("font-family", FONT_NAME);
        mTableLineas.setProperty("font-size", FONT_S_TEX);
        mTableLineas.setBorderStyle("solid");
        mTableLineas.setBorderWidth(BORDERWIDTH);
        mTableLineas.setBorderColor(BORDERCOLOR);
            
        mTableLineas.addColumn(__getColumnLabel('geanmovh', 'fecmov', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("fecmov"));
        mTableLineas.addColumn(__getColumnLabel('geanmovh', 'almori', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("almori"));
        mTableLineas.addColumn(__getColumnLabel('geanmovh', 'tipdoc', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("tipdoc"));
        mTableLineas.addColumn(__getColumnLabel('geanmovd', 'ctaori', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("ctaori"));
        mTableLineas.addColumn(__getColumnLabel('geanmovd', 'ctades', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("ctades"));
        mTableLineas.addColumn(__getColumnLabel('geanmovl', 'codart', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("codart"));
        mTableLineas.addColumn(__getColumnLabel('geanmovl', 'terdep', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("terdep"));
        mTableLineas.addColumn(__getColumnLabel('geanmovl', 'ubiori', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("ubiori"));
        mTableLineas.addColumn(__getColumnLabel('geanmovl', 'ubides', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("ubides"));
        mTableLineas.addColumn(__getColumnLabel('geanmovl', 'canmov', LOCALE)).setBorderRightStyle("solid").setBorderWidth(BORDERWIDTH).setColumnWidth(ColSetWith.getColumnSize("canmov"));

        mTableLineas.getHeader().getRows().forEach(row => {
            row.setBackgroundColor(BACKCOLOR2);
            row.forEach(cell => {
                cell.setPadding(PADDING);
                //cell.setFontWeight("bold");
                cell.setBorderBottomStyle("solid");
                cell.setBorderBottomWidth(BORDERWIDTH);
                cell.setBorderBottomColor(BORDERCOLOR);
                cell.setTextAlign("center");
            });
        });
        
        for (var mRow of mArrGeanmovh) {
            
            var row_ld = mTableLineas.getBody().addRow();            
            row_ld.addCell().addBlock(new Ax.sql.Date(mRow.fecmov).format(DATE_FORMAT).toString() || '').setTextAlign('center');
            row_ld.addCell().addBlock(mRow.almori || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.tipdoc || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.ctaori || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.ctades || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.codart || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.terdep || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.ubiori || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.ubides || '').setTextAlign('left');
            row_ld.addCell().addBlock(NumFormat.format(mRow.canmov, "###,##0.00")  || '').setTextAlign('right');
            
            row_ld.forEach(cell => {
                cell.setPadding(PADDING);
                cell.setBorderBottomStyle("solid");
                cell.setBorderBottomWidth("0.5");
            });
        };

    });

    // =======================================================================
    // CONFIGURE AFTER
    // =======================================================================
    template.setAfter(after => {  

        /********************************************/
        /**         Numeración de páginas.          */
        /********************************************/
        var mPageNumberId = after.getRoot().getPageSequence().getTotalPageNumberCitation();
        var mRowNumPag = after.addBlock().setSpaceBefore("0.2cm");
        var mBlockPage = mRowNumPag.addInlineContainer().setWidth("19cm")
                .addBlock().setFontFamily(FONT_NAME).setFontSize(7).setTextAlign("end");
            mBlockPage.addInline().putPageNumber().addText(" - ").putPageNumberCitation(mPageNumberId);     
    });

    // ====================================================================å
    // GENERATE PDF
    // ====================================================================
    var mFop = template.toFOP();
    var mPdf = new Ax.fop.Processor().transform(mFop);
    return mPdf; 
}
