function sga_alb_report_Print(pStrCond, pDatFecini, pDatFecfin) { 

    /** Local function __getLabel()
     * 
     *  Return label for field or box.
     * 
     *  PARAMETERS: 
     *  =============
     *      
     *      @param      {string}       pStrLBL              label.
     *      @param      {string}       pStrLang             Lang
     */
    function __getLabel (pStrLBL, pStrLang) {
        return Ax.ext.webapp.getLabel(pStrLBL, pStrLang);
    }

    /** Local function __getColumnLabel()
     * 
     *  Column label of a table that returns a field or box.
     * 
     *  PARAMETERS: 
     *  =============
     *      
     *      @param      {string}       pStrTable            Table name
     *      @param      {string}       pStrColumn           Column name
     *      @param      {string}       pStrLang             Lang
     */
    function __getColumnLabel (pStrTable, pStrColumn, pStrLang) {
        return Ax.ext.webapp.getColumn(pStrTable,  pStrColumn, pStrLang).getColMemo();
    }
    
	// =========================================================================
    // Load cvenfach data.
    // =========================================================================
    var mArrTables = Ax.db.executeQuery(`
        <select>
            <columns>
                'Suministros' tabname,
                gcommovh.estcab,
                gcommovh.indmod, gcommovh.fecmov fecha,
                gcommovh.docser, gcommovh.tipdoc,
                COUNT(*) numlin
            </columns>
            <from table='gcommovh'>
                <join table='gcommovl'>
                    <on>gcommovh.cabid = gcommovl.cabid</on>
                </join>
            </from>
            <where>
                gcommovh.tipdoc NOT MATCHES 'OR*' AND
                gcommovh.fecmov BETWEEN ${pDatFecini} AND ${pDatFecfin} AND
                ${pStrCond}
            </where>
            <group>1,2,3,4,5,6</group>
        </select> 
    `).toJSONArray();

    // =========================================================================
    // STYLE VARIABLES
    // =========================================================================
    const BACKCOLOR1  = "#FFDD90";
    const BACKCOLOR2  = "#D6DEE7";
    const FONT_SIZE   = 8;
    const PADDING     = '2pt';
    const BORDERCOLOR = '#000000';
	//Se recupera el idioma del cliente, en caso venga informado; si no se toma el idioma del usuario.
    const LOCALE      = Ax.ext.user.getLang() || 'ca';
    const DATE_FORMAT = (LOCALE == "es" || LOCALE == "ca") ? "dd/MM/yyyy" : "MM/dd/yyyy";
    const NumFormat   = new Ax.text.NumberFormat(LOCALE);
    const FONT_S_REG  = 8;
    const FONT_NAME   = "Noto Sans";
    const FONT_S_TEX  = 8;
    const BORDERWIDTH = '1';
    const DB_NAME = 'Grup Mútua Terrassa (Consulta)';

    /**
     * Se inicializa el espacio para el inicio, que se va a ampliar cuando exista comentario del documento.
     */
    var mSpaceBefore = 3;
   
	//Se inicializa el espacio para el bloque final.
    var mSpaceAfter = 2.0;

	/********************************************/
	/**             Inicio del fop.           **/
	/********************************************/	
    var template = new Ax.fop.SinglePageTemplate("A4");

    template.setRoot(root => {
        //root.setDebug("*");
        // Default Page layout    
        root.getSimplePageMaster().getRegionBefore().setExtent(mSpaceBefore);
        root.getSimplePageMaster().getRegionAfter().setExtent(1.0);
        root.getSimplePageMaster().getRegionStart().setExtent(1.0);
        root.getSimplePageMaster().getRegionEnd().setExtent(1.0);
        //root.getSimplePageMaster().setMargins(0, 0, 0, 0);
        
        // Get the FOPSimplePageMaster now (we only have one)
        // after adding the first .. we can not call again
        // cause we have two ... and dont know witch one ..
        var spm       = root.getSimplePageMaster();
        var pageOnly  = root.addSimplePageMaster("PageOnly").apply(spm);
        var pageFirst = root.addSimplePageMaster("PageFirst").apply(spm);
        var pageRest  = root.addSimplePageMaster("PageRest").apply(spm);
        var pageLast  = root.addSimplePageMaster("PageLast").apply(spm);
        
        // In last page we need to acommodate Tax and Notes table. So we requie more space
        pageFirst.setMargins(0, 0, 1.0, 0); //TODO AJUSTAR TOTALES SOLO A LA ÚLTIMA PAGINA
        pageFirst.getRegionAfter().setExtent(2);
        pageRest.setMargins(0, 0, 1.0, 0);
        pageRest.getRegionAfter().setExtent(2);
        pageLast.setMargins(0, 0, 1.0, 0);
        pageLast.getRegionAfter().setExtent(mSpaceAfter);
        pageOnly.setMargins(0, 0, 1.0, 0);
        pageOnly.getRegionAfter().setExtent(mSpaceAfter);
        
        // Create a pagesequence master
        var master = root.createPageSequenceMaster("master");    
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageOnly"),  "only");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageFirst"), "first");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageRest"),  "rest");
        master.addConditionalPageMasterReference(root.getSimplePageMaster("PageLast"),  "last");
        root.addPageSequenceMaster(master);
        root.getPageSequence().setMasterReferenceName("master");

    });

    // =======================================================================
    //  CONFIGURE START                                                        
    // =======================================================================
    template.setStart(start => {

    });

    // =======================================================================
    //  CONFIGURE END
    // =======================================================================
    template.setEnd(end => {

    });

    // =======================================================================
    //  CONFIGURE BEFORE
    // =======================================================================
    template.setBefore(before => {
        var mDatFecha = new Ax.util.Date();
        var mStrUser  = Ax.db.getUser();
        
    	before.addBlockContainer()
            .setPosition("absolute")
            .addBlock(mDatFecha.format("EEEE, d MMMM yyyy HH:mm:ss z",LOCALE)  + ' ('+mStrUser+')').setFontSize(FONT_SIZE).setMarginLeft(0.1)
            .addBlock(DB_NAME).setFontSize(FONT_SIZE).setFontWeight("bold")
            .addBlock(__getLabel('HDR_SIT_SUB_SGA', LOCALE)).setFontSize(FONT_SIZE).setFontWeight("bold");
        
        var mTableComent = before.addTable();
            mTableComent.setSpaceBefore("1.25cm");
            mTableComent.setFontSize(FONT_SIZE);
            mTableComent.addColumn().setColumnWidth(5);  
            mTableComent.addColumn().setColumnWidth(23.7);  
            mTableComent.setFontFamily(FONT_NAME);  
			
        var mRowComentL = mTableComent.getBody().addRow(); 
        var mcellEtiq = mRowComentL.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
            mcellEtiq.addBlock(__getColumnLabel('virtualmut','consulta',  LOCALE)).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);

        var mcellParam = mRowComentL.addCell().setBorderStyle("solid").setBorderWidth(0.5).setBorderColor(BORDERCOLOR);
            mcellParam.addBlock(pStrCond).setPaddingBottom("1pt").setPaddingTop("1pt").setMarginLeft(0.1);        
    });

    // =======================================================================
    //  CONFIGURE BODY
    // =======================================================================
    template.setBody(body => {   
        const ColSetWith = {
            total_width : 19,
            total_width_ref : 0,
            columns : {},
            setColumnSizeRef (column, sizeRef) {
                this.columns[column] = sizeRef;
                this.total_width_ref += this.columns[column];
            },
            getColumnSize (column) {
                return (this.total_width_ref ? this.columns[column] / this.total_width_ref * this.total_width : 0)
            }
        };

        ColSetWith.setColumnSizeRef("tabname", 3.0);    
        ColSetWith.setColumnSizeRef("estcab",  2.0);    
        ColSetWith.setColumnSizeRef("indmod",  2.0);    
        ColSetWith.setColumnSizeRef("fecha'",  2.5);      
        ColSetWith.setColumnSizeRef("docser",  3.0);    
		ColSetWith.setColumnSizeRef("tipdoc",  3.0); 
        ColSetWith.setColumnSizeRef("numlin",  3.5);      

        var mTableLineas = body.addTable();
        mTableLineas.setProperty("font-family", FONT_NAME);
        mTableLineas.setProperty("font-size", FONT_S_TEX);
        mTableLineas.setBorderStyle("solid");
        mTableLineas.setBorderWidth(BORDERWIDTH);
        mTableLineas.setBorderColor(BORDERCOLOR);
            
        mTableLineas.addColumn(__getColumnLabel('virtualmut', 'tabname', LOCALE)).setBorderRightStyle("solid").setColumnWidth(ColSetWith.getColumnSize("tabname"));
        mTableLineas.addColumn(__getColumnLabel('virtualmut', 'estcab',  LOCALE)).setBorderRightStyle("solid").setColumnWidth(ColSetWith.getColumnSize("estcab"));
        mTableLineas.addColumn(__getColumnLabel('mut_gcomforh', 'indmod',  LOCALE)).setBorderRightStyle("solid").setColumnWidth(ColSetWith.getColumnSize("indmod"));
        mTableLineas.addColumn(__getColumnLabel('virtualmut', 'fecha',   LOCALE)).setBorderRightStyle("solid").setColumnWidth(ColSetWith.getColumnSize("fecha"));
        mTableLineas.addColumn(__getColumnLabel('virtualmut', 'docser',  LOCALE)).setBorderRightStyle("solid").setColumnWidth(ColSetWith.getColumnSize("docser"));
		mTableLineas.addColumn(__getColumnLabel('virtualmut', 'tipdoc',  LOCALE)).setBorderRightStyle("solid").setColumnWidth(ColSetWith.getColumnSize("docser"));
        mTableLineas.addColumn(__getColumnLabel('virtualmut', 'numlin',  LOCALE)).setBorderRightStyle("solid").setColumnWidth(ColSetWith.getColumnSize("numlin"));
        
        mTableLineas.getHeader().getRows().forEach(row => {
            row.setBackgroundColor(BACKCOLOR2);
            row.forEach(cell => {
                cell.setPadding(PADDING);
                cell.setFontWeight("bold");
                cell.setBorderBottomStyle("solid");
                cell.setBorderBottomWidth(BORDERWIDTH);
                cell.setBorderBottomColor(BORDERCOLOR);
                cell.setTextAlign("center");
            });
        });
        
        for (var mRow of mArrTables) {
            
            var row_ld = mTableLineas.getBody().addRow();
            row_ld.addCell().addBlock(mRow.tabname || '').setTextAlign('left');

            var estcab = Ax.ext.webapp.getRenderMapData(
                'gcommovh', 
                'estcab', 
                LOCALE
            ).get(mRow.estcab);

            row_ld.addCell().addBlock(estcab || '').setTextAlign('left');

            var indmod = Ax.ext.webapp.getRenderMapData(
                'gcommovh', 
                'indmod', 
                LOCALE
            ).get(mRow.indmod);

            row_ld.addCell().addBlock(indmod || '').setTextAlign('left');            
            row_ld.addCell().addBlock(new Ax.sql.Date(mRow.fecha).format(DATE_FORMAT).toString() || '').setTextAlign('center');
            row_ld.addCell().addBlock(mRow.docser || '').setTextAlign('left');
			row_ld.addCell().addBlock(mRow.tipdoc || '').setTextAlign('left');
            row_ld.addCell().addBlock(mRow.numlin || '').setTextAlign('left');

            row_ld.forEach(cell => {
                cell.setPadding(PADDING);
                cell.setBorderBottomStyle("solid");
                cell.setBorderBottomWidth("0.5");
            });
        };        
    });

    // =======================================================================
    //  CONFIGURE AFTER
    // =======================================================================
    template.setAfter(after => {  
    
    });

    // ====================================================================
    // GENERATE PDF
    // ====================================================================
    var mFop = template.toFOP();
    var mPdf = new Ax.fop.Processor().transform(mFop);
    return mPdf; 
}