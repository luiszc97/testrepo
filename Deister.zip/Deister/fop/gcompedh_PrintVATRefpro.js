/** 
 *  Copyright (c) 1988 - PRESENT deister software, All Rights Reserved. 
 *  
 *  All information contained herein is, and remains the property of deister software. 
 *  The intellectual and technical concepts contained herein are proprietary to 
 *  deister software and may be covered by trade secret or copyright law. 
 *  Dissemination of this information or reproduction of this material is strictly 
 *  forbidden unless prior written permission is obtained from deister software. 
 *  Access to the source code contained herein is hereby forbidden to anyone except 
 *  current deister software employees, managers or contractors who have executed 
 * "Confidentiality and Non-disclosure" agreements explicitly covering such access. 
 *  The copyright notice above does not evidence any actual or intended publication 
 *  for disclosure of this source code, which includes information that is confidential 
 *  and/or proprietary, and is a trade secret, of deister software. 
 * 
 *  ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE, 
 *  OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT THE 
 *  EXPRESS WRITTEN CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION 
 *  OF APPLICABLE LAWS AND INTERNATIONAL TREATIES.THE RECEIPT OR POSSESSION OF 
 *  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY 
 *  RIGHTS TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, 
 *  USE, OR SELL ANYTHING THAT IT MAY DESCRIBE, IN WHOLE OR IN PART. 
 * ----------------------------------------------------------------------------- 
 * 
 *    JS: gcompedh_PrintVATRefpro
 * 
 *      @version:       V1.0
 *      @since:         2024.12.23
 *      @description:   
 *
 *    LOCAL FUNCTIONS:
 *    ================
 * 
 *    CALLED FROM:
 *    ================
 *      Objet:      gcompedh       Print
 * 
 *    PARAMETERS:
 *    ================
 *      @param      {Integer}       pIntCabid       Serial of row
 *      @param      {Boolean}       pBoolImgcorp    Indicator to include image
 *      @param      {Boolean}       pBoolLikeCopy   Indicator of watermark
 *
 *      @returns    {PDF}                           Document PDF
 */
function gcompedh_PrintVATRefpro(pIntCabid, pBoolImgcorp, pBoolLikeCopy) {

   /**
    * The header data is obtained.
    */
    let mObjGcompedh = Ax.db.executeQuery(`
        <select oracle='ansi'>
            <columns>
                gcompedh.cabid, gcompedd.hide_codbar, gcompedh.codalm,

                'RAZÓN SOCIAL: ' || <trim>ctercero4.nombre</trim> || ' · ' || cterdire4.direcc || ' · '
                || <trim><nvl>cterdire4.codpos, ''</nvl></trim> || ' ' || <trim><nvl>cterdire4.poblac, ''</nvl></trim>
                || ' TEL. ' || <trim><nvl>cterdire4.telef1, ''</nvl></trim> || ' · '
                || 'FAX. ' || <trim><nvl>cterdire4.fax1, ''</nvl></trim> <alias name='poblac' />,
                <trim><nvl>cempresa.regmer , ' '</nvl></trim> || ' · ' || <trim><nvl>ctercero4.cif, ' '</nvl></trim> <alias name='cif' />,
                <trim><nvl>cterdire4.web, ' '</nvl></trim> || ' · TEL ' || <trim><nvl>cterdire4.telef1, ' '</nvl></trim>  || ' · MAIL: ' ||
                <trim><nvl>cterdire4.email, ' '</nvl></trim> <alias name='telef1' />,

                gdelegac.codigo, gdelegac.img_logo,
                CASE WHEN gdelegac.img_logo IS NOT NULL THEN 1
                    ELSE 0
                END <alias name='has_logo'/>,

                gcompedh.delega, gcompedh.nommos <alias name='nombre2' />, gcompedh.direcc <alias name='direcc2' />,
                <trim><nvl>gcompedh.codpos, ''</nvl></trim> || ' ' || <trim><nvl>gcompedh.poblac, ''</nvl></trim> <alias name='poblac2' />,
                gcompedh.nomprv <alias name='nomprv2' />, gcompedh.nomnac <alias name='nomnac2' />,
                'Tel.: ' || <trim><nvl>gcompedh.telef1, ''</nvl></trim> || ' - ' ||
                'Fax.: ' || <trim><nvl>gcompedh.fax, ''</nvl></trim> <alias name='telef2' />,

                <trim><nvl>cterdire3.empres, <nvl>ctercero3.nombre, ''</nvl></nvl></trim> <alias name='nombre3' />,
                cterdire3.direcc <alias name='direcc3' />,
                <trim><nvl>cterdire3.codpos, ''</nvl></trim> || ' ' || <trim><nvl>cterdire3.poblac,''</nvl></trim> <alias name='poblac3' />,
                cprovinc3.nomprv <alias name='nomprv3' />, ctiponac3.nomnac <alias name='nomnac3' />, 'NIF: ' || ctercero3.cif <alias name='cif3' />,
                'Tel.: ' || <trim><nvl>cterdire3.telef1, ''</nvl></trim> || ' - ' ||
                'Fax.: ' || <trim><nvl>cterdire3.fax1, ''</nvl></trim> <alias name='telef3' />,
                cterdire3.zonimp,cterdire3.idioma,

                <trim><nvl>ctercero4.nombre,''</nvl></trim> <alias name='nombre4' />,
                cterdire4.direcc <alias name='direcc4' />,
                <trim><nvl>cterdire4.codpos, ''</nvl></trim> || ' ' || <trim><nvl>cterdire4.poblac,''</nvl></trim> <alias name='poblac4' />,
                cprovinc4.nomprv <alias name='nomprv4' />, ctiponac4.nomnac <alias name='nomnac4' />, 'NIF: ' || ctercero4.cif <alias name='cif4' />,
                'Tel.: ' || <trim><nvl>cterdire4.telef1, ''</nvl></trim> || ' - ' ||
                'Fax.: ' || <trim><nvl>cterdire4.fax1, ''</nvl></trim> <alias name='telef4' />,

                ctercero5.nombre <alias name='nombre5' />, cterdire5.direcc <alias name='direcc5' />,
                <trim><nvl>cterdire5.codpos, ''</nvl></trim> || ' ' || <trim><nvl>cterdire5.poblac, ''</nvl></trim> <alias name='poblac5' />,
                cprovinc5.nomprv <alias name='nomprv5' />, ctiponac5.nomnac <alias name='nomnac5' />,
                'Tel.: ' || <trim><nvl>cterdire5.telef1, ''</nvl></trim> || ' - ' ||
                'Fax.: ' || <trim><nvl>cterdire5.fax1, ''</nvl></trim> <alias name='telef5' />,

                gcompedh.docser, gcompedh.fecha,  gcompedh.portes, gcompedh.fecini,
                gcompedh.fecfin, gcompedh.horpre, gcompedh.dtopp,  gcompedh.dtogen,
                gcompedh.tercer, gcompedh.tipdir, gcompedh.terenv, gcompedh.tipdoc,
                gcompedh.direnv, gcompedh.coment, gcompedh.imptot totped,
                gproveed.impref, gcompedh.empcode, cempresa.empname, gcompedh.divisa,
                gcompedh.estcab, gcompedh.doclock,

                (SELECT COUNT(*) FROM gcompedl WHERE gcompedl.cabid = gcompedh.cabid AND gcompedl.dtoli1 != 0 ) <alias name='count_dtolin' />,
                CASE WHEN gproveed.copfac IS NULL OR gproveed.copfac = 0
                    THEN 1
                    ELSE gproveed.copfac
                END <alias name='print_num_copies' />,

                cempresa_print_settings.logo_top_image,     cempresa_print_settings.font_name, 
                cempresa_print_settings.color_primary,      cempresa_print_settings.color_secondary,
                cempresa_print_settings.text_region_start,  cempresa_print_settings.text_region_end,
                cempresa_print_settings.text_region_after,

                (SELECT COUNT(*)
                  FROM gcompedh
                 WHERE cabid = ${pIntCabid}
                   AND NOT EXISTS (SELECT gcomdatp.cabid FROM gcomdatp WHERE tabori = 'gcompedh' AND cabid = ${pIntCabid})) auth_line1,
                
                (SELECT COUNT(*)
                   FROM gcomdatp
                  WHERE cabid  = ${pIntCabid}
                    AND tabori = 'gcompedh') auth_line2,

                (SELECT COUNT(*)                                                                                          
                   FROM gcompedh                                                                                          
                  WHERE gcompedh.cabid = ${pIntCabid}                                                                           
                    AND (EXISTS (SELECT *                                                                                 
                                   FROM gcompedh_note, gdoctype                                                             
                                  WHERE gcompedh_note.tipnot = gdoctype.codigo                                             
                                    AND gdoctype.impnot = 'C'                                                              
                                    AND gcompedh_note.cabid = ${pIntCabid}                                                      
                                    AND gcompedh_note.linid IS NULL)                                                       
                     OR (SELECT COUNT(*) FROM gcompedh WHERE gcompedh.cabid = ${pIntCabid} AND gcompedh.coment IS NOT NULL) > 0)) auth_notas
            </columns>
            <from table='gcompedh'>
                <join table='gcompedd'>
                    <on>gcompedh.tipdoc = gcompedd.codigo</on>
                </join>
                <join table='gproveed'>
                    <on>gcompedh.tercer = gproveed.codigo</on>
                </join>
                <join table='gdelegac'>
                    <on>gcompedh.delega = gdelegac.codigo</on>            
                </join>
                <join  type='left' table='ctercero' alias='ctercero5'>
                    <on>gdelegac.tercer = ctercero5.codigo</on>                     
                </join>
                <join type='left' table='cterdire' alias='cterdire5'>
                    <on>ctercero5.codigo = cterdire5.codigo</on> 
                    <on>cterdire5.tipdir = gdelegac.dirdlg</on>              
                </join>
                <join type='left' table='ctiponac' alias='ctiponac5'>
                    <on>cterdire5.codnac = ctiponac5.codigo</on>
                </join>
                <join type='left' table='cprovinc' alias='cprovinc5'>
                    <on>cterdire5.codnac = cprovinc5.codnac</on>
                    <on>cterdire5.codprv = cprovinc5.codigo</on>
                </join>
                <join type='left' table='cempresa'>
                    <on>gcompedh.empcode = cempresa.empcode</on> 
                    <join type='left' table='cempresa_print_settings'>
                        <on>cempresa.empcode = cempresa_print_settings.empcode</on>
                    </join>           
                </join>
                <join type='left' table='ctercero' alias='ctercero4'>
                    <on>cempresa.tercer = ctercero4.codigo</on>
                </join>
                <join type='left' table='cterdire' alias='cterdire4'>
                    <on>ctercero4.codigo = cterdire4.codigo</on> 
					<on>cterdire4.tipdir = (select min(tipdir) from cterdire)</on>       
                </join>
                <join type='left' table='ctiponac' alias='ctiponac4'>
                    <on>cterdire4.codnac = ctiponac4.codigo</on>
                </join>
                <join type='left' table='cprovinc' alias='cprovinc4'>
                    <on>cterdire4.codnac = cprovinc4.codnac</on>
                    <on>cterdire4.codprv = cprovinc4.codigo</on>
                </join>
                <join  type='left' table='ctercero' alias='ctercero3'>
                    <on>gcompedh.tercer = ctercero3.codigo</on>            
                </join>
                <join type='left' table='cterdire' alias='cterdire3'>
                    <on>ctercero3.codigo = cterdire3.codigo</on>
                    <on>cterdire3.tipdir = gcompedh.tipdir</on>
                </join>
                <join type='left' table='ctiponac' alias='ctiponac3'>
                    <on>cterdire3.codnac = ctiponac3.codigo</on>
                </join>
                <join type='left' table='cprovinc' alias='cprovinc3'>
                    <on>cterdire3.codnac = cprovinc3.codnac</on>
                    <on>cterdire3.codprv = cprovinc3.codigo</on>
                </join>
                <join type='left' table='ctipoefe'>
                    <on>gcompedh.tipefe = ctipoefe.codigo</on>
                    <on>ctipoefe.clase  = 'P'</on>
                </join>
                <join type='left' table='ctipopag'>
                    <on>gcompedh.frmpag = ctipopag.codigo</on>
                </join>
            </from>
            <where>
                gcompedh.cabid = ?
            </where>
        </select>
    `, 
        pIntCabid
    ).toOne();

    /**
     * Lines data
     */
    

    let mArrGcompedl = [];

    if (mObjGcompedh.auth_line1) {
        mArrGcompedl = Ax.db.executeQuery(`
            <select oracle='ansi'>
                <columns>
                    gcompedl.cabid,
                    gcompedl.linid,

                    CASE WHEN '${mObjGcompedh.impref}' = 'N' 
                    THEN ''
                    ELSE gartprov_get_refpro('${mObjGcompedh.tercer}','${mObjGcompedh.codalm}', gcompedl.codart, gcompedl.varlog, gcompedl.udmcom)
                    END <alias name='refpro'/>,

                    CASE WHEN gdoctext.data IS NOT NULL OR gdoctext2.data IS NOT NULL
                    THEN ''
                    ELSE gartprov_print_despro('${mObjGcompedh.tercer}', '${mObjGcompedh.impref}','${mObjGcompedh.codalm}', gcompedl.codart, gcompedl.varlog, gcompedl.udmcom, <nvl>gcompedl.desvar, garticul.nomart</nvl>)
                    END <alias name='nomart'/>,

                    gcompedl.codart, gcompedl.varlog,

                    TRUNC(gcompedl.canped) <alias name='canped' />,

                    <trim>gcompedl.udmcom</trim> ||
                    CASE WHEN gartvarl.unicon > 1
                        THEN ' (' || <char>gartvarl.unicon</char> || ')'
                        ELSE <whitespace />
                    END ||

                    CASE WHEN gart_uniconv.reldes > 1  AND gart_uniconv.reldes IS NOT NULL
                        THEN ' (' || <char>gart_uniconv.reldes</char> || ')'
                        ELSE <whitespace />
                    END udmcom,

                    ROUND(gcompedl.precio * gcompedl.canpre / CASE WHEN gcompedl.canped = 0
                                                                THEN 1
                                                                ELSE gcompedl.canped
                                                            END , 4) <alias name='precio' />,
                    gcompedl.impnet,
                    TRUNC(garticul_get_tax_porcen('gcompedh',gcompedl.cabid, gcompedl.linid, '${mObjGcompedh.tipdoc}', NULL, NULL,
                                                            ${mObjGcompedh.fecha}, ${mObjGcompedh.fecha}, '${mObjGcompedh.empcode}', '${mObjGcompedh.delega}', NULL,
                                                            '${mObjGcompedh.tercer}',NULL, NULL, '${mObjGcompedh.tipdir}', NULL, gcompedl.codart)) tax_code
                </columns>
                <from table='gcompedl'>
                    <join table='garticul'>
                        <on>gcompedl.codart = garticul.codigo</on>
                    </join>
                    <join type='left' table='gdoctext' alias='gdoctext2'>
                        <on>garticul.desamp = gdoctext2.txtid</on>
                    </join>
                    <join type='left' table='gdoctext'>
                        <on>gcompedl.desamp = gdoctext.txtid</on>
                    </join>
                    <join type='left' table='gartprov'>
                        <on>gcompedl.codart = gartprov.codart</on>
                        <on><nvl>gcompedl.varlog, <whitespace /></nvl> = <nvl>gartprov.varlog, <whitespace /></nvl></on>
                        <on>gartprov.codpro = '${mObjGcompedh.tercer}'</on>
                        <on>gcompedl.udmcom = gartprov.udmcom</on>
                    </join>
                    <join type="left" table="gartvarl">
                        <on>gcompedl.codart = gartvarl.codart</on>
                        <on>gcompedl.varlog = gartvarl.varlog</on>
                    </join>
                    <join type='left' table='gart_unidefs'>
                        <on>gcompedl.codart = gart_unidefs.codart</on>
                        <on>gcompedl.udmcom = gart_unidefs.coduni</on>
                    </join>
                    <join type='left' table='gart_uniconv'>
                        <on>gart_unidefs.codart = gart_uniconv.codart</on>
                        <on>gart_unidefs.coduni = gart_uniconv.udmori</on>
                        <on>garticul.udmbas = gart_uniconv.udmdes</on>
                    </join>
                </from>
                <where>
                    gcompedl.cabid = ${pIntCabid}
                </where>
                <order>2,3</order>
            </select>  
        `).toMemory();
    } else if (mObjGcompedh.auth_line2) {
        let mTmpGcompedl = Ax.db.getTempTableName('tmp_gcompedl');
        Ax.db.execute(`DROP TABLE IF EXISTS ${mTmpGcompedl}`);

        Ax.db.execute(`
            <union type='all' >         
                <select oracle='ansi'>
                    <columns>
                        1 ordre,
                        gcompedl.cabid,
                        gcompedl.linid,
                        CASE WHEN '${mObjGcompedh.impref}' = 'N'
                        THEN ''
                        ELSE gartprov_get_refpro('${mObjGcompedh.tercer}','${mObjGcompedh.codalm}', gcompedl.codart, gcompedl.varlog, gcompedl.udmcom)
                        END <alias name='refpro'/>,
                        CASE WHEN gdoctext.data IS NOT NULL OR gdoctext2.data IS NOT NULL
                        THEN ''
                        ELSE gartprov_print_despro('${mObjGcompedh.tercer}', '${mObjGcompedh.impref}','${mObjGcompedh.codalm}', gcompedl.codart, gcompedl.varlog, gcompedl.udmcom, <nvl>gcompedl.desvar, garticul.nomart</nvl>)
                        END <alias name='nomart'/>,
                        gcompedl.codart, gcompedl.varlog,
                        TRUNC(gcompedl.canped) <alias name='canped' />,
                        <trim>gcompedl.udmcom</trim> ||
                        CASE WHEN gartvarl.unicon > 1
                            THEN ' (' || <char>gartvarl.unicon</char> || ')'
                            ELSE <whitespace />
                        END ||
                        CASE WHEN gart_uniconv.reldes > 1  AND gart_uniconv.reldes IS NOT NULL
                            THEN ' (' || <char>gart_uniconv.reldes</char> || ')'
                            ELSE <whitespace />
                        END udmcom,
                        ROUND(gcompedl.precio * gcompedl.canpre / CASE WHEN gcompedl.canped = 0
                                                                    THEN 1
                                                                    ELSE gcompedl.canped
                                                                END , 4) <alias name='precio' />,
                        gcompedl.impnet,
                        TRUNC(garticul_get_tax_porcen('gcompedh',gcompedl.cabid, gcompedl.linid, '${mObjGcompedh.tipdoc}', NULL, NULL,
                                                            ${mObjGcompedh.fecha}, ${mObjGcompedh.fecha}, '${mObjGcompedh.empcode}', '${mObjGcompedh.delega}', NULL,
                                                            '${mObjGcompedh.tercer}',NULL, NULL, '${mObjGcompedh.tipdir}', NULL, gcompedl.codart)) tax_code
                    </columns>
                    <from table='gcompedl'>
                        <join table='garticul'>                         
                            <on>gcompedl.codart = garticul.codigo</on>
                        </join>
                        <join type='left' table='gdoctext' alias='gdoctext2'>
                            <on>garticul.desamp = gdoctext2.txtid</on>
                        </join>
                        <join type='left' table='gdoctext'>
                            <on>gcompedl.desamp = gdoctext.txtid</on>
                        </join>
                        <join type='left' table='gartprov'>
                            <on>gcompedl.codart = gartprov.codart</on>
                            <on><nvl>gcompedl.varlog, <whitespace /></nvl> = <nvl>gartprov.varlog, <whitespace /></nvl></on>
                            <on>gartprov.codpro = '${mObjGcompedh.tercer}'</on>
                            <on>gcompedl.udmcom = gartprov.udmcom</on>
                        </join>
                        <join type="left" table="gartvarl">
                            <on>gcompedl.codart = gartvarl.codart</on>
                            <on>gcompedl.varlog = gartvarl.varlog</on>
                        </join>
                        <join type='left' table='gart_unidefs'>
                            <on>gcompedl.codart = gart_unidefs.codart</on>
                            <on>gcompedl.udmcom = gart_unidefs.coduni</on>                            
                        </join>
                        <join type='left' table='gart_uniconv'>
                            <on>gart_unidefs.codart = gart_uniconv.codart</on>
                            <on>gart_unidefs.coduni = gart_uniconv.udmori</on>
                            <on>garticul.udmbas = gart_uniconv.udmdes</on>
                        </join>
                    </from>
                    <where>
                        gcompedl.cabid = ${pIntCabid}
                    </where>
                </select> 
                <select intotemp='${mTmpGcompedl}'>
                    <columns>
                            2,
                            gcompedl.cabid,
                            gcompedl.linid,
                            NULL::VARCHAR,
                            gcomdatp_get_print_lbl('es', 
                                                    <nvl>gcomdatp.num_hc, gcomdatp2.num_hc</nvl>, 
                                                    <nvl>gcomdatp.numtor, gcomdatp2.numtor</nvl>, 
                                                    <nvl>gcomdatp.feccad, gcomdatp2.feccad</nvl>, 
                                                    <nvl>gcomdatp.lotart, gcomdatp2.lotart</nvl>, 
                                                    <nvl>gcomdatp.numpol, gcomdatp2.numpol</nvl>, 
                                                    <nvl>gcomdatp.numaut,gcomdatp2.numaut</nvl>, 
                                                    <nvl>gcomdatp.numser,gcomdatp2.numser</nvl>) nomart,
                            NULL::CHAR,
                            NULL::CHAR,
                            NULL::DECIMAL,
                            NULL::CHAR,
                            NULL::DECIMAL(16,4),
                            NULL::DECIMAL,
                            NULL::DECIMAL
                    </columns>
                    <from table="gcompedl">
                        <join type='left' table='gcomdatp'>
                            <on>gcomdatp.linid  = gcompedl.linid</on>
                            <on>gcomdatp.tabori = 'gcompedh'</on>
                        </join>
                        <join type='left' table='gcomdatp' alias='gcomdatp2'>
                            <on>gcomdatp2.cabid  = gcompedl.cabid</on>
                            <on>gcomdatp2.tabori = 'gcompedh'</on>
                            <on>gcomdatp2.linid  IS NULL</on>
                        </join>
                    </from>
                    <where>
                        gcompedl.cabid = ${pIntCabid}
                    </where>
                </select>
            </union> 
        `)

        mArrGcompedl = Ax.db.executeQuery(`
            <select>
                <columns>*</columns>
                <from table='${mTmpGcompedl}'/>
                <order>2,3,1</order>
            </select>    
        `).toMemory();
    };

    /**
     * Notas
     */
    let mArrNotas = Ax.db.executeQuery(`
        <union type='all'>
            <select>
                <columns>
                    'NOTA' <alias name='notac' />, gcompedh_note.data <alias name='notah' />
                </columns>
                <from table="gcompedh_note">
                    <join table="gdoctype">
                        <on>gcompedh_note.tipnot = gdoctype.codigo</on>
                    </join>
                </from>
                <where>
                    gcompedh_note.cabid = ${pIntCabid} AND
                    gcompedh_note.linid IS NULL  AND
                    gdoctype.impnot     = 'C'
                </where>
            </select>            
            <select>
                <columns>
                    'COMENTARIO' <alias name='notac' />, gcompedh.coment <alias name='notah' />
                </columns>
                <from table="gcompedh" />
                <where>
                    gcompedh.cabid = ${pIntCabid} AND
                    gcompedh.coment IS NOT NULL
                </where>
                <order>notac</order>
            </select>
        </union>
    `).toMemory();
    
    
    /**
     * Print settings
     */    
    let mStrLocale = mObjGcompedh.print_lang ?? Ax.ext.user.getLang() ?? 'es';
    const print = Ax.db.call("gdocument_GetPrint");
    print.setLang(mStrLocale);
    const NumFormat   = new Ax.text.NumberFormat(mStrLocale);
    print.setPrintSettings(mObjGcompedh.empcode);
    print.FONT_SIZE_BODY = '8.5';
    print.BORDER_WIDTH   = '1';

    const VALID_PRINT = (mObjGcompedh.estcab == "V" &&
                            (!mObjGcompedh.doclock || mObjGcompedh.doclock.indexOf('P') == -1)
                            );


    /**
     * text_data
     */
    let mCountText = Ax.db.executeGet(`
        <select>
            <columns>
                COUNT(*)
            </columns>
            <from table="cdoctext" />
            <where>
                cdoctext.tabname   = 'gcompedh' AND
                cdoctext.text_code = 'gcompedh_print_iva' AND
                cdoctext.idioma    = ?
            </where>
        </select>
    `, mStrLocale);

    let mArrTextData

    if (mCountText) {
        mArrTextData = Ax.db.executeQuery(`
            <select>
                <columns>
                    cdoctext.text_data
                </columns>
                <from table="cdoctext" />
                <where>
                    cdoctext.tabname   = 'gcompedh' AND
                    cdoctext.text_code = 'gcompedh_print_iva' AND
                    cdoctext.idioma    = ?
                </where>
            </select>
        `, mStrLocale).toMemory();
    }

    let mObjImpues = Ax.db.executeQuery(`
        <select>
            <columns>
                gcompedh_tax.tax_porcen,
                gcompedh_tax.tax_quote
            </columns>
            <from table='gcompedh_tax' />
            <where>
                gcompedh_tax.cabid = ?
            </where>
        </select>    
    `, pIntCabid).toOne();

    let mObjLinTotal = Ax.db.executeQuery(`
        <select>
            <columns>
                'TOTAL ' || '${mObjGcompedh.divisa}' <alias name='divisa' />,
                ROUND(SUM(gcompedl.impnet + gcompedl.impnet / 100 *
                TRUNC(garticul_get_tax_porcen('gcompedh',gcompedl.cabid, gcompedl.linid, '${mObjGcompedh.tipdoc}', NULL, NULL,
                                                                ${mObjGcompedh.fecha}, ${mObjGcompedh.fecha}, '${mObjGcompedh.empcode}', '${mObjGcompedh.delega}', NULL,
                                                                '${mObjGcompedh.tercer}',NULL, NULL, '${mObjGcompedh.tipdir}', NULL, gcompedl.codart))),2) total   

                
            </columns>
            <from table='gcompedl' />
            <where>
                gcompedl.cabid = ?
            </where>
        </select>
    `, pIntCabid).toOne();


    /**
     * Space Settings
     */
    let mSpaceBefore = 15;
    let mSpaceAfter  = 6;

    /*--------------------------------------------------------------------------------------------------------------*/
	/*										              HEADER												    */
	/*--------------------------------------------------------------------------------------------------------------*/
	/*      ┌-------------------------------------------┐       ┌-------------------------------------------┐       */
	/*      |								 			|       |				 COMPANY DATA               |       */
	/*      |								 			|       |	nombre					                |       */
	/*      |								 			|       |	                                        |       */
	/*      |								 			|       |	direcc   				                |       */
	/*      |								 			|       |	    					                |       */
	/*      |	  IMAGEN (COMPANIA LOGO || DB LOGO) 	|       |	poblac	        		                |       */
	/*      |								 			|       |							                |       */
	/*      |								 			|       |	nomprv					                |       */
	/*      |								 			|       |							                |       */
	/*      |								 			|       |	nomnac					                |       */
	/*      |								 			|       |							                |       */
	/*      |								 			|       |	NIF :    abbr_taxpayer_id_c             |       */
	/*      |								 			|       |							                |       */
	/*      |								 			|       |	Tel: abbr_phone_c - Fax:  abbr_fax_c    |       */
	/*      |								 			|       |							                |       */
	/*      └-------------------------------------------┘       └-------------------------------------------┘       */
	/*      ┌-------------------------------------------┐       ┌-------------------------------------------┐       */
	/*      |				 ENTREGAR EN                |       |				 PROVEEDOR                  |       */
	/*      |   nombre2					                |       |	nombre3					                |       */
	/*      |                                           |       |	                                        |       */
	/*      |   direcc2   				                |       |	direcc3   				                |       */
	/*      |       					                |       |	    					                |       */
	/*      |   poblac2	        		                |       |	poblac3	        		                |       */
	/*      |   						                |       |							                |       */
	/*      |   nomprv2				    	            |       |	nomprv3                                 |       */
	/*      |   						                |       |							                |       */
    /*      |   nomnac2                                 |       |	nomnac3                                 |       */
    /*      |   						                |       |							                |       */
    /*      |                                           |       |	NIF :    abbr_taxpayer_id_c3            |       */
    /*      |   						                |       |							                |       */
	/*      |   Tel: abbr_phone_c2   Fax: abbr_fax_c2   |       |	Tel: abbr_phone_c3  Fax: abbr_fax_c3    |       */
	/*      |								 			|       |							                |       */
	/*      └-------------------------------------------┘       └-------------------------------------------┘       */
	/*      ┌-------------------------------------------┐       ┌-------------------------------------------┐       */
	/*      | docser      |	    fecha    |  portes      |       |	fecini	  |	  fecfin    | 	horpre	    |       */
	/*      |___________________________________________|       |_____________|_____________|_______________|       */
	/*--------------------------------------------------------------------------------------------------------------*/
	/*										              BODY												        */
	/*--------------------------------------------------------------------------------------------------------------*/
	/*      ┌-----------------------------------------------------------------------------------------------┐       */
	/*      |                                         LINEAS                                                |       */
	/*      | codart | nomart | codnem | varlog | canped | udmcom | precio | dtoli1 |   dtoli2 |    impnet  |       */
	/*      |-----------------------------------------------------------------------------------------------|       */
    /*      |	     |    	  |   	   |        |     	 |		  |		   |	    |           |           |       */
	/*      └-----------------------------------------------------------------------------------------------┘       */
	/*      ┌-----------------------------------------------------------------------------------------------┐       */
	/*      |                                           NOTAS                                               |       */
	/*      |-----------------------------------------------------------------------------------------------|       */
    /*      |	                                        notah                                               |       */
	/*      └-----------------------------------------------------------------------------------------------┘       */   
	/*      ┌-----------------------------------------------------------------------------------------------┐       */
	/*      |                                           TEXT                                                |       */
	/*      |-----------------------------------------------------------------------------------------------|       */
    /*      |	                                      text_data                                             |       */
	/*      └-----------------------------------------------------------------------------------------------┘       */      
	/*--------------------------------------------------------------------------------------------------------------*/
	/*										           AFTER												        */
	/*--------------------------------------------------------------------------------------------------------------*/
	/*                                                            ┌-------------------------------------------┐     */
	/*                                                            |	totped                                    |     */
	/*                                                            |	                                          |     */
	/*                                                            |	tax_porcen                tax_quote       |     */
	/*                                                            └-------------------------------------------┘     */
	/*                                                            ┌-------------------------------------------┐     */
	/*                                                            |	divisa                    total           |     */
	/*                                                            └-------------------------------------------┘     */   
    /*                                                                                                              */
    /*                                               poblac                                                         */
    /*                                                cif                                                           */
    /*                                               telef1                                                         */
    /*                                                                                                Pag 1-1       */
	/*--------------------------------------------------------------------------------------------------------------*/
	/*--------------------------------------------------------------------------------------------------------------*/
	/*--------------------------------------------------------------------------------------------------------------*/
	/*--------------------------------------------------------------------------------------------------------------*/
    let template = new Ax.fop.SinglePageTemplate("A4");

    // =======================================================================
    // CONFIGURE FOP ROOT LAYOUT
    // =======================================================================
    template.setRoot(root => {
        //root.setDebug("*");
        // Default Page layout
        root.getSimplePageMaster().getRegionBefore().setExtent(mSpaceBefore);
        root.getSimplePageMaster().getRegionAfter().setExtent(mSpaceAfter);
        root.getSimplePageMaster().getRegionStart().setExtent(1.0);
        root.getSimplePageMaster().getRegionEnd().setExtent(1.0);
        root.getSimplePageMaster().setMargins(0, 0, 0, 0);

        // Get the FOPSimplePageMaster now (we only have one)
        // after adding the first .. we can not call again
        // cause we have two ... and dont know witch one ..
        let spm       = root.getSimplePageMaster();
        let pageOnly  = root.addSimplePageMaster("PageOnly").apply(spm);
        let pageFirst = root.addSimplePageMaster("PageFirst").apply(spm);
        let pageRest  = root.addSimplePageMaster("PageRest").apply(spm);
        let pageLast  = root.addSimplePageMaster("PageLast").apply(spm);

        // In last page we need to acommodate Tax and Notes table. So we requie more space
        pageFirst.setMargins(0, 0, 1.0, 0);
        pageFirst.getRegionAfter().setExtent(2);
        pageRest.setMargins(0, 0, 1.0, 0);
        pageRest.getRegionAfter().setExtent(2);
        pageLast.setMargins(0, 0, 1.0, 0);
        pageLast.getRegionAfter().setExtent(mSpaceAfter);
        pageOnly.setMargins(0, 0, 1.0, 0);
        pageOnly.getRegionAfter().setExtent(mSpaceAfter);

        // Create a pagesequence master
        let master = root.createPageSequenceMaster("master");
            master.addConditionalPageMasterReference(root.getSimplePageMaster("PageOnly"),  "only");
            master.addConditionalPageMasterReference(root.getSimplePageMaster("PageFirst"), "first");
            master.addConditionalPageMasterReference(root.getSimplePageMaster("PageRest"),  "rest");
            master.addConditionalPageMasterReference(root.getSimplePageMaster("PageLast"),  "last");
            root.addPageSequenceMaster(master);
            root.getPageSequence().setMasterReferenceName("master");
    });
    
    // =======================================================================
    // SET START REGION CONTENT
    // =======================================================================
    template.setStart(start => {
        // Texto izquierda de página para todos los tipos de página
        if (print.TEXT_REGION_START) {
            start.addBlockContainer().setTop("0.3cm").setPosition("absolute").addBlock(print.TEXT_REGION_START)
                .setTextAlign('center')
                .setFontSize(8);
        }
    });

    // =======================================================================
    // SET END REGION CONTENT
    // =======================================================================
    template.setEnd(end => {
        // Texto izquierda de página para todos los tipos de página
        if (print.TEXT_REGION_END) {
            end.addBlockContainer().setTop("0.3cm").setPosition("absolute").addBlock(print.TEXT_REGION_END)
                .setTextAlign('center')
                .setFontSize(8);
        }
    });

    // =======================================================================
    // SET BEFORE REGION CONTENT
    // =======================================================================
    template.setBefore(before => {
        let mTableBefore = before.addTable();            
        
        [9,1,9].forEach(mBcSizeCol => {
            mTableBefore.addColumn().setColumnWidth(mBcSizeCol);
        });

        let mRowLogoCompany = mTableBefore.getBody().addRow();

        /**
         * ==============================================
         *              Logo de la empresa
         * ==============================================
         */
        var FILEPATH = '';

        FILEPATH = mObjGcompedh.logo_top_image;
        var bytes = Ax.ext.db.getDatabaseDocLogo();

        if (pBoolImgcorp) {
            if (FILEPATH != null) {
                mRowLogoCompany.addCell().addBlock().setTextAlign("center").addExternalGraphic(FILEPATH).setContentWidth(9).setVerticalAlign("top").setProperty('content-height','3cm');
            } else {
           	    mRowLogoCompany.addCell().addBlock().setTextAlign("center").addExternalGraphic(bytes).setContentWidth(9).setVerticalAlign("top").setProperty('content-height','3cm');
        	}
        } else {
            mRowLogoCompany.addCell().addBlock();
        }
        /**
         * Espacio en blanco
         */
        mRowLogoCompany.addCell();
        mRowLogoCompany.addCell();


		/**
		 *	Titulo
		 */ 
		let mRowTit = mTableBefore.getBody().addRow();
		mRowTit.addCell().addBlock(print.getLabel("HDR_PED_IVA_REF_PRV"));
		mRowTit.addCell();
		mRowTit.addCell();

        /********************************************/
        /**          Nombre del documento.          */
        /********************************************/

        let mRowNomdoc = mTableBefore.getBody().addRow();
        mRowNomdoc.addCell().addBlock(mObjGcompedh.nomdoc || '');

        let mRowRazSoc_DirCob = mTableBefore.getBody().addRow();

        /**
         * ==============================================
         *              Supplier Data
         * ==============================================
         */
        let mTableSupplier = print.addFOPTable(
            mRowRazSoc_DirCob.addCell(),
            {   
                MarginTop   : 0.2,
                FontName    : print.FONT_NAME,
                FontSize    : print.FONT_SIZE_BODY,
                BorderWidth : print.BORDER_WIDTH,
                BorderStyle : "solid"
            }
        )

        mTableSupplier.addColumnsTable(
            [
                { Label : print.getLabel("PRN-PROVEEDOR") },
            ],
            {
                BackgroundColor : print.COLOR_PRIMARY,
                TextAlign       : "left",
                BorderStyle     : "solid"
            }
        );


        /**
         * Add data columns
         */

        
        [
            mObjGcompedh.nombre3,
            mObjGcompedh.direcc3,
            mObjGcompedh.poblac3,
            mObjGcompedh.nomprv3,
            mObjGcompedh.nomnac3,
            mObjGcompedh.cif3,
            mObjGcompedh.telef3 
        ].forEach(mStrProvData => {
            mTableSupplier.addRowTable([{ Value : mStrProvData }], { PaddingTop : 5 })
        })

        /**
         * Espacio en blanco
         */
        mRowRazSoc_DirCob.addCell();
        
        
        /********************************************/
        /**         Enviar factura a                */
        /********************************************/
        /**
         * TABLE Enviar factura
         */
        let mTabEnvFac = print.addFOPTable(
            mRowRazSoc_DirCob.addCell().setPadding(2),
            {
                MarginTop   : 0.2,
                FontName    : print.FONT_NAME,
                FontSize    : print.FONT_SIZE_BODY,
                BorderWidth : print.BORDER_WIDTH,
                BorderStyle : "solid"
            }
        );

        /**
         * Set column width
         */
        mTabEnvFac.addColumnsTable(
            [
                { Label : print.getLabel('HDR_ENVIAR_FACTURA_A') }
            ],
            {
                BackgroundColor : print.COLOR_PRIMARY,
                TextAlign       : "left",
                BorderStyle     : "solid"
            }
        );

        /**
         * Add data columns
         */
        [
            mObjGcompedh.nombre5,
            mObjGcompedh.direcc5,
            mObjGcompedh.poblac5,
            mObjGcompedh.nomprv5,
            mObjGcompedh.nomnac5,
            mObjGcompedh.telef5
        ].forEach(mStrAddressData => {
            mTabEnvFac.addRowTable([{ Value : mStrAddressData }], { PaddingTop : 5 })
        })


        let mRowEntregar = mTableBefore.getBody().addRow();

        /********************************************/
        /**         Dirección de cobro.             */
        /********************************************/
        /**
         * TABLE Direccion de cobro
         */
        let mTableAddress = print.addFOPTable(
            mRowEntregar.addCell().setPadding(2),
            {
                MarginTop   : 0.2,
                FontName    : print.FONT_NAME,
                FontSize    : print.FONT_SIZE_BODY,
                BorderWidth : print.BORDER_WIDTH,
                BorderStyle : "solid"
            }
        );

        /**
         * Set column width
         */
        mTableAddress.addColumnsTable(
            [
                { Label : print.getLabel('HDR_ENTREGAR_EN') }
            ],
            {
                BackgroundColor : print.COLOR_PRIMARY,
                TextAlign       : "left",
                BorderStyle     : "solid"
            }
        );

        /**
         * Add data columns
         */
        [
            mObjGcompedh.nombre2,
            mObjGcompedh.direcc2,
            mObjGcompedh.poblac2,
            mObjGcompedh.nomprv2,
            mObjGcompedh.nomnac2,
            mObjGcompedh.telef2
        ].forEach(mStrAddressData => {
            mTableAddress.addRowTable([{ Value : mStrAddressData }], { PaddingTop : 5 })
        })

        mRowEntregar.addCell()

        /**
         * ==============================================
         *              Facturar
         * ==============================================
         */
        let mTableFacturar = print.addFOPTable(
            mRowEntregar.addCell(),
            {   
                MarginTop   : 0.2,
                FontName    : print.FONT_NAME,
                FontSize    : print.FONT_SIZE_BODY,
                BorderWidth : print.BORDER_WIDTH,
                BorderStyle : "solid"
            }
        )

        mTableFacturar.addColumnsTable(
            [
                { Label : print.getLabel("HDR_FACTURAR_A") },
            ],
            {
                BackgroundColor : print.COLOR_PRIMARY,
                TextAlign       : "left",
                BorderStyle     : "solid"
            }
        );


        /**
         * Add data columns
         */       
        [
            mObjGcompedh.nombre4,
            mObjGcompedh.direcc4,
            mObjGcompedh.poblac4,
            mObjGcompedh.nomprv4,
            mObjGcompedh.nomnac4,
            mObjGcompedh.cif4,
            mObjGcompedh.telef4
        ].forEach(mStrProvData => {
            mTableFacturar.addRowTable([{ Value : mStrProvData }], { PaddingTop : 5 })
        })

        

        /**
         *  Caja izquierda y derecha 
         */
        let mRow2 = mTableBefore.getBody().addRow();

        let mTableInvoice = print.addFOPTable(
            mRow2.addCell(), 
            { 
                BorderStyle : "solid",
                FontName    : print.FONT_NAME,
                FontSize    : print.FONT_SIZE_BODY,
                MarginTop   : 0.3
            }
        );

        /**
         * Column width.
         */
        mTableInvoice.addColumnsTable(
            [
                { Label : print.getColumnLabel('gcompedh', "docser") },
                { Label : print.getColumnLabel('gcompedh', "fecha") },
                { Label : print.getColumnLabel('gcompedh', "portes") }
            ],
            {
                BackgroundColor : print.COLOR_SECONDARY,
                TextAlign       : "left",
                BorderStyle     : "solid"
            }
        );

        mTableInvoice.addRowTable(
            [
                { Value : mObjGcompedh.docser },
                { Value : print.getTxtDate(mObjGcompedh.fecha) },
                { Value : print.getRenderMap('gcompedh', 'portes', mObjGcompedh.portes) }
            ],
            {
                PaddingTop : 5
            }
        );

        mRow2.addCell();

        /**
         * TABLE TRANSPORTATION FLAG
         */
        let mTableTranFlag = print.addFOPTable(
            mRow2.addCell(), 
            { 
                BorderStyle : "solid",
                FontName    : print.FONT_NAME,
                FontSize    : print.FONT_SIZE_BODY,
                MarginTop   : 0.3
            }
        );

        /**
         * Column width.
         */
        mTableTranFlag.addColumnsTable(
            [                
                { Label : print.getColumnLabel('gcompedh', "fecini") },
                { Label : print.getColumnLabel('gcompedh', "fecfin")},
                { Label : print.getColumnLabel('gcompedh', "horpre") }
            ],
            {
                BackgroundColor : print.COLOR_SECONDARY,
                TextAlign       : "left",
                BorderStyle     : "solid"
            }
        );

        mTableTranFlag.addRowTable(
            [
                { Value : print.getTxtDate(mObjGcompedh.fecini) },
                { Value : print.getTxtDate(mObjGcompedh.fecfin) },
                { Value : mObjGcompedh.horpre }
            ],
            {
                PaddingTop : 5
            }
        );

        
        
        
        /**
         * If document is not validated, a watermark will be generated.
         */
        if (!VALID_PRINT) {
            before.addBlockContainer()
                .setPosition("absolute")
                .setTop("5cm")
                .setLeft("0cm")
                .addBlock()
                .addInstreamForeignObject(
                print.getWatermark(mObjGcompedh.estcab == 'P' 
                    ? print.WATERMARK_PROVISIONAL
                    : print.WATERMARK_BLOCKED
                    )
            );
        }

        /**
         * The watermark copy is generated whether the number is valid.
         */
        if (pBoolLikeCopy) {
            before.addBlockContainer()
                .setPosition("absolute")
                .setTop("9cm")
                .setLeft("0.0cm")
                .addBlock()
                .addInstreamForeignObject(print.getWatermark(print.WATERMARK_COPY));
        }
	});

	// =======================================================================
	// SET BODY FLOW CONTENT
	// =======================================================================
	template.setBody(body => {
		/**
         * TABLE LINES
         */
        let mTableLines = print.addFOPTable(body,
            {
                FontFamily  : print.FONT_NAME,
                FontSize    : print.FONT_SIZE_BODY,
                BorderWidth : print.BORDER_WIDTH,
                MarginLeft  : 0.06,
                Property    : ['margin-right', 2]
            }
        );

        /**
         * Add columns
         */
        mTableLines.addColumnsTable(
            [
                { Label : print.getColumnLabel('gartprov', 'refpro'), Relation : 1.75},
                { Label : print.getColumnLabel('garticul', 'nomart'), Relation : 4.45},
                { Label : print.getColumnLabel('gartvarl', 'codart'), Relation : 1.8},
                { Label : print.getColumnLabel('gcompedl', 'varlog'), Relation : 0.9},
                { Label : print.getColumnLabel('gcompedl', 'canped'), Relation : 1.5},
                { Label : print.getColumnLabel('gcompedl', 'udmcom'), Relation : 1.2},
                { Label : print.getColumnLabel('gcompedl', 'precio'), Relation : 1.2},
                {
                    Label  : print.getColumnLabel("gcompedl","impnet"), Relation : 1
                },
                {
                    Label  : print.getColumnLabel("gcompedh_tax","tax_code"), Relation : 1
                }
            ],
            {
                BackgroundColor : print.COLOR_SECONDARY,
                TextAlign       : "left",
                BorderStyle     : "solid"
            }
        );
        /**
         * Adding table data
         */
        mArrGcompedl.forEach(mRowLine => {
            mTableLines.addRowTable(
                [
                    { Value: mRowLine.refpro, TextAlign : "left"},
                    { Value: mRowLine.nomart, TextAlign : "left"},
                    { Value: mRowLine.codart, TextAlign : "left"},
                    { Value: mRowLine.varlog, TextAlign : "left"},
                    { Value: NumFormat.format(mRowLine.canped || 0, "###,##0.00"), TextAlign : "right" },
                    { Value: mRowLine.udmcom, TextAlign : "left"},
                    { Value: NumFormat.format(mRowLine.precio || 0, "###,##0.00"), TextAlign : "right" },
                    { Value: NumFormat.format(mRowLine.impnet || 0, "###,##0.00"), TextAlign : "right"},
                    { Value: NumFormat.format(mRowLine.tax_code || 0, "###,##0.00"), TextAlign : "right"}
                ],
                {
                    FontSize   : print.FONT_SIZE_BODY,
                    PaddingTop : 4,
                    BorderStyle:'solid'
                }
            );
        });


        if (mObjGcompedh.auth_notas > 0) {
            /**
             * TABLE LINES
             */
            let mTableNotas = print.addFOPTable(body,
                {
                    MarginTop   : 0.3,
                    FontFamily  : print.FONT_NAME,
                    FontSize    : print.FONT_SIZE_BODY,
                    BorderWidth : print.BORDER_WIDTH,
                    MarginLeft  : 0.06,
                    Property    : ['margin-right', 2]
                }
            );

            /**
             * Add columns
             */
            mTableNotas.addColumnsTable(
                [
                    { Label : print.getColumnLabel('virtualcom', 'notah')},
                ],
                {
                    BackgroundColor : print.COLOR_PRIMARY,
                    TextAlign       : "left",
                    BorderStyle     : "solid"
                }
            );
            /**
             * Adding table data
             */
            mArrNotas.forEach(mRowNota => {
                mTableNotas.addRowTable(
                    [
                        { Value: mRowNota.notah, TextAlign : "left"}
                    ],
                    {
                        FontSize   : print.FONT_SIZE_BODY,
                        PaddingTop : 4,
                        BorderStyle:'solid'
                    }
                );
            });            
        }

        if (mCountText) {
            let mTableText = print.addFOPTable(body,
                {
                    MarginTop   : 0.3,
                    FontFamily  : print.FONT_NAME,
                    FontSize    : print.FONT_SIZE_BODY,
                    BorderWidth : print.BORDER_WIDTH,
                    MarginLeft  : 0.06,
                    Property    : ['margin-right', 2]
                }
            );

            /**
             * Add columns
             */
            mTableText.addColumnsTable(
                [
                    { Label : print.getColumnLabel('cdoctext', 'text_data')},
                ],
                {
                    BackgroundColor : print.COLOR_SECONDARY,
                    TextAlign       : "left",
                    BorderStyle     : "solid"
                }
            );
            /**
             * Adding table data
             */
            mArrTextData.forEach(mRowText => {
                mTableText.addRowTable(
                    [
                        { Value: mRowText.text_data, TextAlign : "left"}
                    ],
                    {
                        FontSize   : print.FONT_SIZE_BODY,
                        PaddingTop : 4,
                        BorderStyle:'solid'
                    }
                );
            });       
        }

	});

	// =======================================================================
	// SET AFTER REGION CONTENT
	// =======================================================================
	template.setAfter(after => {
	    /**
         * CODIDO BARRAS Y TOTAL
         */
        let mTableCodTotal = after.addTable()
            .setFontFamily(print.FONT_NAME)
            .setFontSize(print.FONT_SIZE_BODY)
            .setMarginTop(0.1)
            .setBorderWidth(print.BORDER_WIDTH);
        /**
         * Add columns
         */
        [9,1,9].forEach(mBcSizeCol => {
            mTableCodTotal.addColumn().setColumnWidth(mBcSizeCol);
        });

        let mRowBarTot  = mTableCodTotal.getBody().addRow();
        mRowBarTot.addCell();
        mRowBarTot.addCell();
        var mColmRow63 = mRowBarTot.addCell();

        var mBlockImp = mColmRow63.addBlock().addInlineContainer().addBlock();
        var mTableImp = mBlockImp.addTable().setSpaceBefore("5px")
                .setBorderLeftStyle("solid").setBorderLeftWidth(0.5)
                .setBorderRightStyle("solid").setBorderRightWidth(0.5)
                .setBorderTopStyle("solid").setBorderTopWidth(0.5)
                .setBorderBottomStyle("solid").setBorderBottomWidth(0.5);

        mTableImp.addColumn();
        mTableImp.addColumn();

        var mImpRow1 = mTableImp.getBody().addRow().setBorderBottomStyle("solid").setBorderBottomWidth(0.5);
            mImpRow1.addCell(print.getColumnLabel('virtualerp', 'totped')).setPadding(5).setBorderRightStyle("solid").setBorderRightWidth(0.5).setBackgroundColor(print.COLOR_SECONDARY);
            mImpRow1.addCell(mObjGcompedh.totped || '').setPadding(5).setBorderRightStyle("solid").setBorderRightWidth(0.5).setTextAlign('right');

        var mImpRow2 = mTableImp.getBody().addRow().setBorderBottomStyle("solid").setBorderBottomWidth(0.5);
            mImpRow2.addCell(NumFormat.format(mObjImpues.tax_porcen || 0, "###,##0.00") || '').setPadding(5).setBorderRightStyle("solid").setBorderRightWidth(0.5).setTextAlign('right');
            mImpRow2.addCell(NumFormat.format(mObjImpues.tax_quote || 0, "###,##0.00") || '').setPadding(5).setBorderRightStyle("solid").setBorderRightWidth(0.5).setTextAlign('right');

        var mTableImp2 = mBlockImp.addTable().setSpaceBefore("0.3cm")
                .setBorderLeftStyle("solid").setBorderLeftWidth(0.5)
                .setBorderRightStyle("solid").setBorderRightWidth(0.5)
                .setBorderTopStyle("solid").setBorderTopWidth(0.5)
                .setBorderBottomStyle("solid").setBorderBottomWidth(0.5);

        mTableImp2.addColumn();
        mTableImp2.addColumn();

        var mImpRow3 = mTableImp2.getBody().addRow().setBorderBottomStyle("solid").setBorderBottomWidth(0.5);
            mImpRow3.addCell(mObjLinTotal.divisa || '').setPadding(5).setBorderRightStyle("solid").setBorderRightWidth(0.5).setTextAlign('left');
            mImpRow3.addCell(NumFormat.format(mObjLinTotal.total || 0, "###,##0.00") || '').setPadding(5).setBorderRightStyle("solid").setBorderRightWidth(0.5).setTextAlign('right');

        /**
         *  Regmer 
         */  
        let mTable = after.addTable();
           mTable.setSpaceBefore("0.3cm");
           mTable.setFontSize(5.5);
           mTable.setFontFamily(print.FONT_NAME);
           mTable.addColumn();
 
        let mRow = mTable.getBody().addRow(); 

        let mCellRegmer   = mRow.addCell();
        mCellRegmer.addBlock(mObjGcompedh.poblac).setPaddingBottom("1pt").setPaddingTop("4pt").setTextAlign('center');
        mCellRegmer.addBlock(mObjGcompedh.cif).setPaddingBottom("1pt").setPaddingTop("4pt").setTextAlign('center');
        mCellRegmer.addBlock(mObjGcompedh.telef1).setPaddingBottom("1pt").setPaddingTop("4pt").setTextAlign('center');

		/**
		 * Add pagination
		 */
        var mPageNumberId = after.getRoot().getPageSequence().getTotalPageNumberCitation();
        var mRowNumPag = after.addBlock().setSpaceBefore("0.2cm");
        var mBlockPage = mRowNumPag.addInlineContainer().setWidth("19cm")
                .addBlock()
                .setFontFamily(print.FONT_NAME)
                .setFontSize(print.FONT_SIZE_BODY)
                .setTextAlign("end");
        
            mBlockPage.addInline()
            .addText("Pag. ")
            .putPageNumber()
            .addText(" - ")
            .putPageNumberCitation(mPageNumberId);
	});

	/**
	 * GENERATE PDF
	 */
	let mFopGcomsolh = template.toFOP();
	let mPdfGcomsolh = new Ax.fop.Processor().transform(mFopGcomsolh);

	return mPdfGcomsolh
}