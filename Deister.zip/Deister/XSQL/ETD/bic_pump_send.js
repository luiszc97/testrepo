function bic_pump_send (pStrSerial, pDateDsend, pStrUnit, 
    pStrContact, pStrMailto, pIntCover, 
    pIntCharger, pIntDropsensor, pIntPcabutton, 
    pIntCombicable, pIntRac, pStrAddition) {
    
    /* ======================================================================== -->
    <!-- Registrar línia de reparació i modificar registre mestre.                -->
    <!-- ======================================================================== */
    Ax.db.insert('bic_repair', {
        rep_id          : 0,
        rep_pump        : pStrSerial,
        rep_dsend       : pDateDsend,
        rep_unit        : pStrUnit,
        rep_cover       : pIntCover,
        rep_charger     : pIntCharger,
        rep_dropsensor  : pIntDropsensor,
        rep_pcabutton   : pIntPcabutton,
        rep_combicable  : pIntCombicable,
        rep_rac         : pIntRac,
        user_created    : Ax.ext.user.getUser(),
        date_created    : new Ax.util.Date(),
        user_updated    : Ax.ext.user.getUser(),
        date_updated    : new Ax.util.Date()
    });
    
    if (
        pIntCover !== 0 ||
        pIntCharger !== 0 ||
        pIntDropsensor !== 0 ||
        pIntPcabutton !== 0 ||
        pIntCombicable !== 0 ||
        pIntRac !== 0
    ) {
        Ax.db.insert('bic_movement', {
            mov_id: 0,
            mov_unit: pStrUnit,
            mov_cover: pIntCover,
            mov_charger: pIntCharger,
            mov_dropsensor: pIntDropsensor,
            mov_pcabutton: pIntPcabutton,
            mov_combicable: pIntCombicable,
            user_created: Ax.ext.user.getUser(),
            date_created: new Ax.util.Date()
        });
    }

    Ax.db.update('bic_pump',{
        bic_unit    : pStrUnit,
        bic_dsend   : pDateDsend,
        bic_status  : 'R'
    },{
        bic_serial  : pStrSerial
    });

    /* ======================================================================== -->
    <!-- Enviament de correu al proveïdor.                                      -->
    <!-- ======================================================================== */

    mStrModName = Ax.db.executeGet(`
        <select>
            <columns>bic_model.mod_name</columns>
            <from table='bic_pump'>
                <join table='bic_model'>
                    <on>bic_pump.bic_model = bic_model.mod_code</on>
                </join>
            </from>
            <where>
                bic_pump.bic_serial = ?
            </where>
        </select>
    `,pStrSerial);

    let mStrPhrase1 = 'Estimados Sres';

    if (pStrContact.length !== 0){

        mStrPhrase1 = `A la atención de ${pStrContact}`;
    }

    if (pStrMailto.length > 0){
        
        let mStrSubject = `Reparación unidad ${pStrSerial}`;
        let mStrContent = `<body>
            <p>${mStrPhrase1},<br /></p>
            <p>Hacemos el envío del siguiente material parar reparar: ${mStrModName} nº serie ${pStrSerial}<br /></p>
            </body>`

        if (
            pIntCover !== 0 ||
            pIntCharger !== 0 ||
            pIntDropsensor !== 0 ||
            pIntPcabutton !== 0 ||
            pIntCombicable !== 0 ||
            pIntRac !== 0
        ) {
            mStrContent = `${mStrContent}<body>
                <p>Se incluye:<br /></p>
                <body>`

        }

        if (pIntCover == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCover}Soporte<br /></p>
                <body>`
        }

        if (pIntCover > 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCover}Soportes<br /></p>
                <body>`
        }

        if (pIntCharger == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCharger}Cargador<br /></p>
                <body>`
        }

        if (pIntCharger > 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCharger}Cargadores<br /></p>
                <body>`
        }

        if (pIntDropsensor == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntDropsensor}Sensor de Gota<br /></p>
                <body>`
        }

        if (pIntDropsensor > 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntDropsensor}Sensores de Gota<br /></p>
                <body>`
        }

        if (pIntPcabutton == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntPcabutton}Pulsador PCA<br /></p>
                <body>`
        }

        if (pIntPcabutton > 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntPcabutton}Pulsadores PCA<br /></p>
                <body>`
        }

        if (pIntCombicable == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCombicable}Cable Combi<br /></p>
                <body>`
        }

        if (pIntCombicable > 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCombicable}Cables Combi<br /></p>
                <body>`
        }

        if (pIntRac > 0){

            mStrContent = `${mStrContent}<body>
                <p>${pIntRac}Space Station<br /></p>
                <body>`
        }
        
        if (pStrAddition !== null){

            mStrContent = `${mStrContent}<body>
                <p>${pStrAddition}<br /></p>
                <body>`
        }

        let mObjBicUnit = Ax.db.executeQuery(`
            <select>
                <columns>unt_name, unt_address</columns>
                <from table='bic_unit' />
                <where>
                    unt_code = ?
                </where>
            </select>
        `,pStrUnit).toOne();

        if (mObjBicUnit.unt_name == null){
            
            mObjBicUnit.unt_name = pStrUnit;
        }
        
        mStrContent = `${mStrContent}<body>
            <p><br /></p>
            <p>La recogida y entrega es en ${mObjBicUnit.unt_name}, ${mObjBicUnit.unt_address}.<br /></p>
            <p>Gracias<br /></p>
            </body>`;

        let mStrMailcc = Ax.ext.user.getMail();
        let mStrMailbcc = `ammartinez@mutuaterrassa.es, svilarrubias@mutuaterrassa.cat`;

        // Se arma el email a enviarse
        let mail = new Ax.mail.MailerMessage();
        mail.from('noreply@mutuaterrassa.cat');
        mail.to(pStrMailto);
        mail.cc(mStrMailcc);
        mail.bcc(mStrMailbcc);
        mail.subject(mStrSubject);
        mail.setHtml(mStrContent);

        //Se hace el envío del email
        const mailer = new Ax.mail.Mailer();
        mailer.setSMTPServer("localhost", 25);
        mailer.send(mail);
    }  
}