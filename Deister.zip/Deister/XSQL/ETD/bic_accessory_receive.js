function bic_accessory_receive (pStrUnit, 
    pIntCover, pIntCharger, pIntDropsensor,
    pIntPcabutton, pIntCombicable, pIntRac, pIntRs232,
    pIntExtleadsp, pIntSupspacestat){

    Ax.db.insert('bic_movement',{
        mov_id           : 0,
        mov_unit         : pStrUnit,
        mov_cover        : pIntCover * -1,
        mov_charger      : pIntCharger * -1,
        mov_dropsensor   : pIntDropsensor * -1,
        mov_pcabutton    : pIntPcabutton * -1,
        mov_combicable   : pIntCombicable * -1,
        mov_rac          : pIntRac * -1,
        mov_rs232        : pIntRs232 * -1,
        mov_extleadsp    : pIntExtleadsp * -1,
        mov_supspacestat : pIntSupspacestat * -1,
        user_created     : Ax.ext.user.getCode()
    })
}