function bic_accessory_send (
    pStrUnit,       pStrContact,    pStrMailto, 
    pIntCover,      pIntCharger,    pIntDropsensor, 
    pIntPcabutton,  pIntCombicable, pIntRac, 
    pIntRs232,      pIntExtleadsp,  pStrAddition, 
    pIntSupspacestat)
{

    if (
        pIntCover === 0 &&
        pIntCharger === 0 &&
        pIntDropsensor === 0 &&
        pIntPcabutton === 0 &&
        pIntCombicable === 0 &&
        pIntRac === 0 &&
        pIntRs232 === 0 &&
        pIntExtleadsp === 0 &&
        pIntSupspacestat === 0){

        return;
    }

    Ax.db.insert('bic_movement', {
        mov_id              :   0,
        mov_unit            :   pStrUnit,
        mov_cover           :   pIntCover,
        mov_charger         :   pIntCharger,
        mov_dropsensor      :   pIntDropsensor,
        mov_pcabutton       :   pIntPcabutton,
        mov_combicable      :   pIntCombicable,
        mov_rac             :   pIntRac,
        mov_rs232           :   pIntRs232,
        mov_extleadsp       :   pIntExtleadsp,
        mov_supspacestat    :   pIntSupspacestat,
        user_created        :   Ax.ext.user.getUser(),
        date_created        :   new Ax.util.Date()
    });

    /* ======================================================================== -->
    <!-- Enviament de correu al proveïdor.                                        -->
    <!-- ======================================================================== */

    let mStrPhrase1 = 'Estimados Sres';

    if (pStrContact.length != 0){

        mStrPhrase1 = `A la atención de ${pStrContact}`;
    }

    if (pStrMailto.length > 0){

        let mStrSubtject = 'Envío de material';
        let mStrContent = `
            <body>
            <p>${mStrPhrase1},<br /></p>
            <p>Hacemos el envío del siguiente material parar reparar:<br /></p>
            </body>`

        if (pIntCover == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCover} Soporte<br /></p>
                </body>`;
        }

        if (pIntCover > 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCover} Soportes<br /></p>
                </body>`;
        }

        if (pIntCharger == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCharger} Cargador<br /></p>
                </body>`;
        }

        if (pIntCharger > 1){

            mStrContent = `${mStrContent}<body>
            <p>${pIntCharger} Cargadores<br /></p>
            </body>`;
        }

        if (pIntDropsensor == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntDropsensor} Sensor de Gota<br /></p>
                </body>`;
        }

        if (pIntDropsensor > 1){

            mStrContent = `${mStrContent}<body>
            <p>${pIntDropsensor} Sensores de Gota<br /></p>
            </body>`;
        }

        if (pIntPcabutton == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntPcabutton} Pulsador PCA<br /></p>
                </body>`;
        }

        if (pIntPcabutton > 1){

            mStrContent = `${mStrContent}<body>
            <p>${pIntPcabutton} Pulsadores PCA<br /></p>
            </body>`;
        }

        if (pIntCombicable == 1){

            mStrContent = `${mStrContent}<body>
                <p>${pIntCombicable} Cable Combi<br /></p>
                </body>`;
        }

        if (pIntCombicable > 1){

            mStrContent = `${mStrContent}<body>
            <p>${pIntCombicable} Cables Combi<br /></p>
            </body>`;
        }

        if (pIntRac > 0){

            mStrContent = `${mStrContent}<body>
                <p>${pIntRac} Space Station<br /></p>
                </body>`;
        }

        if (pIntRs232 > 0){

            mStrContent = `${mStrContent}<body>
            <p>${pIntRs232} Cable RS232<br /></p>
            </body>`;
        }

        if (pIntExtleadsp > 0){

            mStrContent = `${mStrContent}<body>
            <p>${pIntExtleadsp} Extensió Lead SP120cm<br /></p>
            </body>`;
        }

        if (pIntSupspacestat > 0){

            mStrContent = `${mStrContent}<body>
            <p>${pIntSupspacestat} Soporte Space Station<br /></p>
            </body>`;
        }

        if (pStrAddition != null){

            mStrContent = `${mStrContent}<body>
            <p>${pStrAddition}<br /></p>
            </body>`;
        }

        let mObjBicUnit = Ax.db.executeQuery(`
            <select>
                <columns>unt_name, unt_address</columns>
                <from table='bic_unit' />
                <where>
                    unt_code = ?
                </where>
            </select>
        `,pStrUnit).toOne();

        if (mObjBicUnit.unt_name == null){
            
            mObjBicUnit.unt_name = pStrUnit;
        }

        mStrContent = `${mStrContent}<body>
            <p><br /></p>
            <p>La recogida y entrega es en ${mObjBicUnit.unt_name}, ${mObjBicUnit.unt_address}.<br /></p>
            <p>Gracias<br /></p>
            </body>`;

        let mStrMailcc = Ax.ext.user.getMail();
        let mStrMailbcc = `ammartinez@mutuaterrassa.es, svilarrubias@mutuaterrassa.cat`;

        // Se arma el email a enviarse
        let mail = new Ax.mail.MailerMessage();
        mail.from('noreply@mutuaterrassa.cat');
        mail.to(pStrMailto);
        mail.cc(mStrMailcc);
        mail.bcc(mStrMailbcc);
        mail.subject(mStrSubtject);
        mail.setHtml(mStrContent);

        //Se hace el envío del email
        const mailer = new Ax.mail.Mailer();
        mailer.setSMTPServer("localhost", 25);
        mailer.send(mail);
    }
}