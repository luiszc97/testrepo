function act_monitor_action (pIntMonId, pStrAction, pStrBuilding, 
    pStrFloor, pStrLocation){

    let mObjParametros = {
        pIntMonId       : pIntMonId,
        pStrAction      : pStrAction,
        pStrBuilding    : pStrBuilding,
        pStrFloor       : pStrFloor,
        pStrLocation    : pStrLocation
    }

    for (let mPropParam in mObjParametros){
        
        if(typeof mObjParametros[mPropParam] !== "string"){

            continue;
        }

        if(mObjParametros[mPropParam] === '[NULL]'){

            eval(`${mPropParam} = null`)
        }         
    }
    let mStrStatus;

    switch (pStrAction){

        /* ==================================================================== -->
        <!-- 1) Desplegament.                                                     -->
        <!-- ==================================================================== */
        case 'DP':
            mStrStatus = 'P';
            break;
        /* ==================================================================== -->
        <!-- 2) Trasllat.                                                    -->
        <!-- ==================================================================== */
        
        case 'TR':
            mStrStatus = 'P';
            break;
        /* ==================================================================== -->
        <!-- 3) Recuperació per l'Estoc.                                                     -->
        <!-- ==================================================================== */

        case 'RE':
            mStrStatus = 'E';
            break;
        /* ==================================================================== -->
        <!-- 4) Retirada per Reciclatge.                                          -->
        <!-- ==================================================================== */
        
        case 'RR':
            mStrStatus = 'R';
            break;
        /* ==================================================================== -->
        <!-- 5) Baixa.                                                       -->
        <!-- ==================================================================== */

        case 'BR':
            mStrStatus = 'B';
            break;

        default:
            throw new Ax.lang.Exception(`Acció [${pStrAction}] no contemplada. Contacti amb l'equip d'Aplicacions Corporatives.`)
    }

    Ax.db.update('act_monitor',{

        mon_status    : mStrStatus,
        mon_building  : pStrBuilding,
        mon_floor     : pStrFloor,
        mon_location  : pStrLocation,
        user_updated  : Ax.ext.user.getUser(),
        date_updated  : new Ax.util.Date()
    },{
        mon_id: pIntMonId
    });

    let mIntMaxHisId = Ax.db.executeGet(`
        <select>
            <columns>MAX(his_id) max_his_id</columns>
            <from table='act_monitor_his' />
            <where>
                mon_id = ?
            </where>
        </select>
    `,pIntMonId);
    
    Ax.db.update('act_monitor_his',{
        his_event: pStrAction
    },{
        his_id: mIntMaxHisId
    });
}