function act_printer_file_import_inc () {

    Ax.db.beginWork();

    let mStrPathname  = '/erpsync/act/printer/';
    let mStrPathback = '/erpsync/act/printer/bak/';

    let mDirectory = new Ax.io.file(`${mStrPathname}`);

    let mArrFilelist = mDirectory.listFiles(f => {
        return /.*\.csv/.test(f.getName())
    });

    if (mArrFilelist.length == 0) {

        throw new Ax.lang.Exception('Fitxer erroni');
    }

    for (let mFile of mArrFilelist) {

        try{
            /* ================================================================ -->
            <!-- Lectura del fitxer.                                              -->
            <!-- ================================================================ */

            let mFileContent = new Ax.io.file(`${mStrPathname}${mFile.getName()}`);
            let mStrContent = mFileContent.readString();
            let mArrLine = mStrContent.split(/\r\n|\n/);

            let mIntFirstline = 0;

            for (let mStrLine of mArrLine) {

                if (mIntFirstline == 0){

                    mIntFirstline = 1;
                } else {
                    
                    mStrLine = ` ${mStrLine} ` //Espacio antes y despues
                    let mStrWord = mStrLine.split(';');
                    let mArrsize = mStrWord.length;

                    /* ================================================================ -->
                    <!-- Per evitar registres en blanc al final del document, el count          -->
                    <!-- del array ha de ser 12                                                                                      -->
                    <!-- ================================================================ */
                    if (mArrsize == 12) {

                        let mObjActPrinter = {};

                        for (let mIntIdx=0; mIntIdx < mArrsize; mIntIdx++) {

                            let mStrElem = mStrWord[mIntIdx].trim();

                            switch (mIntIdx) {

                                case 0:  
                                    mObjActPrinter.inc_codi_intern = mStrElem;
                                    break;  
                                case 1: 
                                    mObjActPrinter.inc_id_incidencia = mStrElem;
                                    break;  
                                case 2: 
                                    mObjActPrinter.inc_n_serie = mStrElem;
                                    break;  
                                case 3: 
                                    mObjActPrinter.inc_data_incidencia = new Ax.util.Date(mStrElem);
                                    break;  
                                case 4: 
                                    mObjActPrinter.inc_hora_incidencia = new Ax.util.Date(mStrElem);
                                    break;  
                                case 5:     
                                    mObjActPrinter.inc_desc_averia = mStrElem;
                                    break;  
                                case 6: 
                                    mObjActPrinter.inc_data_reparacio = new Ax.util.Date(mStrElem);
                                    break;
                                case 7:
                                    mObjActPrinter.inc_hora_inici_reparacio = new Ax.util.Date(mStrElem);
                                    break;
                                case 8:
                                    mObjActPrinter.inc_hora_fi_reparacio = new Ax.util.Date(mStrElem);
                                    break;
                                case 9:
                                    mObjActPrinter.inc_dades_usuari = mStrElem;
                                    break;
                                case 10:
                                    mObjActPrinter.inc_dades_tecnic = mStrElem;
                                    break;
                                case 11:
                                    mObjActPrinter.inc_estado = mStrElem;
                                    break;  
                            }
                        }

                        /* Control d'errors abans de fer l'insert per determinar estat */

                        mObjActPrinter.inc_status = 0;
                        mObjActPrinter.inc_error_msg = '';

                        /* ID_ETD existeix a act_printer */

                        let mIntActPrinter = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    COUNT(*)
                                </columns>
                                <from table="act_printer" />
                                <where>
                                    prt_id = ?
                                </where>
                            </select>
                        `,mObjActPrinter.inc_codi_intern);

                        if (mObjActPrinter.inc_status == 0 && mIntActPrinter == 0) {

                            mObjActPrinter.inc_status = 5;
                            mObjActPrinter.inc_error_msg = 'ID_ETD Inexistent';
                        }

                        /* Data Incidencia */
                        let mStrIncDataInc = mObjActPrinter.inc_data_incidencia != '' ? mObjActPrinter.inc_data_incidencia : null;

                        if (mStrIncDataInc == null){

                            mObjActPrinter.inc_status = 5;
                            mObjActPrinter.inc_error_msg = 'Data incidencia Inexistent';
                        } else {
                            
                            mObjActPrinter.inc_data_incidencia = mObjActPrinter.inc_data_incidencia.format('dd/MM/yyyy');
                        }

                        /* Hora Incidencia */
                        let mStrIncHoraInc = mObjActPrinter.inc_hora_incidencia != '' ? mObjActPrinter.inc_hora_incidencia : null;

                        if ( mStrIncHoraInc == null ){

                            mObjActPrinter.inc_status = 5;
                            mObjActPrinter.inc_error_msg = 'Hora incidencia Inexistent';
                        } else {
                            
                            mObjActPrinter.inc_hora_incidencia = mObjActPrinter.inc_hora_incidencia.format('HH:mm:ss');
                        }

                        /* ID Incidencia */
                        let mStrIncIdInc = mObjActPrinter.inc_id_incidencia != '' ? mObjActPrinter.inc_id_incidencia : null;

                        if ( mStrIncIdInc == null ){

                            mObjActPrinter.inc_status = 5;
                            mObjActPrinter.inc_error_msg = 'ID incidencia Inexistent';
                        }

                        /* Nº Serie */
                        let mStrIncSerie = mObjActPrinter.inc_n_serie != '' ? mObjActPrinter.inc_n_serie : null;

                        if ( mStrIncSerie == null ){

                            mObjActPrinter.inc_status = 5;
                            mObjActPrinter.inc_error_msg = 'Nº Serie Inexistent';
                        }

                        /* Descripció Averia */
                        let mStrIncDescAveria = mObjActPrinter.inc_desc_averia != '' ? mObjActPrinter.inc_desc_averia : null;

                        if ( mStrIncDescAveria == null ){

                            mObjActPrinter.inc_status = 5;
                            mObjActPrinter.inc_error_msg = 'Descripció Averia Inexistent';
                        }

                        /* Dades Usuari */
                        let mStrDades = mObjActPrinter.inc_dades_usuari != '' ? mObjActPrinter.inc_dades_usuari : null;

                        if ( mStrDades == null ){

                            mObjActPrinter.inc_status = 5;
                            mObjActPrinter.inc_error_msg = 'Dades Usuari Inexistent';
                        }

                        /* Data Reparacio */
                        let mStrDataRep = mObjActPrinter.inc_data_reparacio != '' ? mObjActPrinter.inc_data_reparacio : null;

                        if ( mStrDataRep == null ){

                            mObjActPrinter.inc_data_reparacio = mObjActPrinter.inc_data_reparacio.format('dd/MM/yyyy');
                        }

                        /* Hora Fi Reparacio */
                        let mStrHora = mObjActPrinter.inc_hora_fi_reparacio != '' ? mObjActPrinter.inc_hora_fi_reparacio : null;

                        if ( mStrHora == null ){

                            mObjActPrinter.inc_hora_fi_reparacio = mObjActPrinter.inc_hora_fi_reparacio.format('HH:mm:ss');
                        }

                        Ax.db.insert('act_printer_inc_his', mObjActPrinter);
                    
                    } else {

                        throw new Ax.lang.Exception(`Nombre de columnes erroni [${mArrsize}]`);
                    }
                }
            }

            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
        } catch (error){

            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
            throw new Ax.lang.Exception(`${Ax.util.Error.getMessage(error)}`);
        }
    }
    Ax.db.commitWork();
}