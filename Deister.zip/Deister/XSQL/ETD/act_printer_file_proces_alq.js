function act_printer_file_proces_alq (pIntFileId){

    let mIntContador = 0; 
    let mIntDadesLloguer = 1;

    Ax.db.beginWork();

    while(mIntDadesLloguer == 1 ){

        mObjActPrinterAlqIntr = Ax.db.executQuery(`
            <select first = '1'>
                <columns>alq_intr_id, file_id, alq_intr_id_factura, alq_intr_id_printer, alq_intr_emp_cif, alq_intr_cen_cost, alq_intr_seccion, alq_intr_price, alq_intr_month, alq_intr_year, alq_intr_fecha_fact</columns>
                <from table='act_printer_alq_intr' />
                <where>
                file_id = ? and 
                alq_intr_status = 0 

                </where>
            </select>
        `,pIntFileId).toOne();

        Ax.db.insert('act_printer_alq',{
            file_id        :    mObjActPrinterAlqIntr.file_id,
            alq_id_factura :    mObjActPrinterAlqIntr.alq_intr_id_factura,
            alq_id_printer :    mObjActPrinterAlqIntr.alq_intr_id_printer,
            alq_emp_cif    :    mObjActPrinterAlqIntr.alq_intr_emp_cif,
            alq_cen_cost   :    mObjActPrinterAlqIntr.alq_intr_cen_cost,
            alq_seccion    :    mObjActPrinterAlqIntr.alq_intr_seccion,
            alq_price      :    mObjActPrinterAlqIntr.alq_intr_price,
            alq_month      :    mObjActPrinterAlqIntr.alq_intr_month,
            alq_year       :    mObjActPrinterAlqIntr.alq_intr_year,
            alq_fecha_fact :    mObjActPrinterAlqIntr.alq_intr_fecha_fact
        });

        Ax.db.update('act_printer_alq_intr',{
            alq_intr_status: 3
        },{
            alq_intr_id: mObjActPrinterAlqIntr.alq_intr_id
        });

        let mIntAlqIntrId = Ax.executeGet(`
            <select first = '1'>
                <columns>alq_intr_id</columns>
                <from table='act_printer_alq_intr' />
                <where>
                    file_id = ? and 
                    alq_intr_status = 0 
                </where>
            </select>
        `,pIntFileId);

        if(!(mIntAlqIntrId)){
            mIntDadesLloguer = 0;
        }

        mIntContador = mIntContador + 1;

        if(mIntContador == 500){
            mIntContador = 0;
        }
    }

    Ax.db.commitWork();

    Ax.db.update('act_printer_load',{
        file_estat: 3
    },{
        file_id: pIntFileId
    });
}