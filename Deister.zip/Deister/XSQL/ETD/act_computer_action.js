function act_computer_action (pIntComId, pStrAction, pStrArea, 
    pStrUser, pStrBuilding, pStrFloor, pStrLocation, pStrRack, pStrRosette,
    pStrPlatform, pStrIp){

    let mObjParametros = {
        pIntComId           : pIntComId,
        pStrAction          : pStrAction,
        pStrArea            : pStrArea,
        pStrUser            : pStrUser,
        pStrBuilding        : pStrBuilding,
        pStrFloor           : pStrFloor,
        pStrLocation        : pStrLocation,
        pStrRack            : pStrRack,
        pStrRosette         : pStrRosette,
        pStrPlatform        : pStrPlatform,
        pStrIp              : pStrIp
    };

    for (let mPropParam in mObjParametros){
        
        if(typeof mObjParametros[mPropParam] !== "string"){

            continue;
        }

        if(mObjParametros[mPropParam] === '[NULL]'){

            eval(`${mPropParam} = null`)
        }         
    }

    let mStrIp = pStrIp;
    let mStrStatus;

    switch (pStrAction){
        /* ==================================================================== -->
        <!-- 1) Desplegament.                                                   -->
        <!-- ==================================================================== */
        
        case 'DP':
            mStrStatus = 'P';
            
            if(pStrRack !== null && pStrIp == null){

                mStrIp = Ax.db.call("act_computer_get_new_ip", pIntComId, pStrRack);
            }
            break;
        /* ==================================================================== -->
        <!-- 2) Trasllat.                                                       -->
        <!-- ==================================================================== */

        case 'TR':
            mStrStatus = 'P';
            
            if(pStrRack !== null && pStrIp == null){

                mStrIp = Ax.db.call("act_computer_get_new_ip", pIntComId, pStrRack);
            }
            break;
        /* ==================================================================== -->
        <!-- 3) Recuperació per l'Estoc.                                        -->
        <!-- ==================================================================== */

        case 'RE':
            mStrStatus = 'E';
            break;
        /* ==================================================================== -->
        <!-- 4) Retirada per Avaria.                                            -->
        <!-- ==================================================================== */

        case 'RA':
            mStrStatus = 'A';
            break;
        /* ==================================================================== -->
        <!-- 5) Reparació.                                                      -->
        <!-- ==================================================================== */
        
        case 'RP':
            mStrStatus = 'P';
            break;
        /* ==================================================================== -->
        <!-- 6) Retirada per Reciclatge.                                        -->
        <!-- ==================================================================== */

        case 'RR':
            mStrStatus = 'R';
            break;
        /* ==================================================================== -->
        <!-- 7) Baixa.                                                          -->
        <!-- ==================================================================== */
        
        case 'BR':
            mStrStatus = 'B';
            break;
        /* ==================================================================== -->
        <!-- 8) Agafar de l'Estoc.                                              -->
        <!-- ==================================================================== */

        case 'AE':
            mStrStatus = 'I';
            break;
        /* ==================================================================== -->
        <!-- 9) Gestió de Garantia.                                             -->
        <!-- ==================================================================== */
            
        case 'GG':
            mStrStatus = 'G';
            break;
        /* ==================================================================== -->
        <!-- 10) Enviar a proveïdor.                                            -->
        <!-- ==================================================================== */

        case 'EP':
            mStrStatus = 'V';
            break;
        /* ==================================================================== -->
        <!-- 11) Recepcionar de proveïdor.                                      -->
        <!-- ==================================================================== */

        case 'PV':
            mStrStatus = 'E';
            break;
        
        default:
            throw new Ax.lang.Exception(`Acció [${pStrAction}] no contemplada. Contacti amb l'equip d'Aplicacions Corporatives.`)
    }

    Ax.db.update('act_computer',{

        com_status      : mStrStatus,
        com_area        : pStrArea,
        com_user        : pStrUser,
        com_building    : pStrBuilding,
        com_floor       : pStrFloor,
        com_location    : pStrLocation,
        com_rack        : pStrRack,
        com_rosette     : pStrRosette,
        com_platform    : pStrPlatform,
        com_ip          : mStrIp,
        user_updated    : Ax.ext.user.getUser(),
        date_updated    : new Ax.util.Date()
    },{
        com_id: pIntComId
    });

    let mIntMaxHisId = Ax.db.executeGet(`
        <select>
            <columns>MAX(his_id) max_his_id</columns>
            <from table='act_computer_his' />
            <where>
                com_id = ?
            </where>
        </select>
    `,pIntComId);
    
    Ax.db.update('act_computer_his',{
        his_event: pStrAction
    },{
        his_id: mIntMaxHisId
    });
}