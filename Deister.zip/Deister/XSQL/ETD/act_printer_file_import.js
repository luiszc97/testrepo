function act_printer_file_import () {

    Ax.db.beginWork();

    let mStrPathname = '/erpsync/act/printer/';
    let mStrPathback = '/erpsync/act/printer/bak/';
    
    let mDirectory = new Ax.io.file(`${mStrPathname}`);

    let mArrFilelist = mDirectory.listFiles(f => {
        return /.*\.csv/.test(f.getName());
    })

    if (mArrFilelist.length == 0) {

        throw new Ax.lang.Exception('Fitxer erroni');
    }

    for (let mFile of mArrFilelist) {

        try {
            /* ================================================================ -->
            <!-- Lectura del fitxer.                                              -->
            <!-- ================================================================ */
            let mFileContent = new Ax.io.file(`${mStrPathname}${mFile.getName()}`);
            let mStrContent = mFileContent.readString();
        
            let mStrFirstline = 0;

            let mArrLine = mStrContent.split(/\r\n|\n/);

            for (let mStrLine of mArrLine) {

                let mObjActPrinterData = {};

                if (mStrFirstline == 0) {

                    mStrFirstline = 1;
                } else {

                    mStrLine = ` ${mStrLine} `;  //Espaciado antes y después
                    let mStrWord = mStrLine.split(';');
                    let mArrsize = mStrWord.length;

                    /* ================================================================ -->
                    <!-- Per evitar registres en blanc al final del document, el count          -->
                    <!-- del array ha de ser 14                                                                                      -->
                    <!-- ================================================================ */
                    
                    if (mArrsize == 14){
                        
                        for (let mIntIdx = 0; mIntIdx < mArrsize.length; mIntIdx++) {

                            let mStrElem = mStrWord[mIntIdx].trim();

                            switch (m_idx) {
                                case 0:
                                    mObjActPrinterData.data_rao = mStrElem;
                                    break;
                                case 1:
                                    mObjActPrinterData.data_edifici = mStrElem;
                                    break;
                                case 2:
                                    mObjActPrinterData.data_adreca = mStrElem;
                                    break;
                                case 3:
                                    mObjActPrinterData.data_cp = Number(mStrElem);
                                    break;
                                case 4:
                                    mObjActPrinterData.data_poblacio = mStrElem;
                                    break;
                                case 5:
                                    mObjActPrinterData.data_prov = mStrElem;
                                    break;
                                case 6:
                                    mObjActPrinterData.data_pl = Number(mStrElem);
                                    break;
                                case 7:
                                    mObjActPrinterData.data_desc_ubi = mStrElem;
                                    break;
                                case 8:
                                    mObjActPrinterData.data_ricoh = mStrElem;
                                    break;
                                case 9:
                                    mObjActPrinterData.data_serial = mStrElem;
                                    break;
                                case 10:
                                    mObjActPrinterData.data_id_etd = Number(mStrElem);
                                    break;
                                case 11:
                                    mObjActPrinterData.data_id_etiqueta = mStrElem;
                                    break;
                                case 12:
                                    mObjActPrinterData.data_data_alta = mStrElem;
                                    break;
                                case 13:
                                    mObjActPrinterData.data_data_baixa = mStrElem;
                                    break;
                            }                            
                        }
                        /* Control d'errors abans de fer l'insert per determinar estat */

                        mObjActPrinterData.data_estat = 0;
                        mObjActPrinterData.data_error_msg = '';

                        /* ID_ETD existeix a act_printer */

                        let mIntActPrinter = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    COUNT(*)
                                </columns>
                                <from table="act_printer" />
                                <where>
                                    prt_id = ?
                                </where>
                            </select>
                        `,mObjActPrinterData.data_id_etd);
                        
                        if (mObjActPrinterData.data_estat == 0 && mIntActPrinter == 0) {

                            mObjActPrinterData.data_estat = 5;
                            mObjActPrinterData.data_error_msg = 'ID_ETD Inexistent';
                        }

                        /* DATA_ID_ETIQUETA NOT NULL */

                        let mNull = mObjActPrinterData.data_id_etiqueta == '' ? null : mObjActPrinterData.data_id_etiqueta; 

                        if (mObjActPrinterData.data_estat == 0 && mNull == null ) {

                            mObjActPrinterData.data_estat = 5;
                            mObjActPrinterData.data_error_msg = 'N. Serie no informat';
                        }

                        /* DATA_ALTA NOT NULL */
                        
                        if (mObjActPrinterData.data_estat == 0 && mObjActPrinterData.data_data_alta == null){

                            mObjActPrinterData.data_estat = 5;
                            mObjActPrinterData.data_error_msg = 'Data Alta no informat';
                        }
                     
                        /* DATA_ALTA No superior a avui */

                        if (mObjActPrinterData.data_estat == 0 && 
                            mObjActPrinterData.data_data_alta.format('dd/MM/yyyy') > new Ax.util.Date('dd/MM/yyyy')){

                            mObjActPrinterData.data_estat = 5;
                            mObjActPrinterData.data_error_msg = 'Data Alta superior a avui';
                        }

                        /* RICOH NOT NULL */

                        let mNull2 = mObjActPrinterData.data_ricoh == '' ? null : mObjActPrinterData.data_ricoh; 
                        
                        if (mObjActPrinterData.data_estat == 0 && mNull2 == null) {

                            mObjActPrinterData.data_estat = 5;
                            mObjActPrinterData.data_error_msg = 'Model no informat';
                        }
                        
                        /* SERIAL NOT NULL */

                        let mNull3 = mObjActPrinterData.data_serial == '' ? null : mObjActPrinterData.data_serial; 
                        
                        if (mObjActPrinterData.data_estat == 0 && mNull3 == null) {

                            mObjActPrinterData.data_estat = 5;
                            mObjActPrinterData.data_error_msg = 'N. Serie no informat';
                        }
                        
                        /* SERIAL DUPLICADO en act_printer */

                        mIntActPrinter = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    COUNT(*)
                                </columns>
                                <from table="act_printer" />
                                <where>
                                    prt_serial = ? and
                                    prt_id != ?
                                </where>
                            </select>
                        `, mObjActPrinterData.data_serial,mObjActPrinterData.data_id_etd)

                        if (mObjActPrinterData.data_estat == 0 && mIntActPrinter > 0) {

                            mObjActPrinterData.data_estat = 5;
                            mObjActPrinterData.data_error_msg = 'N. Serie duplicat';
                        }

                        Ax.db.insert ('act_printer_data', mObjActPrinterData)

                    } else {

                        throw new Ax.lang.Exception(`Nombre de columnes erroni [${mArrsize.length}]`);
                    }
                }
            }

            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
        } catch (error) { 

            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
            throw new Ax.lang.Exception(`${Ax.util.Error.getMessage(error)}`);
        }
    }
    Ax.db.commitWork();
}