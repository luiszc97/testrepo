function act_printer_file_proces_inc (pIntFileId){
    
    let mIntDadesIncid = 1;

    while (mIntDadesIncid == 1){
        
        let mObjActPrinterIncHis = Ax.db.executeQuery(`
            <select first = '1'>
                <columns>inc_his_id, file_id, inc_codi_intern, inc_id_incidencia, inc_n_serie, inc_data_incidencia, inc_hora_incidencia, inc_desc_averia, inc_data_reparacio, inc_hora_inici_reparacio, inc_hora_fi_reparacio, inc_dades_usuari, inc_dades_tecnic, inc_estado</columns>
                <from table='act_printer_inc_his' />
                <where>
                file_id = ? and 
                inc_status = 0
                </where>
            </select>
        `,pIntFileId).toOne();
        
        Ax.db.insert('act_printer_inc'),{
            file_id                 :  mObjActPrinterIncHis.file_id,
            codi_intern             :  mObjActPrinterIncHis.inc_codi_intern,
            id_incidencia           :  mObjActPrinterIncHis.inc_id_incidencia,
            n_serie                 :  mObjActPrinterIncHis.inc_n_serie,
            data_incidencia         :  mObjActPrinterIncHis.inc_data_incidencia,
            hora_incidencia         :  mObjActPrinterIncHis.inc_hora_incidencia,
            desc_averia             :  mObjActPrinterIncHis.inc_desc_averia,
            data_reparacio          :  mObjActPrinterIncHis.inc_data_reparacio,
            hora_inici_reparacio    :  mObjActPrinterIncHis.inc_hora_inici_reparacio,
            hora_fi_reparacio       :  mObjActPrinterIncHis.inc_hora_fi_reparacio,
            dades_usuari            :  mObjActPrinterIncHis.inc_dades_usuari,
            dades_tecnic            :  mObjActPrinterIncHis.inc_dades_tecnic,
            estado                  :  mObjActPrinterIncHis.inc_estado
        };

        Ax.db.update('act_printer_inc_his',{
            inc_status: 3
        },{
            inc_his_id: mObjActPrinterIncHis.inc_his_id
        });

        let mIntIncHisId = Ax.executeGet(`
            <select first = '1'>
                <columns>inc_his_id</columns>
                <from table='act_printer_inc_his' />
                <where>
                    file_id = ? and 
                    inc_status = 0 
                </where>
            </select>
        `,pIntFileId);

        if(!(mIntIncHisId)){
            mIntDadesIncid = 0;
        }
    }

    Ax.db.update('act_printer_load',{
        file_estat: 3
    },{
        file_id: pIntFileId
    });
}