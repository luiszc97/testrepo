function sit_terfijo_change (pIntTerId,pDateFecha){

    let mObjSitTerfijo = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='sit_terfijo' />
            <where>
                terid  = ?
            </where>
        </select>
    `, pIntTerId).toOne();

    let mDateFecini= new Ax.util.Date(mObjSitTerfijo.fecini);
    let mDateFecha = new Ax.util.Date(pDateFecha);

    if(mDateFecini.after(mDateFecha)) {
        throw new Ax.lang.Exception(`Nova data d'inici anterior o igual a la del registre actual`);
    }

    Ax.db.update('sit_terfijo', {
        fecfin: mDateFecha.addDay(-1),
        estado: 'B',
        user_updated: Ax.ext.user.getCode(),
        date_updated: new Ax.util.Date()
    },{
        terid:pIntTerId 
    });

    mObjSitTerfijo.numhis = Ax.db.executeGet(`
        <select prefix='sit_terfijo_'>
            <columns>NVL(MAX(numhis),0)+1 numhis</columns>
            <from table='sit_terfijo' />
            <where>
                extid = ?
            </where>
        </select>`
    ,mObjSitTerfijo.extid);

    mObjSitTerfijo.terid = 0,
    mObjSitTerfijo.terid = mDateFecha,
    mObjSitTerfijo.terid = null,
    mObjSitTerfijo.terid = 'A'
    mObjSitTerfijo.terid = Ax.ext.user.getCode();
    mObjSitTerfijo.terid = new Ax.util.Date();
    mObjSitTerfijo.terid = Ax.ext.user.getCode();
    mObjSitTerfijo.terid = new Ax.util.Date();

    let mIntFinalTerfijoId = Ax.db.insert('sit_terfijo', mObjSitTerfijo).getserial()

    return mIntFinalTerfijoId;
}