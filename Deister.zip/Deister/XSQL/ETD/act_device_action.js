function act_device_action (pIntDevId, pStrAction, pStrBuilding, 
    pStrFloor, pStrLocation, pStrRack, 
    pStrRosette, pStrIp){

    let mObjParametros = {
        pIntDevId           : pIntDevId,
        pStrAction          : pStrAction,
        pStrBuilding        : pStrBuilding,
        pStrFloor           : pStrFloor,
        pStrLocation        : pStrLocation,
        pStrRack            : pStrRack,
        pStrRosette         : pStrRosette,
        pStrIp              : pStrIp
    };

    for (let mPropParam in mObjParametros){
        
        if(typeof mObjParametros[mPropParam] !== "string"){

            continue;
        }

        if(mObjParametros[mPropParam] === '[NULL]'){

            eval(`${mPropParam} = null`)
        }         
    }

    let mStrStatus;

    switch (pStrAction){
        /* ==================================================================== -->
        <!-- 1) Desplegament.                                                   -->
        <!-- ==================================================================== */
        
        case 'DP':
            mStrStatus = 'P';
            break;
        /* ==================================================================== -->
        <!-- 2) Trasllat.                                                       -->
        <!-- ==================================================================== */

        case 'TR':
            mStrStatus = 'P';
            break;
        /* ==================================================================== -->
        <!-- 3) Recuperació per l'Estoc.                                        -->
        <!-- ==================================================================== */

        case 'RE':
            mStrStatus = 'E';
            break;
        /* ==================================================================== -->
        <!-- 4) Retirada per Avaria.                                            -->
        <!-- ==================================================================== */

        case 'RA':
            mStrStatus = 'A';
            break;
        /* ==================================================================== -->
        <!-- 5) Reparació.                                                      -->
        <!-- ==================================================================== */
        
        case 'RP':
            mStrStatus = 'P';
            break;
        /* ==================================================================== -->
        <!-- 6) Retirada per Reciclatge.                                        -->
        <!-- ==================================================================== */

        case 'RR':
            mStrStatus = 'R';
            break;
        /* ==================================================================== -->
        <!-- 7) Baixa.                                                          -->
        <!-- ==================================================================== */
        
        case 'BR':
            mStrStatus = 'B';
            break;
        /* ==================================================================== -->
        <!-- 8) Agafar de l'Estoc.                                              -->
        <!-- ==================================================================== */

        case 'AE':
            mStrStatus = 'I';
            break;

        default:
            throw new Ax.lang.Exception(`Acció [${pStrAction}] no contemplada. Contacti amb l'equip d'Aplicacions Corporatives.`)
    }

    Ax.db.update('act_device',{

        dev_status      : mStrStatus,
        dev_building    : pStrBuilding,
        dev_floor       : pStrFloor,
        dev_location    : pStrLocation,
        dev_rack        : pStrRack,
        dev_rosette     : pStrRosette,
        dev_ip          : pStrIp,
        user_updated    : Ax.ext.user.getUser(),
        date_updated    : new Ax.util.Date()
    },{
        dev_id: pIntDevId
    });

    let mIntMaxHisId = Ax.db.executeGet(`
        <select>
            <columns>MAX(his_id) max_his_id</columns>
            <from table='act_device_his' />
            <where>
                dev_id = ?
            </where>
        </select>
    `,pIntDevId);
    
    Ax.db.update('act_device_his',{
        his_event: pStrAction
    },{
        his_id: mIntMaxHisId
    });
}