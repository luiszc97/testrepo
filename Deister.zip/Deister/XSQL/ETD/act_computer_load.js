function act_computer_file_load(pIntFileId) {
    try {
        Ax.db.update('act_computer_load', 
            {
                file_estat: 1
            }, 
            {
                file_id: pIntFileId
            }
        )

        var mObjComLoad = Ax.db.executeQuery(`
            <select>
                <columns>file_id, file_data, file_name</columns>
                <from table='act_computer_load' />
                <where>
                    file_id = ?
                </where>
            </select>
        `, pIntFileId).toOne();

        var mFile = `/erpsync/act/computer/${mObjComLoad.file_name}`;

        var mF = new Ax.io.File(mFile);
        mF.write(mObjComLoad.file_data);

        Ax.db.call('act_computer_file_import');

        Ax.db.update('act_computer_data', 
            {
                file_id: mObjComLoad.file_id
            }, 
            `file_id IS NULL`
        )

        Ax.db.update('act_computer_load', 
            {
                file_estat: 2,
                file_error_msg: ''
            }, 
            {
                file_id: pIntFileId
            }
        )

    } catch (error) {
        Ax.db.update('act_computer_load', 
            {
                file_estat: 5,
                file_error_msg: `No s'ha processat el fitxer degut a [${Ax.util.Error.getMessage(error)}]`
            }, 
            {
                file_id: pIntFileId
            }
        )
        
    }

}