function sit_extensi_change (pIntExtId, pDateFecha) {

    let mObjSitExtensi = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='sit_extensi' />
            <where>
                extid = ?
            </where>
        </select>
    `, pIntExtId).toOne();

    let mDateFecini = new Ax.util.Date(mObjSitExtensi.fecini);
    let mDateFecha = new Ax.util.Date(pDateFecha);

    if(mDateFecini.after(mDateFecha)) {
        throw new Ax.lang.Exception(`Nova data d'inici anterior o igual a la del registre actual`);
    }

    Ax.db.update('sit_extensi', {
        fecfin: mDateFecha.addDay(-1),
        estado: 'B',
        user_updated: Ax.ext.user.getCode(),
        date_updated: new Ax.util.Date()
    }, {
        extid: pIntExtId
    });

    mObjSitExtensi.numhis = Ax.db.executeGet(`
        <select>
            <columns>NVL(MAX(numhis),0)+1 numhis</columns>
            <from table='sit_extensi' />
            <where>
                numero = ? AND
                extcor = ?
            </where>
        </select>
    `, mObjSitExtensi.numero, mObjSitExtensi.extcor);

    let mExtid = mObjSitExtensi.extid;
    mObjSitExtensi.extid = 0;
    mObjSitExtensi.fecini = mDateFecha;
    mObjSitExtensi.fecfin = null;
    mObjSitExtensi.estado = 'A';
    mObjSitExtensi.user_created = Ax.ext.user.getCode();
    mObjSitExtensi.date_created = new Ax.util.Date();
    mObjSitExtensi.user_updated = Ax.ext.user.getCode();
    mObjSitExtensi.date_updated = new Ax.util.Date();

    mObjSitExtensi.extid = Ax.db.insert('sit_extensi', mObjSitExtensi).getSerial();

    let mIntFinalExtid = null;

    if(mObjSitExtensi.tiplin == 'M') {

        let mRsjSitTermovi = Ax.db.executeQuery(`
            <select>
                <columns>*</columns>
                <from table='sit_termovi' />
                <where>
                    extid  = ? AND
                    estado = 'A'
                </where>
            </select>
        `, mExtid).toMemory();

        for (let mRowSitTermovi of mRsjSitTermovi){

            Ax.db.update('sit_termovi', {
                fecfin: mDateFecha.addDay(-1),
                estado: 'B',
                user_updated: Ax.ext.user.getCode(),
                date_updated: new Ax.util.Date()
            }, {
                terid: mRowSitTermovi.terid
            });

            mRowSitTermovi.extid = mObjSitExtensi.extid;
            mRowSitTermovi.terid = 0;
            mRowSitTermovi.numhis = 0;
            mRowSitTermovi.fecini = mDateFecha;
            mRowSitTermovi.fecfin = null;
            mRowSitTermovi.estado = 'A';
            mRowSitTermovi.user_created = Ax.ext.user.getCode();
            mRowSitTermovi.date_created = new Ax.util.Date();
            mRowSitTermovi.user_updated = Ax.ext.user.getCode();
            mRowSitTermovi.date_updated = new Ax.util.Date();
        
            mIntFinalExtid = Ax.db.insert('sit_termovi', mRowSitTermovi).getSerial()
        }
    } 

    if (mObjSitExtensi.tiplin == 'F'){

        let mRsSitTerfijo = Ax.db.executeQuery(`
            <select>
                <columns>*</columns>
                <from table='sit_terfijo' />
                <where>
                    extid  =  ? AND
                    estado = 'A'
                </where>
            </select>
        `, mExtid).toMemory();
        
        for (mRowSitTerfijo of mRsSitTerfijo){

            Ax.update('sit_terfijo', {
                fecfin: mDateFecha.addDay(-1),
                estado: 'B',
                user_updated: Ax.ext.getCode(),
                date_updated: new Ax.util.Date()
            
            }, {
                terid: mRowSitTerfijo.terid
            });

            mRowSitTerfijo.terid = mObjSitExtensi.extid;
            mRowSitTerfijo.terid  = 0;
            mRowSitTerfijo.numhis = 0;
            mRowSitTerfijo.fecini = mDateFecha;
            mRowSitTerfijo.fecfin = null;
            mRowSitTerfijo.estado = 'A';
            mRowSitTerfijo.user_created = Ax.ext.user.getCode();
            mRowSitTerfijo.date_created = new Ax.util.Date();
            mRowSitTerfijo.user_updated = Ax.ext.user.getCode();
            mRowSitTerfijo.date_updated = new Ax.util.Date();

            mIntFinalExtid = Ax.db.insert('sit_terfijo',mRowSitTerfijo).getSerial()
        }
    }
    
    return mIntFinalExtid || mObjSitExtensi.extid;
}