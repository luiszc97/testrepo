function act_printer_fact_publish(pIntFileId, pStrFacId, pIntTest, pStrType) {

    // ========================================================================
    // Selección de datos de cabecera factura
    // ========================================================================
    let mObjActPrinter = Ax.db.executeQuery(`
        <select>
            <columns>
                fac_codfac, fac_id_factura, fac_emp_cif, fac_fecha_fact, file_name, file_data, fac_total
            </columns>
            <from table='act_printer_fact' />
            <where>
               fac_id_factura = ? 
               AND fac_file_id = ?  
               AND fac_validat = 1 
               AND fac_erp = 0
            </where>
        </select>
    `, pStrFacId, pIntFileId).toOne();

    // ========================================================================
    // Preparación del fichero
    // ========================================================================
    let mRuta = `/erpsync/etd/print/etd_printfac_${pStrFacId.padStart(10, '0')}.pdf`
    let mFilepath = new Ax.io.file(mRuta);
    mFilepath.write(mObjActPrinter.file_data); 
    //let mStrContent = mFilepath.readString();

    mObjActPrinter.import = Number(mObjActPrinter.fac_total.replace(",", "."));

    // ========================================================================
    // Selección de líneas
    // ========================================================================
    mObjActPrinter.lines = "|";

    let mRsActPrinterCon = Ax.db.executeQuery(`
        <select>
            <columns>
                con_cen_cost, con_seccion, SUM(con_price_total) as ccsec_total
            </columns>
            <from table='act_printer_con' />
            <where>
                con_id_factura = ? 
                AND file_id = ?
            </where>
            <group>1,2</group>
        </select>
    `, pStrFacId, pIntFileId);

    for (let mRowActprinterCon of mRsActPrinterCon) {

        mObjActPrinter.lines += `${mRowActprinterCon.con_cen_cost};${mRowActprinterCon.con_seccion};${mRowActprinterCon.ccsec_total}|`;
    }

    let mSoap = new Ax.net.SOAPClient("http://10.200.0.161/soap/servlet/rpcrouter", options => {
        options.setUser("jas");
        options.setPassword("123mona123");
    });  

    mStrResponse = mSoap.call("SOAPXMLServer", "executeXML", "mutua", "ws_fpr_invoice_create", 
    [
        mObjActPrinter.fac_emp_cif, pStrFacId, mObjActPrinter.fac_fecha_fact,
        mObjActPrinter.import, mObjActPrinter.lines, mRuta, 
        pIntTest, pStrType
    ]);    

    /* ======================================================================== -->
    <!-- Tractament de la resposta.                                               -->
    <!-- ======================================================================== */
    
    if (mStrResponse.getFaultCode() != null) {

        throw new Ax.lang.Exception(`ERROR DE PROCÉS: ${mObjActPrinter.response}`);
    }   

    mXmlRootresp = new Ax.xml.DocumentBuilderFactory();     
    mXmlRootresp.parse(mStrResponse);       

    let mArrRows = mXmlRootresp.getElementsByTagName('r');   
    let mIntCountArrRows = mArrRows.length;

    for (let mIntIdx = 1; mIntIdx <= mIntCountArrRows; mIntIdx++) {   

        let mArrColumns = mArrRows[mIntIdx - 1].getElementsByTagName('c');

        if ( mArrColumns[0].getChildCharacterData() != 1) { 

            throw new Ax.lang.Exception(`${mArrColumns[1].getChildCharacterData()}`);
        }
    }
    /* ======================================================================== -->
    <!-- Actualització de l'estat de la factura.                                -->
    <!-- ======================================================================== */

    Ax.db.update('act_printer_fact', 
        {
            fac_erp: 1
        },
        `
            fac_id_factura = '${pStrFacId}' AND 
            fac_file_id = ${pIntFileId}  AND 
            fac_validat = 1 AND 
            fac_erp = 0
        `
    );
}