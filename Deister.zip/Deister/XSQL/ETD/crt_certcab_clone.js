function crt_certcab_clone (pIntCabid, pDateDatsol, pDateDatven){
    /*
        Clonar capçalera.
    */

    pDateDatsol = new Ax.util.Date(pDateDatsol);
    pDateDatven = new Ax.util.Date(pDateDatven);

    let mObjCrtCertcab = Ax.db.executeQuery(`
        <select>
            <columns>*</columns>
            <from table='crt_certcab' />
            <where>
                    cabid = ?
            </where>
        </select>
    `,pIntCabid).toOne().setRequired(`Certificat ${pIntCabid} inexistent`);

    mObjCrtCertcab.cabid = 0;
    mObjCrtCertcab.numcrt = null;
    mObjCrtCertcab.datsol = pDateDatsol;
    mObjCrtCertcab.datven = pDateDatven;
    mObjCrtCertcab.estado = 'A';
    mObjCrtCertcab.user_created = Ax.ext.user.getCode();
    mObjCrtCertcab.date_created = new Ax.util.Date();
    mObjCrtCertcab.user_updated = Ax.ext.user.getCode();
    mObjCrtCertcab.date_updated = new Ax.util.Date();

    let mIntCabgen = Ax.db.insert('crt_certcab',mObjCrtCertcab).getSerial();

    /*
        Clonar detall. 
    */

    let mRsCrtCertdet = Ax.db.executeQuery(`                    
    <select>
        <columns>*</columns>
            <from table='crt_certdet' />
            <where>
                    cabid = ?
            </where>
        </select>
        `,pIntCabid);

    for (let mRowCrtCertdet of mRsCrtCertdet) {

        mRowCrtCertdet.linid = 0;
        mRowCrtCertdet.cabid = mIntCabgen;
        mRowCrtCertdet.user_created = Ax.ext.user.getCode();
        mRowCrtCertdet.date_created = new Ax.util.Date();
        mRowCrtCertdet.user_updated = Ax.ext.user.getCode();
        mRowCrtCertdet.date_updated = new Ax.util.Date();

        Ax.db.insert('crt_certdet',mRowCrtCertdet);

    }

    /*
        Clonar documents. 
    */

    let mRsCrtCertdoc = Ax.db.executeQuery(`                    
        <select>
            <columns>*</columns>
            <from table='crt_certdoc' />
            <where>
                    cabid = ?
            </where>
        </select>
        `,pIntCabid)

    for (let mRowCrtCertdoc of mRsCrtCertdoc) {

        mRowCrtCertdoc.docid = 0;
        mRowCrtCertdoc.cabid = mIntCabgen;
        mRowCrtCertdoc.user_created = Ax.ext.user.getCode();
        mRowCrtCertdoc.date_created = new Ax.util.Date();
        mRowCrtCertdoc.user_updated = Ax.ext.user.getCode();
        mRowCrtCertdoc.date_updated = new Ax.util.Date();
        Ax.db.insert('crt_certdet',mRowCrtCertdet);
    }
}       