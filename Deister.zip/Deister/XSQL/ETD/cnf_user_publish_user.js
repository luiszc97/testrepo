function cnf_user_publish_user (pStrCodsur){

    let mObjCnfUser = Ax.db.executeQuery(`
        <select>
            <columns>nombre, email, tipusr</columns>
            <from table='cnf_user' />
            <where>
                codigo = ?
            </where>
        </select>
    `,pStrCodsur).toOne().setRequired(`Usuari [#${pStrCodsur}] inexistent`);

    let mRsUserprf      = null;
    let mRsUserprftrx   = null;

    switch (mObjCnfUser.tipusr){
        
        case '0':
            mObjCnfUser.user_group   = 'etdusr';
            mObjCnfUser.user_dbgroup = pStrCodsur;
            
            mRsUserprf = Ax.db.executeQuery(`
                <select>
                    <columns>DISTINCT cnf_perfobj.objname</columns>
                    <from table='cnf_user'>
                        <join table='cnf_userprf'>
                            <on>cnf_user.codigo = cnf_userprf.codusr</on>
                            <join table='cnf_perfaut'>
                                <on>cnf_userprf.projec = cnf_perfaut.projec</on>
                                <on>cnf_userprf.codprf = cnf_perfaut.codprf</on>
                                <join table='cnf_perfobj'>
                                    <on>cnf_perfaut.projec = cnf_perfobj.projec</on>
                                    <on>cnf_perfaut.codprf = cnf_perfobj.codprf</on>
                                </join>
                            </join>
                        </join>
                    </from>
                    <where>
                        cnf_user.codigo = ?
                    </where>
                </select>
            `,pStrCodsur).toMemory();
            
            mRsUserprftrx = Ax.db.executeQuery(`
                <select>
                    <columns>
                        DISTINCT
                        cnf_perftxtab.tabname,
                        cnf_perftxtab.trx_ins,
                        cnf_perftxtab.trx_upd,
                        cnf_perftxtab.trx_del,
                        cnf_perftxtab.trx_exe
                    </columns>
                    <from table='cnf_user'>
                        <join table='cnf_userprftrx'>
                            <on>cnf_user.codigo = cnf_userprftrx.codusr</on>
                            <join table='cnf_perftrx'>
                                <on>cnf_userprftrx.projec = cnf_perftrx.projec</on>
                                <on>cnf_userprftrx.codprf = cnf_perftrx.codprf</on>
                                <join table='cnf_perftxtab'>
                                    <on>cnf_perftrx.projec = cnf_perftxtab.projec</on>
                                    <on>cnf_perftrx.codprf = cnf_perftxtab.codprf</on>
                                </join>
                            </join>
                        </join>
                    </from>
                    <where>
                        cnf_user.codigo = ?
                    </where>
                </select>
            `,pStrCodsur).toMemory();
            break;

        case '1':
            mObjCnfUser.user_group = 'etdusr';
            mObjCnfUser.user_dbgroup = 'admin_usr'
            break;

        case '2':
            return;
    }

    /* ========================================================================== -->
    <!-- S'ha desborrar i canviar les referencies a p_codusr abans de passar a real -->
    <!-- ========================================================================== */

    mObjCnfUser.codusr = pStrCodsur;

    let confdb = Ax.db.of('confdb')

    switch (mObjCnfUser.tipusr){

        case '0':
            try{
                confdb.insert('wic_role_jrep',{
                    role_code:  pStrCodsur,
                    role_mode:  0,
                    role_name:  pStrCodsur,
                    role_info:  'Created by cnf_user_publish_user'
                });
            }catch (error) {}

            confdb.delete('wic_user_role_jrep',{
                role_code: pStrCodsur
            });

            for (let mRowUserprf of mRsUserprf){
                try{
                confdb.insert('wic_user_role_jrep',{
                    role_code: pStrCodsur,
                    rep_code: mRowUserprf.objname
                });
                } catch (error){}
            }

            if (mRsUserprftrx.getRowCount() > 0){

                try{
                    confdb.insert('wic_role_jtrx',{
                        role_code:  pStrCodsur,
                        role_mode:  0,
                        role_name:  pStrCodsur,
                        role_info:  'Created by cnf_user_publish_user'
                    });
                }catch (error) {}

                confdb.delete('wic_user_role_jtrx',{
                    role_code: pStrCodsur
                });

                for (let mRowUserprftrx of mRsUserprftrx){
                    try{
                        confdb.insert('wic_user_role_jtrx',{
                            role_code       :   pStrCodsur,
                            tab_name        :   mRowUserprftrx.tabname,
                            can_insert      :   mRowUserprftrx.trx_ins,
                            can_delete      :   mRowUserprftrx.trx_del,
                            can_update      :   mRowUserprftrx.trx_upd,
                            can_execute     :   mRowUserprftrx.trx_exe,
                            can_load        :   0,
                            can_unload      :   0,
                            req_parent      :   0,
                            sql_delupd      :   null
                        });
                    } catch (error) {}
                }

                mObjCnfUser.user_dbgroup_trx = mObjCnfUser.user_dbgroup;

            } else{

                let mIntWicRoleJtrx =confdb.executeGet(`
                    <select>
                        <columns>COUNT(*)</columns>
                        <from table='wic_role_jtrx' />
                        <where>
                            role_code = '${pStrCodsur}'}
                        </where>
                    </select>
                `);

                if(mIntWicRoleJtrx > 0){

                    confdb.delete('wic_user_role_jtrx',{
                        role_code: pStrCodsur
                    });

                    confdb.delete('wic_role_jtrx',{
                        role_code: pStrCodsur
                    });
                }

                mObjCnfUser.user_dbgroup_trx = null;
            }
            break;

        case '1':

            let mIntWicRoleJrep = confdb.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='wic_role_jrep' />
                    <where>
                        role_code = ?
                    </where>
                </select>
            `,pStrCodsur);

            if(mIntWicRoleJrep > 0){
                
                confdb.delete('wic_user_role_jrep',{
                    role_code: pStrCodsur
                });

                confdb.delete('wic_role_jrep',{
                    role_code: pStrCodsur
                });
            }

            let mIntWicRoleJtrx = confdb.executeGet(`
                <select>
                    <columns>COUNT(*)</columns>
                    <from table='wic_role_jtrx' />
                    <where>
                        role_code = ?
                    </where>
                </select>
            `,pStrCodsur);

            if(mIntWicRoleJtrx > 0){

                confdb.delete('wic_user_role_jtrx',{
                    role_code: pStrCodsur
                });

                confdb.delete('wic_user_role_jtrx',{
                    role_code: pStrCodsur
                });
            }
            break;   
    }

    try{
        confdb.insert('wic_database_group',{
            group_code                  :   mObjCnfUser.user_dbgroup,
            group_maxqrows              :   100000,
            group_rs_max_cached_rows    :   20000,
            group_enable_qrylogs        :   1,
            group_enable_trxlogs        :   1,
            group_enable_xsqllogs       :   1,
            group_enable_soaplogs       :   1
        })
    } catch (error){}

    if (mObjCnfUser.tipusr == 0){
        
        try{
            confdb.insert('wic_database_server_users',{
                server_code     : 'primary',
                group_code      : pStrCodsur,
                server_user     : 'informix',
                server_password : '1cf839618f861b16785bf43770668486f521cad1'
            });

            confdb.insert('wic_database_server_users',{
                server_code     : 'telap',
                group_code      : pStrCodsur,
                server_user     : 'informix',
                server_password : '41dc7a1b6e421a1d5919be558d024e11de473a0d'
            });
        } catch (error){}

        confdb.delete('wic_database_group_objects',{
            group_code: mObjCnfUser.user_dbgroup
        });

        confdb.insert("wic_database_group_objects", {
            group_code              : mObjCnfUser.user_dbgroup,
            database_code           : "mutua_etd",
            database_auth_select    : 1,
            database_auth_insert    : 1,
            database_auth_delete    : 1,
            database_auth_update    : 1,
            database_auth_execute   : 1,
            database_auth_soap_app  : 0,
            database_auth_soap_obj  : 0,
            database_auth_soap_xml  : 0,
            database_auth_soap_sql  : 0,
            database_auth_soap_sqlc : 0,
            database_auth_soap_api  : 0,
            database_role_jrep      : mObjCnfUser.user_dbgroup,
            database_role_jsql      : null,
            database_role_jtrx      : mObjCnfUser.user_dbgroup_trx,
            database_role_jdef      : null,
            database_role_jlck      : null,
            database_role_olap      : null,
            database_role_api       : null
        });
    }

    let mIntWicUser = confdb.executeGet(`         
        <select>
            <columns>COUNT(*)</columns>
            <from table='wic_user' />
            <where>
                user_code = ?
            </where>
        </select>`
    ,mObjCnfUser.codusr);

    if(mIntWicUser > 0){

        confdb.update('wic_user',{

            user_name           : mObjCnfUser.nombre,
            user_group          : mObjCnfUser.user_group,
            user_dbgroup        : mObjCnfUser.user_dbgroup,
            user_initialurl     : 'apps/mutua_etd/jrep/home',
            user_number_pattern : '#.##0,###'
        },{
            user_code: mObjCnfUser.codusr
        });
    } else {

        confdb.insert('wic_user',{
            user_code               : mObjCnfUser.codusr,
            user_pass               : "adb27c8bed3b3e9c8621391ac5761f19",
            user_name               : mObjCnfUser.nombre,
            user_group              : mObjCnfUser.user_group,
            user_dbgroup            : mObjCnfUser.user_dbgroup,
            user_mail               : mObjCnfUser.email,
            user_lang               : "ca",
            user_timezone           : "Europe/Andorra",
            user_initialurl         : "apps/mutua_etd/jrep/home",
            user_number_pattern     : "#.##0,###",
            user_pass_force_change  : 0,
            user_passrule           : "LOW",
            user_lockflag           : 0
        });
    }

    let mArrUserRoles = ['printmgr','printmgr.excel','printmgr.pdf'];

    for ( let mStrUserRoles of mArrUserRoles){

        try{
            confdb.insert('wic_user_role',{
                user_code   :   mObjCnfUser.codusr,
                user_role   :   mStrUserRoles,
                role_auth   :   1
            });   
        } catch {
            confdb.update('wic_user_role',{      
                role_auth   :   1  
            },{
                user_code   :   mObjCnfUser.codusr,
                user_role   :   mStrUserRoles
            })
        }
    }

    try {
        confdb.insert('wic_user_props_desk', {
            user_code: mObjCnfUser.codusr,
            desk_portal_http    : 0,
            desk_portal_soap    : 0,
            desk_portal_total   : 1,
            desk_tool_nrows     : 25,
            desk_portal_bar_pos : 0
        });
    } catch {
        confdb.update('wic_user_props_desk', {
            user_code           : mObjCnfUser.codusr,
            desk_portal_http    : 0,
            desk_portal_soap    : 0,
            desk_portal_total   : 1,
            desk_tool_nrows     : 25,
            desk_portal_bar_pos : 0
        }, {
            user_code: mObjCnfUser.codusr
        });
    }

    try {
        confdb.insert('wic_user_props_apps', {
            user_code                   : mObjCnfUser.codusr,
            apps_look                   : 30,
            apps_primary_fg_colour      : "#FFFFFF",
            apps_primary_bg_colour      : "#43484C",
            apps_secondary_fg_colour    : "#000000",
            apps_secondary_bg_colour    : "#7E96A9",
            apps_appearance             : 0,
            apps_desk_appearance        : 0,
            apps_accent_colour          : "#43484C",
            apps_accent_colour_dark     : null,
            apps_highlight_colour       : "#FFF3E0",
            apps_highlight_colour_dark  : null,
            apps_density                : 2,
            apps_plen                   : 50,
            apps_boxplen                : 20,
            apps_boxsize                : 80,
            apps_onewindow              : 0,
            apps_apptree_collapsed      : 0,
            apps_browsetype             : 0,
            apps_docattach              : 0,
            apps_querytype              : 17,
            apps_checksoff              : 0,
            apps_smallbutt              : 0,
            apps_jsconsole              : 0,
            apps_tabhotkey              : 0,
            apps_hidetopten             : 0,
            apps_ace_editor_style       : "idle_fingers"
        });
        
    } catch {
        confdb.update('wic_user_props_apps', {
            apps_look                   : 30,
            apps_primary_fg_colour      : "#FFFFFF",
            apps_primary_bg_colour      : "#43484C",
            apps_secondary_fg_colour    : "#000000",
            apps_secondary_bg_colour    : "#7E96A9",
            apps_appearance             : 0,
            apps_desk_appearance        : 0,
            apps_accent_colour          : "#43484C",
            apps_accent_colour_dark     : null,
            apps_highlight_colour       : "#FFF3E0",
            apps_highlight_colour_dark  : null,
            apps_density                : 2,
            apps_plen                   : 50,
            apps_boxplen                : 20,
            apps_boxsize                : 80,
            apps_onewindow              : 0,
            apps_apptree_collapsed      : 0,
            apps_browsetype             : 0,
            apps_docattach              : 0,
            apps_querytype              : 17,
            apps_checksoff              : 0,
            apps_smallbutt              : 0,
            apps_jsconsole              : 0,
            apps_tabhotkey              : 0,
            apps_hidetopten             : 0,
            apps_ace_editor_style       : "idle_fingers"
        }, { 
            user_code: mObjCnfUser.codusr
        });
    }

    try {
        confdb.insert('wic_user_desk', {
            desk_seqno      : 0,
            user_code       : mObjCnfUser.codusr,
            desk_id         : 0,
            desk_name       : "Portal",
            desk_bgcolor    : "#3A6EA5",
            desk_portal_fitw: 0
        });
    } catch {
        confdb.update('wic_user_desk', {
            user_code       : mObjCnfUser.codusr,
            desk_id         : 0,
            desk_name       : "Portal",
            desk_bgcolor    : "#3A6EA5",
            desk_portal_fitw: 0
        }, {
            user_code: mObjCnfUser.codusr   
        });
    } 
}