function act_printer_file_import_con () {

    Ax.db.beginWork();

    let mStrPathname = '/erpsync/act/printer/';
    let mStrPathback = '/erpsync/act/printer/bak/';

    let mDirectory = new Ax.io.file(`${mStrPathname}`);

    let mArrFilelist = mDirectory.listFiles(f => {
        return /.*\.csv/.test(f.getName())
    });

    if (mArrFilelist.legnth == 0) {

        throw new Ax.lang.Exception('Fitxer erroni');
    }

    for (let mFile of mArrFilelist) {

        try {
            /* ================================================================ -->
            <!-- Lectura del fitxer.                                              -->
            <!-- ================================================================ */
            let mFileContent = new Ax.io.file(`${mStrPathname}${mFile.getName()}`);
            let mStrContent = mFileContent.readString();
        
            let mIntFirstline = 0;

            let mArrLine = mStrContent.split(/\r\n|\n/);

            for (let mStrLine of mArrLine) {

                if (mIntFirstline == 0) {

                    mIntFirstline = 1;
                } else {

                    mStrLine = ` ${mStrLine} `;  //Espaciado antes y después
                    let mStrWord = mStrLine.split(';');
                    let mArrsize = mStrWord.length;

                    /* ================================================================ -->
                    <!-- Per evitar registres en blanc al final del document, el count          -->
                    <!-- del array ha de ser 32                                                                                      -->
                    <!-- ================================================================ */
                    if (mArrsize == 32) {

                        let mObjActPrinter = {};

                        for ( let mIntIdx = 0; mIntIdx < mArrsize; mIntIdx++) {

                            let mStrOldWord = ',';
                            let mStrNewWord = '.';
                            let mStrElem = mStrWord[mIntIdx].trim().replace(mStrOldWord,mStrNewWord)

                            switch (mIntIdx) {
                                case 0:
                                    mObjActPrinter.con_his_id_factura = mStrElem;
                                    break;
                                case 1:
                                    mObjActPrinter.con_his_usuari = mStrElem;
                                    break;
                                case 2:
                                    mObjActPrinter.con_his_professional = mStrElem;
                                    break;
                                case 3:
                                    mObjActPrinter.con_his_cen_cost = mStrElem;
                                    break;
                                case 4:
                                    mObjActPrinter.con_his_emp_cif = mStrElem;
                                    break;
                                case 5:
                                    mObjActPrinter.con_his_seccion = mStrElem;
                                    break;
                                case 6:
                                    mObjActPrinter.con_his_cua = mStrElem;
                                    break;
                                case 7:
                                    mObjActPrinter.con_his_id_etd = mStrElem;
                                    break;
                                case 8:
                                    mObjActPrinter.con_his_printer_ceco = mStrElem;
                                    break;
                                case 9:
                                    mObjActPrinter.con_his_printer_cif = mStrElem;
                                    break;
                                case 10:
                                    mObjActPrinter.con_his_printer_seccio = mStrElem;
                                    break;
                                case 11:
                                    mObjActPrinter.con_his_serial = mStrElem;
                                    break;
                                case 12:
                                    mObjActPrinter.con_his_etiqueta_mt = mStrElem;
                                    break;
                                case 13:
                                    mObjActPrinter.con_his_total_copies_bn = mStrElem;
                                    break;
                                case 14:
                                    mObjActPrinter.con_his_price_copies_bn = Number((mStrElem != "") ? mStrElem : 0);
                                    break;
                                case 15:
                                    mObjActPrinter.con_his_total_cara_bn = mStrElem;
                                    break;
                                case 16:
                                    mObjActPrinter.con_his_price_cara_bn = Number((mStrElem != "") ? mStrElem : 0);
                                    break;
                                case 17:
                                    mObjActPrinter.con_his_total_doble_bn = mStrElem;
                                    break;
                                case 18:
                                    mObjActPrinter.con_his_price_doble_bn = Number((mStrElem != "") ? mStrElem : 0);
                                    break;
                                case 19:
                                    mObjActPrinter.con_his_total_copies_color = mStrElem;
                                    break;
                                case 20:
                                    mObjActPrinter.con_his_price_copies_color = Number((mStrElem != "") ? mStrElem : 0);
                                    break;
                                case 21:
                                    mObjActPrinter.con_his_total_cara_color = mStrElem;
                                    break;
                                case 22:
                                    mObjActPrinter.con_his_price_cara_color = Number((mStrElem != "") ? mStrElem : 0);
                                    break;
                                case 23:
                                    mObjActPrinter.con_his_total_doble_color = mStrElem;
                                    break;
                                case 24:
                                    mObjActPrinter.con_his_price_doble_color = Number((mStrElem != "") ? mStrElem : 0);
                                    break;
                                case 25:
                                    mObjActPrinter.con_his_total_pagines = mStrElem;
                                    break;
                                case 26:
                                    mObjActPrinter.con_his_price_total = Number((mStrElem != "") ? mStrElem : 0);
                                    break;
                                case 27:
                                    mObjActPrinter.con_his_paper_size = mStrElem;
                                    break;
                                case 28:
                                    mObjActPrinter.con_his_tipus_treball = mStrElem;
                                    break;
                                case 29:
                                    mObjActPrinter.con_his_month = mStrElem;
                                    break;
                                case 30:
                                    mObjActPrinter.con_his_year = mStrElem;
                                    break;
                                case 31:
                                    mObjActPrinter.con_his_fecha_fact = mStrElem;
                                    break;
                            }
                            /* Control d'errors abans de fer l'insert per determinar estat */

                            mObjActPrinter.con_his_status = 0;
                            mObjActPrinter.con_his_error_msg = '';

                            /* ID_ETD existeix a act_printer */

                            let mIntActPrinter = Ax.db.executeGet(`
                                <select>
                                    <columns>
                                        COUNT(*)
                                    </columns>
                                    <from table="act_printer" />
                                    <where>
                                        prt_id = ?
                                    </where>
                                </select>
                            `,mObjActPrinter.con_his_id_etd);

                            if (mObjActPrinter.con_his_status == 0 && mIntActPrinter == 0) {

                                mObjActPrinter.con_his_status = 5;
                                mObjActPrinter.con_his_error_msg = 'ID_ETD Inexistent';
                            }
                            
                            /* Data Facturacio */

                            let mStrTrimNull = mObjActPrinter.con_his_fecha_fact != '' ? mObjActPrinter.con_his_fecha_fact : null; 
                            
                            if (mStrTrimNull == null) {

                                mObjActPrinter.con_his_status = 5;
                                mObjActPrinter.con_his_error_msg = 'Data facturacio Inexistent';
                            } else {

                                mObjActPrinter.con_his_fecha_fact = mObjActPrinter.con_his_fecha_fact.format('yyyy-MM-dd');
                            }
                            
                            let mStrCeco;
                            let mStrCese;

                            /* CECO y CESE */
                            if (mObjActPrinter.con_his_cen_cost == null || mObjActPrinter.con_his_cen_cost == '' ||
                                mObjActPrinter.con_his_seccion == null || mObjActPrinter.con_his_seccion == '') {
                                throw new Ax.lang.Exception('CECO o CESE Inexistents');
                            } else {
                                mStrCeco = mObjActPrinter.con_his_cen_cost.substring(0,2);
                                mStrCese = mObjActPrinter.con_his_seccion.substring(0,2);
                            }

                            /* CECO Y CESE no pertany a la mateixa empresa */
                            if (mObjActPrinter.con_his_status == 0 && !(mStrCeco == mStrCese)) {
                                mObjActPrinter.con_his_status = 5;
                                mObjActPrinter.con_his_error_msg = 'CECO i CESE no pertanyen a la mateixa empresa';
                            }

                            /* CECO y CESE impresora */
                            if (mObjActPrinter.con_his_printer_ceco == null || mObjActPrinter.con_his_printer_ceco == '' ||
                                mObjActPrinter.con_his_printer_seccio == null || mObjActPrinter.con_his_printer_seccio == '') {
                                throw new Ax.lang.Exception('CECO o CESE Inexistents');
                            } else {
                                mStrCeco = mObjActPrinter.con_his_printer_ceco.substring(0,2);
                                mStrCese = mObjActPrinter.con_his_printer_seccio.substring(0,2);
                            }

                            /* CECO Y CESE printer no pertany a la mateixa empresa */
                            if (mObjActPrinter.con_his_status == 0 && !(mStrCeco == mStrCese)) {
                                mObjActPrinter.con_his_status = 5;
                                mObjActPrinter.con_his_error_msg = 'CECO i CESE no pertanyen a la mateixa empresa';
                            }

                            Ax.db.insert('act_printer_con_his_fecha_fact', mObjActPrinter);
                        } 
                    } else {

                        throw new Ax.lang.Exception(`Nombre de columnes erroni [${mArrsize}]`);
                    }
                }
            }

            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
        } catch (error){

            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
            throw new Ax.lang.Exception(`${Ax.util.Error.getMessage(error)}`);
        }
    }
    Ax.db.commitWork();
}