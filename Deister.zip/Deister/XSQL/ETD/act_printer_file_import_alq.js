function act_printer_file_import_alq () {

    Ax.db.beginWork();

    let mStrPathname = '/erpsync/act/printer/';
    let mStrPathback = '/erpsync/act/printer/bak/';

    let mDirectory = new Ax.io.file(`${mStrPathname}`);

    let mArrFilelist = mDirectory.listFiles(f => {
        return /.*\.csv/.test(f.getName())
    });

    if (mArrFilelist.length == 0) {

        throw new Ax.ext.Exception('Fitxer erroni');
    }

    for (let mFile of mArrFilelist) {

        try {
            /* ================================================================ -->
            <!-- Lectura del fitxer.                                              -->
            <!-- ================================================================ */
            let mFileContent = new Ax.io.file(`${mStrPathname}${mFile.getName()}`);
            let mStrContent = mFileContent.readString();
        
            let mIntFirstline = 0;

            let mArrLine = mStrContent.split(/\r\n|\n/);

            for (let mStrLine of mArrLine) {

                if (mIntFirstline == 0) {

                    mIntFirstline = 1;
                } else {

                    mStrLine = ` ${mStrLine} `;  //Espaciado antes y después
                    let mStrWord = mStrLine.split(';');
                    let mArrsize = mStrWord.length;

                    /* ================================================================ -->
                    <!-- Per evitar registres en blanc al final del document, el count          -->
                    <!-- del array ha de ser 14                                                                                      -->
                    <!-- ================================================================ */
                    if (mArrsize == 9) {

                        let mObjActPrinter = {};

                        for (let mIntIdx = 0; mIntIdx < mArrsize; mIntIdx++) {

                            let mStrOldWord = ',';
                            let mStrNewWord = '.';
                            let mStrElem = mStrWord[mIntIdx].trim().replaceAll(mStrOldWord,mStrNewWord);

                            switch (mIntIdx) {
                                case 0:  
                                mObjActPrinter.alq_intr_id_factura = Number(mStrElem);
                                break;
                            case 1:
                                mObjActPrinter.alq_intr_id_printer = Number(mStrElem);
                                break;
                            case 2:
                                mObjActPrinter.alq_intr_emp_cif = mStrElem;
                                break;
                            case 3:
                                mObjActPrinter.alq_intr_cen_cost = mStrElem;
                                break;
                            case 4:
                                mObjActPrinter.alq_intr_seccion = mStrElem;
                                break;
                            case 5: 
                                mObjActPrinter.alq_intr_price = Number((mStrElem !== "") ? mStrElem : 0);
                                break;
                            case 6:
                                mObjActPrinter.alq_intr_month = Number(mStrElem);
                                break;
                            case 7:
                                mObjActPrinter.alq_intr_year = Number(mStrElem);
                                break;
                            case 8:
                                mObjActPrinter.alq_intr_fecha_fact = new Ax.util.Date(mStrElem);
                                break;
                            }
                        }
                        /* Control d'errors abans de fer l'insert per determinar estat */

                        mObjActPrinter.alq_intr_status = 0;
                        mObjActPrinter.alq_intr_error_msg = '';

                        /* ID_ETD existeix a act_printer */

                        let mIntActPrinter = Ax.db.executeGet(`
                            <select>
                                <columns>
                                    COUNT(*)
                                </columns>
                                <from table="act_printer" />
                                <where>
                                    prt_id = ?
                                </where>
                            </select>
                        `,mObjActPrinter.alq_intr_id_printer);

                        if (mObjActPrinter.alq_intr_status == 0 && mIntActPrinter == 0) {

                            mObjActPrinter.alq_intr_status = 5;
                            mObjActPrinter.alq_intr_error_msg = 'ID_ETD Inexistent';
                        }

                        Ax.db.insert('act_printer_alq_intr', mObjActPrinter);
                    } else {

                        throw new Ax.ext.Exception(`Nombre de columnes erroni [${mArrsize}]`);
                    }
                }
            }

            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
        } catch (error){
            let mNewFile = new Ax.io.File(`${mStrPathback}${mFile.getName()}`);
            mNewFile.write(mStrContent);

            mFileContent.delete();
            throw new Ax.ext.Exception(`${Ax.util.Error.getMessage(error)}`);
        }
    }
    Ax.db.commitWork();
}